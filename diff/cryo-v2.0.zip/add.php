<?php
function read_env($path) {
    if (!file_exists($path)) return array();
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $env = array();
    foreach ($lines as $line) {
        $line = trim($line);
        // Skip komentar dan baris kosong
        if ($line === '' || $line[0] === '#') continue;
        // Pecah berdasarkan pertama kali tanda '=' muncul
        $equalPos = strpos($line, '=');
        if ($equalPos === false) continue;
        $key = trim(substr($line, 0, $equalPos));
        $value = trim(substr($line, $equalPos + 1));
        // Hilangkan quote jika ada
        if ((substr($value, 0, 1) === '"' && substr($value, -1) === '"') ||
            (substr($value, 0, 1) === "'" && substr($value, -1) === "'")) {
            $value = substr($value, 1, -1);
        }
        $env[$key] = $value;
    }
    return $env;
}
?>