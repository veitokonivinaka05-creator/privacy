<?php
// ======================================================
// Utils
// ======================================================

if (!function_exists('hash_equals')) {
    function hash_equals($a, $b) {
        if (!is_string($a) || !is_string($b)) return false;
        if (strlen($a) !== strlen($b)) return false;

        $diff = 0;
        for ($i = 0; $i < strlen($a); $i++) {
            $diff |= (ord($a[$i]) ^ ord($b[$i]));
        }
        return $diff === 0;
    }
}

/**
 * Base32 decode versi lebih "clean"
 */
function base32_decode_custom($input) {
    $map = array_flip(str_split('ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'));
    $input = strtoupper(preg_replace('/[^A-Z2-7]/', '', $input));

    $buffer = 0;
    $bitsLeft = 0;
    $output = '';

    foreach (str_split($input) as $char) {
        if (!isset($map[$char])) continue;

        $buffer = ($buffer << 5) | $map[$char];
        $bitsLeft += 5;

        if ($bitsLeft >= 8) {
            $bitsLeft -= 8;
            $output .= chr(($buffer >> $bitsLeft) & 0xFF);
        }
    }

    return $output;
}

/**
 * HOTP
 */
function hotp($key, $counter, $digits = 6) {
    $binCounter = pack('N2', 0, $counter);
    $hash = hash_hmac('sha1', $binCounter, $key, true);

    $offset = ord(substr($hash, -1)) & 0x0F;

    $value =
        ((ord($hash[$offset])     & 0x7F) << 24) |
        ((ord($hash[$offset + 1]) & 0xFF) << 16) |
        ((ord($hash[$offset + 2]) & 0xFF) << 8)  |
        (ord($hash[$offset + 3])  & 0xFF);

    $mod = 10 ** (int)$digits;
    return str_pad((string)($value % $mod), $digits, '0', STR_PAD_LEFT);
}

// ======================================================
// TOTP CORE
// ======================================================

function totp_current($secret_b32, $period = 30, $digits = 6, $t0 = 0) {
    $timeSlice = (int) floor((time() - $t0) / $period);
    return hotp(base32_decode_custom($secret_b32), $timeSlice, $digits);
}

function totp_verify($secret_b32, $userCode, $window = 1, $period = 30, $digits = 6, $t0 = 0) {
    $userCode = trim($userCode);
    if (!preg_match('/^\d{6}$/', $userCode)) return false;

    $key = base32_decode_custom($secret_b32);
    $timeSlice = (int) floor((time() - $t0) / $period);

    for ($i = -$window; $i <= $window; $i++) {
        if (hash_equals(hotp($key, $timeSlice + $i, $digits), $userCode)) {
            return true;
        }
    }
    return false;
}

// ======================================================
// TIME-SPECIFIC
// ======================================================

function totp_current_at($secret_b32, $ts, $period = 30, $digits = 6, $t0 = 0) {
    $slice = (int) floor(($ts - $t0) / $period);
    return hotp(base32_decode_custom($secret_b32), $slice, $digits);
}

function totp_verify_at($secret_b32, $userCode, $ts, $window = 0, $period = 30, $digits = 6, $t0 = 0) {
    $userCode = trim($userCode);
    if (!preg_match('/^\d{6}$/', $userCode)) return false;

    $key = base32_decode_custom($secret_b32);
    $slice = (int) floor(($ts - $t0) / $period);

    for ($i = -$window; $i <= $window; $i++) {
        if (hash_equals(hotp($key, $slice + $i, $digits), $userCode)) {
            return true;
        }
    }
    return false;
}

/**
 * Long window (3–5 menit)
 */
function totp_verify_long($secret_b32, $userCode, $pastSeconds = 180, $futureSeconds = 30, $period = 30, $digits = 6, $t0 = 0) {
    $userCode = trim($userCode);
    if (!preg_match('/^\d{6}$/', $userCode)) return false;

    $key = base32_decode_custom($secret_b32);

    $current = (int) floor((time() - $t0) / $period);
    $start   = $current - (int) floor($pastSeconds / $period);
    $end     = $current + (int) floor($futureSeconds / $period);

    for ($i = $start; $i <= $end; $i++) {
        if (hash_equals(hotp($key, $i, $digits), $userCode)) {
            return true;
        }
    }
    return false;
}