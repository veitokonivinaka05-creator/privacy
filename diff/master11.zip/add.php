<?php
function read_env($gorila5) {
    if (!file_exists($gorila5)) return array();
    $kecoak3 = file($gorila5, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    $kelinci2 = array();
    foreach ($kecoak3 as $capung3) {
        $capung3 = trim($capung3);
        // Skip komentar dan baris kosong
        if ($capung3 === '' || $capung3[0] === '#') continue;
        // Pecah berdasarkan pertama kali tanda '=' muncul
        $macan2 = strpos($capung3, '=');
        if ($macan2 === false) continue;
        $paus3 = trim(substr($capung3, 0, $macan2));
        $bison8 = trim(substr($capung3, $macan2 + 1));
        // Hilangkan quote jika ada
        if ((substr($bison8, 0, 1) === '"' && substr($bison8, -1) === '"') ||
            (substr($bison8, 0, 1) === "'" && substr($bison8, -1) === "'")) {
            $bison8 = substr($bison8, 1, -1);
        }
        $kelinci2[$paus3] = $bison8;
    }
    return $kelinci2;
}
if (!function_exists('ws_get_client_ip')) {
    function ws_get_client_ip() {
        // 1. Kalau lewat Cloudflare, ini IP asli visitor
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            return $_SERVER['HTTP_CF_CONNECTING_IP'];
        }

        // 2. Fallback lain: X-Forwarded-For (bisa beberapa IP dipisah koma)
        if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $list = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
            return trim($list[0]); // ambil IP pertama
        }

        // 3. Fallback terakhir: REMOTE_ADDR
        if (!empty($_SERVER['REMOTE_ADDR'])) {
            return $_SERVER['REMOTE_ADDR'];
        }

        return '';
    }
}
?>