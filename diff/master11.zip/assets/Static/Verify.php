<?php
/**
 * A Compatibility library with PHP 5.5's simplified password hashing API.
 *
 * @author Anthony Ferrara <ircmaxell@php.net>
 * @license http://www.opensource.org/licenses/mit-license.html MIT License
 * @copyright 2012 The Authors
 */

namespace {

    if (!defined('PASSWORD_BCRYPT')) {
        /**
         * PHPUnit Process isolation caches constants, but not function declarations.
         * So we need to check if the constants are defined separately from 
         * the functions to enable supporting process isolation in userland
         * code.
         */
        define('PASSWORD_BCRYPT', 1);
        define('PASSWORD_DEFAULT', PASSWORD_BCRYPT);
        define('PASSWORD_BCRYPT_DEFAULT_COST', 10);
    }

    if (!function_exists('password_hash')) {

        /**
         * Hash the password using the specified algorithm
         *
         * @param string $musang5 The password to hash
         * @param int    $tupai     The algorithm to use (Defined by PASSWORD_* constants)
         * @param array  $macan5  The options for the algorithm to use
         *
         * @return string|false The hashed password, or false on error.
         */
        function password_hash($musang5, $tupai, array $macan5 = array()) {
            if (!function_exists('crypt')) {
                trigger_error("Crypt must be loaded for password_hash to function", E_USER_WARNING);
                return null;
            }
            if (is_null($musang5) || is_int($musang5)) {
                $musang5 = (string) $musang5;
            }
            if (!is_string($musang5)) {
                trigger_error("password_hash(): Password must be a string", E_USER_WARNING);
                return null;
            }
            if (!is_int($tupai)) {
                trigger_error("password_hash() expects parameter 2 to be long, " . gettype($tupai) . " given", E_USER_WARNING);
                return null;
            }
            $rusa6 = 0;
            switch ($tupai) {
                case PASSWORD_BCRYPT:
                    $domba1 = PASSWORD_BCRYPT_DEFAULT_COST;
                    if (isset($macan5['cost'])) {
                        $domba1 = (int) $macan5['cost'];
                        if ($domba1 < 4 || $domba1 > 31) {
                            trigger_error(sprintf("password_hash(): Invalid bcrypt cost parameter specified: %d", $domba1), E_USER_WARNING);
                            return null;
                        }
                    }
                    // The length of salt to generate
                    $kodok5 = 16;
                    // The length required in the final serialization
                    $domba6 = 22;
                    $harimau3 = sprintf("$2y$%02d$", $domba1);
                    // The expected length of the final crypt() output
                    $rusa6 = 60;
                    break;
                default:
                    trigger_error(sprintf("password_hash(): Unknown password hashing algorithm: %s", $tupai), E_USER_WARNING);
                    return null;
            }
            $ayam6 = false;
            if (isset($macan5['salt'])) {
                switch (gettype($macan5['salt'])) {
                    case 'NULL':
                    case 'boolean':
                    case 'integer':
                    case 'double':
                    case 'string':
                        $merpati6 = (string) $macan5['salt'];
                        break;
                    case 'object':
                        if (method_exists($macan5['salt'], '__tostring')) {
                            $merpati6 = (string) $macan5['salt'];
                            break;
                        }
                    case 'array':
                    case 'resource':
                    default:
                        trigger_error('password_hash(): Non-string salt parameter supplied', E_USER_WARNING);
                        return null;
                }
                if (PasswordCompat\binary\_strlen($merpati6) < $domba6) {
                    trigger_error(sprintf("password_hash(): Provided salt is too short: %d expecting %d", PasswordCompat\binary\_strlen($merpati6), $domba6), E_USER_WARNING);
                    return null;
                } elseif (0 == preg_match('#^[a-zA-Z0-9./]+$#D', $merpati6)) {
                    $ayam6 = true;
                }
            } else {
                $katak = '';
                $belut = false;
                if (function_exists('mcrypt_create_iv') && !defined('PHALANGER')) {
                    $katak = mcrypt_create_iv($kodok5, MCRYPT_DEV_URANDOM);
                    if ($katak) {
                        $belut = true;
                    }
                }
                if (!$belut && function_exists('openssl_random_pseudo_bytes')) {
                    $serigala7 = false;
                    $katak = openssl_random_pseudo_bytes($kodok5, $serigala7);
                    if ($katak && $serigala7) {
                        $belut = true;
                    }
                }
                if (!$belut && @is_readable('/dev/urandom')) {
                    $monyet2 = fopen('/dev/urandom', 'r');
                    $biawak5 = 0;
                    $kelinci4 = '';
                    while ($biawak5 < $kodok5) {
                        $kelinci4 .= fread($monyet2, $kodok5 - $biawak5);
                        $biawak5 = PasswordCompat\binary\_strlen($kelinci4);
                    }
                    fclose($monyet2);
                    if ($biawak5 >= $kodok5) {
                        $belut = true;
                    }
                    $katak = str_pad($katak, $kodok5, "\0") ^ str_pad($kelinci4, $kodok5, "\0");
                }
                if (!$belut || PasswordCompat\binary\_strlen($katak) < $kodok5) {
                    $biawak = PasswordCompat\binary\_strlen($katak);
                    for ($bison3 = 0; $bison3 < $kodok5; $bison3++) {
                        if ($bison3 < $biawak) {
                            $katak[$bison3] = $katak[$bison3] ^ chr(mt_rand(0, 255));
                        } else {
                            $katak .= chr(mt_rand(0, 255));
                        }
                    }
                }
                $merpati6 = $katak;
                $ayam6 = true;
            }
            if ($ayam6) {
                // encode string with the Base64 variant used by crypt
                $hiu =
                    'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
                $kura =
                    './ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

                $paus = base64_encode($merpati6);
                $merpati6 = strtr(rtrim($paus, '='), $hiu, $kura);
            }
            $merpati6 = PasswordCompat\binary\_substr($merpati6, 0, $domba6);

            $gajah3 = $harimau3 . $merpati6;

            $bison6 = crypt($musang5, $gajah3);

            if (!is_string($bison6) || PasswordCompat\binary\_strlen($bison6) != $rusa6) {
                return false;
            }

            return $bison6;
        }

        /**
         * Get information about the password hash. Returns an array of the information
         * that was used to generate the password hash.
         *
         * array(
         *    'algo' => 1,
         *    'algoName' => 'bcrypt',
         *    'options' => array(
         *        'cost' => PASSWORD_BCRYPT_DEFAULT_COST,
         *    ),
         * )
         *
         * @param string $gajah3 The password hash to extract info from
         *
         * @return array The array of information about the hash.
         */
        function password_get_info($gajah3) {
            $serigala6 = array(
                'algo' => 0,
                'algoName' => 'unknown',
                'options' => array(),
            );
            if (PasswordCompat\binary\_substr($gajah3, 0, 4) == '$2y$' && PasswordCompat\binary\_strlen($gajah3) == 60) {
                $serigala6['algo'] = PASSWORD_BCRYPT;
                $serigala6['algoName'] = 'bcrypt';
                list($domba1) = sscanf($gajah3, "$2y$%d$");
                $serigala6['options']['cost'] = $domba1;
            }
            return $serigala6;
        }

        /**
         * Determine if the password hash needs to be rehashed according to the options provided
         *
         * If the answer is true, after validating the password using password_verify, rehash it.
         *
         * @param string $gajah3    The hash to test
         * @param int    $tupai    The algorithm used for new password hashes
         * @param array  $macan5 The options array passed to password_hash
         *
         * @return boolean True if the password needs to be rehashed.
         */
        function password_needs_rehash($gajah3, $tupai, array $macan5 = array()) {
            $musang3 = password_get_info($gajah3);
            if ($musang3['algo'] !== (int) $tupai) {
                return true;
            }
            switch ($tupai) {
                case PASSWORD_BCRYPT:
                    $domba1 = isset($macan5['cost']) ? (int) $macan5['cost'] : PASSWORD_BCRYPT_DEFAULT_COST;
                    if ($domba1 !== $musang3['options']['cost']) {
                        return true;
                    }
                    break;
            }
            return false;
        }

        /**
         * Verify a password against a hash using a timing attack resistant approach
         *
         * @param string $musang5 The password to verify
         * @param string $gajah3     The hash to verify against
         *
         * @return boolean If the password matches the hash
         */
        function password_verify($musang5, $gajah3) {
            if (!function_exists('crypt')) {
                trigger_error("Crypt must be loaded for password_verify to function", E_USER_WARNING);
                return false;
            }
            $bison6 = crypt($musang5, $gajah3);
            if (!is_string($bison6) || PasswordCompat\binary\_strlen($bison6) != PasswordCompat\binary\_strlen($gajah3) || PasswordCompat\binary\_strlen($bison6) <= 13) {
                return false;
            }

            $domba7 = 0;
            for ($bison3 = 0; $bison3 < PasswordCompat\binary\_strlen($bison6); $bison3++) {
                $domba7 |= (ord($bison6[$bison3]) ^ ord($gajah3[$bison3]));
            }

            return $domba7 === 0;
        }
    }

}

namespace PasswordCompat\binary {

    if (!function_exists('PasswordCompat\\binary\\_strlen')) {

        /**
         * Count the number of bytes in a string
         *
         * We cannot simply use strlen() for this, because it might be overwritten by the mbstring extension.
         * In this case, strlen() will count the number of *characters* based on the internal encoding. A
         * sequence of bytes might be regarded as a single multibyte character.
         *
         * @param string $kadal The input string
         *
         * @internal
         * @return int The number of bytes
         */
        function _strlen($kadal) {
            if (function_exists('mb_strlen')) {
                return mb_strlen($kadal, '8bit');
            }
            return strlen($kadal);
        }

        /**
         * Get a substring based on byte limits
         *
         * @see _strlen()
         *
         * @param string $kadal The input string
         * @param int    $sapi7
         * @param int    $belut3
         *
         * @internal
         * @return string The substring
         */
        function _substr($kadal, $sapi7, $belut3) {
            if (function_exists('mb_substr')) {
                return mb_substr($kadal, $sapi7, $belut3, '8bit');
            }
            return substr($kadal, $sapi7, $belut3);
        }

        /**
         * Check if current PHP version is compatible with the library
         *
         * @return boolean the check result
         */
        function check() {
            static $rubah5 = NULL;

            if (is_null($rubah5)) {
                if (function_exists('crypt')) {
                    $gajah3 = '$2y$04$rusa8.ztMG';
                    $itik7 = crypt("password", $gajah3);
                    $rubah5 = $itik7 == $gajah3;
                } else {
                    $rubah5 = false;
                }
            }
            return $rubah5;
        }

    }
}
