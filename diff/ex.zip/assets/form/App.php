<?php
    ob_start();
    session_start();
    if (empty($_SESSION['logged_in'])) {
        header("Location: /../../index.php");
        exit;
    }

    $rootDirectory = rtrim(realpath($_SERVER['DOCUMENT_ROOT']), DIRECTORY_SEPARATOR);
    // Jangan pernah izinkan ke "/" — rootPath kita paksa sama dengan public_html
    $rootPath = $rootDirectory;

    // === URL root website (otomatis)
    $webRootUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") .
        "://$_SERVER[HTTP_HOST]";

    // === SANITIZE ===
    function sanitizePath($path) {
        $path = str_replace(['../', './', '..\\', '.\\'], '', $path);
        $path = str_replace(chr(0), '', $path);
        return $path;
    }
    function getFileEmoji($filename) {
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        switch($ext) {
            case 'php': return '🛠️';
            case 'txt': return '📄';
            case 'css': return '🎨';
            case 'js': return '📜';
            case 'html': return '🌐';
            case 'json': return '🧾';
            case 'jpg': case 'jpeg': case 'png': case 'gif': return '🖼️';
            case 'zip': return '📚';
            case 'rar': return '📦';
            case 'pdf': return '📕';
            default: return '⚙️';
        }
    }

    function redirectHome() {
        global $rootDirectory;
        header("Location: ?folder=" . urlencode($rootDirectory));
        exit;
    }

    function isInsideHome($path) {
        global $rootDirectory;

        $home = rtrim(str_replace('\\','/', realpath($rootDirectory)), '/') . '/';

        $real = realpath($path);
        if ($real === false) return false;

        $real = rtrim(str_replace('\\','/', $real), '/') . '/';
        return strpos($real, $home) === 0;
    }

    /**
     * Paksa path harus berada di dalam public_html.
     * Kalau tidak valid → redirect ke Home.
     */
    function enforceInsideHome($path) {
        $path = sanitizePath($path);

        if (!isInsideHome($path)) {
            redirectHome();
        }

        // Pakai realpath final biar konsisten
        $real = realpath($path);
        if ($real === false) redirectHome();

        return $real;
    }

    // === FUNGSI DIRECT LINK ===
    function getDirectLink($fullpath) {
        global $webRootUrl;
        $real = realpath($fullpath);
        if (!$real) return '#';
        $relative = str_replace('\\', '/', str_replace($_SERVER['DOCUMENT_ROOT'], '', $real));
        // Untuk folder, tambah trailing slash jika perlu (optional)
        if (is_dir($real) && substr($relative, -1) !== '/') $relative .= '/';
        return $webRootUrl . $relative;
    }

    // === AUTOCOMPLETE ===
    if (isset($_GET['autocomplete']) && isset($_GET['q'])) {
        $q = sanitizePath($_GET['q']);
        $base = is_dir($q) ? $q : dirname($q);
        $result = [];
        if (is_dir($base)) {
            $files = @scandir($base);
            $count = 0;
            foreach ($files as $f) {
                if ($f === '.' || $f === '..') continue;
                $full = $base . '/' . $f;
                if (is_dir($full) && stripos($full, $_GET['q']) === 0) {
                    $result[] = $full;
                    $count++;
                    if ($count >= 30) break;
                }
            }
        }
        header('Content-Type: application/json');
        echo json_encode($result);
        exit;
    }

    // === ZIP UTILITY ===
    function zipFolder($folderPath, $zipFilePath) {
        $zip = new ZipArchive();
        if ($zip->open($zipFilePath, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
            $folderPath = realpath($folderPath);
            $files = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($folderPath, FilesystemIterator::SKIP_DOTS),
                RecursiveIteratorIterator::LEAVES_ONLY
            );
            foreach ($files as $file) {
                if (!$file->isDir()) {
                    $filePath = $file->getRealPath();
                    $relativePath = substr($filePath, strlen($folderPath) + 1);
                    $zip->addFile($filePath, $relativePath);
                }
            }
            $zip->close();
            return true;
        }
        return false;
    }

    // === HELPER NOTIFIKASI DOWNLOAD ERROR ===
    function downloadError($msg, $statusCode = 500) {
        // Bersihkan semua buffer dulu
        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        http_response_code($statusCode);

        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Download Error</title>
            <style>
                body {
                    font-family: Arial, sans-serif;
                    background:#111;
                    color:#fff;
                    display:flex;
                    align-items:center;
                    justify-content:center;
                    height:100vh;
                    margin:0;
                }
                .alert {
                    background:#e74c3c;
                    padding:14px 18px;
                    border-radius:6px;
                    box-shadow:0 0 12px rgba(0,0,0,0.5);
                    max-width:380px;
                    text-align:center;
                    font-size:13px;
                }
            </style>
        </head>
        <body>
            <div class="alert">
                <?= htmlspecialchars($msg) ?>
            </div>
        </body>
        </html>
        <?php
        exit;
    }

    // === DOWNLOAD FILE/FOLDER (UPGRADED) ===
    if (isset($_GET['download'])) {
        // Pakai raw dulu, sanitasi & validasi di enforceInsideHome
        $raw = $_GET['download'];

        // Paksa tetap di dalam DOCUMENT_ROOT (public_html)
        $downloadPath = enforceInsideHome($raw);

        // Bersihkan semua output buffer (karena di atas ada ob_start)
        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        // Matikan kompresi otomatis supaya Content-Length tidak kacau
        @ini_set('zlib.output_compression', 'Off');
        if (function_exists('apache_setenv')) {
            @apache_setenv('no-gzip', '1');
        }

        // === DOWNLOAD FILE BIASA ===
        if (is_file($downloadPath)) {
            $filename = basename($downloadPath);
            $size     = @filesize($downloadPath);

            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Expires: 0');
            header('Cache-Control: no-store, no-cache, must-revalidate');
            header('Pragma: public');

            if ($size !== false) {
                header('Content-Length: ' . $size);
            }

            $fp = @fopen($downloadPath, 'rb');
            if ($fp === false) {
                downloadError('Gagal membuka file untuk di-download.', 500);
            }

            while (!feof($fp)) {
                echo fread($fp, 8192);
                flush();
            }
            fclose($fp);
            exit;
        }

        // === DOWNLOAD FOLDER → DI-ZIP DULU ===
        if (is_dir($downloadPath)) {
            global $rootDirectory;

            $zipName = basename($downloadPath) . '_' . date('Ymd_His') . '.zip';
            $zipFile = $rootDirectory . '/' . $zipName;

            if (file_exists($zipFile)) {
                $zipFile = $rootDirectory . '/' . uniqid('archive_', true) . '.zip';
            }

            if (!zipFolder($downloadPath, $zipFile) || !file_exists($zipFile) || filesize($zipFile) === 0) {
                if (file_exists($zipFile)) {
                    @unlink($zipFile);
                }
                downloadError('Gagal membuat arsip ZIP. Cek ekstensi ZipArchive atau permission folder.', 500);
            }

            $size = @filesize($zipFile);

            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="' . basename($downloadPath) . '.zip"');
            header('Expires: 0');
            header('Cache-Control: no-store, no-cache, must-revalidate');
            header('Pragma: public');
            if ($size !== false) {
                header('Content-Length: ' . $size);
            }

            $fp = @fopen($zipFile, 'rb');
            if ($fp === false) {
                @unlink($zipFile);
                downloadError('Gagal membuka file ZIP.', 500);
            }

            while (!feof($fp)) {
                echo fread($fp, 8192);
                flush();
            }
            fclose($fp);
            @unlink($zipFile);
            exit;
        }

        // Kalau bukan file dan bukan folder
        downloadError('Target download tidak valid.', 400);
    }

    // === VIEW CODE (dipaksa tetap di dalam home) ===
    if (isset($_GET['view'])) {
        $viewPath = enforceInsideHome($_GET['view']);
        if (is_file($viewPath) && is_readable($viewPath)) {
            $content = @file_get_contents($viewPath);
            $fileName = basename($viewPath);
            ?>
            <!DOCTYPE html>
            <html>
            <head>
                <title>View File: <?= htmlspecialchars($fileName) ?></title>
                <style>
                    body { background: #f5f5f5; font-family: Arial; color:#222; }
                    .view-box { margin: 32px auto; max-width: 700px; background: #fff; border-radius: 8px; padding: 24px 24px 18px 24px; box-shadow: 0 2px 12px #ff0000; }
                    h2 { font-size: 18px; margin-bottom: 12px;}
                    pre { background: #272822; color: #eee; padding: 12px; border-radius: 6px; font-size:13px; overflow-x:auto;}
                    a { color: #2980b9; text-decoration: none; font-size: 14px;}
                    a:hover { text-decoration: underline; }
                </style>
            </head>
            <body>
                <div class="view-box">
                    <a href="javascript:history.back()">⬅️ Kembali</a>
                    <h2>View File: <?= htmlspecialchars($fileName) ?></h2>
                    <pre><?= htmlspecialchars($content) ?></pre>
                </div>
            </body>
            </html>
            <?php
            exit;
        } else {
            echo "<div class='alert error'>File tidak bisa dibuka atau tidak ditemukan.</div>";
            exit;
        }
    }

    // === DIR HISTORY ===
    if (!isset($_SESSION['dir_history']) || !is_array($_SESSION['dir_history'])) {
        $_SESSION['dir_history'] = [$rootDirectory];
    }
    if (isset($_GET['folder'])) {
        $current = sanitizePath($_GET['folder']);
        $last = end($_SESSION['dir_history']);
        if ($last !== $current) {
            $_SESSION['dir_history'][] = $current;
            if (count($_SESSION['dir_history']) > 20) array_shift($_SESSION['dir_history']);
        }
    }
    if (isset($_GET['back_dir'])) {
        if (count($_SESSION['dir_history']) > 1) {
            array_pop($_SESSION['dir_history']);
            $backFolder = end($_SESSION['dir_history']);
            header("Location: ?folder=" . urlencode($backFolder));
            exit;
        }
    }

    // === PERMISSION COLOR (TIDAK cek owner, biar ringan!) ===
    function getPermissionColor($fullpath) {
        if (!file_exists($fullpath)) return 'danger';
        if (!is_readable($fullpath) && !is_writable($fullpath)) {
            return 'danger';
        } elseif (!is_writable($fullpath)) {
            return 'warning';
        } else {
            return 'success';
        }
    }

    // === DELETE RECURSIVE ===
    function deleteRecursive($path) {
        if (!file_exists($path)) return true;
        @chmod($path, 0777);
        if (is_file($path) || is_link($path)) {
            return @unlink($path);
        }
        if (is_dir($path)) {
            $items = array_diff(scandir($path), ['.','..']);
            foreach ($items as $item) {
                if (!deleteRecursive($path . '/' . $item)) return false;
            }
            return @rmdir($path);
        }
        return false;
    }

    // === MAIN LOGIC ===
    $fileToEdit = null;
    $fileContent = null;
    $directory = isset($_GET['folder']) ? $_GET['folder'] : $rootDirectory;
    $directory = sanitizePath($directory);

    if (!is_dir($directory) || !isInsideHome($directory)) {
        redirectHome();
    }

    $directory = realpath($directory); // aman & rapi
    $allItems = @scandir($directory) ?: [];
    $allItems = array_diff($allItems, array('..', '.'));
    $folders = []; $files = [];
    foreach ($allItems as $item) {
        if (is_dir($directory . '/' . $item)) $folders[] = $item;
        else $files[] = $item;
    }
    sort($folders); sort($files); // urutkan
    $filesAndFolders = array_merge($folders, $files);

    $perPage = 40;
    $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
    $totalItems = count($filesAndFolders);
    $totalPages = max(1, ceil($totalItems / $perPage));
    $filesAndFolders = array_slice($filesAndFolders, ($page - 1) * $perPage, $perPage);

    // Multi delete
    if (isset($_POST['deleteSelected']) && !empty($_POST['selectedItems'])) {
        foreach ($_POST['selectedItems'] as $selected) {
            $pathToDelete = $directory . '/' . sanitizePath($selected);
            deleteRecursive($pathToDelete);
        }
        header("Location: " . $_SERVER['REQUEST_URI']); exit;
    }
    // Chmod Selected
    if (isset($_POST['chmodSelected']) && !empty($_POST['selectedItems']) && !empty($_POST['chmodSelectedValue'])) {
        $chmod = intval($_POST['chmodSelectedValue'], 8);
        foreach ($_POST['selectedItems'] as $selected) {
            $pathToChmod = $directory . '/' . sanitizePath($selected);
            @chmod($pathToChmod, $chmod);
        }
        header("Location: " . $_SERVER['REQUEST_URI']); exit;
    }
    // Create file/folder, upload
    if (isset($_POST['createFile'])) {
        $newFileName = $directory . '/' . sanitizePath($_POST['fileName']);
        if (!file_exists($newFileName)) {
            touch($newFileName);
            header("Location: " . $_SERVER['REQUEST_URI']); exit;
        } else {
            echo "<div class='alert error'>File sudah ada!</div>";
        }
    }
    if (isset($_POST['createFolder'])) {
        $newFolderName = $directory . '/' . sanitizePath($_POST['folderName']);
        if (!is_dir($newFolderName)) {
            mkdir($newFolderName, 0777, true);
            header("Location: " . $_SERVER['REQUEST_URI']); exit;
        } else {
            echo "<div class='alert error'>Folder sudah ada!</div>";
        }
    }
    if (isset($_POST['upload'])) {
        if (isset($_FILES['fileToUpload']) && isset($_FILES['fileToUpload']['name'])) {
            $totalFiles = count($_FILES['fileToUpload']['name']);
            $errors = [];
            for ($i = 0; $i < $totalFiles; $i++) {
                $fileName = $_FILES['fileToUpload']['name'][$i];
                $fileTmp = $_FILES['fileToUpload']['tmp_name'][$i];
                $fileError = $_FILES['fileToUpload']['error'][$i];
                if ($fileError != 0) {
                    $errors[] = "Gagal upload file $fileName (Error code: $fileError)";
                    continue;
                }
                $maxSize = 5 * 1024 * 1024; // 5 MB
                $allowedExtensions = ['jpg','jpeg','png','gif','txt','pdf','zip','rar','doc','docx', 'php', 'html', "xml", "htaccess"];
                $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                if (!in_array($ext, $allowedExtensions)) {
                    $errors[] = "Ekstensi file $fileName tidak diizinkan";
                    continue;
                }
                if ($_FILES['fileToUpload']['size'][$i] > $maxSize) {
                    $errors[] = "File $fileName terlalu besar (maksimal 5MB)";
                    continue;
                }
                $targetFile = $directory . '/' . basename(sanitizePath($fileName));
                if (move_uploaded_file($fileTmp, $targetFile)) {
                    // Sukses upload
                } else {
                    $errors[] = "Gagal upload file $fileName";
                }
            }
            if (empty($errors)) {
                header("Location: " . $_SERVER['REQUEST_URI']);
                exit;
            } else {
                echo "<div class='alert error'>" . implode('<br>', $errors) . "</div>";
            }
        }
    }

    if (isset($_POST['downloadFromUrl'])) {
        $url = trim($_POST['fileUrl']);
        $customName = trim($_POST['fileUrlName']);
        if (filter_var($url, FILTER_VALIDATE_URL)) {
            // Tentukan nama file
            $basename = basename(parse_url($url, PHP_URL_PATH));
            $filename = $customName !== '' ? sanitizePath($customName) : sanitizePath($basename);
            if ($filename === '') $filename = 'downloaded_file';
            $targetFile = $directory . '/' . $filename;
            // Pastikan file belum ada
            if (file_exists($targetFile)) {
                echo "<div class='alert error'>File sudah ada di folder ini!</div>";
            } else {
                // Download file dari URL
                $opts = ['http'=>['timeout'=>15]]; // 15 detik timeout
                $context = stream_context_create($opts);
                $data = @file_get_contents($url, false, $context);
                if ($data === false) {
                    echo "<div class='alert error'>Gagal mendownload file. Pastikan URL benar dan file bisa diakses!</div>";
                } else {
                    if (@file_put_contents($targetFile, $data) !== false) {
                        echo "<div class='alert success'>File berhasil diunduh ke: <b>".htmlspecialchars($filename)."</b></div>";
                        header("Refresh: 1; URL=".$_SERVER['REQUEST_URI']);
                        exit;
                    } else {
                        echo "<div class='alert error'>Gagal menyimpan file ke server!</div>";
                    }
                }
            }
        } else {
            echo "<div class='alert error'>URL tidak valid!</div>";
        }
    }

    if (isset($_POST['rename'])) {
        $oldName = $directory . '/' . sanitizePath($_POST['oldName']);
        $newName = $directory . '/' . sanitizePath($_POST['newName']);
        if (file_exists($newName)) {
            echo "<div class='alert error'>File atau folder dengan nama ini sudah ada.</div>";
        } else {
            if (@rename($oldName, $newName)) {
                header("Location: " . $_SERVER['REQUEST_URI']); exit;
            } else {
                echo "<div class='alert error'>Gagal mengubah nama.</div>";
            }
        }
    }
    if (isset($_POST['chmod'])) {
        $nameToChmod = $directory . '/' . sanitizePath($_POST['nameToChmod']);
        $perm = intval($_POST['perm'], 8);
        if (@chmod($nameToChmod, $perm)) {
            header("Location: " . $_SERVER['REQUEST_URI']); exit;
        } else {
            echo "<div class='alert error'>Gagal mengubah permission.</div>";
        }
    }
    if (isset($_POST['delete'])) {
        $nameToDelete = $directory . '/' . sanitizePath($_POST['nameToDelete']);
        if (deleteRecursive($nameToDelete)) {
            header("Location: " . $_SERVER['REQUEST_URI']); exit;
        } else {
            echo "<div class='alert error'>Gagal menghapus file/folder. Cek permission/ownership!</div>";
        }
    }
    if (isset($_POST['edit'])) {
        $fileToEdit = sanitizePath($_POST['fileNameToEdit']);
        $fileContent = @file_get_contents($directory . '/' . $fileToEdit);
    }
    if (isset($_POST['saveEdit'])) {
        $fileNameToEdit = sanitizePath($_POST['fileNameToEdit']);
        $newContent = $_POST['content'];
        $filePath = $directory . '/' . $fileNameToEdit;
        if (empty($newContent)) {
            echo "<div class='alert error'>Konten file tidak boleh kosong!</div>";
        } else if (file_exists($filePath)) {
            if (@file_put_contents($filePath, $newContent) !== false) {
                header("Location: " . $_SERVER['REQUEST_URI']); exit;
            } else {
                echo "<div class='alert error'>Gagal menyimpan perubahan.</div>";
            }
        } else {
            echo "<div class='alert error'>File tidak ditemukan.</div>";
        }
    }
    // Archive ke ZIP (manual ZIP satu item di list)
    if (isset($_POST['zip'])) {
        $item = sanitizePath($_POST['itemToZip']);
        $path = $directory . '/' . $item;
        $zipName = $item . '_' . date('Ymd_His') . '.zip';
        $zipPath = $directory . '/' . $zipName;
        if (is_dir($path)) {
            zipFolder($path, $zipPath);
        } elseif (is_file($path)) {
            $zip = new ZipArchive();
            if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
                $zip->addFile($path, basename($path));
                $zip->close();
            }
        }
        header("Location: " . $_SERVER['REQUEST_URI']); exit;
    }
    // Extract ZIP
    if (isset($_POST['extractZip'])) {
        $zipFile = $directory . '/' . sanitizePath($_POST['zipToExtract']);
        $destDir = sanitizePath($_POST['extractDest']);
        if (!is_dir($destDir)) mkdir($destDir, 0777, true);
        $zip = new ZipArchive();
        if ($zip->open($zipFile) === TRUE) {
            $zip->extractTo($destDir);
            $zip->close();
            header("Location: " . $_SERVER['REQUEST_URI']); exit;
        } else {
            echo "<div class='alert error'>Gagal extract ZIP!</div>";
        }
    }
    // Copy file/folder
    if (isset($_POST['copy'])) {
        $src = $directory . '/' . sanitizePath($_POST['itemToCopy']);
        $dst = $directory . '/' . sanitizePath($_POST['copyDestName']);
        function copy_recursive($src, $dst) {
            if (is_dir($src)) {
                mkdir($dst, 0777, true);
                $files = scandir($src);
                foreach ($files as $file) {
                    if ($file === '.' || $file === '..') continue;
                    copy_recursive("$src/$file", "$dst/$file");
                }
            } else {
                copy($src, $dst);
            }
        }
        if (file_exists($dst)) {
            echo "<div class='alert error'>Sudah ada file/folder dengan nama itu!</div>";
        } else {
            copy_recursive($src, $dst);
            header("Location: " . $_SERVER['REQUEST_URI']); exit;
        }
    }

    function getNiceSize($bytes) {
        $sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        if ($bytes == 0) return '0 B';
        $i = floor(log($bytes, 1024));
        return round($bytes / pow(1024, $i), 2).' '.$sizes[$i];
    }

    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>File Manager</title>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
            body {
                min-height: 100vh;
                background: linear-gradient(-45deg, #232536, #191930 40%, #183550 100%);
                background-size: 400% 400%;
                animation: gradientBG 14s ease infinite;
            }
            @keyframes gradientBG {
                0% { background-position: 0% 55%; }
                50% { background-position: 100% 46%; }
                100% { background-position: 0% 55%; }
            }
            body { background: transparent !important; font-family: Arial, Helvetica, sans-serif; color: #333; margin: 0; padding: 0; font-size:12px;}
            #bg-video { position: fixed; top: 0; left: 0; min-width: 100vw; min-height: 100vh; width: 100vw; height: 100vh; object-fit: cover; z-index: -2; opacity: 1; background: #222; pointer-events: none;}
            .bg-overlay { position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(20, 20, 20, 0.7); z-index: -1; pointer-events: none;}
            .file-manager { display: flex; width: 100%; margin-top: 6px;}
            .sidebar { width: 20%; padding: 7px; color: #fff;}
            .sidebar h3 { color: #ecf0f1; font-size:13px; margin:8px 0 4px 0;}
            .sidebar input, .sidebar button, .main-content input, .main-content button { font-size: 12px; padding: 5px 6px; border-radius: 3px;}
            .main-content { width: 80%; padding: 5px 5px 5px 0;}
            .file-list { margin-top: 0; width: 100%; }
            .file-item { display: flex; justify-content: space-between; align-items: center; gap: 5px; padding: 1.5px 1.5px; margin: 0.5px 0; border: 1px solid #ddd; border-radius: 2px; background-color: #fff; font-size: 12px;}
            .file-item.danger { border-left: 2px solid rgba(255, 0, 0, 0.64); background:rgba(214, 101, 101, 1);}
            .file-item.warning { border-left: 2px solid rgba(255, 204, 0, 0.7); background:rgba(214, 196, 107, 1);}
            .file-item.success { border-left: 2px solid rgba(9, 255, 0, 0.45); background:rgba(101, 207, 147, 1);}
            .file-item:hover { background-color:rgba(255, 255, 255, 0.2);}
            .file-item a, .file-item button[name="edit"] { text-decoration: none; color:rgb(0, 0, 0); background: none; border: none; cursor:pointer; font-size: 14px; font-weight: bold; padding:0;}
            .actions { min-width: 160px; display: flex; gap: 4px; justify-content: flex-end;}
            .actions form { margin: 0; }
            .actions button, .actions input[type="text"], .actions form { font-size: 11px; padding: 3px 6px; border-radius: 2.5px; min-width: 48px;}
            .actions button { border: 1px solid #ccc; border-radius: 4px; background-color: #2ecc71; color: white; cursor: pointer;}
            .actions button:hover { background-color: #27ae60;}
            .actions button.delete { background-color: #e74c3c;}
            .actions button.delete:hover { background-color: #c0392b;}
            .actions input[type="text"] { padding: 4px 5px; font-size: 11px; margin-right: 2px; border-radius: 2px; border: 1px solid #ccc; width: 25px;}
            .alert { padding: 7px; margin-bottom: 7px; border-radius: 5px; font-size: 12px;}
            .alert.success { background-color: #2ecc71; color: white;}
            .alert.error { background-color: #e74c3c; color: white;}
            textarea { width: 100%; height: 230px; border: 1px solid #ddd; border-radius: 4px; padding: 7px; font-size: 12px;}
            .logout-link { float: right; color: #e74c3c; text-decoration: none; margin-bottom: 6px; font-weight: bold; font-size:13px;}
            .logout-link:hover { text-decoration: underline; }
            .file-permission { font-size: 10px; margin-left: 7px; color: #555; letter-spacing: 1px; white-space:nowrap;}
            .logout-link { display: inline-flex; align-items: center; gap: 6px; padding: 5px 14px 5px 10px; border: 1.5px solid #e74c3c; background: #fff; border-radius: 15px; color: #e74c3c; text-decoration: none; margin-bottom: 5px;}
            .logout-link:hover { background: #ffeaea; color: #fff; background: linear-gradient(90deg, #e74c3c 0 100%);}
            .logout-link .logout-icon { font-size: 17px; display: inline-block; line-height: 1;}
            .nav-link { display: inline-block; padding: 4px 12px; border: 1px solid #3498db; border-radius: 11px; background: #ecf6fc; color: #2980b9; text-decoration: none; margin-right: 4px; font-weight: 500; font-size:12px;}
            .nav-link:hover { background: #3498db; color:#fff; }
            .nav-link.disabled, .nav-link[disabled] { cursor: not-allowed; color: #ff0000 !important; border-color: #ddd; background: #f8f8f8; pointer-events: none; }
            @media (max-width: 800px) {
                .file-manager { flex-direction:column;}
                .sidebar,.main-content { width: 100%;}
                .file-item { flex-direction: column; align-items: flex-start; }
                .file-item > .actions { width: 100%; justify-content: flex-start; }
            }
            .nama-file-folder-ellipsis {
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                display: block;
                max-width: 210px;
            }
            .file-item-row {
            display: grid;
            grid-template-columns:
                28px  /* No */
                36px  /* Checkbox */
                32px  /* Emoji/Folder Icon */
                220px /* Nama File/Folder */
                92px  /* Size */
                68px  /* Permission */
                48px  /* Direct Link */
                158px /* Date Modified */
            ;
            align-items: center;
            gap: 0 6px;
            }

            @media (max-width: 900px) {
                .file-item-row {
                    grid-template-columns: 22px 28px 24px 1fr 44px 36px 34px 84px;
                    font-size: 11px;
                }
            }
        </style>
    </head>
    <body>
    <video autoplay loop muted playsinline id="bg-video">
        <source src="https://res.cloudinary.com/dowtrfruz/video/upload/v1751743944/pinterestdownloader.com-1751743705.806863_1_yqd7dy.mp4" type="video/mp4">
    </video>
    <div class="bg-overlay"></div>

    <div class="file-manager">
        <div class="sidebar">
            <h3>Create File</h3>
            <form action="" method="post">
                <input type="text" name="fileName" placeholder="Nama File" required>
                <button type="submit" name="createFile">Create File</button>
            </form>
            <h3>Create Folder</h3>
            <form action="" method="post">
                <input type="text" name="folderName" placeholder="Nama Folder" required>
                <button type="submit" name="createFolder">Create Folder</button>
            </form>
            <h3>Upload File</h3>
            <form action="" method="post" enctype="multipart/form-data">
                <input type="file" name="fileToUpload[]" multiple required>
                <button type="submit" name="upload">Upload</button>
            </form>
            <h3>Download File dari URL Atau Wget</h3>
            <form action="" method="post">
                <input type="url" name="fileUrl" placeholder="Masukkan URL file" required style="width:98%;">
                <input type="text" name="fileUrlName" placeholder="Nama file (opsional)" style="width:98%;">
                <button type="submit" name="downloadFromUrl">Download</button>
            </form>
        </div>
        <div class="main-content">
            <a href="Log.php" class="logout-link" id="logoutBtn">
            <span class="logout-icon">🔴</span> Logout
            </a>
            <h1 style="color: #fff; font-size:16px; margin:10px 0 8px 0;">Jangan Dirusak ya!! (˶ᵔ ᵕ ᵔ˶)</h1>
            <div style="margin-bottom:8px;">
                <?php if (count($_SESSION['dir_history']) > 1): ?>
                    <a href="?back_dir=1" class="nav-link" style="margin-right:9px;">⬅️ Back</a>
                <?php else: ?>
                    <span class="nav-link disabled" style="margin-right:9px;">⬅️ Back</span>
                <?php endif; ?>
                <?php if ($directory != $rootDirectory): ?>
                    <a href="?folder=<?= urlencode($rootDirectory) ?>" class="nav-link" style="margin-right:9px;">🏠 Home</a>
                <?php else: ?>
                    <span class="nav-link disabled" style="margin-right:9px;">🏠 Home</span>
                <?php endif; ?>
                <?php if ($directory != $rootPath): ?>
                    <a href="?folder=<?= urlencode($rootPath) ?>" class="nav-link">🌐 Root</a>
                <?php else: ?>
                    <span class="nav-link disabled">🌐 Root</span>
                <?php endif; ?>
            </div>
            <div style="position:relative; margin-bottom:8px;">
                <form method="get" style="display:inline;">
                    <label for="customPath" style="color: #fff; font-size:11px; margin-right:5px;"><strong>Full Path:</strong></label>
                    <input type="text" id="customPath" name="folder" 
                        value="<?= htmlspecialchars($directory) ?>" 
                        style="width:320px; font-size:11px; padding:3px 6px; border-radius:4px; border:1px solid #ff0000;"
                        autocomplete="off" spellcheck="false"
                    >
                    <button type="submit" style="font-size:11px; padding:2px 12px; border-radius:4px; margin-left:4px;">Go</button>
                </form>
                <div id="suggestions" class="autocomplete-suggestions" style="display:none; position:absolute;"></div>
            </div>
            <form id="multiActionForm" action="" method="post">
                <div style="margin-bottom:10px;">
                    <button type="button" onclick="selectAll(true)">Select All</button>
                    <button type="button" onclick="selectAll(false)">Unselect All</button>
                    <button type="submit" name="deleteSelected" onclick="return confirm('Yakin ingin menghapus semua yang dipilih?')">Delete Selected</button>
                    <input type="text" name="chmodSelectedValue" placeholder="Chmod for selected (eg: 755)" style="width:90px;" pattern="[0-7]{3,4}" title="Contoh: 755">
                    <button type="submit" name="chmodSelected">CHMOD Selected</button>
                </div>
                <div class="file-list">
                    <!-- HEADER KOLOM -->
                <div class="file-item" style="background:#222846; font-weight:bold; color:#fff;">
                    <div style="display: flex; align-items: center; gap: 7px; flex:1;">
                        <span style="min-width:20px;">#</span>
                        <span></span>
                        <span></span>
                        <span>Nama File/Folder</span>
                    </div>
                </div>
                <?php
                $no = 0;
                foreach ($filesAndFolders as $item):
                    $no++;
                    $fullpath = $directory . '/' . $item;
                    $colorClass = getPermissionColor($fullpath);
                    $perms = @fileperms($fullpath) ? substr(sprintf('%o', fileperms($fullpath)), -4) : '----';

                    // Date modified (Asia/Jakarta)
                    $timestamp = @filemtime($fullpath);
                    $dt = new DateTime("@$timestamp");
                    $dt->setTimezone(new DateTimeZone('Asia/Jakarta'));
                    $dateModified = $timestamp ? $dt->format('M-d H:i') . ' WIB' : '📌';

                    $directLink = getDirectLink($fullpath);

                    if (is_file($fullpath)) {
                        $sizeDisplay = getNiceSize(@filesize($fullpath));
                    } elseif (is_dir($fullpath)) {
                        $sizeDisplay = '📌';
                    } else {
                        $sizeDisplay = '📌';
                    }
                ?>
                <div class="file-item <?= $colorClass ?>" title="Permission: <?= $perms ?>">
                    <div style="display: flex; align-items: center; gap: 7px; flex:1;">
                        <span style="min-width:20px;"><?= $no ?></span>
                        <input type="checkbox" class="select-item" name="selectedItems[]" value="<?= htmlspecialchars($item) ?>">
                        <?php if (is_dir($fullpath)): ?>
                            <span style="font-size: 1.15em;">🗂️</span>
                            <a href="?folder=<?= urlencode($fullpath) ?>"
                            class="nama-file-folder-ellipsis"
                            style="max-width:210px;"
                            title="<?= htmlspecialchars($item) ?>">
                                <?= htmlspecialchars($item) ?>
                            </a>
                        <?php else: ?>
                            <span style="font-size: 1.05em;"><?= getFileEmoji($item) ?></span>
                            <form action="" method="post" style="display:inline;margin:0;padding:0;vertical-align:middle;max-width:210px;" id="editForm_<?= md5($item) ?>">
                                <input type="hidden" name="fileNameToEdit" value="<?= $item ?>">
                                <button type="submit" name="edit"
                                        class="nama-file-folder-ellipsis"
                                        style="font-size: 1em; vertical-align:middle; max-width:210px; overflow:hidden;"
                                        title="<?= htmlspecialchars($item) ?>">
                                    <?= htmlspecialchars($item) ?>
                                </button>
                            </form>
                        <?php endif; ?>
                    </div>
                    <div class="actions" style="min-width:460px; display:flex; align-items:center; gap:4px; flex-wrap:wrap;">
                        <!-- INFO FILE -->
                        <span title="Ukuran" style="font-size:11px; color:#ff0000; min-width:55px; display:inline-block; text-align:right;">
                            <?= $sizeDisplay ?>
                        </span>
                        <span class="file-permission" title="Izin" style="min-width:38px; color:#ff0000;">(<?= $perms ?>)</span>
                        <!-- TOMBOL RENAME -->
                        <form action="" method="post" style="display: inline;">
                            <input type="hidden" name="oldName" value="<?= $item ?>">
                            <input type="text" name="newName" placeholder="New Name">
                            <button type="submit" name="rename">Rename</button>
                        </form>
                        <!-- TOMBOL DIRECT LINK DI SINI -->
                        <span title="Direct Link" style="font-size:14px;">
                            <a href="<?= htmlspecialchars($directLink) ?>" target="_blank" style="color:#1a73e8;">
                                <i class="fa fa-link" aria-hidden="true"></i>
                            </a>
                        </span>
                        <!-- TOMBOL VIEW SESUDAHNYA -->
                        <?php if (is_file($fullpath) && is_readable($fullpath)): ?>
                            <a href="?view=<?= urlencode($fullpath) ?>" title="View">
                                <button type="button" style="background:#dedede;color:#333;border:1px solid #aaa;padding:2px 7px;margin-left:2px;">
                                    👁️
                                </button>
                            </a>
                        <?php endif; ?>
                        <!-- LANJUTAN AKSI LAINNYA -->
                        <form action="" method="post" style="display: inline; margin-left:3px;">
                            <input type="hidden" name="nameToChmod" value="<?= $item ?>">
                            <input type="text" name="perm" placeholder="chmod" style="width:36px;" pattern="[0-7]{3,4}" title="Contoh: 755">
                            <button type="submit" name="chmod">CHMOD</button>
                        </form>
                        <?php if (!is_dir($fullpath) && @filesize($fullpath)<500000): ?>
                            <form action="" method="post" style="display: inline;">
                                <input type="hidden" name="fileNameToEdit" value="<?= $item ?>">
                                <button type="submit" name="edit">Edit</button>
                            </form>
                        <?php elseif (!is_dir($fullpath)): ?>
                            <button type="button" disabled title="File terlalu besar">Edit</button>
                        <?php endif; ?>
                        <form action="" method="post" style="display: inline;">
                            <input type="hidden" name="nameToDelete" value="<?= htmlspecialchars($item) ?>">
                            <button type="submit" name="delete" class="delete" onclick="return confirm('Yakin ingin menghapus <?= htmlspecialchars($item) ?>?')">Delete</button>
                        </form>
                        <a href="?download=<?= urlencode($fullpath) ?>" style="margin-left:2px; padding:2px 7px; border:1px solid #2980b9; border-radius:4px; background:#2980b9; color:#fff; text-decoration:none;" title="Download">⬇️</a>
                        <form action="" method="post" style="display:inline;">
                            <input type="hidden" name="itemToZip" value="<?= htmlspecialchars($item) ?>">
                            <button type="submit" name="zip" style="background:#FFB400; color:#333; border:none; padding:2px 8px; border-radius:4px; cursor:pointer;">ZIP</button>
                        </form>
                        <?php if (strtolower(pathinfo($item, PATHINFO_EXTENSION)) === 'zip'): ?>
                            <button type="button" class="extract-btn" data-zip="<?= htmlspecialchars($item) ?>" style="background:#43dbb0; color:#111; border:none; padding:2px 8px; border-radius:4px; cursor:pointer;">Extract</button>
                        <?php endif; ?>
                        <button type="button" class="copy-btn" data-src="<?= htmlspecialchars($item) ?>" data-defaultname="copy_of_<?= htmlspecialchars($item) ?>" style="background:#76c96a;color:#fff; padding:2px 7px;">Copy</button>
                        <!-- MODIFIED -->
                        <span title="Date Modified" style="font-size:11px; color:#ff0000; min-width:95px;">
                            <?= htmlspecialchars($dateModified) ?>
                        </span>
                    </div>
                </div>
                <?php endforeach; ?>
                </div>
            </form>
            <?php if (!empty($fileToEdit)): ?>
                <h2 id="editfile" style="font-size:15px;">Edit File: <?= htmlspecialchars($fileToEdit) ?></h2>
                <form action="" method="post">
                    <textarea name="content" rows="10"><?= htmlspecialchars($fileContent) ?></textarea><br>
                    <input type="hidden" name="fileNameToEdit" value="<?= htmlspecialchars($fileToEdit) ?>">
                    <button type="submit" name="saveEdit">Save Changes</button>
                </form>
            <?php endif; ?>
        </div>
    </div>

    <div id="copyModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.4); z-index:10001; justify-content:center; align-items:center;">
    <div style="background:#fff; border-radius:7px; padding:18px 14px; min-width:220px;">
        <h3 style="margin-bottom:10px; font-size:13px;">Copy File/Folder</h3>
        <form method="post" id="copyForm">
        <input type="hidden" name="itemToCopy" id="itemToCopy">
        <label for="copyDestName" style="font-size:11px;">Nama baru:</label>
        <input type="text" name="copyDestName" id="copyDestName" required style="width:98%;margin-bottom:10px;">
        <div>
            <button type="submit" name="copy" style="background:#3498db;color:#fff;">Copy</button>
            <button type="button" onclick="document.getElementById('copyModal').style.display='none';">Cancel</button>
        </div>
        </form>
    </div>
    </div>
    <div id="extractModal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.32); z-index:10004; justify-content:center; align-items:center;">
    <div style="background:#fff; border-radius:7px; padding:16px 11px; min-width:220px;">
        <form method="post">
        <input type="hidden" name="zipToExtract" id="zipToExtract" value="">
        <label for="extractDest" style="font-size:12px;">Extract ke folder:</label>
        <input type="text" name="extractDest" id="extractDest" style="width:96%;" required>
        <div style="text-align:center; margin-top:8px;">
            <button type="submit" name="extractZip" style="background:#43dbb0; color:#111;">Extract</button>
            <button type="button" onclick="document.getElementById('extractModal').style.display='none';">Cancel</button>
        </div>
        </form>
    </div>
    </div>

    <script>
    function selectAll(flag) {
        document.querySelectorAll('.select-item').forEach(function(cb) { cb.checked = flag; });
    }
    <?php if (!empty($fileToEdit)): ?>
    window.onload = function() {
        var editArea = document.getElementById('editfile');
        if(editArea) editArea.scrollIntoView({behavior:'smooth'});
    };
    <?php endif; ?>
    // Modal Extract ZIP
    document.querySelectorAll('.extract-btn').forEach(function(btn){
        btn.onclick = function(){
            document.getElementById('zipToExtract').value = btn.getAttribute('data-zip');
            document.getElementById('extractDest').value = '<?= htmlspecialchars($directory) ?>';
            document.getElementById('extractModal').style.display = 'flex';
        }
    });
    document.querySelectorAll('.copy-btn').forEach(function(btn){
        btn.onclick = function() {
            document.getElementById('itemToCopy').value = btn.getAttribute('data-src');
            document.getElementById('copyDestName').value = btn.getAttribute('data-defaultname');
            document.getElementById('copyModal').style.display = 'flex';
        };
    });
    // AUTOCOMPLETE
    const pathBox = document.getElementById('customPath');
    const form = pathBox.closest('form');
    const suggestBox = document.getElementById('suggestions');
    let lastVal = '', selectedIdx = -1, currentSuggestions = [];
    function updateSuggestPos() {
        suggestBox.style.left = (pathBox.offsetLeft) + 'px';
        suggestBox.style.top = (pathBox.offsetTop + pathBox.offsetHeight) + 'px';
        suggestBox.style.width = pathBox.offsetWidth + 'px';
    }
    pathBox.addEventListener('input', function() {
        const val = this.value;
        lastVal = val;
        selectedIdx = -1;
        currentSuggestions = [];
        if (val.length < 2) { suggestBox.style.display='none'; return; }
        fetch('?autocomplete=1&q=' + encodeURIComponent(val))
            .then(res=>res.json())
            .then(list=>{
                updateSuggestPos();
                suggestBox.innerHTML = '';
                currentSuggestions = list;
                if (list.length === 0) { suggestBox.style.display = 'none'; return; }
                list.forEach(function(folder, idx){
                    let div = document.createElement('div');
                    div.className = 'autocomplete-suggestion';
                    div.textContent = folder;
                    div.onclick = function(){
                        pathBox.value = folder;
                        suggestBox.style.display = 'none';
                        form.submit();
                    };
                    suggestBox.appendChild(div);
                });
                suggestBox.style.display = 'block';
            });
    });
    pathBox.addEventListener('keydown', function(e){
        const items = suggestBox.querySelectorAll('.autocomplete-suggestion');
        if (suggestBox.style.display !== 'block' || items.length === 0) return;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            if (selectedIdx < items.length - 1) selectedIdx++;
            items.forEach((div, i)=>div.classList.toggle('active', i===selectedIdx));
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            if (selectedIdx > 0) selectedIdx--;
            items.forEach((div, i)=>div.classList.toggle('active', i===selectedIdx));
        } else if (e.key === 'Enter') {
            if (selectedIdx >= 0 && selectedIdx < items.length) {
                e.preventDefault();
                items[selectedIdx].click();
            }
        }
    });
    document.addEventListener('click', function(e){
        if (suggestBox && !suggestBox.contains(e.target) && e.target !== pathBox) {
            suggestBox.style.display = 'none';
        }
    });
    window.addEventListener('resize', updateSuggestPos);
    window.addEventListener('scroll', updateSuggestPos);
    pathBox.addEventListener('focus', updateSuggestPos);
    </script>
    <?php if ($totalPages > 1): ?>
        <div style="margin:10px 0;">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <?php if ($i == $page): ?>
                    <span class="nav-link disabled"><?= $i ?></span>
                <?php else: ?>
                    <a class="nav-link" href="?folder=<?= urlencode($directory) ?>&page=<?= $i ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
        </div>
    <?php endif; ?>
    </body>
    </html>
    <?php ob_end_flush(); ?>