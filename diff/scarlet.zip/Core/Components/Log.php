<?php
// CRYO Logout Handler - sinkron dengan session save_path Dashboard.php
$cryoPluginRoot = realpath(__DIR__ . '/../../');
if ($cryoPluginRoot) {
    $cryoSessDir = $cryoPluginRoot . '/.cryo_sessions';
    if (is_dir($cryoSessDir) && is_writable($cryoSessDir)) {
        @ini_set('session.save_path', $cryoSessDir);
        @session_save_path($cryoSessDir);
    }
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}

$_SESSION = [];

if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    @setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

@session_unset();
@session_destroy();

// Bangun URL absolut ke default.php (sama logikanya dengan cryo_default_url di Dashboard)
$uri = '';
if (!empty($_SERVER['REQUEST_URI']))      $uri = $_SERVER['REQUEST_URI'];
elseif (!empty($_SERVER['SCRIPT_NAME']))  $uri = $_SERVER['SCRIPT_NAME'];
elseif (!empty($_SERVER['PHP_SELF']))     $uri = $_SERVER['PHP_SELF'];
$qpos = strpos($uri, '?');
if ($qpos !== false) $uri = substr($uri, 0, $qpos);
$dir = preg_replace('#/Core/Components/[^/]*$#', '', $uri);
if ($dir === null || $dir === $uri) {
    $dir = preg_replace('#/[^/]*$#', '', $uri);
}
if ($dir === null) $dir = '';
if ($dir === '' || $dir[0] !== '/') $dir = '/' . ltrim((string)$dir, '/');
$dir = rtrim($dir, '/');

header("Location: " . $dir . '/default.php?logout=1');
exit;
