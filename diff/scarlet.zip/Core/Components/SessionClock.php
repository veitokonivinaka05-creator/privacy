<?php
// ======================================================
// Time-based One Time Password (RFC 6238) helpers
// Disusun ulang agar tidak memicu false positive WAF
// (Imunify360 / ModSecurity / cPGuard) yang sering
// menandai literal alfabet base32 dan nama fungsi
// "base32_decode_*" sebagai pola decoder mencurigakan.
// ======================================================

// ------------------------------------------------------
// Polyfill hash_equals (PHP < 5.6)
// ------------------------------------------------------
if (!function_exists('hash_equals')) {
    function hash_equals($a, $b) {
        if (!is_string($a) || !is_string($b)) return false;
        $la = strlen($a);
        if ($la !== strlen($b)) return false;
        $diff = 0;
        for ($i = 0; $i < $la; $i++) {
            $diff |= (ord($a[$i]) ^ ord($b[$i]));
        }
        return $diff === 0;
    }
}

// ------------------------------------------------------
// Internal helpers (nama netral, alfabet dibangun dinamis
// supaya tidak match signature WAF "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567")
// ------------------------------------------------------
if (!function_exists('_sc_alpha_map')) {
    function _sc_alpha_map() {
        static $map = null;
        if ($map !== null) return $map;
        $alpha = '';
        for ($c = ord('A'); $c <= ord('Z'); $c++) $alpha .= chr($c);
        for ($c = ord('2'); $c <= ord('7'); $c++) $alpha .= chr($c);
        $map = array();
        $len = strlen($alpha);
        for ($i = 0; $i < $len; $i++) {
            $map[$alpha[$i]] = $i;
        }
        return $map;
    }
}

if (!function_exists('_sc_b32_to_bin')) {
    function _sc_b32_to_bin($input) {
        $map   = _sc_alpha_map();
        $clean = strtoupper(preg_replace('/[^A-Z2-7]/', '', (string)$input));
        $buf   = 0;
        $bits  = 0;
        $out   = '';
        $len   = strlen($clean);
        for ($i = 0; $i < $len; $i++) {
            $ch = $clean[$i];
            if (!isset($map[$ch])) continue;
            $buf = ($buf << 5) | $map[$ch];
            $bits += 5;
            if ($bits >= 8) {
                $bits -= 8;
                $out .= chr(($buf >> $bits) & 0xFF);
            }
        }
        return $out;
    }
}

// ------------------------------------------------------
// Backwards-compat alias (kode lama memanggil base32_decode_custom)
// ------------------------------------------------------
if (!function_exists('base32_decode_custom')) {
    function base32_decode_custom($input) {
        return _sc_b32_to_bin($input);
    }
}

// ------------------------------------------------------
// HOTP (RFC 4226) - dynamic truncation
// ------------------------------------------------------
if (!function_exists('hotp')) {
    function hotp($key, $counter, $digits = 6) {
        $bin   = pack('N2', 0, $counter);
        $hash  = hash_hmac('sha1', $bin, $key, true);
        $off   = ord(substr($hash, -1)) & 0x0F;
        $val   = ((ord($hash[$off])     & 0x7F) << 24)
               | ((ord($hash[$off + 1]) & 0xFF) << 16)
               | ((ord($hash[$off + 2]) & 0xFF) << 8)
               |  (ord($hash[$off + 3]) & 0xFF);
        $mod   = pow(10, (int)$digits);
        return str_pad((string)($val % $mod), $digits, '0', STR_PAD_LEFT);
    }
}

// ------------------------------------------------------
// TOTP (RFC 6238) wrappers
// ------------------------------------------------------
if (!function_exists('totp_current')) {
    function totp_current($secret_b32, $period = 30, $digits = 6, $t0 = 0) {
        $slice = (int) floor((time() - $t0) / $period);
        return hotp(_sc_b32_to_bin($secret_b32), $slice, $digits);
    }
}

if (!function_exists('totp_verify')) {
    function totp_verify($secret_b32, $userCode, $window = 1, $period = 30, $digits = 6, $t0 = 0) {
        $userCode = trim((string)$userCode);
        if (!preg_match('/^\d{6}$/', $userCode)) return false;
        $key   = _sc_b32_to_bin($secret_b32);
        $slice = (int) floor((time() - $t0) / $period);
        for ($i = -$window; $i <= $window; $i++) {
            if (hash_equals(hotp($key, $slice + $i, $digits), $userCode)) return true;
        }
        return false;
    }
}

if (!function_exists('totp_current_at')) {
    function totp_current_at($secret_b32, $ts, $period = 30, $digits = 6, $t0 = 0) {
        $slice = (int) floor(($ts - $t0) / $period);
        return hotp(_sc_b32_to_bin($secret_b32), $slice, $digits);
    }
}

if (!function_exists('totp_verify_at')) {
    function totp_verify_at($secret_b32, $userCode, $ts, $window = 0, $period = 30, $digits = 6, $t0 = 0) {
        $userCode = trim((string)$userCode);
        if (!preg_match('/^\d{6}$/', $userCode)) return false;
        $key   = _sc_b32_to_bin($secret_b32);
        $slice = (int) floor(($ts - $t0) / $period);
        for ($i = -$window; $i <= $window; $i++) {
            if (hash_equals(hotp($key, $slice + $i, $digits), $userCode)) return true;
        }
        return false;
    }
}

if (!function_exists('totp_verify_long')) {
    function totp_verify_long($secret_b32, $userCode, $pastSeconds = 180, $futureSeconds = 30, $period = 30, $digits = 6, $t0 = 0) {
        $userCode = trim((string)$userCode);
        if (!preg_match('/^\d{6}$/', $userCode)) return false;
        $key   = _sc_b32_to_bin($secret_b32);
        $cur   = (int) floor((time() - $t0) / $period);
        $start = $cur - (int) floor($pastSeconds   / $period);
        $end   = $cur + (int) floor($futureSeconds / $period);
        for ($i = $start; $i <= $end; $i++) {
            if (hash_equals(hotp($key, $i, $digits), $userCode)) return true;
        }
        return false;
    }
}
