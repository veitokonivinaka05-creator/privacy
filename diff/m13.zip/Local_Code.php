<?php
/**
 * code-totp.php — halaman debug TOTP (jangan dipublikasikan)
 * Menampilkan:
 *  - Kode TOTP saat ini
 *  - Detik tersisa sebelum berganti
 *  - Info jendela penerimaan server (mis. 3–5 menit)
 *  - Semua waktu ditampilkan dalam zona Asia/Jakarta (WIB)
 */
// === Pakai zona waktu Asia/Jakarta untuk DISPLAY ===
date_default_timezone_set('Asia/Jakarta');
$tzJakarta = new DateTimeZone('Asia/Jakarta');

// === Load lib & config ===
require_once __DIR__ . '/assets/Static/Totp.php'; // base32_decode_custom, hotp, totp_current, dll.
require_once __DIR__ . '/add.php';              // read_env()

$env    = read_env(__DIR__ . '/config/.env');
$SECRET = isset($env['META_TOTP']) ? $env['META_TOTP'] : '';

if (!$SECRET) {
  http_response_code(500);
  die('META_TOTP kosong. Isi dulu di config/.env');
}

// === Setup jendela penerimaan agar match dengan index.php ===
// Ubah sesuai kebijakan login-mu: 180 = 3 menit, 300 = 5 menit
$PAST_SECONDS   = 300; // terima sampai 5 menit ke belakang
$FUTURE_SECONDS = 30;  // terima sampai 1 step ke depan (30 dtk)

// === Helper opsional: totp_current_at (kalau belum ada di Tp.php) ===
if (!function_exists('totp_current_at')) {
  function totp_current_at($secret_b32, $ts, $period = 30, $digits = 6, $t0 = 0) {
    $key     = base32_decode_custom($secret_b32);
    $counter = (int) floor(($ts - $t0) / $period);
    return hotp($key, $counter, $digits);
  }
}

// === Data dasar tampilan ===
$periodSeconds = 30;
$now           = time(); // epoch (independen zona)
$currentCode   = totp_current($SECRET, $periodSeconds, 6, 0);
$remain        = $periodSeconds - ($now % $periodSeconds);

// Waktu lokal (Asia/Jakarta) untuk tampilan
$nowLocalDT  = new DateTime('@' . $now); // @epoch
$nowLocalDT->setTimezone($tzJakarta);
$serverLocal = $nowLocalDT->format('Y-m-d H:i:s');
$offsetWIB   = $nowLocalDT->format('P'); // mis. +07:00

// === (opsional) daftar kode sekitar waktu sekarang untuk inspeksi cepat ===
// Menampilkan 6 step ke belakang & 2 step ke depan (sekitar 3 menit sejarah + 1 menit depan)
$stepsBack   = 6;
$stepsAhead  = 2;
$codesAround = [];
for ($i = -$stepsBack; $i <= $stepsAhead; $i++) {
  $ts    = $now + ($i * $periodSeconds);
  $dt    = new DateTime('@' . $ts);
  $dt->setTimezone($tzJakarta);
  $label = ($i === 0) ? 'NOW' : ($i > 0 ? "+{$i} step" : "{$i} step");
  $codesAround[] = [
    'label' => $label,
    'time'  => $dt->format('H:i:s'),
    'code'  => totp_current_at($SECRET, $ts, $periodSeconds, 6, 0),
    'ctr'   => (int) floor($ts / $periodSeconds),
  ];
}

// Hitung range counter yang diterima (untuk kolom “Masih diterima?”)
$nowCtr  = (int) floor($now / $periodSeconds);
$pastCtr = $nowCtr - (int) floor($PAST_SECONDS / $periodSeconds);
$futCtr  = $nowCtr + (int) floor($FUTURE_SECONDS / $periodSeconds);

?><!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>TOTP Debug (Asia/Jakarta)</title>
  <style>
    :root { color-scheme: dark; }
    body {
      margin: 0; padding: 24px;
      background: #171717; color: #eaeaea;
      font-family: system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, Noto Sans, Arial, "Apple Color Emoji", "Segoe UI Emoji";
    }
    .wrap { max-width: 680px; margin: 0 auto; }
    h1 { font-size: 20px; margin: 0 0 16px; }
    .card {
      background: #212121; border: 1px solid #2d2d2d; border-radius: 12px;
      padding: 18px 16px; margin-bottom: 16px; box-shadow: 0 2px 12px rgba(0,0,0,.25);
    }
    .muted { color: #b5b5b5; font-size: 13px; }
    .code {
      font-size: 36px; letter-spacing: 2px;
      background: #111; padding: 8px 12px; border-radius: 10px; display: inline-block;
    }
    table { width: 100%; border-collapse: collapse; margin-top: 8px; }
    th, td { text-align: left; padding: 8px 10px; font-size: 14px; }
    th { color: #bcbcbc; font-weight: 600; border-bottom: 1px solid #2e2e2e; }
    tr + tr td { border-top: 1px dashed #2a2a2a; }
    .ok { color: #5ec45e; }
    .warn { color: #f1c40f; }
    .sep { height: 1px; background: #2b2b2b; margin: 12px 0; opacity: .7; }
    .tag {
      font-size: 12px; padding: 3px 8px; border-radius: 999px; background: #2a2a2a; display: inline-block; margin-left: 8px;
    }
  </style>
</head>
<body>
  <div class="wrap">
    <h1>TOTP Debug <span class="tag">Asia/Jakarta (WIB)</span></h1>

    <div class="card">
      <div class="muted">Waktu lokal (Asia/Jakarta)</div>
      <div><?= htmlspecialchars($serverLocal, ENT_QUOTES) ?> (UTC<?= htmlspecialchars($offsetWIB, ENT_QUOTES) ?>)</div>

      <div class="sep"></div>

      <div class="muted">Kode saat ini</div>
      <div class="code"><?= htmlspecialchars($currentCode, ENT_QUOTES) ?></div>

      <div class="muted" style="margin-top:8px;">Berganti dalam ~<?= (int)$remain ?> detik</div>

      <div class="sep"></div>

      <div class="muted">Jendela penerimaan server</div>
      <div>
        Menerima hingga <b><?= (int)($PAST_SECONDS / 60) ?></b> menit ke belakang
        dan <b><?= (int)($FUTURE_SECONDS / 30) ?></b> step ke depan.
      </div>
      <div class="muted" style="margin-top:6px;">
        (Samakan nilai ini dengan yang kamu pakai di <code>index.php</code> saat memanggil
        <code>totp_verify_long(...)</code>.)
      </div>
    </div>

    <div class="card">
      <div class="muted">Kode sekitar waktu sekarang (untuk inspeksi)</div>
      <table>
        <thead>
          <tr>
            <th>Offset</th>
            <th>Waktu (WIB)</th>
            <th>Kode</th>
            <th>Masih diterima?</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($codesAround as $row): ?>
            <?php $ok = ($row['ctr'] >= $pastCtr && $row['ctr'] <= $futCtr); ?>
            <tr>
              <td><?= htmlspecialchars($row['label'], ENT_QUOTES) ?></td>
              <td><?= htmlspecialchars($row['time'], ENT_QUOTES) ?></td>
              <td><code><?= htmlspecialchars($row['code'], ENT_QUOTES) ?></code></td>
              <td><?= $ok ? '<span class="ok">Ya</span>' : '<span class="warn">Tidak</span>' ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <div class="muted" style="margin-top:8px;">
        Catatan: baris <b>NOW</b> adalah step aktif saat ini.
      </div>
    </div>
  </div>
</body>
</html>
