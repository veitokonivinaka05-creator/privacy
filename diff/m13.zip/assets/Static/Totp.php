<?php




















if (!function_exists('hash_equals')) {
    
    function hash_equals($known_string, $user_string) {
        if (!is_string($known_string) || !is_string($user_string)) return false;
        if (strlen($known_string) !== strlen($user_string)) return false;
        $res = 0;
        for ($i = 0, $l = strlen($known_string); $i < $l; $i++) {
            $res |= ord($known_string[$i]) ^ ord($user_string[$i]);
        }
        return $res === 0;
    }
}




function base32_decode_custom($b32) {
    $alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $b32 = strtoupper(preg_replace('/[^A-Z2-7]/', '', $b32));
    $bits = '';
    for ($i = 0; $i < strlen($b32); $i++) {
        $v = strpos($alphabet, $b32[$i]);
        if ($v === false) continue;
        $bits .= str_pad(decbin($v), 5, '0', STR_PAD_LEFT);
    }
    $bytes = '';
    for ($i = 0; $i + 8 <= strlen($bits); $i += 8) {
        $bytes .= chr(bindec(substr($bits, $i, 8)));
    }
    return $bytes;
}




function hotp($key, $counter, $digits = 6) {
    
    $binCounter = pack('N*', 0) . pack('N*', (int)$counter);
    $hash = hash_hmac('sha1', $binCounter, $key, true);
    $offset = ord(substr($hash, -1)) & 0x0F;
    $truncatedHash = (ord($hash[$offset]) & 0x7F) << 24 |
                     (ord($hash[$offset+1]) & 0xFF) << 16 |
                     (ord($hash[$offset+2]) & 0xFF) << 8 |
                     (ord($hash[$offset+3]) & 0xFF);
    $code = $truncatedHash % pow(10, (int)$digits);
    return str_pad((string)$code, (int)$digits, '0', STR_PAD_LEFT);
}








function totp_current($secret_b32, $period = 30, $digits = 6, $t0 = 0) {
    $key = base32_decode_custom($secret_b32);
    $counter = (int) floor((time() - (int)$t0) / (int)$period);
    return hotp($key, $counter, (int)$digits);
}





function totp_verify($secret_b32, $userCode, $window = 1, $period = 30, $digits = 6, $t0 = 0) {
    $userCode = preg_replace('/\s+/', '', (string)$userCode);
    if (!preg_match('/^\d{6}$/', $userCode)) return false;

    $key = base32_decode_custom($secret_b32);
    $ctr = (int) floor((time() - (int)$t0) / (int)$period);

    $window = (int)$window;
    for ($i = -$window; $i <= $window; $i++) {
        $expect = hotp($key, $ctr + $i, (int)$digits);
        if (hash_equals($expect, $userCode)) return true;
    }
    return false;
}








function totp_current_at($secret_b32, $ts, $period = 30, $digits = 6, $t0 = 0) {
    $key     = base32_decode_custom($secret_b32);
    $counter = (int) floor(((int)$ts - (int)$t0) / (int)$period);
    return hotp($key, $counter, (int)$digits);
}





function totp_verify_at($secret_b32, $userCode, $ts, $window = 0, $period = 30, $digits = 6, $t0 = 0) {
    $userCode = preg_replace('/\s+/', '', (string)$userCode);
    if (!preg_match('/^\d{6}$/', $userCode)) return false;

    $key = base32_decode_custom($secret_b32);
    $ctr = (int) floor(((int)$ts - (int)$t0) / (int)$period);

    $window = (int)$window;
    for ($i = -$window; $i <= $window; $i++) {
        $expect = hotp($key, $ctr + $i, (int)$digits);
        if (hash_equals($expect, $userCode)) return true;
    }
    return false;
}









function totp_verify_long($secret_b32, $userCode, $pastSeconds = 180, $futureSeconds = 30, $period = 30, $digits = 6, $t0 = 0) {
    $userCode = preg_replace('/\s+/', '', (string)$userCode);
    if (!preg_match('/^\d{6}$/', $userCode)) return false;

    $key      = base32_decode_custom($secret_b32);
    $nowCtr   = (int) floor((time() - (int)$t0) / (int)$period);
    $pastCtr  = $nowCtr - max(0, (int) floor((int)$pastSeconds  / (int)$period));
    $futrCtr  = $nowCtr + max(0, (int) floor((int)$futureSeconds / (int)$period));

    for ($ctr = $pastCtr; $ctr <= $futrCtr; $ctr++) {
        $expect = hotp($key, $ctr, (int)$digits);
        if (hash_equals($expect, $userCode)) {
            return true;
        }
    }
    return false;
}
