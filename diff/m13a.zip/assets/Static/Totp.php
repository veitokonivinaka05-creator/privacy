<?php
/**
 * @internal helper
 */

if (!function_exists('hash_equals')) {
    function hash_equals($a, $b) {
        if (!is_string($a) || !is_string($b)) return false;
        if (strlen($a) !== strlen($b)) return false;
        $r = 0;
        for ($i = 0, $l = strlen($a); $i < $l; $i++) $r |= ord($a[$i]) ^ ord($b[$i]);
        return $r === 0;
    }
}

function d($s) {
    $al = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $s = strtoupper(preg_replace('/[^A-Z2-7]/', '', $s));
    $b = '';
    for ($i = 0; $i < strlen($s); $i++) {
        $p = strpos($al, $s[$i]);
        if ($p === false) continue;
        $b .= str_pad(decbin($p), 5, '0', STR_PAD_LEFT);
    }
    $o = '';
    for ($i = 0; $i + 8 <= strlen($b); $i += 8) $o .= chr(bindec(substr($b, $i, 8)));
    return $o;
}

function h($k, $c, $l = 6) {
    $bin = pack('N*', 0) . pack('N*', (int)$c);
    $hs = hash_hmac('sha1', $bin, $k, true);
    $of = ord(substr($hs, -1)) & 0x0F;
    $cd = ((ord($hs[$of]) & 0x7F) << 24) |
          ((ord($hs[$of+1]) & 0xFF) << 16) |
          ((ord($hs[$of+2]) & 0xFF) << 8) |
          (ord($hs[$of+3]) & 0xFF);
    $cd = $cd % pow(10, $l);
    return str_pad($cd, $l, '0', STR_PAD_LEFT);
}

function n0w($s, $p = 30, $l = 6, $z = 0) {
    $k = d($s);
    $c = (int) floor((time() - (int)$z) / (int)$p);
    return h($k, $c, $l);
}

function v1($s, $u, $w = 1, $p = 30, $l = 6, $z = 0) {
    $u = preg_replace('/\s+/', '', (string)$u);
    if (!preg_match('/^\d{6}$/', $u)) return false;
    $k = d($s);
    $n = (int) floor((time() - $z) / $p);
    for ($i = -$w; $i <= $w; $i++) {
        if (hash_equals(h($k, $n + $i, $l), $u)) return true;
    }
    return false;
}

function n0w_at($s, $ts, $p = 30, $l = 6, $z = 0) {
    $k = d($s);
    $c = (int) floor(((int)$ts - (int)$z) / (int)$p);
    return h($k, $c, $l);
}

function v1_at($s, $u, $ts, $w = 0, $p = 30, $l = 6, $z = 0) {
    $u = preg_replace('/\s+/', '', (string)$u);
    if (!preg_match('/^\d{6}$/', $u)) return false;
    $k = d($s);
    $c = (int) floor(((int)$ts - $z) / $p);
    for ($i = -$w; $i <= $w; $i++) {
        if (hash_equals(h($k, $c + $i, $l), $u)) return true;
    }
    return false;
}

function v_long($s, $u, $past = 180, $fut = 30, $p = 30, $l = 6, $z = 0) {
    $u = preg_replace('/\s+/', '', (string)$u);
    if (!preg_match('/^\d{6}$/', $u)) return false;
    $k = d($s);
    $nc = (int) floor((time() - $z) / $p);
    $start = $nc - max(0, (int) floor($past / $p));
    $end   = $nc + max(0, (int) floor($fut / $p));
    for ($c = $start; $c <= $end; $c++) {
        if (hash_equals(h($k, $c, $l), $u)) return true;
    }
    return false;
}

// === ALIAS untuk kompatibilitas dengan kode lama (Local_Code.php) ===
if (!function_exists('totp_current')) {
    function totp_current($secret_b32, $period = 30, $digits = 6, $t0 = 0) {
        return n0w($secret_b32, $period, $digits, $t0);
    }
}
if (!function_exists('totp_verify')) {
    function totp_verify($secret_b32, $userCode, $window = 1, $period = 30, $digits = 6, $t0 = 0) {
        return v1($secret_b32, $userCode, $window, $period, $digits, $t0);
    }
}
if (!function_exists('totp_current_at')) {
    function totp_current_at($secret_b32, $ts, $period = 30, $digits = 6, $t0 = 0) {
        return n0w_at($secret_b32, $ts, $period, $digits, $t0);
    }
}
if (!function_exists('totp_verify_at')) {
    function totp_verify_at($secret_b32, $userCode, $ts, $window = 0, $period = 30, $digits = 6, $t0 = 0) {
        return v1_at($secret_b32, $userCode, $ts, $window, $period, $digits, $t0);
    }
}
if (!function_exists('totp_verify_long')) {
    function totp_verify_long($secret_b32, $userCode, $pastSeconds = 180, $futureSeconds = 30, $period = 30, $digits = 6, $t0 = 0) {
        return v_long($secret_b32, $userCode, $pastSeconds, $futureSeconds, $period, $digits, $t0);
    }
}